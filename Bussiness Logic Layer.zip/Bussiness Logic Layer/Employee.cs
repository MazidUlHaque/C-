﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Data_Access_Layer;

namespace Bussiness_Logic_Layer
{
    public class Employee
    {
        EmployeeDataAccess da = new EmployeeDataAccess();
        public string Name { get; set; }
        public int ID { get; set; }
        public string Gender { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }
        public string RegisterDate { get; set; }
        public string Email { get; set; }
        public string DateOfBirth { get; set; }
        public string BloodGroup { get; set; }
        public byte[] Photo { get; set; }

        public void AddEmployee()
        {
            da.AddEmployee(this.Name,this.ID, this.Gender, this.Phone, this.Address, this.RegisterDate, this.Email, this.DateOfBirth, this.BloodGroup, this.Photo);
        }
        public void UpdateEmployee()
        {
            da.UpdateEmployee(this.Name,this.ID, this.Gender, this.Phone, this.Address, this.RegisterDate, this.Email, 
                                this.DateOfBirth, this.BloodGroup, this.Photo);

        }
        public void DeleteEmployee(int id)
        {
            da.DeleteEmployee(id);
        }
        public List<object> GetList()
        {
            return da.GetList();
        }
        public byte[] GetPhoto(int id)
        {
            return da.GetPhoto(id);
        }
        public List<object> SearchEmployee(string id)
        {
            return da.SearchEmployee(id);
        }
        public int GetLastEmployeeId()
        {
            return da.GetLastEmpId();
        }

        #region Employee Attendance
        public List<object> GetEmployeeListForAttendance()
        {
            return da.GetEmployeeListForAttendance();
        }
        public void AddInEmployeeAttendance(string i, string n, string d, int a)
        {
            da.AddInEmployeeAttendance(i, n, d, a);
        }
        public void UpdateInEmployeeAttendance(string i, string n, string d, int a)
        {
            da.UpdateInEmployeeAttendance(i, n, d, a);
        }

      
        public List<object> GetAttendance(string d)
        {
            return da.GetAttendance(d);
        }

        public List<object> SearchAttendanceByDate(string d)
        {
            return da.SearchAttendanceByDate(d);
        }

        #endregion
    }
}
