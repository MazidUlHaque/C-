﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Data_Access_Layer;

namespace Bussiness_Logic_Layer
{
    public class Student
    {
        StudentDataAccess da = new StudentDataAccess();

        public string Name { get; set; }
        public int AdmissionNumber { get; set; }
        public string Gender { get; set; }
        public string Department { get; set; }
        public int ID { get; set; }
        public string BloodGroup { get; set; }
        public string AdmissionDate { get; set; }
        public string DateOfBirth { get; set; }
        public string Class { get; set; }
        public string Password { get; set; }
        public string FatherName { get; set; }
        public string MotherName { get; set; }
        public string FatherOccupation { get; set; }
        public string MotherOccupation { get; set; }
        public string PhoneNumber { get; set; }
        public string Address { get; set; }
        public string Email { get; set; }
        public byte[] Photo { get; set; }

        public void AddStudent()
        {
            da.AddStudentToDB(this.AdmissionNumber,this.ID, this.AdmissionDate, this.BloodGroup, this.Class, this.DateOfBirth, this.Department,
                this.Email, this.FatherName, this.FatherOccupation, this.Gender, this.MotherName, this.MotherOccupation, this.Name, this.PhoneNumber, this.Photo,this.Address,this.Password);
        }

        public void UpdateStudent(int sid)
        {
            da.UpdateStudentToDB(this.AdmissionNumber, this.AdmissionDate, this.BloodGroup, this.Class, this.DateOfBirth, this.Department,
               this.Email, this.FatherName, this.FatherOccupation, this.Gender, this.MotherName, this.MotherOccupation, this.Name, this.PhoneNumber, this.Photo, this.Address,this.Password,sid);
       
        }
        public void DeleteStudent(int sid)
        {
            da.DeleteStudentFromDB(sid);
        }

        public List<object> SearchStudent(string sid)
        {
            return da.SearchStudentFromDB(sid);
        }

        public void PromoteStudent(string currentClassName,string promotedClassName)
        {
            da.PromoteStudents(currentClassName, promotedClassName);
        }

        public byte[] GetPhoto(int sOfId)
        {
            byte[] ap = da.GetPhotoOfStudent(sOfId);
            return ap;
        }
        public byte[] GetPhoto(string sOfId)
        {
            byte[] ap = da.GetPhotoOfStudent(sOfId);
            return ap;
        }

        public int GetLastStudentId()
        {
            return da.GetLastStudentID();
        }

        public List<object> GetList()
        {
            return da.GetList();
        }

        public List<object> SearchByClassName(string str)
        {
            return da.SearchByClassName(str);
        }
        public bool CheckUser(string uid, string pass)
        {
            return da.CheckUser(uid, pass);
        }
        public bool CheckUser(string uid)
        {
            return da.CheckUser(uid);
        }

        public List<string> GetStudentIdList(string classn,string dept)
        {
            return da.StudentIdList(classn, dept);
        }
        public List<object> GetListByClass(string className, string dept)
        {
            return da.GetListByClass(className, dept);
        }

        public string ClassName(string sId)
        {
            return da.ClassName(sId);
        }
        public string DepartmentName(string sId)
        {
            return da.DepartmentName(sId);
        }

        public void UpdatePassword(string i, string p)
        {
            da.UpdatePassword(i,p);
        }
        public string GetEmail(string uid)
        {
            return da.GetEmail(uid);
        }
    }
}
