﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Data_Access_Layer;

namespace Bussiness_Logic_Layer
{
    public class Exam
    {
        ExamDataAccess da = new ExamDataAccess();        
        public string Name { get;set;}
        public string Subject { get; set; }
        public string Class { get; set; }
        public string Date { get; set; }
        public string TeacherId { get; set; }
        public string Department { get; set; }

        public Exam(string id)
        {
            Teacher t = new Teacher();
            this.Subject = t.GetSubjectName(id);
            this.Department = t.GetDepartment(id);
        }
        public Exam() { }

        public void AddExam() 
        {
            da.AddExam(this.Name, this.Class,this.Subject, this.Date, this.TeacherId,this.Department); 
        }
        public void UpdateExam(int id)
        {
            da.UpdateExam(this.Name,this.Class, this.Subject, this.Date, this.TeacherId,this.Department,id);
        }
        public List<object> SearchByName(string str,string tid)
        {
            return da.SearchExamByName(str, tid);
        }
        public List<object> GetList(string tid)
        {
            return da.GetList(tid);
        }

        public void DeleteExam(string tid, int examid)
        {
            da.DeleteExam(tid, examid);
        }

        public int GetLastId()
        {
            return da.GetLastID();
        }
        public List<object> GetListForStudent(string className)
        {
            return da.GetListForStudent(className);
        }

        public string GetExamName(int i)
        {
            return da.GetExamName(i);
        }
        public string GetTeacherName(int i)
        {
            return da.GetTeacherName(i);
        }
        public string GetSubjectName(int i)
        {
            return da.GetSubjectName(i);
        }

        public void AddTermExam(string termDate, string Subject, string ClassName,string department)
        {
            da.AddTermExam(termDate, Subject, ClassName, department);
        }

        public void UpdateTermExam(string termDate, string Subject, string ClassName, string dept, int i)
        {
            da.UpdateTermExam(termDate, Subject, ClassName, dept ,i);
        }
        public void DeleteTermExam(int i)
        {
            da.DeleteTermExam(i);
        }
        public List<object> GetTermExamList()
        {
            return da.GetTermExamList();
        }

        public List<object> GetTermExamListForTeacher(string uid)
        {
            Teacher t = new Teacher();
            string[] classNa = t.GetClasses(uid);
            return da.GetTermExamListForTeacher(classNa, t.GetSubjectName(uid) ,t.GetDepartment(uid));
        }

        //term Exam Marks
        public void AddDataForTermExamMark(string className, string dept, string Tid, int ExamID, string Subject)
        {

            da.AddDataForTermExamMark(className, dept, Tid, ExamID, Subject);
        }

        public List<object> GetMarksList(int eid)
        {
            return da.GetMarksList(eid);
        }
        public void AddMark(string si ,float m)
        {
            da.AddMark(si, m);
        }

        public List<object> GetTermExamListForStudents(string sid)
        {
            return da.GetTermExamListForStudents(sid);
        }
        public List<object> GetTermExamMarksForStudents(string sid,int eid)
        {
            return da.GetTermExamMarksForStudents(sid,eid);
        }
    }
}
