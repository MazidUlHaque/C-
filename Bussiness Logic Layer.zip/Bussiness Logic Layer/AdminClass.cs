﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Data_Access_Layer;

namespace Bussiness_Logic_Layer
{
    public class AdminClass
    {
        AdminDataAccess da = new AdminDataAccess();
        public string Name { get; set; }
        public string Gender { get; set; }
        public string Password { get; set; }
        public string Address { get; set; }
        public string RegisterDate { get; set; }
        public string BloodGroup { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string DOB { get; set; }
        public byte[] Photo { get; set; }

        public void AddAdmin()
        {
            da.AddAdmin(this.Name, this.Gender, this.Password, this.Address, this.RegisterDate, this.BloodGroup, this.Email,
                            this.Phone, this.DOB, this.Photo);
        }
        public void UpdateAdmin(string ID)
        {
            da.UpdateAdmin(this.Name, this.Gender, this.Password, this.Address, this.RegisterDate, this.BloodGroup, this.Email,
                            this.Phone, this.DOB, this.Photo,ID);
        }
        public void DeleteAdmin(string ID)
        {
            da.DeleteAdmin(ID);
        }
        public List<object> GetList()
        {
            return da.GetList();
        }
        public List<object> SearchAdmin(string ID)
        {
            return da.SearchAdmin(ID);
        }
        public byte[] GetPhoto(string ID)
        {
            return da.GetPhoto(ID);
        }
        public int GetLastID()
        {
            return da.GetLastID();
        }
        public bool CheckUser(string uid, string pass)
        {
            return da.CheckUser(uid, pass);
        }
        public bool CheckUser(string uid)
        {
            return da.CheckUser(uid);
        }
        public string GetEmail(string uid)
        {
            return da.GetEmail(uid);
        }
        public void UpdatePassword(string uid, string p)
        {
            da.UpdatePassword(uid, p);
        }
    }
}
