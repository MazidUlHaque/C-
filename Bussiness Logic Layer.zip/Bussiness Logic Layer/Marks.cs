﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Data_Access_Layer;

namespace Bussiness_Logic_Layer
{
    public class Marks
    {
        MarksDataAccess da = new MarksDataAccess();

        public void AddInMarksTable(int examId,string className,string departmentName)
        {
            List<string> o = new List<string>();
            Student stu = new Student();
            o = stu.GetStudentIdList(className, departmentName);
            foreach (string s in o)
            {
                da.AddMarksInTable(examId, s);
            }
        }

        public List<object> GetList(int examId)
        {
            return da.GetList(examId);
        }

        public void SetMark(int examId, string sid, float m)
        {
            da.SetMark(examId, sid, m);
        }

        public List<object> GetMarks(int i,string uid)
        {
            Exam ex = new Exam();
            Teacher t = new Teacher();
            return da.GetMarks(i, ex.GetExamName(i), ex.GetSubjectName(i), t.GetTeacherName(ex.GetTeacherName(i)), uid);
        }

    }
}
