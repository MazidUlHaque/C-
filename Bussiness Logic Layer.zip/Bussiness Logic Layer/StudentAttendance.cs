﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Data_Access_Layer;

namespace Bussiness_Logic_Layer
{
    public class StudentAttendance
    {
        StudentAttendanceDataAccess da = new StudentAttendanceDataAccess();
        public List<object> GetStudentList(string className,string tid)
        {
            Teacher t = new Teacher();
            string dept = t.GetDepartment(tid);
            Student s = new Student();
            return s.GetListByClass(className, dept);
        }

        public void AddStu(string Name,string id,int p,string className,string Tid)
        {
            Teacher t = new Teacher();
            da.ADD(Name, id, p,className,t.GetDepartment(Tid),Tid);
        }

        public List<object> GetListByDate(string dat,string className,string tid)
        {
            Teacher t = new Teacher();

            return da.GetListByDate(dat,className,t.GetDepartment(tid),tid);
        }
        public List<object> GetAttendanceListByDate(string dat, string className, string tid)
        {
            Teacher t = new Teacher();
            return da.GetAttendanceListByDate(dat, className, t.GetDepartment(tid),tid);
        }

        public void Update(string dat, string className, string tid, int p)
        {
            Teacher t = new Teacher();
            da.Update(dat, className, t.GetDepartment(tid), tid,p);

        }

    }
}
