﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Data_Access_Layer;

namespace Bussiness_Logic_Layer
{
    public class Teacher
    {
        TeacherDataAccess da = new TeacherDataAccess();

        public string Name { get; set; }
        public int ID { get; set; }
        public string Gender { get; set; }
        public string Password { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string DateOfBirth { get; set; }
        public string RegisterDate { get; set; }
        public string Subject { get; set; }
        public string Department { get; set; }
        public string Address { get; set; }
        public string BloodGroup { get; set; }
        public byte[] Photo { get; set; }
        public bool Nursary { get; set; }
        public bool STD1{get;set;}
        public bool STD2 { get; set; }
        public bool STD3 { get; set; }
        public bool STD4 { get; set; }
        public bool STD5 { get; set; }
        public bool STD6 { get; set; }
        public bool STD7 { get; set; }
        public bool STD8 { get; set; }
        public bool STD9 { get; set; }
        public bool STD10 { get; set; }

        public void AddTeacher() 
        {
            da.AddTeacher(this.Name,this.ID, this.Gender, this.Password, this.Email, this.Phone, this.DateOfBirth,this.RegisterDate,this.Address, this.Subject,
                                this.Department, this.BloodGroup, this.Nursary, this.STD1, this.STD2, this.STD3, this.STD4, this.STD5,
                                this.STD6, this.STD7, this.STD8, this.STD9, this.STD10, this.Photo);
        }
        public void UpdateTeacher(int id)
        {
            da.UpdateTeacher(this.Name,this.ID, this.Gender, this.Password, this.Email, this.Phone, this.DateOfBirth,this.Address, this.Subject,
                                this.Department, this.BloodGroup, this.Nursary, this.STD1, this.STD2, this.STD3, this.STD4, this.STD5,
                                this.STD6, this.STD7, this.STD8, this.STD9, this.STD10, id, this.Photo);
        }
        public List<object> GetList()
        {
            return da.GetList();
        }
        public List<object> GetListForProfile(string uid)
        {
            return da.GetListForProfile(uid);
        }
        public void DeleteTeacher(int id)
        {
            da.DeleteTeacher(id);
        }
        public List<object> SearchTeacher(string id)
        {
           return da.SearchTeacher(id);
        }
        public int LastTeacherID()
        {
            return da.LastTeacherID();
        }

        public byte[] GetPhoto(int id)
        {
            return da.GetPhotoOfTeacher(id);
        }
        public bool CheckUser(string uid, string pass)
        {
            return da.CheckUser(uid, pass);
        }
        public bool CheckUser(string uid)
        {
            return da.CheckUser(uid);
        }
        public string GetEmail(string uid)
        {
            return da.GetEmail(uid);
        }

        public string GetDepartment(string uid, string pass)
        {
           return da.GetDepartment(uid, pass);
        }
        public string GetDepartment(string uid)
        {
            return da.GetDepartment(uid);
        }
        public string[] GetClasses(string uid, string pass)
        {
            return da.GetClasses(uid, pass);
        }
        public string[] GetClasses(string uid)
        {
            return da.GetClasses(uid);
        }
        public string GetSubjectName(string tid)
        {
            return da.GetSubjectName(tid);
        }
        public string GetTeacherName(string tid)
        {
            return da.GetTeacherName(tid);
        }

        public void UpdatePassword(string i, string p)
        {
            da.UpdatePassWord(i, p);
        }
        public byte[] GetPhotoOfTeacher(string i)
        {
            return da.GetPhotoOfTeacher(i);
        }

    }
}
