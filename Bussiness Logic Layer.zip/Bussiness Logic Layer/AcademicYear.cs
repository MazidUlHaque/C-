﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Data_Access_Layer;

namespace Bussiness_Logic_Layer
{
    public class AcademicYear
    {
        AcademicYearDataAccess da = new AcademicYearDataAccess();
        public string Year { get; set; }
        public void AddAcademicYear(string str)
        {
            da.AddAcademicYear(str);
        }

        public List<object> GetList()
        {
            return da.GetAcademicYearList();
        }

        public void UpdateYear(int id,string str)
        {
            da.UpdateYear(id, str);
        }
        public void Delete(int id)
        {
            da.DeleteYear(id);
        }
    }
}
