﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookShopManSystem
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void loginButton_Click(object sender, EventArgs e)
        {
            string query = "select * from UserInfo where UserID =" + userTB.Text + "AND Password='" + passTB.Text+"'";
            string myConnectionString = ConfigurationManager.ConnectionStrings["BookShopManDB"].ConnectionString.ToString();
            SqlConnection myConnection = new SqlConnection(myConnectionString);
            myConnection.Open();
            SqlCommand myCommand = new SqlCommand(query, myConnection);
            SqlDataReader dr = myCommand.ExecuteReader();

            if (dr.HasRows)
            {
                MessageBox.Show("Done !!!");

                Home h = new Home();
                h.Visible = true;
                this.Visible = false;
            }
            else
            {
                MessageBox.Show("Not Done !!!");
            }
            myConnection.Close();
        }
    }
}
