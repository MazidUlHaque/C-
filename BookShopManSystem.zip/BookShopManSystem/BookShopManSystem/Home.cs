﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookShopManSystem
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void loadData_Click(object sender, EventArgs e)
        {
            string query = "select * from UserInfo";
            string myConnectionString = ConfigurationManager.ConnectionStrings["BookShopManDB"].ConnectionString.ToString();
            SqlConnection myConnection = new SqlConnection(myConnectionString);
            myConnection.Open();
            SqlCommand myCommand = new SqlCommand(query, myConnection);
            SqlDataReader dr = myCommand.ExecuteReader();

            if (dr.HasRows)
            {
                DataTable dt = new DataTable();
                dt.Load(dr);
                userTableGridView.DataSource = dt;
            }
            myConnection.Close();
        }

        private void insertData_Click(object sender, EventArgs e)
        {
            string query = "insert into UserInfo values ('"+nameTB.Text+"','"+passTB.Text+"',"+typeTB.Text+")";
            string myConnectionString = ConfigurationManager.ConnectionStrings["BookShopManDB"].ConnectionString.ToString();
            SqlConnection myConnection = new SqlConnection(myConnectionString);
            myConnection.Open();
            SqlCommand myCommand = new SqlCommand(query, myConnection);
            myCommand.ExecuteNonQuery();
            MessageBox.Show("Insert Done");
            myConnection.Close();
        }

        private void updateData_Click(object sender, EventArgs e)
        {
            string myConnectionString = ConfigurationManager.ConnectionStrings["BookShopManDB"].ConnectionString.ToString();
            SqlConnection myConnection = new SqlConnection(myConnectionString);
            myConnection.Open();
            if (nameTB.Text != "")
            {
                string query = "update UserInfo set UserName='" + nameTB.Text + "'where UserID="+idTB.Text;
                SqlCommand myCommand = new SqlCommand(query, myConnection);
                myCommand.ExecuteNonQuery();
            }
            if (passTB.Text != "")
            {
                string query = "update UserInfo set Password='" + passTB.Text + "'where UserID=" + idTB.Text;
                SqlCommand myCommand = new SqlCommand(query, myConnection);
                myCommand.ExecuteNonQuery();
            }
            if (typeTB.Text != "")
            {
                string query = "update UserInfo set Type='" + typeTB.Text + "'where UserID=" + idTB.Text;
                SqlCommand myCommand = new SqlCommand(query, myConnection);
                myCommand.ExecuteNonQuery();
            }
            MessageBox.Show("Update Done");
        }

        private void deleteData_Click(object sender, EventArgs e)
        {
            string query = "delete from UserInfo where UserId="+idTB.Text;
            string myConnectionString = ConfigurationManager.ConnectionStrings["BookShopManDB"].ConnectionString.ToString();
            SqlConnection myConnection = new SqlConnection(myConnectionString);
            myConnection.Open();
            SqlCommand myCommand = new SqlCommand(query, myConnection);
            myCommand.ExecuteNonQuery();
            MessageBox.Show("Delete Done");
        }

        private void backButton_Click(object sender, EventArgs e)
        {
            LoginForm lf = new LoginForm();
            lf.Visible = true;
            this.Visible = false;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
