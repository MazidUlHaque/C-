﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            List <string>l1 = new List<string>();
            List<int> l2 = new List<int>();
            List<object> l3 = new List<object>();

            Int32 a1 = new Int32();
            a1=20;
            Double d1 = new Double();
            d1 = 30.6;

            l2.Add(6);
            l2.Add(10);
            l2.Add(15);
            l2.Add(10);

            foreach(int i in l2)
                Console.WriteLine(i);

            l3.Add(a1);
            l3.Add(d1);

            foreach (object o in l3)
                Console.WriteLine(o);

            Console.WriteLine(l3.Count);
            l2.Insert(0,100);
            foreach (int i in l2)
                Console.WriteLine(i);

            Console.WriteLine(l2.LastIndexOf(10));
            Console.WriteLine(l2.Max());

            //l2.RemoveAll(10);
            foreach (int i in l2)
                Console.WriteLine(i);

            l2.Clear();
            Console.WriteLine("After Clear: ");
            foreach (int i in l2)
                Console.WriteLine(i);

          //  Console.WriteLine(l3.Capacity);
        }
    }
}
