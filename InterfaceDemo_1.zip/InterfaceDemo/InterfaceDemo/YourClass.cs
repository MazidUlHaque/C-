﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceDemo
{
    abstract class YourClass : IMyInterface, IYourInterface
    {
        protected int y;

        public void setY(int y) { this.y = y; }

        public  void show() 
        { 
            Console.WriteLine("show: "+y);
        }
        public abstract void print();
    }
}
