﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyFormIntro
{
    public partial class Form1 : Form
    {
        private Label title, userLabel, passLabel;
        private TextBox userTB, passTB;
        private Button loginButton, exitButton;
        public Form1()
        {
            InitializeComponent();
            this.Size = new Size(800,450);
            this.Text = "My Form Introduction";
            this.BackColor = Color.LimeGreen;

            title = new Label();
            title.Text = "A  I  U  B";
            title.Location = new Point(200,100);
            title.Size = new Size(200, 40);
            title.Font = new Font("Comic Sans MS", 16, FontStyle.Bold);
            title.ForeColor = Color.Red;
            title.BackColor = Color.LawnGreen;
            this.Controls.Add(title);

            userTB = new TextBox();
            userTB.Location = new Point(350, 150);
            userTB.Size = new Size(200, 40);
            this.Controls.Add(userTB);

            passTB = new TextBox();
            passTB.Location = new Point(350, 220);
            passTB.Size = new Size(200, 40);
            passTB.PasswordChar = '$';
            this.Controls.Add(passTB);

            loginButton = new Button();
            loginButton.Text = "Login";
            loginButton.Location = new Point(250, 300);
            loginButton.Size = new Size(80, 30);
            loginButton.Click += loginButton_Click;
            loginButton.MouseEnter += loginButton_MouseEnter;
            loginButton.MouseLeave += loginButton_MouseLeave;
            this.Controls.Add(loginButton);

            exitButton = new Button();
            exitButton.Text = "Exit";
            exitButton.Location = new Point(350, 300);
            exitButton.Size = new Size(80, 30);
            exitButton.Click += exitButton_Click;
            this.Controls.Add(exitButton);

        }

        void loginButton_MouseLeave(object sender, EventArgs e)
        {
            loginButton.BackColor = Color.White;
        }

        void loginButton_MouseEnter(object sender, EventArgs e)
        {
            loginButton.BackColor = Color.Blue;
        }

        void exitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        void loginButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("User: "+userTB.Text+"\nPassword: "+passTB.Text);
        }
    }
}
