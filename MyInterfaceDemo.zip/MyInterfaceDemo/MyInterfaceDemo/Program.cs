﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyInterfaceDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            MyClass m = new MyClass();
            m.show();
            InterfaceA a = m;
            a.show();
            InterfaceB b = m;
            b.show();

            ((InterfaceA)m).show();
            ((InterfaceB)m).show();
            m.show();
        }
    }
}
