﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyInterfaceDemo
{
    public class MyClass : InterfaceA, InterfaceB
    {
        private int x;

        public MyClass() { Console.WriteLine("Empty-MyClass"); }
        public MyClass(int x)
        {
            Console.WriteLine("Para-MyClass");
            this.x = x;
        }
        public void show()
        {
            Console.WriteLine("show-MyClass");
        }
        void InterfaceA.show()
        {
            Console.WriteLine("show-InterfaceA");
        }
        void InterfaceB.show()
        {
            Console.WriteLine("show-InterfaceB");
        }

    }
}
