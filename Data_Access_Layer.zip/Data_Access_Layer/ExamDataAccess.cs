﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Access_Layer
{
    public class ExamDataAccess
    {
         ExamDBDataContext edc = new ExamDBDataContext(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\Taha\Documents\Visual_Studio_2012\Projects\Projectwork111\Data_Access_Layer\StudentData.mdf;Integrated Security=True;Connect Timeout=30");
         public void AddExam(string Name,string Class,string Subject,string Date,string TeacherId,string Department)
         {
             ExamTable et = new ExamTable();
             et.name = Name;
             et.subject = Subject;
             et.department = Department;
             et.@class = Class;
             et.date = Convert.ToDateTime(Date);
             et.teacherID = TeacherId;
             et.Id = Convert.ToInt32(GetLastID() + 1);

             edc.ExamTables.InsertOnSubmit(et);
             edc.SubmitChanges();
         }
         public void UpdateExam(string Name,string Class, string Subject, string Date, string TeacherId,string Department,int id)
         {
             var et = edc.ExamTables.Where(x => x.Id == id).FirstOrDefault();
             et.name = Name;
             et.department = Department;
             et.@class = Class;
             et.subject = Subject;
             et.date = Convert.ToDateTime(Date);
             et.teacherID = TeacherId;

             edc.SubmitChanges();
         }

         public int GetLastID()
         {
             try
             {
                 var x = from a in edc.ExamTables orderby a.Id descending select a;
                 return x.FirstOrDefault().Id;
             }
             catch (Exception ec) { return 0; }
         }
         public List<object> SearchExamByName(string str,string tid)
         {
             var x = from a in edc.ExamTables where a.name == str && a.teacherID == tid select new { a.Id,a.name,a.@class,a.subject,
                                                                                                    a.date,a.teacherID,a.department};
             List<object> o = new List<object>();
             o.AddRange(x.ToList());
             return o;
         }
         public List<object> GetList(string tid)
         {
             var x = from a in edc.ExamTables where a.teacherID == tid select new { a.Id, a.name, a.@class, a.subject, a.date, a.teacherID,a.department };
             List<object> o = new List<object>();
             o.AddRange(x.ToList());
             return o;
         }
         public void DeleteExam(string tid,int examid)
         {
             var x = from a in edc.ExamTables where a.Id == examid && a.teacherID == tid select a;
             edc.ExamTables.DeleteOnSubmit(x.FirstOrDefault());
             edc.SubmitChanges();
             MarksDataAccess da = new MarksDataAccess();
             da.DeleteForExamDeletion(examid);
         }

         public List<object> GetListForStudent(string className)
         {
                 var x = from a in edc.ExamTables where a.@class == className select new { Exam_Name=a.name,Date= a.date, Class=a.@class, Subject=a.subject, Teacher=a.teacherID, Exam_ID  =a.Id };
                 List<object> o = new List<object>();
                 o.AddRange(x.ToList());
                 return o;
             
         }
         public string GetExamName(int i)
         {
             var x = from a in edc.ExamTables where a.Id == i select new { a.name };
             return x.FirstOrDefault().name;
         }
         public string GetTeacherName(int i)
         {
             var x = from a in edc.ExamTables where a.Id == i select new { a.teacherID };
             return x.FirstOrDefault().teacherID;
         }
         public string GetSubjectName(int i)
         {
             var x = from a in edc.ExamTables where a.Id == i select new { a.subject };
             return x.FirstOrDefault().subject;
         }


        //term Exam
         public void AddTermExam(string Date,string Subject,string ClassName,string dept)
         {
             TermExamTable tt = new TermExamTable();
             try { tt.date = Convert.ToDateTime(Date); }
             catch (Exception ec) { tt.date = Convert.ToDateTime(Date); }
             tt.subject = Subject;
             tt.department = dept;
             tt.@class = ClassName;

             edc.TermExamTables.InsertOnSubmit(tt);
             edc.SubmitChanges();

             StudentDataAccess sda = new StudentDataAccess();
             string[] strarr = sda.GetStudentNamePerClass(ClassName, dept);
             string[] idarr = sda.GetStudentIDPerClass(ClassName, dept);
             int i = 0;
             foreach (string s in strarr)
             {
                 TermExamMarksTable ttm = new TermExamMarksTable();
                 ttm.studentName = s;
                 ttm.sid = idarr[i];
                 i++;
                 ttm.subject = Subject;
                 ttm.department = dept;
                 ttm.examId = GetLastExamId();
                 edc.TermExamMarksTables.InsertOnSubmit(ttm);
                 edc.SubmitChanges();
             }

         }
         public int GetLastExamId()
         {
             try{var x = from a in edc.TermExamTables orderby a.Id descending select new { a.Id };
             return x.FirstOrDefault().Id; }
             catch(Exception ec){return 1;}
             
         }

         public void UpdateTermExam(string Date, string Subject, string ClassName,string dept,int i)
         {
             var tt = edc.TermExamTables.Where(a => a.Id == i).FirstOrDefault();
             tt.date = Convert.ToDateTime(Date);
             tt.subject = Subject;
             tt.department = dept;
             tt.@class = ClassName;

             edc.SubmitChanges();
         }
         public void DeleteTermExam(int i)
         {
             var tt = edc.TermExamTables.Where(a => a.Id == i).FirstOrDefault();
             edc.TermExamTables.DeleteOnSubmit(tt);
             edc.SubmitChanges();
             var tt2 = from a in edc.TermExamMarksTables where a.examId == i select a;
             edc.TermExamMarksTables.DeleteAllOnSubmit(tt2);
             edc.SubmitChanges();
         }
         public List<object> GetTermExamList()
         {
             var x = from a in edc.TermExamTables select new { a.Id,a.date,a.subject,a.@class,a.department};
             List<object> o = new List<object>();
             o.AddRange(x.ToList());
             return o;
         }

         public List<object> GetTermExamListForTeacher(string[] classes, string Subject,string dept)
         {
             List<object> o = new List<object>();
             foreach (string s in classes)
             {
                 var x = from a in edc.TermExamTables where a.subject == Subject && a.@class == s select new { a.Id, a.date, a.@class, a.subject, a.department };
                 o.AddRange(x.ToList());
             }
             return o;
         }

        //term Exam Marks
         public void AddDataForTermExamMark(string className,string dept,string Tid,int ExamID,string Subject)
         {
             
             
         }

         public List<object> GetMarksList(int eid)
         {
             var x = from a in edc.TermExamMarksTables where a.examId == eid select new { a.studentName,StudentID=a.sid, a.subject, a.department, a.examId, a.marks };
             List<object> o = new List<object>();
             o.AddRange(x.ToList());
             return o;
         }

         public void AddMark(string si,float m)
         {
             TermExamMarksTable x = edc.TermExamMarksTables.Where(a => a.sid == si ).FirstOrDefault();
             x.marks = m;
             edc.SubmitChanges();
         }

         public List<object> GetTermExamListForStudents(string sid)
         {
             StudentDataAccess sda = new StudentDataAccess();
             var x = from a in edc.TermExamTables where a.department == sda.DepartmentName(sid) && a.@class==sda.ClassName(sid) 
                     select new {a.Id,a.date,a.@class,a.department};
             List<object> o = new List<object>();
             o.AddRange(x.ToList());
             return o;
         }
         public List<object> GetTermExamMarksForStudents(string sid,int eid)
         {
             StudentDataAccess sda = new StudentDataAccess();
             var x = from a in edc.TermExamMarksTables
                     where a.sid==sid && a.examId==eid
                     select new { Name=a.studentName,ID = a.sid,a.subject,a.department,a.marks,a.examId };
             List<object> o = new List<object>();
             o.AddRange(x.ToList());
             return o;
         }

    }
}
