﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Access_Layer
{
    public class EmployeeDataAccess
    {
        EmployeeDBDataContext edc = new EmployeeDBDataContext(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\Taha\Documents\Visual_Studio_2012\Projects\Projectwork111\Data_Access_Layer\StudentData.mdf;Integrated Security=True;Connect Timeout=30");

        public void AddEmployee(string Name,int ID,string Gender,string Phone,string Address,string RegisterDate,string Email,string DateOfBirth
                                ,string BloodGroup,byte[] Photo)
        {
            EmployeeTable et = new EmployeeTable();
            et.name = Name;
            et.gender = Gender;
            et.phone = Phone;
            et.address = Address;
            et.registerDate = Convert.ToDateTime(RegisterDate);
            et.email = Email;
            et.dateOfBirth = Convert.ToDateTime(DateOfBirth);
            et.bloodGroup = BloodGroup;
            et.photo = Photo;
            et.empId = ID;
            et.id = "E-" + ID.ToString();

            edc.EmployeeTables.InsertOnSubmit(et);
            edc.SubmitChanges();
        }
        public void UpdateEmployee(string Name,int ID, string Gender, string Phone, string Address, string RegisterDate, string Email, string DateOfBirth
                                , string BloodGroup, byte[] Photo)
        {
            var et = edc.EmployeeTables.Where(x => x.empId == ID).FirstOrDefault();
            et.name = Name;
            et.gender = Gender;
            et.phone = Phone;
            et.address = Address;
            et.registerDate = Convert.ToDateTime(RegisterDate);
            et.email = Email;
            et.dateOfBirth = Convert.ToDateTime(DateOfBirth);
            et.bloodGroup = BloodGroup;
            et.photo = Photo;
            et.id = "E-" + ID.ToString();

            edc.SubmitChanges();
        }

        public void DeleteEmployee(int id)
        {
            var et = edc.EmployeeTables.Where(x => x.empId == id).FirstOrDefault();
            edc.EmployeeTables.DeleteOnSubmit(et);
            edc.SubmitChanges();
        }

        public List<object> GetList()
        {
            var x = from a in edc.EmployeeTables select new { a.id,a.name,a.gender,a.phone,a.address,a.registerDate,a.dateOfBirth,a.bloodGroup,
                                                                a.email};
            List<object> o = new List<object>();
            o.AddRange(x.ToList());
            return o;
        }
        public byte[] GetPhoto(int id)
        {
            var x = from a in edc.EmployeeTables where a.empId==id select new { a.photo };
            return (byte[])x.FirstOrDefault().photo.ToArray();
        }
        public byte[] GetPhoto(string i)
        {
            var x = from a in edc.EmployeeTables where a.id==i select new { a.photo };
            return (byte[])x.FirstOrDefault().photo.ToArray();
        }
        public List<object> SearchEmployee(string id)
        {
            var x = from a in edc.EmployeeTables where a.id==id select new { a.id,a.name,a.gender,a.phone,a.address,a.registerDate,a.dateOfBirth,a.bloodGroup,
                                                                a.email};
            List<object> o = new List<object>();
            o.AddRange(x.ToList());
            return o;
        }

        public int GetLastEmpId()
        {
            try
            {
                var x = from a in edc.EmployeeTables orderby a.empId descending select new { a.empId };
                return x.FirstOrDefault().empId;
            }
            catch (Exception ec) {  return 1000; }
        }

        #region Employee Attendance
        public List<object> GetEmployeeListForAttendance()
        {
            var x = from a in edc.EmployeeTables select new { a.id, a.name };
            List<object> o = new List<object>();
            o.AddRange(x.ToList());
            return o;
        }
        public void AddInEmployeeAttendance(string i,string n,string d,int a)
        {
            EmployeeAttendanceTable et = new EmployeeAttendanceTable();
            et.empId = i;
            et.empName = n;
            et.date = Convert.ToDateTime(d);
            et.attendance = a;
            edc.EmployeeAttendanceTables.InsertOnSubmit(et);
            edc.SubmitChanges();
        }
        public void UpdateInEmployeeAttendance(string i, string n, string d, int a)
        {
            var et = edc.EmployeeAttendanceTables.Where(x => x.empId == i && x.empName == n && x.date == Convert.ToDateTime(d)).FirstOrDefault();
            et.empId = i;
            et.empName = n;
            et.date = Convert.ToDateTime(d);
            et.attendance = a;
            edc.SubmitChanges();
        }

        
        public List<object> GetAttendance(string d)
        {
            var x = from a in edc.EmployeeAttendanceTables where a.date==Convert.ToDateTime(d) select new { a.attendance };
            List<object> o = new List<object>();
            o.AddRange(x.ToList());
            return o;
        }

        public List<object> SearchAttendanceByDate(string d)
        {
            var x = from a in edc.EmployeeAttendanceTables where a.date==Convert.ToDateTime(d) select new { a.empId,a.empName,a.date };
            List<object> o = new List<object>();
            o.AddRange(x.ToList());
            return o;
        }

        #endregion
    }
}
