﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;


namespace Data_Access_Layer
{
    public  class StudentDataAccess
    {
       static StudentDBDataContext sdc = new StudentDBDataContext(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\Taha\documents\visual_studio_2012\Projects\Projectwork111\Data_Access_Layer\StudentData.mdf;Integrated Security=True;Connect Timeout=30");

        public void AddStudentToDB(int AdmissionNumber,int ID, string AdmissionDate, string BloodGroup, string Class,string DateOfBirth,
            string Department,string Email,string FatherName,string FatherOccupation,string Gender,string MotherName,
            string MotherOccupation, string Name, string PhoneNumber,byte[] Photo,string Address,string Password)
        {
            StudentTable s = new StudentTable();
            s.admissionNumber = AdmissionNumber;
            s.admissionDate = Convert.ToDateTime(AdmissionDate);
            s.bloodgroup = BloodGroup;
            s.@class = Class;
            s.dateOfBirth = Convert.ToDateTime(DateOfBirth);
            s.department = Department;
            s.email = Email;
            s.id = "S-" + ID.ToString();
            s.StudentId = ID;
            s.fatherName = FatherName;
            s.fatherOccupation = FatherOccupation;
            s.gender = Gender;
            s.motherName = MotherName;
            s.motherOccupation =MotherOccupation;
            s.name = Name;
            s.phone = PhoneNumber;
            s.address = Address;
            s.photo = Photo;
            s.password = Password;
            sdc.StudentTables.InsertOnSubmit(s);
            sdc.SubmitChanges();

        }

        public byte[] GetPhotoOfStudent(int sid)
        {
            var x = from a in sdc.StudentTables where a.StudentId == sid select new { a.photo };
            return (byte[])x.FirstOrDefault().photo.ToArray();
        }

        public byte[] GetPhotoOfStudent(string sid)
        {
            var x = from a in sdc.StudentTables where a.id == sid select new { a.photo };
            return (byte[])x.FirstOrDefault().photo.ToArray();
        }

        public void UpdateStudentToDB(int AdmissionNumber, string AdmissionDate, string BloodGroup, string Class, string DateOfBirth,
            string Department, string Email, string FatherName, string FatherOccupation, string Gender, string MotherName,
            string MotherOccupation, string Name, string PhoneNumber, byte[] Photo, string Address,string Password,int sid)
        {
            var s = sdc.StudentTables.Where(w => w.StudentId == sid).FirstOrDefault();

            s.admissionNumber = AdmissionNumber;
            s.admissionDate = Convert.ToDateTime(AdmissionDate);
            s.bloodgroup = BloodGroup;
            s.@class = Class;
            s.dateOfBirth = Convert.ToDateTime(DateOfBirth);
            s.department = Department;
            s.email = Email;
            s.fatherName = FatherName;
            s.fatherOccupation = FatherOccupation;
            s.gender = Gender;
            s.motherName = MotherName;
            s.motherOccupation = MotherOccupation;
            s.name = Name;
            s.phone = PhoneNumber;
            s.address = Address;
            s.photo = Photo;
            s.password = Password;

            sdc.SubmitChanges();

        }
        public void DeleteStudentFromDB(int sid)
        {
            var s = sdc.StudentTables.Where(w => w.StudentId == sid).FirstOrDefault();
            sdc.StudentTables.DeleteOnSubmit(s);
            sdc.SubmitChanges();
        }

        public List<object> SearchStudentFromDB(string sid)
        {
            var s = from a in sdc.StudentTables where a.id==sid select new {a.id,a.admissionNumber,a.name,a.fatherName,a.motherName,
                                    a.fatherOccupation,a.motherOccupation,a.phone,a.email
                                 ,a.bloodgroup,a.gender,a.@class,a.admissionDate,a.dateOfBirth,a.department,a.address,a.password};
            List<object> o = new List<object>();
            o.AddRange(s.ToList());
            return o;
        }

       

        public void PromoteStudents(string currentClass,string promoteClass)
        {

            foreach (StudentTable st in sdc.StudentTables.Where(X => X.@class == currentClass))
            {
                st.@class = promoteClass;
                sdc.SubmitChanges();

            }
        }

        public  int GetLastStudentID()
        {
            try
            {
                var x = from a in sdc.StudentTables orderby a.StudentId descending select new { a.StudentId };

                return Convert.ToInt32(x.FirstOrDefault().StudentId);
            }
            catch (Exception exc)
            {
                return 10000;
            }
        }

        public  List<object> GetList()
        {
             var x = from a in sdc.StudentTables select new {a.id,a.admissionNumber,a.name,a.fatherName,a.motherName,a.fatherOccupation,a.motherOccupation,a.phone,a.email
                                 ,a.bloodgroup,a.gender,a.@class,a.admissionDate,a.dateOfBirth,a.department,a.address,a.password};
            List<object> o = new List<object>();
            o.AddRange(x.ToList());
            return o;
        }


        public List<object> SearchByClassName(string str)
        {
            var x = from a in sdc.StudentTables where a.@class == str select new { a.id, a.name, a.@class };
            List<object> o = new List<object>();
            o.AddRange(x.ToList());
            return o;
        }

        public bool CheckUser(string uid, string pass)
        {
            bool status = false;
            foreach (StudentTable st in sdc.StudentTables)
            {
                if (st.id == uid && st.password == pass) { status = true; break; }
            }
            return status;
        }

        public List<string> StudentIdList(string className,string departmentName)
        {
            List<string> o = new List<string>();
            foreach (StudentTable st in sdc.StudentTables.Where(a=>a.@class == className && a.department == departmentName))
            {
                o.Add(st.id);
            }
            return o;
        }
        public List<object> GetListByClass(string className, string dept)
        {
            var x = from a in sdc.StudentTables where a.@class == className && a.department == dept select new { a.name, a.id };
            List<object> o = new List<object>();
            o.AddRange(x.ToList());
            return o;
        }

        public string ClassName(string sId)
        {
            var x = from a in sdc.StudentTables where a.id == sId select new { a.@class };
            return x.FirstOrDefault().@class;
        }

        public string DepartmentName(string sId)
        {
            var x = from a in sdc.StudentTables where a.id == sId select new { a.department };
            return x.FirstOrDefault().department;
        }

        public string[] GetStudentIDPerClass(string className,string dept)
        {
            var x = from a in sdc.StudentTables where a.@class == className && a.department == dept select new { a.StudentId };
            List<string> s = new List<string>();
            foreach (var x1 in x)
            {
                s.Add(x1.StudentId.ToString());
            }
            string[] arr = s.ToArray();
            return arr;
        }
        public string[] GetStudentNamePerClass(string className, string dept)
        {
            var x = from a in sdc.StudentTables where a.@class == className && a.department == dept select new { a.name };
            List<string> s = new List<string>();
            foreach (var x1 in x)
            {
                s.Add(x1.name.ToString());
            }
            string[] arr = s.ToArray();
            return arr;
        }

        public void UpdatePassword(string uid,string p)
        {
            var x = sdc.StudentTables.Where(a => a.id == uid).FirstOrDefault();
            x.password = p;
            sdc.SubmitChanges();
        }

        public bool CheckUser(string uid)
        {
            bool status = false;
            foreach (StudentTable st in sdc.StudentTables)
            {
                if (st.id == uid ) { status = true; break; }
            }
            return status;
        }
        public string GetEmail(string uid)
        {
            var x = sdc.StudentTables.Where(a => a.id == uid).FirstOrDefault();
            return x.email;
        }

    }
}
