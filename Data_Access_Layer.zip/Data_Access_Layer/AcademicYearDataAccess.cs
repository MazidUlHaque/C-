﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Access_Layer
{
    public class AcademicYearDataAccess
    {
        static AcademicYearDBDataContext adc = new AcademicYearDBDataContext(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\Taha\Documents\Visual_Studio_2012\Projects\Projectwork111\Data_Access_Layer\StudentData.mdf;Integrated Security=True;Connect Timeout=30");

        public void AddAcademicYear(string str)
        {
            //var x = from a in adc.AcademicYearTables select a;
            AcademicYearTable ac = new AcademicYearTable();
            ac.academicYear = str;
            adc.AcademicYearTables.InsertOnSubmit(ac);
            adc.SubmitChanges();
        }

        public List<object> GetAcademicYearList()
        {
            var x = from a in adc.AcademicYearTables orderby a.Id descending select a;
            List<object> o = new List<object>();
            o.AddRange(x.ToList());
            return o;
        }

        public void UpdateYear(int i,string str)
        {
            var x = from a in adc.AcademicYearTables where a.Id == i select a;
            x.FirstOrDefault().academicYear = str;
            adc.SubmitChanges();
        }

        public void DeleteYear(int i)
        {
            var x = from a in adc.AcademicYearTables where a.Id == i select a;
            adc.AcademicYearTables.DeleteOnSubmit(x.FirstOrDefault());
            adc.SubmitChanges();
        }
    }
}
