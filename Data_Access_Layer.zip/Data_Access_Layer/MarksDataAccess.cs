﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Access_Layer
{
    public class MarksDataAccess
    {
        MarksDBDataContext mdc = new MarksDBDataContext(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\Taha\Documents\Visual_Studio_2012\Projects\Projectwork111\Data_Access_Layer\StudentData.mdf;Integrated Security=True;Connect Timeout=30");

        public void AddMarksInTable(int ExamId, string stuId)
        {
            MarksTable mk = new MarksTable();
            mk.examId = ExamId;
            mk.studentId = stuId;

            mdc.MarksTables.InsertOnSubmit(mk);
            mdc.SubmitChanges();
        }

        public List<object> GetList(int ExamId)
        {
            var x = from a in mdc.MarksTables where a.examId == ExamId select new { a.examId,a.studentId,a.mark};
            List<object> o = new List<object>();
            o.AddRange(x.ToList());
            return o;
        }

        public void SetMark(int ExamId, string sid,float marks)
        {
            var x1 = mdc.MarksTables.Where(x => x.examId == ExamId && x.studentId == sid).FirstOrDefault();
            x1.mark = marks;
            mdc.SubmitChanges();
        }

        public List<object> GetMarks(int i,string examName,string subject,string teacher,string uid)
        {
            var x = from a in mdc.MarksTables where a.examId == i && a.studentId==uid select new { a.examId, examName, subject, a.mark, a.studentId, teacher };
            List<object> o = new List<object>();
            o.AddRange(x.ToList());
            return o;
        }

        public void DeleteForExamDeletion(int i)
        {
            var x = from a in mdc.MarksTables where a.examId==i select a;
            mdc.MarksTables.DeleteAllOnSubmit(x);
            mdc.SubmitChanges();
        }

    }
}
