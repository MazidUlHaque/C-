﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Access_Layer
{
    public class AdminDataAccess
    {
        AdminDBDataContext adc = new AdminDBDataContext(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\Taha\Documents\Visual_Studio_2012\Projects\Projectwork111\Data_Access_Layer\StudentData.mdf;Integrated Security=True;Connect Timeout=30");

        public void AddAdmin(string Name,string Gender,string Password,string Address,string RegisterDate,string BloodGroup
                                ,string Email,string Phone,string DOB,byte[] Photo)
        {
            AdminTable at = new AdminTable();
            at.Id = GetLastID() + 1;
            at.aid = "A-" + Convert.ToString(GetLastID() + 1);
            at.name = Name;
            at.gender = Gender;
            at.password = Password;
            at.address = Address;
            at.registerdate = Convert.ToDateTime(RegisterDate);
            at.bloodgroup = BloodGroup;
            at.email = Email;
            at.phone = Phone;
            at.dateofbirth = Convert.ToDateTime(DOB);
            at.photo = Photo;
            adc.AdminTables.InsertOnSubmit(at);
            adc.SubmitChanges();
        }
        public void UpdateAdmin(string Name, string Gender, string Password, string Address, string RegisterDate, string BloodGroup
                                , string Email, string Phone, string DOB, byte[] Photo,string ID)
        {
            var at = adc.AdminTables.Where(a => a.aid == ID).FirstOrDefault();
            at.aid = "A-" + Convert.ToString(GetLastID() + 1);
            at.name = Name;
            at.gender = Gender;
            at.password = Password;
            at.address = Address;
            at.registerdate = Convert.ToDateTime(RegisterDate);
            at.bloodgroup = BloodGroup;
            at.email = Email;
            at.phone = Phone;
            at.dateofbirth = Convert.ToDateTime(DOB);
            at.photo = Photo;
            adc.SubmitChanges();
        }

        public void DeleteAdmin(string ID)
        {
            var at = adc.AdminTables.Where(a => a.aid == ID).FirstOrDefault();
            adc.AdminTables.DeleteOnSubmit(at);
            adc.SubmitChanges();
        }
        public List<object> GetList()
        {
            var x = from a in adc.AdminTables select new {a.aid,a.name,a.gender,a.password,a.address,a.registerdate,a.bloodgroup,
                                                            a.email,a.phone,a.dateofbirth};
            List<object> o = new List<object>();
            o.AddRange(x.ToList());
            return o;
        }
        public List<object> SearchAdmin(string ID)
        {
            var x = from a in adc.AdminTables where a.aid==ID
                    select new
                    {a.aid,a.name,a.gender,a.password,a.address,a.registerdate,a.bloodgroup,a.email,a.phone,a.dateofbirth};
            List<object> o = new List<object>();
            o.AddRange(x.ToList());
            return o;
        }
        public byte[] GetPhoto(string ID)
        {
            var x = adc.AdminTables.Where(a => a.aid == ID).FirstOrDefault();
            return (byte[])x.photo.ToArray();
        }

        public int GetLastID()
        {
            try
            {
                var x = from a in adc.AdminTables orderby a.Id descending select new { a.Id };
                return x.FirstOrDefault().Id;
            }
            catch (Exception ec) { return 100; }
        }

        public bool CheckUser(string uid,string Pss)
        {
            bool status = false;
            foreach (AdminTable at in adc.AdminTables)
            {
                if (at.aid == uid && at.password == Pss) { status = true; break; }
            }
            return status;
        }
        public bool CheckUser(string uid)
        {
            bool status = false;
            foreach (AdminTable at in adc.AdminTables)
            {
                if (at.aid == uid ) { status = true; break; }
            }
            return status;
        }

        public string GetEmail(string uid)
        {
            var x = adc.AdminTables.Where(a => a.aid == uid).FirstOrDefault();
            return x.email;
        }
        public void UpdatePassword(string uid,string p)
        {
            var x = adc.AdminTables.Where(a => a.aid == uid).FirstOrDefault();
            x.password = p;
            adc.SubmitChanges();
        }

    }
}
