﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Access_Layer
{
    public class StudentAttendanceDataAccess
    {
        StudentAttendanceDBDataContext sdc = new StudentAttendanceDBDataContext(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\Taha\Documents\Visual_Studio_2012\Projects\Projectwork111\Data_Access_Layer\StudentData.mdf;Integrated Security=True;Connect Timeout=30");

        public void ADD(string Name,string stuId,int p,string className,string dept,string Tid)
        {
            StudentAttendanceTable sa = new StudentAttendanceTable();
            sa.date = Convert.ToDateTime(System.DateTime.Now.ToShortDateString());
            sa.studentName = Name;
            sa.studentId = stuId;
            sa.teacherId = Tid;
            sa.attendance = p;
            sa.@class = className;
            sa.department = dept;

            sdc.StudentAttendanceTables.InsertOnSubmit(sa);
            sdc.SubmitChanges();
        }

        public List<object> GetListByDate(string dat,string className,string dept,string tid)
        {
            var x = from a in sdc.StudentAttendanceTables where a.teacherId==tid && a.date == Convert.ToDateTime(dat) && a.@class == className && a.department == dept select new { a.date, a.studentName, a.studentId };
            List<object> o = new List<object>();
            o.AddRange(x.ToList());
            return o;
        }

        public List<object> GetAttendanceListByDate(string dat, string className, string dept,string tid)
        {
            var x = from a in sdc.StudentAttendanceTables where a.teacherId==tid && a.date == Convert.ToDateTime(dat) && a.@class == className && a.department == dept select new {  a.attendance };
            List<object> o = new List<object>();
            o.AddRange(x.ToList());
            return o;
        }

        public void Update(string dat,string className,string dept,string tid,int p)
        {
            var sa = sdc.StudentAttendanceTables.Where(a => a.teacherId == tid && a.date == Convert.ToDateTime(dat)
                                                            && a.@class == className && a.department == dept).FirstOrDefault();
            sa.attendance = p;
            sdc.SubmitChanges();

        }

        
    }
}
