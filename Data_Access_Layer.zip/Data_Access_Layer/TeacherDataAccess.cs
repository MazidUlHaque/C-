﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Access_Layer
{
    public class TeacherDataAccess
    {
        TeacherDBDataContext tac = new TeacherDBDataContext(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\Taha\Documents\Visual_Studio_2012\Projects\Projectwork111\Data_Access_Layer\StudentData.mdf;Integrated Security=True;Connect Timeout=30");

       public void AddTeacher(string Name,int ID,string Gender,string Password,string Email,string Phone,string DOB
                                ,string RegisterDate,string Address,string Subject,
                                string Department,string BloodGroup,bool Nursary,bool STD1,bool STD2,bool STD3,bool STD4,bool STD5,
                                bool STD6,bool STD7,bool STD8,bool STD9,bool STD10,byte[] Photo)
       {
           TeacherTable tb = new TeacherTable();
           tb.name = Name;
           tb.gender = Gender;
           tb.password = Password;
           tb.email = Email;
           tb.phone = Phone;
           tb.dateOfBirth = Convert.ToDateTime(DOB);
           tb.subject = Subject;
           tb.address = Address;
           tb.department = Department;
           tb.registerDate = Convert.ToDateTime(RegisterDate);
           tb.photo = Photo;
           tb.id = "T-" + ID.ToString();
           tb.teacherId = ID;
           tb.bloodGroup = BloodGroup;
           tb.nursary = Nursary ? 1 : 0;
           tb.std1 = STD1 ? 1 : 0;
           tb.std2 = STD2 ? 1 : 0;
           tb.std3 = STD3 ? 1 : 0;
           tb.std4 = STD4 ? 1 : 0;
           tb.std5 = STD5 ? 1 : 0;
           tb.std6 = STD6 ? 1 : 0;
           tb.std7 = STD7 ? 1 : 0;
           tb.std8 = STD8 ? 1 : 0;
           tb.std9 = STD9 ? 1 : 0;
           tb.std10 = STD10 ? 1 : 0;

           tac.TeacherTables.InsertOnSubmit(tb);
           tac.SubmitChanges();
       }

       public void UpdateTeacher(string Name, int ID, string Gender, string Password, string Email, string Phone, string DOB, string Address, string Subject,
                               string Department, string BloodGroup, bool Nursary, bool STD1, bool STD2, bool STD3, bool STD4, bool STD5,
                               bool STD6, bool STD7, bool STD8, bool STD9, bool STD10,int id,byte[] Photo)
       {
           var tb = tac.TeacherTables.Where(x=>x.teacherId==id).FirstOrDefault();
           tb.name = Name;
           tb.gender = Gender;
           tb.password = Password;
           tb.email = Email;
           tb.phone = Phone;
           tb.address = Address;
           tb.dateOfBirth = Convert.ToDateTime(DOB);
           tb.subject = Subject;
           tb.department = Department;
           tb.bloodGroup = BloodGroup;
           tb.photo = Photo;
           tb.nursary = Nursary ? 1 : 0;
           tb.std1 = STD1 ? 1 : 0;
           tb.std2 = STD2 ? 1 : 0;
           tb.std3 = STD3 ? 1 : 0;
           tb.std4 = STD4 ? 1 : 0;
           tb.std5 = STD5 ? 1 : 0;
           tb.std6 = STD6 ? 1 : 0;
           tb.std7 = STD7 ? 1 : 0;
           tb.std8 = STD8 ? 1 : 0;
           tb.std9 = STD9 ? 1 : 0;
           tb.std10 = STD10 ? 1 : 0;

           tac.SubmitChanges();
       }
       public void DeleteTeacher(int id)
       {
           var x = from a in tac.TeacherTables where a.teacherId == id select a;
           tac.TeacherTables.DeleteOnSubmit(x.FirstOrDefault());
           tac.SubmitChanges();
       }

       public List<object> GetList()
       {
           var x = from a in tac.TeacherTables select new { a.id,a.name,a.gender,a.password,a.email,a.phone,a.dateOfBirth,a.subject,
                                                            a.department,a.bloodGroup,a.address,a.registerDate,a.nursary,a.std1,a.std2,a.std3,a.std4,a.std5,a.std6,
                                                               a.std7,a.std8,a.std9,a.std10};
           List<object> o = new List<object>();
           o.AddRange(x.ToList());
           return o;
       }

       public List<object> GetListForProfile(string uid)
       {
           var x = from a in tac.TeacherTables where a.id==uid
                   select new
                   {a.id,a.name,a.gender,a.password,a.email,a.phone,a.dateOfBirth,a.subject,a.department,a.bloodGroup,a.address,
                       a.registerDate,a.nursary,a.std1,a.std2,a.std3,a.std4,a.std5,a.std6,a.std7,a.std8,a.std9,a.std10
                   };
           List<object> o = new List<object>();
           o.AddRange(x.ToList());
           return o;
       }

       public List<object> SearchTeacher(string id)
       {
           var x = from a in tac.TeacherTables
                   where a.id == id
                   select new
                   {a.id,a.name,a.gender,a.password,a.email,a.phone,a.dateOfBirth,a.subject,a.department,a.bloodGroup,
                       a.address,a.registerDate,a.nursary,a.std1,a.std2,a.std3,a.std4,a.std5,a.std6,a.std7,a.std8,a.std9,a.std10};
           List<object> o = new List<object>();
           o.AddRange(x.ToList());
           return o; 
       }

       public int LastTeacherID()
       {
           try
           {
               var x = from a in tac.TeacherTables orderby a.teacherId descending select new { a.teacherId };
               return x.FirstOrDefault().teacherId;
           }
           catch (Exception esc) { return 100; }
       }

       public byte[] GetPhotoOfTeacher(int id)
       {
           var x = from a in tac.TeacherTables where a.teacherId == id select new { a.photo };
           return (byte[])x.FirstOrDefault().photo.ToArray();
       }
       public byte[] GetPhotoOfTeacher(string i)
       {
           var x = from a in tac.TeacherTables where a.id == i select new { a.photo };
           return (byte[])x.FirstOrDefault().photo.ToArray();
       }
       public bool CheckUser(string uid, string pass)
       {
           bool status = false;
           foreach (TeacherTable st in tac.TeacherTables)
           {
               if (st.id == uid && st.password == pass) { status = true; break; }
           }
           return status;
       }
       public bool CheckUser(string uid)
       {
           bool status = false;
           foreach (TeacherTable st in tac.TeacherTables)
           {
               if (st.id == uid ) { status = true; break; }
           }
           return status;
       }
       public string GetEmail(string uid)
       {
           var x = tac.TeacherTables.Where(a => a.id == uid).FirstOrDefault();
           return x.email;
       }

       public string GetDepartment(string uid, string pass)
       {
           var x = from a in tac.TeacherTables where a.id == uid && a.password == pass select new { a.department };
           if (x.FirstOrDefault().department != null) { return x.FirstOrDefault().department; }
           else{return "x";}
       }
       public string GetDepartment(string uid)
       {
           var x = from a in tac.TeacherTables where a.id == uid  select new { a.department };
           if (x.FirstOrDefault().department != null) { return x.FirstOrDefault().department; }
           else { return " "; }
       }

       public string[] GetClasses(string uid, string pass)
       {
           string[] str=new string[11];int i=0;
           var x = from a in tac.TeacherTables where a.id == uid && a.password == pass select new { a.nursary,a.std1,a.std2,a.std3,a.std4,a.std5,
                                                                                                        a.std6,a.std7,a.std8,a.std9,a.std10};
           if(x.FirstOrDefault().nursary==1){str[i]="Nursary";i++;}
           if(x.FirstOrDefault().std1==1){str[i]="STD-1";i++;}
           if(x.FirstOrDefault().std2==1){str[i]="STD-2";i++;}
           if(x.FirstOrDefault().std3==1){str[i]="STD-3";i++;}
           if(x.FirstOrDefault().std4==1){str[i]="STD-4";i++;}
           if(x.FirstOrDefault().std5==1){str[i]="STD-5";i++;}
           if(x.FirstOrDefault().std6==1){str[i]="STD-6";i++;}
           if(x.FirstOrDefault().std7==1){str[i]="STD-7";i++;}
           if(x.FirstOrDefault().std8==1){str[i]="STD-8";i++;}
           if(x.FirstOrDefault().std9==1){str[i]="STD-9";i++;}
           if(x.FirstOrDefault().std10==1){str[i]="STD-10";i++;}
           return str;
           
       }
       public string[] GetClasses(string uid)
       {
           string[] str = new string[11]; int i = 0;
           var x = from a in tac.TeacherTables
                   where a.id == uid 
                   select new
                   {a.nursary,a.std1,a.std2,a.std3,a.std4,a.std5,a.std6,a.std7,a.std8,a.std9,a.std10};
           if (x.FirstOrDefault().nursary == 1) { str[i] = "Nursary"; i++; }
           if (x.FirstOrDefault().std1 == 1) { str[i] = "STD-1"; i++; }
           if (x.FirstOrDefault().std2 == 1) { str[i] = "STD-2"; i++; }
           if (x.FirstOrDefault().std3 == 1) { str[i] = "STD-3"; i++; }
           if (x.FirstOrDefault().std4 == 1) { str[i] = "STD-4"; i++; }
           if (x.FirstOrDefault().std5 == 1) { str[i] = "STD-5"; i++; }
           if (x.FirstOrDefault().std6 == 1) { str[i] = "STD-6"; i++; }
           if (x.FirstOrDefault().std7 == 1) { str[i] = "STD-7"; i++; }
           if (x.FirstOrDefault().std8 == 1) { str[i] = "STD-8"; i++; }
           if (x.FirstOrDefault().std9 == 1) { str[i] = "STD-9"; i++; }
           if (x.FirstOrDefault().std10 == 1) { str[i] = "STD-10"; i++; }
           return str;

       }
       public string GetSubjectName(string tid)
       {
           var x = from a in tac.TeacherTables where a.id == tid select new { a.subject };
           return x.FirstOrDefault().subject;
       }
       public string GetTeacherName(string tid)
       {
           var x = from a in tac.TeacherTables where a.id == tid select new { a.name };
           return x.FirstOrDefault().name;
       }

       public void UpdatePassWord(string uid, string p)
       {
           var x = tac.TeacherTables.Where(a => a.id == uid).FirstOrDefault();
           x.password = p;
           tac.SubmitChanges();
       }
       
    }
}
