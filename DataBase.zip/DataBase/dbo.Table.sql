﻿CREATE TABLE [dbo].[User]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [UserType] VARCHAR(50) NULL, 
    [Name] VARCHAR(50) NULL, 
    [UserName] VARCHAR(50) NULL, 
    [Email] VARCHAR(50) NULL, 
    [Password] VARCHAR(50) NULL, 
    [Phone] VARCHAR(50) NULL, 
    [Gender] VARCHAR(50) NULL, 
    [BG] VARCHAR(5) NULL, 
    [DOB] DATE NULL
)
