﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace puzzle
{
    public partial class Form1 : Form
    {
        int[] array = new int[9];
        int blank;
        int steps = 0;

        bool check = false;

        private Solution sol = new Solution();
        private Condition con = new Condition();

        Nodes[] node;

        private int[] nextNode = new int[1000];
        private int far;

        public Form1()
        {
            InitializeComponent();

            generateRandom();
            ShowNumbers();
            showSteps();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            check = false;

            Array.Clear(array, 0, array.Length);

            label1.Text = "";

            generateRandom();
            ShowNumbers();
            steps = 0;
            showSteps();
        }

        private void showSteps()
        {
            label2.Text = "Step: " + steps;
        }

        public void generateRandom()
        {
            blank = new Random().Next(0, 9);

            for (int i = 0; i < 9; i++)
            {
                if (i == blank)
                {
                    array[i] = 0;
                }
                else
                {
                    array[i] = Rand();
                }

                //MessageBox.Show(array[i]+" ");

            }
        }
        public void ShowNumbers()
        {
            

            textBox1.Text = array[0].ToString();
            textBox2.Text = array[1].ToString();
            textBox3.Text = array[2].ToString();
            textBox4.Text = array[3].ToString();
            textBox5.Text = array[4].ToString();
            textBox6.Text = array[5].ToString();
            textBox7.Text = array[6].ToString();
            textBox8.Text = array[7].ToString();
            textBox9.Text = array[8].ToString();

            if (blank == 0)
            {
                textBox1.Text = "";
            }
            else if (blank == 1)
            {
                textBox2.Text = "";
            }
            else if (blank == 2)
            {
                textBox3.Text = "";
            }
            else if (blank == 3)
            {
                textBox4.Text = "";
            }
            else if (blank == 4)
            {
                textBox5.Text = "";
            }
            else if (blank == 5)
            {
                textBox6.Text = "";
            }
            else if (blank == 6)
            {
                textBox7.Text = "";
            }
            else if (blank == 7)
            {
                textBox8.Text = "";
            }
            else if (blank == 8)
            {
                textBox9.Text = "";
            }
        }

        public int Rand()
        {
            Random rnd = new Random();
            int temp =  rnd.Next(1, 9);

            while (array.Contains(temp))
            {
                temp = rnd.Next(1, 9);
            }

            return temp;
        }

        private void button2_Click(object sender, EventArgs e)
        {

            //label1.Text = "Number of mismatch: "+mismatch().ToString();

            steps = 0;
            showSteps();

            far = 0;
            int nodeMax = 1000;


            node = new Nodes[nodeMax];

            int[] answer = {1,2,3,
                            4,5,6,
                            7,8,0};


            int lastNode = 0;
            node[lastNode] = new Nodes();
            node[lastNode].addNode(array, 0);
            int currNode = lastNode;

            while (!sol.isCorrect(answer, node[currNode].getNode()) && lastNode < nodeMax)
            {
                for (int j = 0; j < 4; j++)
                {
                    int[] temp1 = new int[node[currNode].getNode().Length];
                    for (int i = 0; i < temp1.Length; i++)
                    {
                        temp1[i] = node[currNode].getNode()[i];
                    }
                    int[] temp2 = con.spread(temp1, j);

                    if (!sol.isSame(temp2, node, lastNode))
                    {
                        lastNode++;
                        try
                        {
                            node[lastNode] = new Nodes();
                        }
                        catch (Exception ex)
                        {
                            break;
                        }
                        node[lastNode].addNode(temp2, currNode);
                    }
                }
                node[currNode].visited = true;

                currNode = sol.BFS(answer, node, lastNode);
                //MessageBox.Show(sol.missMatch.ToString());
            }

            int final = currNode;
            
            richTextBox1.Text = "";
            sol.missMatch = 0;
            sol.reversal = 0;

            while (currNode != 0)
            {
                nextNode[far] = currNode;

                int x = sol.getMinCost(answer, node[currNode].getNode());

                sol.getReversal(node[currNode].getNode(), answer);

                //MessageBox.Show(sol.missMatch.ToString());

                richTextBox1.Text += "\n" + node[currNode].toString() + "\n";
                currNode = node[currNode].prevNode;

                far++;
            }
            richTextBox1.Text += "\n" + node[0].toString() + "\n";

            if (sol.isCorrect(answer, node[final].getNode()))
            {
                string s = "F(n)=G(n)+H(n) \n=" + far + "+" + sol.missMatch + "+" + sol.reversal + "\n=" + (far + sol.missMatch+sol.reversal);
                richTextBox1.Text = "\nSolution found!\nNode : " + final + "\n" + "Moves :" + far + "\n"+s+"\n"+ richTextBox1.Text;
            }
            else
            {
                richTextBox1.Text = "\nNo solution found\n"+ richTextBox1.Text;
            }

            //MessageBox.Show(str);

            check = true;

        }
        
        private void up()
        {
            if (blank != 6 && blank != 7 && blank != 8 )
            {
                int temp = array[blank];
                array[blank] = array[blank + 3];
                array[blank + 3] = temp;
                blank += 3;
                steps++;
                result();
            }
        }
        private void down()
        {
            if (blank != 0 && blank != 1 && blank != 2)
            {
                int temp = array[blank];
                array[blank] = array[blank - 3];
                array[blank - 3] = temp;
                blank -= 3;
                steps++;
                result();
            }
        }
        private void right()
        {
            if (blank != 0 && blank != 3 && blank != 6)
            {
                int temp = array[blank];
                array[blank] = array[blank - 1];
                array[blank - 1] = temp;
                blank -= 1;
                steps++;
                result();
            }
        }
        private void left()
        {
            if (blank != 2 && blank != 5 && blank != 8)
            {
                int temp = array[blank];
                array[blank] = array[blank + 1];
                array[blank + 1] = temp;
                blank += 1;
                steps++;
                result();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            up();
            ShowNumbers();
            showSteps();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            down();
            ShowNumbers();
            showSteps();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            right();
            ShowNumbers();
            showSteps();

        }

        private void button6_Click(object sender, EventArgs e)
        {
            left();
            ShowNumbers();
            showSteps();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
           // switch (keyData)
            //{
                /*case Keys.Down:
                    button4.PerformClick();
                    //MessageBox.Show("inside");
                    return true;
                    
                case Keys.Right:
                    button5.PerformClick();
                    return true;
                    
                case Keys.Up:
                    button3.PerformClick();
                    return true;
                    
                case Keys.Left:
                    button6.PerformClick();
                    return true;*/
                    
            //}
            
            return base.ProcessCmdKey(ref msg, keyData);
        }

        public void result()
        {
            bool flag = true;
            for (int i = 0; i < 9; i++)
            {
                if (i == 8 && array[i] == 0)
                {
                    continue;
                }
                else if (array[i] != (i + 1))
                {
                    flag = false;
                }
            }

            if (flag)
            {
                label3.Text = "Puzzle complete".ToString();
            }
            else
            {
                label3.Text = "";
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if(!check)
            {
                button2.PerformClick();
            }
            else
            {
                far--;

                if (far >= 0)
                {
                    int[] temp = node[nextNode[far]].getNode();

                    array = temp;

                    for(int i = 0; i<9; i++)
                    {
                        if(array[i] == 0)
                        {
                            blank = i;
                        }
                    }

                    textBox1.Text = "" + ((temp[0] == 0) ? "" : temp[0].ToString());
                    textBox2.Text = "" + ((temp[1] == 0) ? "" : temp[1].ToString());
                    textBox3.Text = "" + ((temp[2] == 0) ? "" : temp[2].ToString());
                    textBox4.Text = "" + ((temp[3] == 0) ? "" : temp[3].ToString());
                    textBox5.Text = "" + ((temp[4] == 0) ? "" : temp[4].ToString());
                    textBox6.Text = "" + ((temp[5] == 0) ? "" : temp[5].ToString());
                    textBox7.Text = "" + ((temp[6] == 0) ? "" : temp[6].ToString());
                    textBox8.Text = "" + ((temp[7] == 0) ? "" : temp[7].ToString());
                    textBox9.Text = "" + ((temp[8] == 0) ? "" : temp[8].ToString());
                    steps++;
                    showSteps();
                    //label1.Text = "Number of mismatch: " + mismatch().ToString();
                }
                result();
            }
            
        }

    }
}
