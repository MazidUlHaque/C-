﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace puzzle
{
    class Nodes
    {
        private int[] node = new int[9];
        public bool visited = false;

        public int prevNode { get; set; }

        public void addNode(int[] node, int prevNode)
        {
            this.node = node;
            this.prevNode = prevNode;
        }

        public int[] getNode()
        {
            return node;
        }

        public string toString()
        {
            string msg = "";

            for (int i = 0; i < node.Length; i++)
            {
                
                if (i % 3 == 0 && i != 0)
                    msg += "\n";

                msg += "  ";
                msg += node[i];
            }

            return msg;
        }
    }
}
