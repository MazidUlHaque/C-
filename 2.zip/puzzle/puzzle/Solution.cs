﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace puzzle
{
    class Solution
    {
        public int missMatch = 0;
        public int reversal = 0;
        int temp = 0;
        int temp2 = 0;

        public int BFS(int[] ans, Nodes[] node, int lastNode)
        {
            int max_h = 100;
            int minNode = 1;
            int h = 0;

            for (int i = 1; i < lastNode; i++)
            {
                

                if(!node[i].visited)
                {
                    try
                    {
                        //temp = 0;
                        h = getMinCost(ans, node[i].getNode());
                    }
                    catch (Exception e)
                    {
                        break;
                    }

                    if (h < max_h)
                    {
                        max_h = h;
                        minNode = i;
                    }
                }
                
                
            }
            //this.missMatch += temp;

            return minNode;
        }

        public int getMinCost(int[] ans, int[] node)
        {
            int h = 0;

            for (int i = 0; i < ans.Length; i++)
            {
                int j = 0;
                for (j = 0; j <= ans.Length; j++)
                {
                    if (node[i] == ans[j])
                    {
                        break;
                    }
                }

                try
                {
                    temp = 0;
                    temp2 = 0;
                    h += getCost(i, j);
                }
                catch (Exception e)
                {

                    break;
                }
                this.missMatch += temp;
            }

            return h;
        }

        public void getReversal(int[] node, int[] ans)
        {
            temp2 = 0;

            for (int i = 0; i < node.Length; i++)
            {
                try
                {
                    if (ans[i] == node[i + 1] && ans[i + 1] == node[i])
                    {
                        temp2++;
                    }
                    else if (ans[i] == node[i + 3] && ans[i + 3] == node[i])
                    {
                        temp2++;
                    }
                }
                catch (Exception e)
                {
                    continue;
                }
                
            }

            this.reversal += temp2;
        }

        public int getCost(int pos1, int pos2)
        {
            //		_____________
            //		|_0_|_1_|_2_|
            //		|_3_|_4_|_5_|
            //		|_6_|_7_|_8_|

            if (pos1 == pos2)
            {
                return 0;
            }
            else 
            {
                temp++;
            }
            
            if ((pos1 == 0 && (pos2 == 1 || pos2 == 3)) ||
                    (pos1 == 2 && (pos2 == 1 || pos2 == 5)) ||
                    (pos1 == 6 && (pos2 == 3 || pos2 == 7)) ||
                    (pos1 == 8 && (pos2 == 5 || pos2 == 7)) ||
                    (pos1 == 1 && (pos2 == 0 || pos2 == 2 || pos2 == 4)) ||
                    (pos1 == 3 && (pos2 == 0 || pos2 == 4 || pos2 == 6)) ||
                    (pos1 == 5 && (pos2 == 2 || pos2 == 4 || pos2 == 8)) ||
                    (pos1 == 7 && (pos2 == 4 || pos2 == 6 || pos2 == 8)) ||
                    (pos1 == 4 && (pos2 == 1 || pos2 == 3 || pos2 == 5 || pos2 == 7)))
            {
                //temp2++;
                return 1;
            }
            else if ((pos1 == 0 && (pos2 == 2 || pos2 == 4 || pos2 == 6)) ||
                    (pos1 == 2 && (pos2 == 0 || pos2 == 4 || pos2 == 8)) ||
                    (pos1 == 6 && (pos2 == 0 || pos2 == 4 || pos2 == 8)) ||
                    (pos1 == 8 && (pos2 == 2 || pos2 == 4 || pos2 == 6)) ||
                    (pos1 == 1 && (pos2 == 3 || pos2 == 5 || pos2 == 7)) ||
                    (pos1 == 3 && (pos2 == 1 || pos2 == 5 || pos2 == 7)) ||
                    (pos1 == 5 && (pos2 == 1 || pos2 == 3 || pos2 == 7)) ||
                    (pos1 == 7 && (pos2 == 1 || pos2 == 3 || pos2 == 5)) ||
                    (pos1 == 4 && (pos2 == 0 || pos2 == 2 || pos2 == 6 || pos2 == 8)))
            {
                //temp++;
                return 2;
            }
            else if ((pos1 == 0 && (pos2 == 5 || pos2 == 7)) ||
                    (pos1 == 2 && (pos2 == 3 || pos2 == 7)) ||
                    (pos1 == 6 && (pos2 == 1 || pos2 == 5)) ||
                    (pos1 == 8 && (pos2 == 1 || pos2 == 3)) ||
                    (pos1 == 1 && (pos2 == 6 || pos2 == 8)) ||
                    (pos1 == 3 && (pos2 == 2 || pos2 == 8)) ||
                    (pos1 == 5 && (pos2 == 0 || pos2 == 6)) ||
                    (pos1 == 7 && (pos2 == 0 || pos2 == 2)))
            {
                //temp++;
                return 3;
            }
            else if ((pos1 == 0 && (pos2 == 8)) ||
                    (pos1 == 2 && (pos2 == 6)) ||
                    (pos1 == 6 && (pos2 == 2)) ||
                    (pos1 == 8 && (pos2 == 0)))
            {
                //temp++;
                return 4;
            }
            else
            {
                return 99;
            }
            
        }

        public bool isCorrect(int[] ans, int[] set)
        {
            for (int i = 0; ans[i] == set[i]; i++)
            {
                if (i == 8)
                {
                    return true;
                }
            }
            return false;
        }

        public bool isSame(int[] set, Nodes[] node, int lastNode)
        {
            for (int j = 0; j < lastNode; j++)
            {
                int[] temp = new int[node[j].getNode().Length];
                for (int i = 0; i < temp.Length; i++)
                {
                    temp[i] = node[j].getNode()[i];
                }

                for (int i = 0; set[i] == temp[i]; i++)
                {
                    if (i == 8)
                    {
                        return true;
                    }
                }
            }
            return false;
        }
    }

}
