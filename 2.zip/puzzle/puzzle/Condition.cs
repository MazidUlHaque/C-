﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace puzzle
{
    class Condition
    {
        public int[] spread(int[] node, int ignore)
        {
            int zero = zero_pos(node);
            int pass = 0;

            for (int i = 0; i < node.Length; i++)
            {
                if (canSwap(zero, i))
                {
                    pass++;

                    if (pass > ignore)
                    {
                        swap(node, zero, i);

                        return node;
                    }
                }
            }

            return node;
        }

        public int zero_pos(int[] node)
        {
            for (int i = 0; i < node.Length; i++)
            {
                if (node[i] == 0)
                {
                    return i;
                }
            }
            return -1;
        }
        public void swap(int[] node, int a, int b)
        {
            if (canSwap(a, b))
            {
                int temp = node[a];
                node[a] = node[b];
                node[b] = temp;
            }
        }
        public bool canSwap(int pos1, int pos2)
        {
            //		_____________
            //		|_0_|_1_|_2_|
            //		|_3_|_4_|_5_|
            //		|_6_|_7_|_8_|

            if (pos1 == 0 && (pos2 == 1 || pos2 == 3))
            {
                return true;
            }
            if (pos1 == 1 && (pos2 == 0 || pos2 == 2 || pos2 == 4))
            {
                return true;
            }
            if (pos1 == 2 && (pos2 == 1 || pos2 == 5))
            {
                return true;
            }
            if (pos1 == 3 && (pos2 == 0 || pos2 == 4 || pos2 == 6))
            {
                return true;
            }
            if (pos1 == 4 && (pos2 == 1 || pos2 == 3 || pos2 == 5 || pos2 == 7))
            {
                return true;
            }
            if (pos1 == 5 && (pos2 == 2 || pos2 == 4 || pos2 == 8))
            {
                return true;
            }
            if (pos1 == 6 && (pos2 == 3 || pos2 == 7))
            {
                return true;
            }
            if (pos1 == 7 && (pos2 == 4 || pos2 == 6 || pos2 == 8))
            {
                return true;
            }
            if (pos1 == 8 && (pos2 == 5 || pos2 == 7))
            {
                return true;
            }
            return false;
        }
    }
}
