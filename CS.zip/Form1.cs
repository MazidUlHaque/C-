﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projectwork111
{
    public partial class Form1 : Form
    {
        UserDbDataContext mdc = new UserDbDataContext(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\Taha\Documents\UserDB.mdf;Integrated Security=True;Connect Timeout=30");

        public Form1()
        {
            InitializeComponent();
            this.administratorPanel.SetBounds(185, 20, 825, 470);
            this.administratorPanel.Visible = true;

            this.academicYearPanel.SetBounds(0, 28, 825, 430);
            this.academicYearPanel.Visible = false;

            //userPanel
            this.userPanel.SetBounds(0, 28, 825, 430);
            this.userPanel.Visible = false;

            this.addUserPanel.SetBounds(0, 35, 825, 417);
            this.addUserPanel.Visible = false;
            this.userSearchPanel.SetBounds(0, 35, 825, 425);
            this.userSearchPanel.Visible = false;
            this.userTypeComboBoxSearch.SelectedIndex=0;

            //sectionPanel
            this.administratorPanel.Controls.Add(sectionPanel);
            this.sectionPanel.SetBounds(0, 28, 825, 430);
            this.sectionPanel.Visible = false;

            this.sectionAddPanel.SetBounds(0, 35, 825, 417);
            this.sectionAddPanel.Visible = false;
            this.sectionSearchPanel.SetBounds(0, 35, 825, 425);
            this.sectionSearchPanel.Visible = false;

            //student Panel
            this.studentPanel.SetBounds(185, 20, 825, 470);
            this.Controls.Add(studentPanel);
            this.studentPanel.Visible = false;
            
            // Student registration Panel
            this.studentRegistrationPanel.SetBounds(0, 28, 825, 430);
            this.studentRegistrationPanel.Visible = false;

            this.studentPromotionPanel.SetBounds(0, 28, 825, 430);
            this.studentPromotionPanel.Visible = false;

            this.studentRegistrationRegisterPanel.SetBounds(0, 35, 825, 417);
            this.studentRegistrationRegisterPanel.Visible = false;
            this.studentRegistrationSearchPanel.SetBounds(0, 35, 825, 425);
            this.studentRegistrationSearchPanel.Visible = false;

            //attendance Panel
            this.Controls.Add(attendancePanel);
            this.attendancePanel.SetBounds(185, 20, 825, 470);
            this.attendancePanel.Visible = false;

            this.attendanceStudentPanel.SetBounds(0, 28, 825, 430);
            this.attendanceStudentPanel.Visible = false;

            var listOfUsers = from a in mdc.Users select a;
            userSearchDataGrid.DataSource = listOfUsers;
            
        }

        private void crossButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        
        private void administratorsMenuButton_Click(object sender, EventArgs e)
        {
            this.studentPanel.Visible = false;
            this.sectionPanel.Visible = false;
            this.administratorPanel.Visible = true;
            this.path.Text = "Administrator >> ";
        }

        private void studentMenuButton_Click(object sender, EventArgs e)
        {
            this.studentPanel.Visible = true;
            this.sectionPanel.Visible = false;
            this.administratorPanel.Visible = false;
            this.path.Text = "";
            this.path.Text = "Student >>";
        }

        //administrator Panel
        private void administratorPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        

        private void bunifuTextbox1_OnTextChange(object sender, EventArgs e)
        {

        }

        private void academicYearButton_Click(object sender, EventArgs e)
        {
            this.academicYearPanel.Visible = true;
            this.userPanel.Visible = false;
            this.path.Text = "Administrator >> Academic Year >>";
        }

        //userPanel Button Events
        private void userButton_Click(object sender, System.EventArgs e)
        {
            this.userPanel.Visible = true;
            this.academicYearPanel.Visible = false;
            this.path.Text = "Administrator >> User >>";
        }

        private void addUserButton_Click(object sender, System.EventArgs e)
        {
            this.addUserPanel.Visible = true;
            this.userSearchPanel.Visible = false;
            this.path.Text = "Administrator >> User >> Add >>";
        }

        private void doneAddUserButton_Click(object sender, EventArgs e)
        {
            if (userAddPasswordTextBox.Text == userAddConfirmPasswordTextBox.Text)
            {
                MessageBox.Show("User Added ");
                User u = new User();
                u.UserType = userTypeComboBox.Text;
                u.Name = userAddNameTextBox.Text;
                u.UserName = userAddUsernameTextBox.Text;
                u.Email = userAddEmailTextBox.Text;
                u.Password = userAddEmailTextBox.Text;
                u.PhoneNumber = userAddPhoneTextBox.Text;
                if (maleRadioButton.Checked) { u.Gender = "Male"; }
                else if (femaleRadioButton.Checked) { u.Gender = "Female"; }
                else { u.Gender = "Others"; }
                u.BloodGroup = bgComboBox.Text;
                u.DateOfBirth = Convert.ToDateTime(dateTimePicker1.Value.ToShortDateString());

                mdc.Users.InsertOnSubmit(u);
                mdc.SubmitChanges();

                GridViewUpdate();
                userAddNameTextBox.Text = userAddUsernameTextBox.Text = userAddNameTextBox.Text=userAddPasswordTextBox.Text=userAddConfirmPasswordTextBox.Text=userAddPhoneTextBox.Text ="";
                
            }
            else { MessageBox.Show("Password Did not Matched."); }
        }

        void GridViewUpdate()
        {
            var listOfUsers = from a in mdc.Users select a;
            userSearchDataGrid.DataSource = listOfUsers;
        }

        private void bunifuCustomDataGrid1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            nameUpdateTectBox.Text = userSearchDataGrid.Rows[e.RowIndex].Cells[1].Value.ToString();
            userNameUpdateTextBox.Text = userSearchDataGrid.Rows[e.RowIndex].Cells[2].Value.ToString();
            emailUpdateTextBox.Text = userSearchDataGrid.Rows[e.RowIndex].Cells[3].Value.ToString();
            passwordUpdateTextBox.Text = userSearchDataGrid.Rows[e.RowIndex].Cells[4].Value.ToString();
            confirmPasswordUpdateTextBox.Text = userSearchDataGrid.Rows[e.RowIndex].Cells[4].Value.ToString();
            phoneUpdateTextBox.Text = userSearchDataGrid.Rows[e.RowIndex].Cells[5].Value.ToString();
            bgUpdateTextBox.Text = userSearchDataGrid.Rows[e.RowIndex].Cells[6].Value.ToString();
            if (userSearchDataGrid.Rows[e.RowIndex].Cells[7].Value.ToString() == "Male") { maleUpdate.Checked=true; }
            else if (userSearchDataGrid.Rows[e.RowIndex].Cells[7].Value.ToString() == "Female") { femaleUpdate.Checked = true; }
            else { othersUpdate.Checked = true; }
            datePickerUserUpdate.Text = userSearchDataGrid.Rows[e.RowIndex].Cells[8].Value.ToString();
            userTypeUpdateComboBox.Text = userSearchDataGrid.Rows[e.RowIndex].Cells[9].Value.ToString();

        }

        private void updateButton_Click(object sender, EventArgs e)
        {
            UserDbDataContext db = new UserDbDataContext(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\Taha\Documents\UserDB.mdf;Integrated Security=True;Connect Timeout=30");

            if (passwordUpdateTextBox.Text == confirmPasswordUpdateTextBox.Text)
            {
                MessageBox.Show("User Added ");
                int pId = Convert.ToInt32(userSearchDataGrid.CurrentRow.Cells[0].Value.ToString());
                
                var u = db.Users.Where(w => w.ID == pId).FirstOrDefault();
                u.UserType = userTypeUpdateComboBox.Text;
                u.Name = nameUpdateTectBox.Text;
                u.UserName = userNameUpdateTextBox.Text;
                u.Email = emailUpdateTextBox.Text;
                u.Password = passwordUpdateTextBox.Text;
                u.PhoneNumber = phoneUpdateTextBox.Text;
                if (maleUpdate.Checked) { u.Gender = "Male"; }
                else if (femaleUpdate.Checked) { u.Gender = "Female"; }
                else { u.Gender = "Others"; }
                u.BloodGroup = bgUpdateTextBox.Text;
                u.DateOfBirth = Convert.ToDateTime(datePickerUserUpdate.Value.ToShortDateString());

                db.SubmitChanges();
                userSearchDataGrid.DataSource = db.Users;

            }
            else { MessageBox.Show("Password Did not Matched."); }
        }
        private void deleteButton_Click(object sender, EventArgs e)
        {
            UserDbDataContext db = new UserDbDataContext(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\Taha\Documents\UserDB.mdf;Integrated Security=True;Connect Timeout=30");
            int pId = Convert.ToInt32(userSearchDataGrid.CurrentRow.Cells[0].Value.ToString());
            var u = db.Users.Where(w => w.ID == pId).FirstOrDefault();
            db.Users.DeleteOnSubmit(u);
            db.SubmitChanges();
            userSearchDataGrid.DataSource = db.Users;
                
        }

        private void searchUserButton_Click(object sender, System.EventArgs e)
        {
            this.addUserPanel.Visible = false;
            this.userSearchPanel.Visible = true;
            this.path.Text = "Administrator >> User >> Search >>";
        }

        private void searchInUserSearchPanelButton_Click(object sender, EventArgs e)
        {
            if (userTypeComboBoxSearch.Text == "All")
            {
                var listofusers = from a in mdc.Users select a;
                userSearchDataGrid.DataSource = listofusers;
            }
            else
            {
                var listofusers = from a in mdc.Users where a.UserType == userTypeComboBoxSearch.Text select a;
                userSearchDataGrid.DataSource = listofusers;
            }
            //int idnum;
            //string usertype = userTypeComboBoxSearch.Text;
            //if (idTextBoxSearch.Text == null) { idnum = 0; }
            //else { idnum = Convert.ToInt32(idTextBoxSearch.Text); }
            //string namet = nameTextBoxSearch.Text;
            //if (usertype == "All" )
            //{
            //    if(idnum != 0 && namet != null){
            //        var listofusers = from a in mdc.Users where a.ID == idnum && a.Name == namet select a;
            //        userSearchDataGrid.DataSource = listofusers;
            //    }
            //    else if(idnum == 0 && namet != null){
            //        var listofusers = from a in mdc.Users where  a.Name == namet select a;
            //        userSearchDataGrid.DataSource = listofusers;
            //    }
            //    else if(idnum == 0 && namet == null){
            //        var listofusers = from a in mdc.Users select a;
            //        userSearchDataGrid.DataSource = listofusers;
            //    }

            //}
            //else if (usertype == "Admin")
            //{
            //    if (idnum != 0 && namet != null)
            //    {
            //        var listofusers = from a in mdc.Users where a.UserType == usertype && a.ID == idnum && a.Name == namet select a;
            //        userSearchDataGrid.DataSource = listofusers;
            //    }
            //    else if (idnum == 0 && namet != null)
            //    {
            //        var listofusers = from a in mdc.Users where a.UserType == usertype && a.Name == namet select a;
            //        userSearchDataGrid.DataSource = listofusers;
            //    }
            //    else if (idnum == 0 && namet == null)
            //    {
            //        var listofusers = from a in mdc.Users where a.UserType == usertype  select a;
            //        userSearchDataGrid.DataSource = listofusers;
            //    }

            //}
            //else if (usertype == "Teacher")
            //{
            //    if (idnum != 0 && namet != null)
            //    {
            //        var listofusers = from a in mdc.Users where a.UserType == usertype && a.ID == idnum && a.Name == namet select a;
            //        userSearchDataGrid.DataSource = listofusers;
            //    }
            //    else if (idnum == 0 && namet != null)
            //    {
            //        var listofusers = from a in mdc.Users where a.UserType == usertype && a.Name == namet select a;
            //        userSearchDataGrid.DataSource = listofusers;
            //    }
            //    else if (idnum == 0 && namet == null)
            //    {
            //        var listofusers = from a in mdc.Users where a.UserType == usertype select a;
            //        userSearchDataGrid.DataSource = listofusers;
            //    }

            //}
            //else if (usertype == "Student")
            //{
            //    if (idnum != 0 && namet != null)
            //    {
            //        var listofusers = from a in mdc.Users where a.UserType == usertype && a.ID == idnum && a.Name == namet select a;
            //        userSearchDataGrid.DataSource = listofusers;
            //    }
            //    else if (idnum == 0 && namet != null)
            //    {
            //        var listofusers = from a in mdc.Users where a.UserType == usertype && a.Name == namet select a;
            //        userSearchDataGrid.DataSource = listofusers;
            //    }
            //    else if (idnum == 0 && namet == null)
            //    {
            //        var listofusers = from a in mdc.Users where a.UserType == usertype select a;
            //        userSearchDataGrid.DataSource = listofusers;
            //    }

            //}
        }


        //sectionPanel
        private void sectionSearchDataGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void sectionButton_click(object sender, EventArgs e)
        {
            this.academicYearPanel.Visible = false;
            this.userPanel.Visible = false;
            this.sectionPanel.Visible = true;
            this.path.Text = "Administrator >> Section >>";
        }

        private void sectionAddButton_Click(object sender, EventArgs e)
        {
            this.sectionAddPanel.Visible = true;
            this.sectionSearchPanel.Visible = false;
            this.path.Text = "Administrator >> Section >> Add >> ";
        }

        private void sectionSearchButton_Click(object sender, EventArgs e)
        {
            this.sectionAddPanel.Visible = false;
            this.sectionSearchPanel.Visible = true;
            this.path.Text = "Administrator >> Section >> Search >> ";
        }


        //student Panel
        private void studentRegistrationButton_Click(object sender, EventArgs e)
        {
            this.studentRegistrationPanel.Visible = true;
            this.studentPromotionPanel.Visible = false;
        }

        private void studentPromotion_Click(object sender, EventArgs e)
        {
            this.studentRegistrationPanel.Visible = false;
            this.studentPromotionPanel.Visible = true;
        }

        private void studentRegistrationRegisterButton_Click(object sender, EventArgs e)
        {
            this.studentRegistrationRegisterPanel.Visible = true;
            this.studentRegistrationSearchPanel.Visible = false;
        }

        private void studentRegistrationSearchButton_Click(object sender, EventArgs e)
        {
            this.studentRegistrationRegisterPanel.Visible = false;
            this.studentRegistrationSearchPanel.Visible = true;
        }

        //attendancePanel
        private void attendanceMenuButton_Click(object sender, EventArgs e)
        {
            this.administratorPanel.Visible = false;
            this.studentPanel.Visible = false;
            this.attendancePanel.Visible = true;
        }

        private void attendanceStudentButton_Click(object sender, EventArgs e)
        {
            this.attendanceStudentPanel.Visible = true;
        }

        

       

       
    }
}
