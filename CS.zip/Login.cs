﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bussiness_Logic_Layer;
using System.Net;
using System.Net.Mail;

namespace Projectwork111
{
    public partial class Login : Form
    {

        public Login()
        {
            InitializeComponent();
            //login Panel
            this.loginPanel.SetBounds(0, 20, 780, 450);
            this.loginPanel.Visible = true;

            //forgot Panel
            this.forgotPanel.SetBounds(0, 20, 780, 450);
            this.forgotPanel.Visible = false;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            
            if (userIdTextBox.Text.Contains("A-"))
            {
                AdminClass ac = new AdminClass();
                if (ac.CheckUser(userIdTextBox.Text, passwordTextBox.Text))
                {
                    Admin a = new Admin(this);
                    a.Show();
                    this.Hide();
                    userIdTextBox.Text = passwordTextBox.Text = "";
                }
                else
                {
                    MessageBox.Show("Wrong User ID or Password");
                }
                
            }
            else if (userIdTextBox.Text.Contains("S-"))
            {
                Student stu = new Student();
                if (stu.CheckUser(userIdTextBox.Text, passwordTextBox.Text))
                {
                    StudentForm s = new StudentForm(userIdTextBox.Text, passwordTextBox.Text, this);
                    s.Show();
                    this.Hide();
                    userIdTextBox.Text = passwordTextBox.Text = "";
                }
                else
                {
                    MessageBox.Show("Wrong User ID or Password");
                }

            }
            else if (userIdTextBox.Text.Contains("T-"))
            {
                Teacher t = new Teacher();
                if (t.CheckUser(userIdTextBox.Text, passwordTextBox.Text))
                {
                    TeacherForm tf = new TeacherForm(userIdTextBox.Text, passwordTextBox.Text, this);
                    tf.Show();
                    this.Hide();
                    userIdTextBox.Text = passwordTextBox.Text = "";
                }
                else
                {
                    MessageBox.Show("Wrong User ID or Password");
                }
            }
            else
            {
                MessageBox.Show("Wrong User ID or Password");
            }
        }


        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.loginPanel.Visible = false;
            this.forgotPanel.Visible = true;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.loginPanel.Visible = true;
            this.forgotPanel.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
            if (forgotUserIdTextBox.Text.Contains("A-"))
            {
                AdminClass a = new AdminClass();
                if (a.CheckUser(forgotUserIdTextBox.Text))
                {
                    var client = new SmtpClient("smtp.gmail.com", 587)
                    {
                        Credentials = new NetworkCredential("farahaidid1996@gmail.com", "googlepass12345"),
                        EnableSsl = true
                    };
                    Random r = new Random();
                    string p = r.Next(1000, 10000).ToString();
                    a.UpdatePassword(forgotUserIdTextBox.Text, p);
                    client.Send("farahaidid1996@gmail.com", a.GetEmail(forgotUserIdTextBox.Text), "New Password",
                                "Your New Password is : " + p + "\nNow You Can Login to your System with New Password.");
                    MessageBox.Show("A new Password is sent to your e-mail address. \nCheck Mail and Login");
                }
                else
                {
                    MessageBox.Show("Wrong User Name.");
                }

                
            }
            else if (forgotUserIdTextBox.Text.Contains("S-"))
            {
                Student s = new Student();
                if (s.CheckUser(forgotUserIdTextBox.Text))
                {
                    var client = new SmtpClient("smtp.gmail.com", 587)
                    {
                        Credentials = new NetworkCredential("farahaidid1996@gmail.com", "googlepass12345"),
                        EnableSsl = true
                    };
                    Random r = new Random();
                    string p = r.Next(1000, 10000).ToString();
                    s.UpdatePassword(forgotUserIdTextBox.Text, p);
                    client.Send("farahaidid1996@gmail.com", s.GetEmail(forgotUserIdTextBox.Text), "New Password",
                                "Your New Password is : " + p + "\nNow You Can Login to your System with New Password.");
                    MessageBox.Show("A new Password is sent to your e-mail address. \nCheck Mail and Login");
                }
                else
                {
                    MessageBox.Show("Wrong User Name.");
                }
            }
            else if (forgotUserIdTextBox.Text.Contains("T-"))
            {
                Teacher s = new Teacher();
                if (s.CheckUser(forgotUserIdTextBox.Text))
                {
                    var client = new SmtpClient("smtp.gmail.com", 587)
                    {
                        Credentials = new NetworkCredential("farahaidid1996@gmail.com", "googlepass12345"),
                        EnableSsl = true
                    };
                    Random r = new Random();
                    string p = r.Next(1000, 10000).ToString();
                    s.UpdatePassword(forgotUserIdTextBox.Text, p);
                    client.Send("farahaidid1996@gmail.com", s.GetEmail(forgotUserIdTextBox.Text), "New Password",
                                "Your New Password is : " + p + "\nNow You Can Login to your System with New Password.");
                    MessageBox.Show("A new Password is sent to your e-mail address. \nCheck Mail and Login");
                }
                else
                {
                    MessageBox.Show("Wrong User Name.");
                }
            }
            else
            {
                MessageBox.Show("Wrong User Name.");
            }
            forgotUserIdTextBox.Text = "";

        }

    }
}
