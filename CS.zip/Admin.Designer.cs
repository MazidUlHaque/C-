﻿using System.Windows.Forms;
namespace Projectwork111
{
    partial class Admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Admin));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.attendancePanel = new System.Windows.Forms.Panel();
            this.employeeAttendaceButton = new System.Windows.Forms.Button();
            this.employeeAttendanceUpdate = new System.Windows.Forms.Button();
            this.employeeAttendanceUpdatePanel = new System.Windows.Forms.Panel();
            this.button7 = new System.Windows.Forms.Button();
            this.employeeAttendanceData2 = new System.Windows.Forms.DataGridView();
            this.employeeAttendanceUpdateSearchButton = new System.Windows.Forms.Button();
            this.label115 = new System.Windows.Forms.Label();
            this.employeeAttendanceUpdateButton = new System.Windows.Forms.Button();
            this.employeeAttendanceUpdateDate = new System.Windows.Forms.DateTimePicker();
            this.label114 = new System.Windows.Forms.Label();
            this.employeeAttendanceUpdateDataGrid = new System.Windows.Forms.DataGridView();
            this.dataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.employeeAttendancePanel = new System.Windows.Forms.Panel();
            this.employeeAttendanceDoneButton = new System.Windows.Forms.Button();
            this.employeeAttendanceDate = new System.Windows.Forms.DateTimePicker();
            this.label113 = new System.Windows.Forms.Label();
            this.attendanceEmployeeDataGrid = new System.Windows.Forms.DataGridView();
            this.attendance = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.employeePanel = new System.Windows.Forms.Panel();
            this.employeeRegisterPanel = new System.Windows.Forms.Panel();
            this.employeeRegisterBrowseButton = new System.Windows.Forms.Button();
            this.employeeRegisterPictureBox = new System.Windows.Forms.PictureBox();
            this.employeeRegisterEmployeeIdTextBox = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.employeeRegisterSubmitButton = new System.Windows.Forms.Button();
            this.employeeRegisterDOB = new System.Windows.Forms.DateTimePicker();
            this.employeeRegisterDate = new System.Windows.Forms.DateTimePicker();
            this.employeeRegisterBGComboBox = new System.Windows.Forms.ComboBox();
            this.label35 = new System.Windows.Forms.Label();
            this.employeeRegisterGenderComboBox = new System.Windows.Forms.ComboBox();
            this.employeeRegisterAddressTextBox = new System.Windows.Forms.RichTextBox();
            this.employeeRegisterEmailTextBox = new System.Windows.Forms.TextBox();
            this.employeeRegisterPhoneTextBox = new System.Windows.Forms.TextBox();
            this.employeeRegisterNameTextBox = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.employeeSearchPanel = new System.Windows.Forms.Panel();
            this.button5 = new System.Windows.Forms.Button();
            this.label112 = new System.Windows.Forms.Label();
            this.label111 = new System.Windows.Forms.Label();
            this.label110 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.label107 = new System.Windows.Forms.Label();
            this.label108 = new System.Windows.Forms.Label();
            this.label109 = new System.Windows.Forms.Label();
            this.employeeSearchBrowseButton = new System.Windows.Forms.Button();
            this.employeeSearchPictureBox = new System.Windows.Forms.PictureBox();
            this.employeeSearchEmployeeIdTextBox = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.employeeSearchSearchButton = new System.Windows.Forms.Button();
            this.employeeSearchTextBox = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.employeeSearchUpdateButton = new System.Windows.Forms.Button();
            this.employeeSearchDeleteButton = new System.Windows.Forms.Button();
            this.employeeSearchDOBUpdate = new System.Windows.Forms.DateTimePicker();
            this.employeeSearchRegisterDateUpdate = new System.Windows.Forms.DateTimePicker();
            this.employeeSearchBGUpdateComboBox = new System.Windows.Forms.ComboBox();
            this.label54 = new System.Windows.Forms.Label();
            this.employeeSearchGenderUpdateComboBox = new System.Windows.Forms.ComboBox();
            this.employeeSearchAddressUpdateTextBox = new System.Windows.Forms.RichTextBox();
            this.employeeSearchEmailUpdateTextBox = new System.Windows.Forms.TextBox();
            this.employeeSearchPhoneUpdateTextBox = new System.Windows.Forms.TextBox();
            this.employeeSearchNameUpdateTextBox = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.employeeSearchDataGrid = new System.Windows.Forms.DataGridView();
            this.employeeSearchButton = new System.Windows.Forms.Button();
            this.employeeRegisterButton = new System.Windows.Forms.Button();
            this.teacherPanel = new System.Windows.Forms.Panel();
            this.teacherAddPanel = new System.Windows.Forms.Panel();
            this.teacherRegisterRegisterDate = new System.Windows.Forms.DateTimePicker();
            this.label100 = new System.Windows.Forms.Label();
            this.teacherAddStd6 = new System.Windows.Forms.CheckBox();
            this.teacherAddStd10 = new System.Windows.Forms.CheckBox();
            this.teacherAddStd2 = new System.Windows.Forms.CheckBox();
            this.teacherAddStd5 = new System.Windows.Forms.CheckBox();
            this.teacherAddStd8 = new System.Windows.Forms.CheckBox();
            this.teacherAddStd7 = new System.Windows.Forms.CheckBox();
            this.teacherAddStd1 = new System.Windows.Forms.CheckBox();
            this.teacherAddStd3 = new System.Windows.Forms.CheckBox();
            this.teacherAddStd9 = new System.Windows.Forms.CheckBox();
            this.teacherAddNursary = new System.Windows.Forms.CheckBox();
            this.teacherAddStd4 = new System.Windows.Forms.CheckBox();
            this.label76 = new System.Windows.Forms.Label();
            this.teacherAddConfirmPasswordTextBox = new System.Windows.Forms.TextBox();
            this.label68 = new System.Windows.Forms.Label();
            this.teacherAddPasswordTextBox = new System.Windows.Forms.TextBox();
            this.label69 = new System.Windows.Forms.Label();
            this.teacherAddTeacherIDTextBox = new System.Windows.Forms.TextBox();
            this.label70 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.teacherAddBrowseButton = new System.Windows.Forms.Button();
            this.teacherAddPictureBox = new System.Windows.Forms.PictureBox();
            this.teacherAddBGComboBox = new System.Windows.Forms.ComboBox();
            this.label73 = new System.Windows.Forms.Label();
            this.teacherAddSubmitButton = new System.Windows.Forms.Button();
            this.teacherAddDOB = new System.Windows.Forms.DateTimePicker();
            this.teacherAddDepartmentComboBox = new System.Windows.Forms.ComboBox();
            this.label74 = new System.Windows.Forms.Label();
            this.teacherAddSubjectComboBox = new System.Windows.Forms.ComboBox();
            this.teacherAddGenderComboBox = new System.Windows.Forms.ComboBox();
            this.teacherAddAddressTextBox = new System.Windows.Forms.RichTextBox();
            this.teacherAddEmailTextBox = new System.Windows.Forms.TextBox();
            this.teacherAddPhoneTextBox = new System.Windows.Forms.TextBox();
            this.teacherAddNameTextBox = new System.Windows.Forms.TextBox();
            this.label75 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.searchUserButton = new System.Windows.Forms.Button();
            this.addUserButton = new System.Windows.Forms.Button();
            this.teacherSearchPanel = new System.Windows.Forms.Panel();
            this.button6 = new System.Windows.Forms.Button();
            this.teacherSearchSearchButton = new System.Windows.Forms.Button();
            this.label99 = new System.Windows.Forms.Label();
            this.teacherSearchTextBox = new System.Windows.Forms.TextBox();
            this.label98 = new System.Windows.Forms.Label();
            this.teacherSearchDelateButton = new System.Windows.Forms.Button();
            this.label97 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.teacherSearchStd6 = new System.Windows.Forms.CheckBox();
            this.teacherSearchStd10 = new System.Windows.Forms.CheckBox();
            this.teacherSearchStd2 = new System.Windows.Forms.CheckBox();
            this.teacherSearchStd5 = new System.Windows.Forms.CheckBox();
            this.teacherSearchStd8 = new System.Windows.Forms.CheckBox();
            this.teacherSearchStd7 = new System.Windows.Forms.CheckBox();
            this.teacherSearchStd1 = new System.Windows.Forms.CheckBox();
            this.teacherSearchStd3 = new System.Windows.Forms.CheckBox();
            this.teacherSearchStd9 = new System.Windows.Forms.CheckBox();
            this.teacherSearchNursary = new System.Windows.Forms.CheckBox();
            this.teacherSearchStd4 = new System.Windows.Forms.CheckBox();
            this.label77 = new System.Windows.Forms.Label();
            this.teacherSearchConfirmPasswordTextBox = new System.Windows.Forms.TextBox();
            this.label78 = new System.Windows.Forms.Label();
            this.teacherSearchPasswordTextBox = new System.Windows.Forms.TextBox();
            this.label81 = new System.Windows.Forms.Label();
            this.teacherSearchTeacherIdTextBox = new System.Windows.Forms.TextBox();
            this.label82 = new System.Windows.Forms.Label();
            this.teacherSearchBrowseButton = new System.Windows.Forms.Button();
            this.teacherSearchPictureBox = new System.Windows.Forms.PictureBox();
            this.teacherSearchBGComboBox = new System.Windows.Forms.ComboBox();
            this.label83 = new System.Windows.Forms.Label();
            this.teacherSearchUpdateButton = new System.Windows.Forms.Button();
            this.teacherSearchDOB = new System.Windows.Forms.DateTimePicker();
            this.teacherSearchDepartmentComboBox = new System.Windows.Forms.ComboBox();
            this.label88 = new System.Windows.Forms.Label();
            this.teacherSearchSubjectComboBox = new System.Windows.Forms.ComboBox();
            this.teacherSearchGenderComboBox = new System.Windows.Forms.ComboBox();
            this.teacherSearchAddressTextBox = new System.Windows.Forms.RichTextBox();
            this.teacherSearchEmailTextBox = new System.Windows.Forms.TextBox();
            this.teacherSearchPhoneTextBox = new System.Windows.Forms.TextBox();
            this.teacherSearchNameTextBox = new System.Windows.Forms.TextBox();
            this.label89 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.searchInUserSearchPanelButton = new System.Windows.Forms.Button();
            this.teacherSearchDataGrid = new System.Windows.Forms.DataGridView();
            this.idTextBoxSearch = new System.Windows.Forms.TextBox();
            this.bunifuCustomLabel13 = new System.Windows.Forms.Label();
            this.studentPromotionPanel = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.label105 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.studentPromotionClassUpdateComboBox = new System.Windows.Forms.ComboBox();
            this.label64 = new System.Windows.Forms.Label();
            this.studentPromotionClassComboBox = new System.Windows.Forms.ComboBox();
            this.studentPromotionSearchButton = new System.Windows.Forms.Button();
            this.label50 = new System.Windows.Forms.Label();
            this.studentPromotionPromoteButton = new System.Windows.Forms.Button();
            this.studentPromotionDataGrid = new System.Windows.Forms.DataGridView();
            this.studentRegistrationPanel = new System.Windows.Forms.Panel();
            this.studentRegistrationSearchPanel = new System.Windows.Forms.Panel();
            this.studentRegistrationSearchDataGrid = new System.Windows.Forms.DataGridView();
            this.label117 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.studentRegistrationSearchPasswordTextBox = new System.Windows.Forms.TextBox();
            this.label62 = new System.Windows.Forms.Label();
            this.studentRegistrationSearchConfirmPasswordTextBox = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.studentRegistrationSearchBGComboBox = new System.Windows.Forms.ComboBox();
            this.label57 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.studentRegistrationSearchPictudeBox = new System.Windows.Forms.PictureBox();
            this.label34 = new System.Windows.Forms.Label();
            this.studentRegistrationSearchSearchButton = new System.Windows.Forms.Button();
            this.studentRegistrationSearchIDTextBox = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.studentRegistrationSearchUpdateButton = new System.Windows.Forms.Button();
            this.studentRegistrationSearchDeleteButton = new System.Windows.Forms.Button();
            this.studentRegistrationSearchDOBUpdate = new System.Windows.Forms.DateTimePicker();
            this.studentRegistrationSearchAdmissionDateUpdate = new System.Windows.Forms.DateTimePicker();
            this.studentRegistrationSearchDepartmentUpdateComboBox = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.studentRegistrationSearchClassUpdateComboBox = new System.Windows.Forms.ComboBox();
            this.studentRegistrationSearchGenderUpdateComboBox = new System.Windows.Forms.ComboBox();
            this.studentRegistrationSearchAddressUpdateTextBox = new System.Windows.Forms.RichTextBox();
            this.studentRegistrationSearchEmailUpdateTextBox = new System.Windows.Forms.TextBox();
            this.studentRegistrationSearchPhoneUpdateTextBox = new System.Windows.Forms.TextBox();
            this.studentRegistrationSearchMotherOccupationUpdateTextBox = new System.Windows.Forms.TextBox();
            this.studentRegistrationSearchMotherNameUpdateTextBox = new System.Windows.Forms.TextBox();
            this.studentRegistrationSearchFatherOccupationUpdateTextBox = new System.Windows.Forms.TextBox();
            this.studentRegistrationSearchFatherNameUpdateTextBox = new System.Windows.Forms.TextBox();
            this.studentRegistrationSearchNameUpdateTextBox = new System.Windows.Forms.TextBox();
            this.studentRegistrationSearchAdmissionNumberUpdateTextBox = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.studentRegistrationRegisterPanel = new System.Windows.Forms.Panel();
            this.studentRegistrationRegisterConfirmPasswordTextBox = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.studentRegistrationRegisterPasswordTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.studentRegistrationRegisterStudentIdTextBox = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.studentRegistrationRegisterBrowseButton = new System.Windows.Forms.Button();
            this.studentRegistrationRegisterPictureBox = new System.Windows.Forms.PictureBox();
            this.studentRegistrationRegisterBGComboBox = new System.Windows.Forms.ComboBox();
            this.label39 = new System.Windows.Forms.Label();
            this.studentRegistrationRegisterSubmitButton = new System.Windows.Forms.Button();
            this.studentRegistrationRegisterDOB = new System.Windows.Forms.DateTimePicker();
            this.studentRegistrationRegisterAdmissionDate = new System.Windows.Forms.DateTimePicker();
            this.studentRegistrationRegisterDepartmentComboBox = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.studentRegistrationRegisterClassComboBox = new System.Windows.Forms.ComboBox();
            this.studentRegistrationRegisterGenderComboBox = new System.Windows.Forms.ComboBox();
            this.studentRegistrationRegisterAddressTextBox = new System.Windows.Forms.RichTextBox();
            this.studentRegistrationRegisterEmailTextBox = new System.Windows.Forms.TextBox();
            this.studentRegistrationRegisterPhoneTextBox = new System.Windows.Forms.TextBox();
            this.studentRegistrationRegisterMotherOccupationTextBox = new System.Windows.Forms.TextBox();
            this.studentRegistrationRegisterMotherNameTextBox = new System.Windows.Forms.TextBox();
            this.studentRegistrationRegisterFatherOccupationTextBox = new System.Windows.Forms.TextBox();
            this.studentRegistrationRegisterFatherNameTextBox = new System.Windows.Forms.TextBox();
            this.studentRegistrationRegisterNameTextBox = new System.Windows.Forms.TextBox();
            this.studentRegistrationRegisterAdmissionNumberTextBox = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.studentRegistrationSearchButton = new System.Windows.Forms.Button();
            this.studentRegistrationRegisterButton = new System.Windows.Forms.Button();
            this.studentPanel = new System.Windows.Forms.Panel();
            this.label51 = new System.Windows.Forms.Label();
            this.studentPromotion = new System.Windows.Forms.Button();
            this.studentRegistrationButton = new System.Windows.Forms.Button();
            this.Id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BloodGroup = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Gender = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DOB = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.usersFullName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UserName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Email = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Password = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Phone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tileBarPanel = new System.Windows.Forms.Panel();
            this.crossButton = new System.Windows.Forms.Button();
            this.termExamPanel = new System.Windows.Forms.Panel();
            this.termExamDepartmentComboBox = new System.Windows.Forms.ComboBox();
            this.label103 = new System.Windows.Forms.Label();
            this.termExamUpdateButton = new System.Windows.Forms.Button();
            this.termExamDeleteButton = new System.Windows.Forms.Button();
            this.termExamDataGrid = new System.Windows.Forms.DataGridView();
            this.termExamAddButton = new System.Windows.Forms.Button();
            this.termExamDate = new System.Windows.Forms.DateTimePicker();
            this.label102 = new System.Windows.Forms.Label();
            this.termExamSubjectComboBox = new System.Windows.Forms.ComboBox();
            this.label101 = new System.Windows.Forms.Label();
            this.termExamClassNameComboBox = new System.Windows.Forms.ComboBox();
            this.label58 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.adminPanel = new System.Windows.Forms.Panel();
            this.adminAddPanel = new System.Windows.Forms.Panel();
            this.adminAddRegisterDate = new System.Windows.Forms.DateTimePicker();
            this.label116 = new System.Windows.Forms.Label();
            this.adminAddConfirmPasswordTextBox = new System.Windows.Forms.TextBox();
            this.label118 = new System.Windows.Forms.Label();
            this.adminAddPasswordTextBox = new System.Windows.Forms.TextBox();
            this.label119 = new System.Windows.Forms.Label();
            this.adminAddAdminIdTextBox = new System.Windows.Forms.TextBox();
            this.label120 = new System.Windows.Forms.Label();
            this.label121 = new System.Windows.Forms.Label();
            this.adminAddBrowseButton = new System.Windows.Forms.Button();
            this.adminAddPicture = new System.Windows.Forms.PictureBox();
            this.adminAddBGComboBox = new System.Windows.Forms.ComboBox();
            this.label122 = new System.Windows.Forms.Label();
            this.adminAddSubmitButton = new System.Windows.Forms.Button();
            this.adminAddDOB = new System.Windows.Forms.DateTimePicker();
            this.adminAddGenderComboBox = new System.Windows.Forms.ComboBox();
            this.adminAddAddressTextBox = new System.Windows.Forms.RichTextBox();
            this.adminAddEmailTextBox = new System.Windows.Forms.TextBox();
            this.adminAddPhoneNumberTextBox = new System.Windows.Forms.TextBox();
            this.adminAddNameTextBox = new System.Windows.Forms.TextBox();
            this.label124 = new System.Windows.Forms.Label();
            this.label125 = new System.Windows.Forms.Label();
            this.label126 = new System.Windows.Forms.Label();
            this.label127 = new System.Windows.Forms.Label();
            this.label128 = new System.Windows.Forms.Label();
            this.label129 = new System.Windows.Forms.Label();
            this.adminSearchButton = new System.Windows.Forms.Button();
            this.adminAddButton = new System.Windows.Forms.Button();
            this.adminSearchPanel = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.adminSearchSearchButton = new System.Windows.Forms.Button();
            this.label131 = new System.Windows.Forms.Label();
            this.adminSearchByIdTextBox = new System.Windows.Forms.TextBox();
            this.label132 = new System.Windows.Forms.Label();
            this.adminSearchDeleteButton = new System.Windows.Forms.Button();
            this.label133 = new System.Windows.Forms.Label();
            this.label134 = new System.Windows.Forms.Label();
            this.adminSearchConfirmPasswordTextBox = new System.Windows.Forms.TextBox();
            this.label136 = new System.Windows.Forms.Label();
            this.adminSearchPasswordTextBox = new System.Windows.Forms.TextBox();
            this.label137 = new System.Windows.Forms.Label();
            this.adminSearchAdminIDTextBox = new System.Windows.Forms.TextBox();
            this.label138 = new System.Windows.Forms.Label();
            this.adminSearchBrowseButton = new System.Windows.Forms.Button();
            this.adminSearchPicture = new System.Windows.Forms.PictureBox();
            this.adminSearchBGComboBox = new System.Windows.Forms.ComboBox();
            this.label139 = new System.Windows.Forms.Label();
            this.adminSearchUpdateButton = new System.Windows.Forms.Button();
            this.adminSearchDOBTextBox = new System.Windows.Forms.DateTimePicker();
            this.adminSearchGenderComboBox = new System.Windows.Forms.ComboBox();
            this.adminSearchAddressTextBox = new System.Windows.Forms.RichTextBox();
            this.adminSearchEmailTextBox = new System.Windows.Forms.TextBox();
            this.adminSearchPhoneNumberTextBox = new System.Windows.Forms.TextBox();
            this.adminSearchNameTextBox = new System.Windows.Forms.TextBox();
            this.label141 = new System.Windows.Forms.Label();
            this.label142 = new System.Windows.Forms.Label();
            this.label143 = new System.Windows.Forms.Label();
            this.label144 = new System.Windows.Forms.Label();
            this.label145 = new System.Windows.Forms.Label();
            this.label146 = new System.Windows.Forms.Label();
            this.label148 = new System.Windows.Forms.Label();
            this.button10 = new System.Windows.Forms.Button();
            this.adminSearchData = new System.Windows.Forms.DataGridView();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.label149 = new System.Windows.Forms.Label();
            this.menu = new System.Windows.Forms.Panel();
            this.adminMenuButton = new System.Windows.Forms.Button();
            this.LogoutBotton = new System.Windows.Forms.Button();
            this.termExamMenuButton = new System.Windows.Forms.Button();
            this.teacherMenuButton = new System.Windows.Forms.Button();
            this.employeeMenuButton = new System.Windows.Forms.Button();
            this.attendanceMenuButton = new System.Windows.Forms.Button();
            this.studentMenuButton = new System.Windows.Forms.Button();
            this.attendancePanel.SuspendLayout();
            this.employeeAttendanceUpdatePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.employeeAttendanceData2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeAttendanceUpdateDataGrid)).BeginInit();
            this.employeeAttendancePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.attendanceEmployeeDataGrid)).BeginInit();
            this.employeePanel.SuspendLayout();
            this.employeeRegisterPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.employeeRegisterPictureBox)).BeginInit();
            this.employeeSearchPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.employeeSearchPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeSearchDataGrid)).BeginInit();
            this.teacherPanel.SuspendLayout();
            this.teacherAddPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.teacherAddPictureBox)).BeginInit();
            this.teacherSearchPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.teacherSearchPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacherSearchDataGrid)).BeginInit();
            this.studentPromotionPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.studentPromotionDataGrid)).BeginInit();
            this.studentRegistrationPanel.SuspendLayout();
            this.studentRegistrationSearchPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.studentRegistrationSearchDataGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentRegistrationSearchPictudeBox)).BeginInit();
            this.studentRegistrationRegisterPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.studentRegistrationRegisterPictureBox)).BeginInit();
            this.studentPanel.SuspendLayout();
            this.tileBarPanel.SuspendLayout();
            this.termExamPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.termExamDataGrid)).BeginInit();
            this.adminPanel.SuspendLayout();
            this.adminAddPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.adminAddPicture)).BeginInit();
            this.adminSearchPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.adminSearchPicture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.adminSearchData)).BeginInit();
            this.menu.SuspendLayout();
            this.SuspendLayout();
            // 
            // attendancePanel
            // 
            this.attendancePanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.attendancePanel.Controls.Add(this.employeeAttendaceButton);
            this.attendancePanel.Controls.Add(this.employeeAttendanceUpdate);
            this.attendancePanel.Controls.Add(this.employeeAttendanceUpdatePanel);
            this.attendancePanel.Controls.Add(this.employeeAttendancePanel);
            this.attendancePanel.Location = new System.Drawing.Point(191, 34);
            this.attendancePanel.Name = "attendancePanel";
            this.attendancePanel.Size = new System.Drawing.Size(69, 42);
            this.attendancePanel.TabIndex = 3;
            this.attendancePanel.Visible = false;
            // 
            // employeeAttendaceButton
            // 
            this.employeeAttendaceButton.BackColor = System.Drawing.Color.MistyRose;
            this.employeeAttendaceButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.employeeAttendaceButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.employeeAttendaceButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeAttendaceButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.employeeAttendaceButton.Location = new System.Drawing.Point(760, 3);
            this.employeeAttendaceButton.Name = "employeeAttendaceButton";
            this.employeeAttendaceButton.Size = new System.Drawing.Size(105, 26);
            this.employeeAttendaceButton.TabIndex = 75;
            this.employeeAttendaceButton.Text = "Attendance";
            this.employeeAttendaceButton.UseVisualStyleBackColor = false;
            this.employeeAttendaceButton.Click += new System.EventHandler(this.employeeAttendaceButton_Click);
            // 
            // employeeAttendanceUpdate
            // 
            this.employeeAttendanceUpdate.BackColor = System.Drawing.Color.MistyRose;
            this.employeeAttendanceUpdate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.employeeAttendanceUpdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.employeeAttendanceUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeAttendanceUpdate.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.employeeAttendanceUpdate.Location = new System.Drawing.Point(880, 3);
            this.employeeAttendanceUpdate.Name = "employeeAttendanceUpdate";
            this.employeeAttendanceUpdate.Size = new System.Drawing.Size(174, 26);
            this.employeeAttendanceUpdate.TabIndex = 74;
            this.employeeAttendanceUpdate.Text = "Update Attendance";
            this.employeeAttendanceUpdate.UseVisualStyleBackColor = false;
            this.employeeAttendanceUpdate.Click += new System.EventHandler(this.employeeAttendanceUpdate_Click);
            // 
            // employeeAttendanceUpdatePanel
            // 
            this.employeeAttendanceUpdatePanel.AutoScroll = true;
            this.employeeAttendanceUpdatePanel.Controls.Add(this.button7);
            this.employeeAttendanceUpdatePanel.Controls.Add(this.employeeAttendanceData2);
            this.employeeAttendanceUpdatePanel.Controls.Add(this.employeeAttendanceUpdateSearchButton);
            this.employeeAttendanceUpdatePanel.Controls.Add(this.label115);
            this.employeeAttendanceUpdatePanel.Controls.Add(this.employeeAttendanceUpdateButton);
            this.employeeAttendanceUpdatePanel.Controls.Add(this.employeeAttendanceUpdateDate);
            this.employeeAttendanceUpdatePanel.Controls.Add(this.label114);
            this.employeeAttendanceUpdatePanel.Controls.Add(this.employeeAttendanceUpdateDataGrid);
            this.employeeAttendanceUpdatePanel.Location = new System.Drawing.Point(543, 160);
            this.employeeAttendanceUpdatePanel.Name = "employeeAttendanceUpdatePanel";
            this.employeeAttendanceUpdatePanel.Size = new System.Drawing.Size(431, 305);
            this.employeeAttendanceUpdatePanel.TabIndex = 71;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.MistyRose;
            this.button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button7.Location = new System.Drawing.Point(717, 262);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(105, 26);
            this.button7.TabIndex = 77;
            this.button7.Text = "Cancel Search";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // employeeAttendanceData2
            // 
            this.employeeAttendanceData2.AllowUserToAddRows = false;
            this.employeeAttendanceData2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.employeeAttendanceData2.Location = new System.Drawing.Point(562, 293);
            this.employeeAttendanceData2.Name = "employeeAttendanceData2";
            this.employeeAttendanceData2.Size = new System.Drawing.Size(104, 114);
            this.employeeAttendanceData2.TabIndex = 76;
            this.employeeAttendanceData2.Visible = false;
            // 
            // employeeAttendanceUpdateSearchButton
            // 
            this.employeeAttendanceUpdateSearchButton.BackColor = System.Drawing.Color.MistyRose;
            this.employeeAttendanceUpdateSearchButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.employeeAttendanceUpdateSearchButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.employeeAttendanceUpdateSearchButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeAttendanceUpdateSearchButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.employeeAttendanceUpdateSearchButton.Location = new System.Drawing.Point(717, 220);
            this.employeeAttendanceUpdateSearchButton.Name = "employeeAttendanceUpdateSearchButton";
            this.employeeAttendanceUpdateSearchButton.Size = new System.Drawing.Size(105, 26);
            this.employeeAttendanceUpdateSearchButton.TabIndex = 75;
            this.employeeAttendanceUpdateSearchButton.Text = "Search";
            this.employeeAttendanceUpdateSearchButton.UseVisualStyleBackColor = false;
            this.employeeAttendanceUpdateSearchButton.Click += new System.EventHandler(this.employeeAttendanceUpdateSearchButton_Click);
            // 
            // label115
            // 
            this.label115.AutoSize = true;
            this.label115.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label115.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label115.Location = new System.Drawing.Point(618, 179);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(44, 20);
            this.label115.TabIndex = 74;
            this.label115.Text = "Date";
            // 
            // employeeAttendanceUpdateButton
            // 
            this.employeeAttendanceUpdateButton.BackColor = System.Drawing.Color.MistyRose;
            this.employeeAttendanceUpdateButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.employeeAttendanceUpdateButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.employeeAttendanceUpdateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeAttendanceUpdateButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.employeeAttendanceUpdateButton.Location = new System.Drawing.Point(581, 461);
            this.employeeAttendanceUpdateButton.Name = "employeeAttendanceUpdateButton";
            this.employeeAttendanceUpdateButton.Size = new System.Drawing.Size(105, 26);
            this.employeeAttendanceUpdateButton.TabIndex = 73;
            this.employeeAttendanceUpdateButton.Text = "Done";
            this.employeeAttendanceUpdateButton.UseVisualStyleBackColor = false;
            this.employeeAttendanceUpdateButton.Click += new System.EventHandler(this.employeeAttendanceUpdateButton_Click);
            // 
            // employeeAttendanceUpdateDate
            // 
            this.employeeAttendanceUpdateDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeAttendanceUpdateDate.Location = new System.Drawing.Point(691, 179);
            this.employeeAttendanceUpdateDate.Name = "employeeAttendanceUpdateDate";
            this.employeeAttendanceUpdateDate.Size = new System.Drawing.Size(129, 22);
            this.employeeAttendanceUpdateDate.TabIndex = 72;
            this.employeeAttendanceUpdateDate.Value = new System.DateTime(2017, 12, 12, 0, 0, 0, 0);
            // 
            // label114
            // 
            this.label114.AutoSize = true;
            this.label114.BackColor = System.Drawing.Color.White;
            this.label114.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label114.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label114.Location = new System.Drawing.Point(385, 15);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(272, 25);
            this.label114.TabIndex = 71;
            this.label114.Text = "Update Employee Attendance";
            // 
            // employeeAttendanceUpdateDataGrid
            // 
            this.employeeAttendanceUpdateDataGrid.AllowUserToAddRows = false;
            this.employeeAttendanceUpdateDataGrid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(52)))), ((int)(((byte)(118)))));
            this.employeeAttendanceUpdateDataGrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.employeeAttendanceUpdateDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.employeeAttendanceUpdateDataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewCheckBoxColumn1});
            this.employeeAttendanceUpdateDataGrid.Location = new System.Drawing.Point(85, 112);
            this.employeeAttendanceUpdateDataGrid.Name = "employeeAttendanceUpdateDataGrid";
            this.employeeAttendanceUpdateDataGrid.Size = new System.Drawing.Size(441, 375);
            this.employeeAttendanceUpdateDataGrid.TabIndex = 70;
            // 
            // dataGridViewCheckBoxColumn1
            // 
            this.dataGridViewCheckBoxColumn1.HeaderText = "Attendance";
            this.dataGridViewCheckBoxColumn1.Name = "dataGridViewCheckBoxColumn1";
            // 
            // employeeAttendancePanel
            // 
            this.employeeAttendancePanel.AutoScroll = true;
            this.employeeAttendancePanel.Controls.Add(this.employeeAttendanceDoneButton);
            this.employeeAttendancePanel.Controls.Add(this.employeeAttendanceDate);
            this.employeeAttendancePanel.Controls.Add(this.label113);
            this.employeeAttendancePanel.Controls.Add(this.attendanceEmployeeDataGrid);
            this.employeeAttendancePanel.Location = new System.Drawing.Point(26, 128);
            this.employeeAttendancePanel.Name = "employeeAttendancePanel";
            this.employeeAttendancePanel.Size = new System.Drawing.Size(499, 328);
            this.employeeAttendancePanel.TabIndex = 70;
            // 
            // employeeAttendanceDoneButton
            // 
            this.employeeAttendanceDoneButton.BackColor = System.Drawing.Color.MistyRose;
            this.employeeAttendanceDoneButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.employeeAttendanceDoneButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.employeeAttendanceDoneButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeAttendanceDoneButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.employeeAttendanceDoneButton.Location = new System.Drawing.Point(581, 461);
            this.employeeAttendanceDoneButton.Name = "employeeAttendanceDoneButton";
            this.employeeAttendanceDoneButton.Size = new System.Drawing.Size(105, 26);
            this.employeeAttendanceDoneButton.TabIndex = 73;
            this.employeeAttendanceDoneButton.Text = "Done";
            this.employeeAttendanceDoneButton.UseVisualStyleBackColor = false;
            this.employeeAttendanceDoneButton.Click += new System.EventHandler(this.employeeAttendanceDoneButton_Click);
            // 
            // employeeAttendanceDate
            // 
            this.employeeAttendanceDate.Location = new System.Drawing.Point(577, 176);
            this.employeeAttendanceDate.Name = "employeeAttendanceDate";
            this.employeeAttendanceDate.Size = new System.Drawing.Size(129, 20);
            this.employeeAttendanceDate.TabIndex = 72;
            this.employeeAttendanceDate.Visible = false;
            // 
            // label113
            // 
            this.label113.AutoSize = true;
            this.label113.BackColor = System.Drawing.Color.White;
            this.label113.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label113.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label113.Location = new System.Drawing.Point(385, 15);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(204, 25);
            this.label113.TabIndex = 71;
            this.label113.Text = "Employee Attendance";
            // 
            // attendanceEmployeeDataGrid
            // 
            this.attendanceEmployeeDataGrid.AllowUserToAddRows = false;
            this.attendanceEmployeeDataGrid.AllowUserToDeleteRows = false;
            this.attendanceEmployeeDataGrid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(52)))), ((int)(((byte)(118)))));
            this.attendanceEmployeeDataGrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.attendanceEmployeeDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.attendanceEmployeeDataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.attendance});
            this.attendanceEmployeeDataGrid.Location = new System.Drawing.Point(85, 112);
            this.attendanceEmployeeDataGrid.Name = "attendanceEmployeeDataGrid";
            this.attendanceEmployeeDataGrid.ReadOnly = true;
            this.attendanceEmployeeDataGrid.Size = new System.Drawing.Size(441, 375);
            this.attendanceEmployeeDataGrid.TabIndex = 70;
            this.attendanceEmployeeDataGrid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.attendanceEmployeeDataGrid_CellContentClick);
            // 
            // attendance
            // 
            this.attendance.HeaderText = "Attendance";
            this.attendance.Name = "attendance";
            this.attendance.ReadOnly = true;
            // 
            // employeePanel
            // 
            this.employeePanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.employeePanel.Controls.Add(this.employeeRegisterPanel);
            this.employeePanel.Controls.Add(this.employeeSearchPanel);
            this.employeePanel.Controls.Add(this.employeeSearchButton);
            this.employeePanel.Controls.Add(this.employeeRegisterButton);
            this.employeePanel.Location = new System.Drawing.Point(200, 120);
            this.employeePanel.Name = "employeePanel";
            this.employeePanel.Size = new System.Drawing.Size(188, 148);
            this.employeePanel.TabIndex = 4;
            this.employeePanel.Visible = false;
            // 
            // employeeRegisterPanel
            // 
            this.employeeRegisterPanel.AutoScroll = true;
            this.employeeRegisterPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.employeeRegisterPanel.Controls.Add(this.employeeRegisterBrowseButton);
            this.employeeRegisterPanel.Controls.Add(this.employeeRegisterPictureBox);
            this.employeeRegisterPanel.Controls.Add(this.employeeRegisterEmployeeIdTextBox);
            this.employeeRegisterPanel.Controls.Add(this.label37);
            this.employeeRegisterPanel.Controls.Add(this.label71);
            this.employeeRegisterPanel.Controls.Add(this.employeeRegisterSubmitButton);
            this.employeeRegisterPanel.Controls.Add(this.employeeRegisterDOB);
            this.employeeRegisterPanel.Controls.Add(this.employeeRegisterDate);
            this.employeeRegisterPanel.Controls.Add(this.employeeRegisterBGComboBox);
            this.employeeRegisterPanel.Controls.Add(this.label35);
            this.employeeRegisterPanel.Controls.Add(this.employeeRegisterGenderComboBox);
            this.employeeRegisterPanel.Controls.Add(this.employeeRegisterAddressTextBox);
            this.employeeRegisterPanel.Controls.Add(this.employeeRegisterEmailTextBox);
            this.employeeRegisterPanel.Controls.Add(this.employeeRegisterPhoneTextBox);
            this.employeeRegisterPanel.Controls.Add(this.employeeRegisterNameTextBox);
            this.employeeRegisterPanel.Controls.Add(this.label36);
            this.employeeRegisterPanel.Controls.Add(this.label40);
            this.employeeRegisterPanel.Controls.Add(this.label41);
            this.employeeRegisterPanel.Controls.Add(this.label44);
            this.employeeRegisterPanel.Controls.Add(this.label45);
            this.employeeRegisterPanel.Controls.Add(this.label46);
            this.employeeRegisterPanel.Controls.Add(this.label47);
            this.employeeRegisterPanel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.employeeRegisterPanel.Location = new System.Drawing.Point(15, 68);
            this.employeeRegisterPanel.Name = "employeeRegisterPanel";
            this.employeeRegisterPanel.Size = new System.Drawing.Size(175, 84);
            this.employeeRegisterPanel.TabIndex = 4;
            this.employeeRegisterPanel.Visible = false;
            // 
            // employeeRegisterBrowseButton
            // 
            this.employeeRegisterBrowseButton.BackColor = System.Drawing.Color.MistyRose;
            this.employeeRegisterBrowseButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.employeeRegisterBrowseButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.employeeRegisterBrowseButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeRegisterBrowseButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.employeeRegisterBrowseButton.Location = new System.Drawing.Point(790, 183);
            this.employeeRegisterBrowseButton.Name = "employeeRegisterBrowseButton";
            this.employeeRegisterBrowseButton.Size = new System.Drawing.Size(128, 26);
            this.employeeRegisterBrowseButton.TabIndex = 31;
            this.employeeRegisterBrowseButton.Text = "Browse";
            this.employeeRegisterBrowseButton.UseVisualStyleBackColor = false;
            this.employeeRegisterBrowseButton.Click += new System.EventHandler(this.employeeRegisterBrowseButton_Click);
            // 
            // employeeRegisterPictureBox
            // 
            this.employeeRegisterPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.employeeRegisterPictureBox.Location = new System.Drawing.Point(790, 63);
            this.employeeRegisterPictureBox.Name = "employeeRegisterPictureBox";
            this.employeeRegisterPictureBox.Size = new System.Drawing.Size(121, 114);
            this.employeeRegisterPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.employeeRegisterPictureBox.TabIndex = 30;
            this.employeeRegisterPictureBox.TabStop = false;
            // 
            // employeeRegisterEmployeeIdTextBox
            // 
            this.employeeRegisterEmployeeIdTextBox.Enabled = false;
            this.employeeRegisterEmployeeIdTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeRegisterEmployeeIdTextBox.Location = new System.Drawing.Point(147, 75);
            this.employeeRegisterEmployeeIdTextBox.Name = "employeeRegisterEmployeeIdTextBox";
            this.employeeRegisterEmployeeIdTextBox.Size = new System.Drawing.Size(151, 22);
            this.employeeRegisterEmployeeIdTextBox.TabIndex = 29;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label37.Location = new System.Drawing.Point(36, 77);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(86, 16);
            this.label37.TabIndex = 28;
            this.label37.Text = "Employee ID";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.BackColor = System.Drawing.Color.White;
            this.label71.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label71.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label71.Location = new System.Drawing.Point(291, 12);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(199, 24);
            this.label71.TabIndex = 27;
            this.label71.Text = "Employee Registration";
            // 
            // employeeRegisterSubmitButton
            // 
            this.employeeRegisterSubmitButton.BackColor = System.Drawing.Color.MistyRose;
            this.employeeRegisterSubmitButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.employeeRegisterSubmitButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.employeeRegisterSubmitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeRegisterSubmitButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.employeeRegisterSubmitButton.Location = new System.Drawing.Point(629, 355);
            this.employeeRegisterSubmitButton.Name = "employeeRegisterSubmitButton";
            this.employeeRegisterSubmitButton.Size = new System.Drawing.Size(128, 26);
            this.employeeRegisterSubmitButton.TabIndex = 26;
            this.employeeRegisterSubmitButton.Text = "Submit";
            this.employeeRegisterSubmitButton.UseVisualStyleBackColor = false;
            this.employeeRegisterSubmitButton.Click += new System.EventHandler(this.employeeRegisterSubmitButton_Click);
            // 
            // employeeRegisterDOB
            // 
            this.employeeRegisterDOB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeRegisterDOB.Location = new System.Drawing.Point(505, 116);
            this.employeeRegisterDOB.Name = "employeeRegisterDOB";
            this.employeeRegisterDOB.Size = new System.Drawing.Size(154, 22);
            this.employeeRegisterDOB.TabIndex = 25;
            // 
            // employeeRegisterDate
            // 
            this.employeeRegisterDate.Enabled = false;
            this.employeeRegisterDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeRegisterDate.Location = new System.Drawing.Point(505, 89);
            this.employeeRegisterDate.Name = "employeeRegisterDate";
            this.employeeRegisterDate.Size = new System.Drawing.Size(154, 22);
            this.employeeRegisterDate.TabIndex = 24;
            // 
            // employeeRegisterBGComboBox
            // 
            this.employeeRegisterBGComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeRegisterBGComboBox.FormattingEnabled = true;
            this.employeeRegisterBGComboBox.Items.AddRange(new object[] {
            "A+",
            "A-",
            "B+",
            "B-",
            "AB+",
            "AB-",
            "O+",
            "O-"});
            this.employeeRegisterBGComboBox.Location = new System.Drawing.Point(506, 147);
            this.employeeRegisterBGComboBox.Name = "employeeRegisterBGComboBox";
            this.employeeRegisterBGComboBox.Size = new System.Drawing.Size(151, 24);
            this.employeeRegisterBGComboBox.TabIndex = 23;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label35.Location = new System.Drawing.Point(405, 148);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(84, 16);
            this.label35.TabIndex = 22;
            this.label35.Text = "Blood Group";
            // 
            // employeeRegisterGenderComboBox
            // 
            this.employeeRegisterGenderComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeRegisterGenderComboBox.FormattingEnabled = true;
            this.employeeRegisterGenderComboBox.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Others"});
            this.employeeRegisterGenderComboBox.Location = new System.Drawing.Point(145, 142);
            this.employeeRegisterGenderComboBox.Name = "employeeRegisterGenderComboBox";
            this.employeeRegisterGenderComboBox.Size = new System.Drawing.Size(151, 24);
            this.employeeRegisterGenderComboBox.TabIndex = 18;
            // 
            // employeeRegisterAddressTextBox
            // 
            this.employeeRegisterAddressTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeRegisterAddressTextBox.Location = new System.Drawing.Point(125, 239);
            this.employeeRegisterAddressTextBox.Name = "employeeRegisterAddressTextBox";
            this.employeeRegisterAddressTextBox.Size = new System.Drawing.Size(545, 63);
            this.employeeRegisterAddressTextBox.TabIndex = 17;
            this.employeeRegisterAddressTextBox.Text = "";
            // 
            // employeeRegisterEmailTextBox
            // 
            this.employeeRegisterEmailTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeRegisterEmailTextBox.Location = new System.Drawing.Point(506, 187);
            this.employeeRegisterEmailTextBox.Name = "employeeRegisterEmailTextBox";
            this.employeeRegisterEmailTextBox.Size = new System.Drawing.Size(151, 22);
            this.employeeRegisterEmailTextBox.TabIndex = 16;
            // 
            // employeeRegisterPhoneTextBox
            // 
            this.employeeRegisterPhoneTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeRegisterPhoneTextBox.Location = new System.Drawing.Point(145, 182);
            this.employeeRegisterPhoneTextBox.Name = "employeeRegisterPhoneTextBox";
            this.employeeRegisterPhoneTextBox.Size = new System.Drawing.Size(155, 22);
            this.employeeRegisterPhoneTextBox.TabIndex = 16;
            // 
            // employeeRegisterNameTextBox
            // 
            this.employeeRegisterNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeRegisterNameTextBox.Location = new System.Drawing.Point(147, 106);
            this.employeeRegisterNameTextBox.Name = "employeeRegisterNameTextBox";
            this.employeeRegisterNameTextBox.Size = new System.Drawing.Size(151, 22);
            this.employeeRegisterNameTextBox.TabIndex = 16;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label36.Location = new System.Drawing.Point(47, 256);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(59, 16);
            this.label36.TabIndex = 14;
            this.label36.Text = "Address";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label40.Location = new System.Drawing.Point(31, 182);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(98, 16);
            this.label40.TabIndex = 10;
            this.label40.Text = "Phone Number";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label41.Location = new System.Drawing.Point(406, 188);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(42, 16);
            this.label41.TabIndex = 9;
            this.label41.Text = "Email";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label44.Location = new System.Drawing.Point(405, 89);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(91, 16);
            this.label44.TabIndex = 6;
            this.label44.Text = "Register Date";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label45.Location = new System.Drawing.Point(77, 108);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(45, 16);
            this.label45.TabIndex = 5;
            this.label45.Text = "Name";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label46.Location = new System.Drawing.Point(405, 119);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(82, 16);
            this.label46.TabIndex = 4;
            this.label46.Text = "Date Of Birth";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label47.Location = new System.Drawing.Point(71, 146);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(53, 16);
            this.label47.TabIndex = 3;
            this.label47.Text = "Gender";
            // 
            // employeeSearchPanel
            // 
            this.employeeSearchPanel.AutoScroll = true;
            this.employeeSearchPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.employeeSearchPanel.Controls.Add(this.button5);
            this.employeeSearchPanel.Controls.Add(this.label112);
            this.employeeSearchPanel.Controls.Add(this.label111);
            this.employeeSearchPanel.Controls.Add(this.label110);
            this.employeeSearchPanel.Controls.Add(this.label106);
            this.employeeSearchPanel.Controls.Add(this.label107);
            this.employeeSearchPanel.Controls.Add(this.label108);
            this.employeeSearchPanel.Controls.Add(this.label109);
            this.employeeSearchPanel.Controls.Add(this.employeeSearchBrowseButton);
            this.employeeSearchPanel.Controls.Add(this.employeeSearchPictureBox);
            this.employeeSearchPanel.Controls.Add(this.employeeSearchEmployeeIdTextBox);
            this.employeeSearchPanel.Controls.Add(this.label38);
            this.employeeSearchPanel.Controls.Add(this.label52);
            this.employeeSearchPanel.Controls.Add(this.employeeSearchSearchButton);
            this.employeeSearchPanel.Controls.Add(this.employeeSearchTextBox);
            this.employeeSearchPanel.Controls.Add(this.label53);
            this.employeeSearchPanel.Controls.Add(this.employeeSearchUpdateButton);
            this.employeeSearchPanel.Controls.Add(this.employeeSearchDeleteButton);
            this.employeeSearchPanel.Controls.Add(this.employeeSearchDOBUpdate);
            this.employeeSearchPanel.Controls.Add(this.employeeSearchRegisterDateUpdate);
            this.employeeSearchPanel.Controls.Add(this.employeeSearchBGUpdateComboBox);
            this.employeeSearchPanel.Controls.Add(this.label54);
            this.employeeSearchPanel.Controls.Add(this.employeeSearchGenderUpdateComboBox);
            this.employeeSearchPanel.Controls.Add(this.employeeSearchAddressUpdateTextBox);
            this.employeeSearchPanel.Controls.Add(this.employeeSearchEmailUpdateTextBox);
            this.employeeSearchPanel.Controls.Add(this.employeeSearchPhoneUpdateTextBox);
            this.employeeSearchPanel.Controls.Add(this.employeeSearchNameUpdateTextBox);
            this.employeeSearchPanel.Controls.Add(this.label55);
            this.employeeSearchPanel.Controls.Add(this.label59);
            this.employeeSearchPanel.Controls.Add(this.label60);
            this.employeeSearchPanel.Controls.Add(this.label63);
            this.employeeSearchPanel.Controls.Add(this.label65);
            this.employeeSearchPanel.Controls.Add(this.label66);
            this.employeeSearchPanel.Controls.Add(this.label67);
            this.employeeSearchPanel.Controls.Add(this.employeeSearchDataGrid);
            this.employeeSearchPanel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeSearchPanel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.employeeSearchPanel.Location = new System.Drawing.Point(310, 22);
            this.employeeSearchPanel.Name = "employeeSearchPanel";
            this.employeeSearchPanel.Size = new System.Drawing.Size(97, 59);
            this.employeeSearchPanel.TabIndex = 5;
            this.employeeSearchPanel.Visible = false;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.MistyRose;
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button5.Cursor = System.Windows.Forms.Cursors.Default;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button5.Location = new System.Drawing.Point(679, 183);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(128, 26);
            this.button5.TabIndex = 76;
            this.button5.Text = "Cancel Search";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.BackColor = System.Drawing.Color.White;
            this.label112.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label112.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label112.Location = new System.Drawing.Point(334, 13);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(166, 24);
            this.label112.TabIndex = 75;
            this.label112.Text = "Search Employee ";
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label111.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label111.Location = new System.Drawing.Point(224, 185);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(92, 18);
            this.label111.TabIndex = 74;
            this.label111.Text = "Employee ID";
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label110.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label110.Location = new System.Drawing.Point(69, 686);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(62, 18);
            this.label110.TabIndex = 73;
            this.label110.Text = "Address";
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label106.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label106.Location = new System.Drawing.Point(44, 494);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(92, 18);
            this.label106.TabIndex = 72;
            this.label106.Text = "Employee ID";
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label107.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label107.Location = new System.Drawing.Point(37, 611);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(108, 18);
            this.label107.TabIndex = 70;
            this.label107.Text = "Phone Number";
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label108.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label108.Location = new System.Drawing.Point(83, 530);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(48, 18);
            this.label108.TabIndex = 69;
            this.label108.Text = "Name";
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label109.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label109.Location = new System.Drawing.Point(77, 569);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(57, 18);
            this.label109.TabIndex = 68;
            this.label109.Text = "Gender";
            // 
            // employeeSearchBrowseButton
            // 
            this.employeeSearchBrowseButton.BackColor = System.Drawing.Color.MistyRose;
            this.employeeSearchBrowseButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.employeeSearchBrowseButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.employeeSearchBrowseButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeSearchBrowseButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.employeeSearchBrowseButton.Location = new System.Drawing.Point(823, 629);
            this.employeeSearchBrowseButton.Name = "employeeSearchBrowseButton";
            this.employeeSearchBrowseButton.Size = new System.Drawing.Size(96, 26);
            this.employeeSearchBrowseButton.TabIndex = 67;
            this.employeeSearchBrowseButton.Text = "Browse";
            this.employeeSearchBrowseButton.UseVisualStyleBackColor = false;
            this.employeeSearchBrowseButton.Click += new System.EventHandler(this.employeeSearchBrowseButton_Click);
            // 
            // employeeSearchPictureBox
            // 
            this.employeeSearchPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.employeeSearchPictureBox.Location = new System.Drawing.Point(784, 494);
            this.employeeSearchPictureBox.Name = "employeeSearchPictureBox";
            this.employeeSearchPictureBox.Size = new System.Drawing.Size(135, 119);
            this.employeeSearchPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.employeeSearchPictureBox.TabIndex = 66;
            this.employeeSearchPictureBox.TabStop = false;
            // 
            // employeeSearchEmployeeIdTextBox
            // 
            this.employeeSearchEmployeeIdTextBox.Enabled = false;
            this.employeeSearchEmployeeIdTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeSearchEmployeeIdTextBox.Location = new System.Drawing.Point(151, 493);
            this.employeeSearchEmployeeIdTextBox.Name = "employeeSearchEmployeeIdTextBox";
            this.employeeSearchEmployeeIdTextBox.Size = new System.Drawing.Size(171, 24);
            this.employeeSearchEmployeeIdTextBox.TabIndex = 65;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(-189, 218);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(77, 15);
            this.label38.TabIndex = 64;
            this.label38.Text = "Employee ID";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(-47, 511);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(0, 15);
            this.label52.TabIndex = 63;
            // 
            // employeeSearchSearchButton
            // 
            this.employeeSearchSearchButton.BackColor = System.Drawing.Color.MistyRose;
            this.employeeSearchSearchButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.employeeSearchSearchButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.employeeSearchSearchButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeSearchSearchButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.employeeSearchSearchButton.Location = new System.Drawing.Point(534, 182);
            this.employeeSearchSearchButton.Name = "employeeSearchSearchButton";
            this.employeeSearchSearchButton.Size = new System.Drawing.Size(128, 26);
            this.employeeSearchSearchButton.TabIndex = 62;
            this.employeeSearchSearchButton.Text = "Search";
            this.employeeSearchSearchButton.UseVisualStyleBackColor = false;
            this.employeeSearchSearchButton.Click += new System.EventHandler(this.employeeSearchSearchButton_Click);
            // 
            // employeeSearchTextBox
            // 
            this.employeeSearchTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeSearchTextBox.Location = new System.Drawing.Point(338, 184);
            this.employeeSearchTextBox.Name = "employeeSearchTextBox";
            this.employeeSearchTextBox.Size = new System.Drawing.Size(151, 20);
            this.employeeSearchTextBox.TabIndex = 61;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(106, -114);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(77, 15);
            this.label53.TabIndex = 60;
            this.label53.Text = "Employee ID";
            // 
            // employeeSearchUpdateButton
            // 
            this.employeeSearchUpdateButton.BackColor = System.Drawing.Color.MistyRose;
            this.employeeSearchUpdateButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.employeeSearchUpdateButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.employeeSearchUpdateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeSearchUpdateButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.employeeSearchUpdateButton.Location = new System.Drawing.Point(367, 759);
            this.employeeSearchUpdateButton.Name = "employeeSearchUpdateButton";
            this.employeeSearchUpdateButton.Size = new System.Drawing.Size(128, 26);
            this.employeeSearchUpdateButton.TabIndex = 59;
            this.employeeSearchUpdateButton.Text = "Update";
            this.employeeSearchUpdateButton.UseVisualStyleBackColor = false;
            this.employeeSearchUpdateButton.Click += new System.EventHandler(this.employeeSearchUpdateButton_Click);
            // 
            // employeeSearchDeleteButton
            // 
            this.employeeSearchDeleteButton.BackColor = System.Drawing.Color.MistyRose;
            this.employeeSearchDeleteButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.employeeSearchDeleteButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.employeeSearchDeleteButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeSearchDeleteButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.employeeSearchDeleteButton.Location = new System.Drawing.Point(517, 759);
            this.employeeSearchDeleteButton.Name = "employeeSearchDeleteButton";
            this.employeeSearchDeleteButton.Size = new System.Drawing.Size(128, 26);
            this.employeeSearchDeleteButton.TabIndex = 58;
            this.employeeSearchDeleteButton.Text = "Delete";
            this.employeeSearchDeleteButton.UseVisualStyleBackColor = false;
            this.employeeSearchDeleteButton.Click += new System.EventHandler(this.employeeSearchDeleteButton_Click);
            // 
            // employeeSearchDOBUpdate
            // 
            this.employeeSearchDOBUpdate.Location = new System.Drawing.Point(512, 519);
            this.employeeSearchDOBUpdate.Name = "employeeSearchDOBUpdate";
            this.employeeSearchDOBUpdate.Size = new System.Drawing.Size(180, 24);
            this.employeeSearchDOBUpdate.TabIndex = 57;
            // 
            // employeeSearchRegisterDateUpdate
            // 
            this.employeeSearchRegisterDateUpdate.Location = new System.Drawing.Point(512, 489);
            this.employeeSearchRegisterDateUpdate.Name = "employeeSearchRegisterDateUpdate";
            this.employeeSearchRegisterDateUpdate.Size = new System.Drawing.Size(180, 24);
            this.employeeSearchRegisterDateUpdate.TabIndex = 56;
            // 
            // employeeSearchBGUpdateComboBox
            // 
            this.employeeSearchBGUpdateComboBox.FormattingEnabled = true;
            this.employeeSearchBGUpdateComboBox.Items.AddRange(new object[] {
            "A+",
            "A-",
            "B+",
            "B-",
            "AB+",
            "AB-",
            "O+",
            "O-"});
            this.employeeSearchBGUpdateComboBox.Location = new System.Drawing.Point(513, 556);
            this.employeeSearchBGUpdateComboBox.Name = "employeeSearchBGUpdateComboBox";
            this.employeeSearchBGUpdateComboBox.Size = new System.Drawing.Size(179, 26);
            this.employeeSearchBGUpdateComboBox.TabIndex = 55;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label54.Location = new System.Drawing.Point(412, 558);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(93, 18);
            this.label54.TabIndex = 54;
            this.label54.Text = "Blood Group";
            // 
            // employeeSearchGenderUpdateComboBox
            // 
            this.employeeSearchGenderUpdateComboBox.FormattingEnabled = true;
            this.employeeSearchGenderUpdateComboBox.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Others"});
            this.employeeSearchGenderUpdateComboBox.Location = new System.Drawing.Point(151, 567);
            this.employeeSearchGenderUpdateComboBox.Name = "employeeSearchGenderUpdateComboBox";
            this.employeeSearchGenderUpdateComboBox.Size = new System.Drawing.Size(171, 26);
            this.employeeSearchGenderUpdateComboBox.TabIndex = 51;
            // 
            // employeeSearchAddressUpdateTextBox
            // 
            this.employeeSearchAddressUpdateTextBox.Location = new System.Drawing.Point(151, 664);
            this.employeeSearchAddressUpdateTextBox.Name = "employeeSearchAddressUpdateTextBox";
            this.employeeSearchAddressUpdateTextBox.Size = new System.Drawing.Size(511, 63);
            this.employeeSearchAddressUpdateTextBox.TabIndex = 50;
            this.employeeSearchAddressUpdateTextBox.Text = "";
            // 
            // employeeSearchEmailUpdateTextBox
            // 
            this.employeeSearchEmailUpdateTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeSearchEmailUpdateTextBox.Location = new System.Drawing.Point(512, 594);
            this.employeeSearchEmailUpdateTextBox.Name = "employeeSearchEmailUpdateTextBox";
            this.employeeSearchEmailUpdateTextBox.Size = new System.Drawing.Size(180, 24);
            this.employeeSearchEmailUpdateTextBox.TabIndex = 48;
            // 
            // employeeSearchPhoneUpdateTextBox
            // 
            this.employeeSearchPhoneUpdateTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeSearchPhoneUpdateTextBox.Location = new System.Drawing.Point(151, 609);
            this.employeeSearchPhoneUpdateTextBox.Name = "employeeSearchPhoneUpdateTextBox";
            this.employeeSearchPhoneUpdateTextBox.Size = new System.Drawing.Size(171, 24);
            this.employeeSearchPhoneUpdateTextBox.TabIndex = 47;
            // 
            // employeeSearchNameUpdateTextBox
            // 
            this.employeeSearchNameUpdateTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeSearchNameUpdateTextBox.Location = new System.Drawing.Point(151, 527);
            this.employeeSearchNameUpdateTextBox.Name = "employeeSearchNameUpdateTextBox";
            this.employeeSearchNameUpdateTextBox.Size = new System.Drawing.Size(171, 24);
            this.employeeSearchNameUpdateTextBox.TabIndex = 43;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(-162, 359);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(51, 15);
            this.label55.TabIndex = 41;
            this.label55.Text = "Address";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.Location = new System.Drawing.Point(-202, 296);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(91, 15);
            this.label59.TabIndex = 37;
            this.label59.Text = "Phone Number";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label60.Location = new System.Drawing.Point(443, 598);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(45, 18);
            this.label60.TabIndex = 36;
            this.label60.Text = "Email";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label63.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label63.Location = new System.Drawing.Point(409, 490);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(98, 18);
            this.label63.TabIndex = 33;
            this.label63.Text = "Register Date";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label65.Location = new System.Drawing.Point(-154, 220);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(41, 15);
            this.label65.TabIndex = 32;
            this.label65.Text = "Name";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label66.Location = new System.Drawing.Point(412, 522);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(93, 18);
            this.label66.TabIndex = 31;
            this.label66.Text = "Date Of Birth";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.Location = new System.Drawing.Point(-158, 247);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(48, 15);
            this.label67.TabIndex = 30;
            this.label67.Text = "Gender";
            // 
            // employeeSearchDataGrid
            // 
            this.employeeSearchDataGrid.AllowUserToAddRows = false;
            this.employeeSearchDataGrid.AllowUserToDeleteRows = false;
            this.employeeSearchDataGrid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(52)))), ((int)(((byte)(118)))));
            this.employeeSearchDataGrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.employeeSearchDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.employeeSearchDataGrid.Location = new System.Drawing.Point(78, 228);
            this.employeeSearchDataGrid.MultiSelect = false;
            this.employeeSearchDataGrid.Name = "employeeSearchDataGrid";
            this.employeeSearchDataGrid.ReadOnly = true;
            this.employeeSearchDataGrid.Size = new System.Drawing.Size(747, 236);
            this.employeeSearchDataGrid.TabIndex = 0;
            this.employeeSearchDataGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.employeeSearchDataGrid_CellClick);
            // 
            // employeeSearchButton
            // 
            this.employeeSearchButton.BackColor = System.Drawing.Color.MistyRose;
            this.employeeSearchButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.employeeSearchButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.employeeSearchButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeSearchButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.employeeSearchButton.Location = new System.Drawing.Point(133, 3);
            this.employeeSearchButton.Name = "employeeSearchButton";
            this.employeeSearchButton.Size = new System.Drawing.Size(128, 26);
            this.employeeSearchButton.TabIndex = 2;
            this.employeeSearchButton.Text = "Search";
            this.employeeSearchButton.UseVisualStyleBackColor = false;
            this.employeeSearchButton.Click += new System.EventHandler(this.employeeSearchButton_Click);
            // 
            // employeeRegisterButton
            // 
            this.employeeRegisterButton.BackColor = System.Drawing.Color.MistyRose;
            this.employeeRegisterButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.employeeRegisterButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.employeeRegisterButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeRegisterButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.employeeRegisterButton.Location = new System.Drawing.Point(4, 3);
            this.employeeRegisterButton.Name = "employeeRegisterButton";
            this.employeeRegisterButton.Size = new System.Drawing.Size(128, 26);
            this.employeeRegisterButton.TabIndex = 1;
            this.employeeRegisterButton.Text = "Register";
            this.employeeRegisterButton.UseVisualStyleBackColor = false;
            this.employeeRegisterButton.Click += new System.EventHandler(this.employeeRegisterButton_Click);
            // 
            // teacherPanel
            // 
            this.teacherPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(52)))), ((int)(((byte)(118)))));
            this.teacherPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.teacherPanel.Controls.Add(this.teacherAddPanel);
            this.teacherPanel.Controls.Add(this.searchUserButton);
            this.teacherPanel.Controls.Add(this.addUserButton);
            this.teacherPanel.Controls.Add(this.teacherSearchPanel);
            this.teacherPanel.Location = new System.Drawing.Point(277, 35);
            this.teacherPanel.Name = "teacherPanel";
            this.teacherPanel.Size = new System.Drawing.Size(69, 37);
            this.teacherPanel.TabIndex = 2;
            // 
            // teacherAddPanel
            // 
            this.teacherAddPanel.AutoScroll = true;
            this.teacherAddPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(52)))), ((int)(((byte)(118)))));
            this.teacherAddPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.teacherAddPanel.Controls.Add(this.teacherRegisterRegisterDate);
            this.teacherAddPanel.Controls.Add(this.label100);
            this.teacherAddPanel.Controls.Add(this.teacherAddStd6);
            this.teacherAddPanel.Controls.Add(this.teacherAddStd10);
            this.teacherAddPanel.Controls.Add(this.teacherAddStd2);
            this.teacherAddPanel.Controls.Add(this.teacherAddStd5);
            this.teacherAddPanel.Controls.Add(this.teacherAddStd8);
            this.teacherAddPanel.Controls.Add(this.teacherAddStd7);
            this.teacherAddPanel.Controls.Add(this.teacherAddStd1);
            this.teacherAddPanel.Controls.Add(this.teacherAddStd3);
            this.teacherAddPanel.Controls.Add(this.teacherAddStd9);
            this.teacherAddPanel.Controls.Add(this.teacherAddNursary);
            this.teacherAddPanel.Controls.Add(this.teacherAddStd4);
            this.teacherAddPanel.Controls.Add(this.label76);
            this.teacherAddPanel.Controls.Add(this.teacherAddConfirmPasswordTextBox);
            this.teacherAddPanel.Controls.Add(this.label68);
            this.teacherAddPanel.Controls.Add(this.teacherAddPasswordTextBox);
            this.teacherAddPanel.Controls.Add(this.label69);
            this.teacherAddPanel.Controls.Add(this.teacherAddTeacherIDTextBox);
            this.teacherAddPanel.Controls.Add(this.label70);
            this.teacherAddPanel.Controls.Add(this.label72);
            this.teacherAddPanel.Controls.Add(this.teacherAddBrowseButton);
            this.teacherAddPanel.Controls.Add(this.teacherAddPictureBox);
            this.teacherAddPanel.Controls.Add(this.teacherAddBGComboBox);
            this.teacherAddPanel.Controls.Add(this.label73);
            this.teacherAddPanel.Controls.Add(this.teacherAddSubmitButton);
            this.teacherAddPanel.Controls.Add(this.teacherAddDOB);
            this.teacherAddPanel.Controls.Add(this.teacherAddDepartmentComboBox);
            this.teacherAddPanel.Controls.Add(this.label74);
            this.teacherAddPanel.Controls.Add(this.teacherAddSubjectComboBox);
            this.teacherAddPanel.Controls.Add(this.teacherAddGenderComboBox);
            this.teacherAddPanel.Controls.Add(this.teacherAddAddressTextBox);
            this.teacherAddPanel.Controls.Add(this.teacherAddEmailTextBox);
            this.teacherAddPanel.Controls.Add(this.teacherAddPhoneTextBox);
            this.teacherAddPanel.Controls.Add(this.teacherAddNameTextBox);
            this.teacherAddPanel.Controls.Add(this.label75);
            this.teacherAddPanel.Controls.Add(this.label79);
            this.teacherAddPanel.Controls.Add(this.label80);
            this.teacherAddPanel.Controls.Add(this.label84);
            this.teacherAddPanel.Controls.Add(this.label85);
            this.teacherAddPanel.Controls.Add(this.label86);
            this.teacherAddPanel.Controls.Add(this.label87);
            this.teacherAddPanel.Location = new System.Drawing.Point(20, 65);
            this.teacherAddPanel.Name = "teacherAddPanel";
            this.teacherAddPanel.Size = new System.Drawing.Size(100, 104);
            this.teacherAddPanel.TabIndex = 10;
            this.teacherAddPanel.Visible = false;
            // 
            // teacherRegisterRegisterDate
            // 
            this.teacherRegisterRegisterDate.Enabled = false;
            this.teacherRegisterRegisterDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherRegisterRegisterDate.Location = new System.Drawing.Point(596, 87);
            this.teacherRegisterRegisterDate.Name = "teacherRegisterRegisterDate";
            this.teacherRegisterRegisterDate.Size = new System.Drawing.Size(160, 26);
            this.teacherRegisterRegisterDate.TabIndex = 55;
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Enabled = false;
            this.label100.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label100.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label100.Location = new System.Drawing.Point(472, 91);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(108, 20);
            this.label100.TabIndex = 54;
            this.label100.Text = "Register Date";
            // 
            // teacherAddStd6
            // 
            this.teacherAddStd6.AutoSize = true;
            this.teacherAddStd6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherAddStd6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.teacherAddStd6.Location = new System.Drawing.Point(524, 313);
            this.teacherAddStd6.Name = "teacherAddStd6";
            this.teacherAddStd6.Size = new System.Drawing.Size(61, 19);
            this.teacherAddStd6.TabIndex = 53;
            this.teacherAddStd6.Text = "STD-6";
            this.teacherAddStd6.UseVisualStyleBackColor = true;
            // 
            // teacherAddStd10
            // 
            this.teacherAddStd10.AutoSize = true;
            this.teacherAddStd10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherAddStd10.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.teacherAddStd10.Location = new System.Drawing.Point(615, 336);
            this.teacherAddStd10.Name = "teacherAddStd10";
            this.teacherAddStd10.Size = new System.Drawing.Size(68, 19);
            this.teacherAddStd10.TabIndex = 52;
            this.teacherAddStd10.Text = "STD-10";
            this.teacherAddStd10.UseVisualStyleBackColor = true;
            // 
            // teacherAddStd2
            // 
            this.teacherAddStd2.AutoSize = true;
            this.teacherAddStd2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherAddStd2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.teacherAddStd2.Location = new System.Drawing.Point(711, 270);
            this.teacherAddStd2.Name = "teacherAddStd2";
            this.teacherAddStd2.Size = new System.Drawing.Size(61, 19);
            this.teacherAddStd2.TabIndex = 51;
            this.teacherAddStd2.Text = "STD-2";
            this.teacherAddStd2.UseVisualStyleBackColor = true;
            // 
            // teacherAddStd5
            // 
            this.teacherAddStd5.AutoSize = true;
            this.teacherAddStd5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherAddStd5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.teacherAddStd5.Location = new System.Drawing.Point(711, 292);
            this.teacherAddStd5.Name = "teacherAddStd5";
            this.teacherAddStd5.Size = new System.Drawing.Size(61, 19);
            this.teacherAddStd5.TabIndex = 50;
            this.teacherAddStd5.Text = "STD-5";
            this.teacherAddStd5.UseVisualStyleBackColor = true;
            // 
            // teacherAddStd8
            // 
            this.teacherAddStd8.AutoSize = true;
            this.teacherAddStd8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherAddStd8.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.teacherAddStd8.Location = new System.Drawing.Point(711, 317);
            this.teacherAddStd8.Name = "teacherAddStd8";
            this.teacherAddStd8.Size = new System.Drawing.Size(61, 19);
            this.teacherAddStd8.TabIndex = 49;
            this.teacherAddStd8.Text = "STD-8";
            this.teacherAddStd8.UseVisualStyleBackColor = true;
            // 
            // teacherAddStd7
            // 
            this.teacherAddStd7.AutoSize = true;
            this.teacherAddStd7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherAddStd7.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.teacherAddStd7.Location = new System.Drawing.Point(615, 316);
            this.teacherAddStd7.Name = "teacherAddStd7";
            this.teacherAddStd7.Size = new System.Drawing.Size(61, 19);
            this.teacherAddStd7.TabIndex = 48;
            this.teacherAddStd7.Text = "STD-7";
            this.teacherAddStd7.UseVisualStyleBackColor = true;
            // 
            // teacherAddStd1
            // 
            this.teacherAddStd1.AutoSize = true;
            this.teacherAddStd1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherAddStd1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.teacherAddStd1.Location = new System.Drawing.Point(615, 271);
            this.teacherAddStd1.Name = "teacherAddStd1";
            this.teacherAddStd1.Size = new System.Drawing.Size(61, 19);
            this.teacherAddStd1.TabIndex = 47;
            this.teacherAddStd1.Text = "STD-1";
            this.teacherAddStd1.UseVisualStyleBackColor = true;
            // 
            // teacherAddStd3
            // 
            this.teacherAddStd3.AutoSize = true;
            this.teacherAddStd3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherAddStd3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.teacherAddStd3.Location = new System.Drawing.Point(523, 293);
            this.teacherAddStd3.Name = "teacherAddStd3";
            this.teacherAddStd3.Size = new System.Drawing.Size(61, 19);
            this.teacherAddStd3.TabIndex = 46;
            this.teacherAddStd3.Text = "STD-3";
            this.teacherAddStd3.UseVisualStyleBackColor = true;
            // 
            // teacherAddStd9
            // 
            this.teacherAddStd9.AutoSize = true;
            this.teacherAddStd9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherAddStd9.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.teacherAddStd9.Location = new System.Drawing.Point(524, 338);
            this.teacherAddStd9.Name = "teacherAddStd9";
            this.teacherAddStd9.Size = new System.Drawing.Size(61, 19);
            this.teacherAddStd9.TabIndex = 45;
            this.teacherAddStd9.Text = "STD-9";
            this.teacherAddStd9.UseVisualStyleBackColor = true;
            // 
            // teacherAddNursary
            // 
            this.teacherAddNursary.AutoSize = true;
            this.teacherAddNursary.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherAddNursary.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.teacherAddNursary.Location = new System.Drawing.Point(523, 272);
            this.teacherAddNursary.Name = "teacherAddNursary";
            this.teacherAddNursary.Size = new System.Drawing.Size(68, 19);
            this.teacherAddNursary.TabIndex = 44;
            this.teacherAddNursary.Text = "Nursary";
            this.teacherAddNursary.UseVisualStyleBackColor = true;
            // 
            // teacherAddStd4
            // 
            this.teacherAddStd4.AutoSize = true;
            this.teacherAddStd4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherAddStd4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.teacherAddStd4.Location = new System.Drawing.Point(615, 295);
            this.teacherAddStd4.Name = "teacherAddStd4";
            this.teacherAddStd4.Size = new System.Drawing.Size(61, 19);
            this.teacherAddStd4.TabIndex = 43;
            this.teacherAddStd4.Text = "STD-4";
            this.teacherAddStd4.UseVisualStyleBackColor = true;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label76.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label76.Location = new System.Drawing.Point(474, 233);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(221, 20);
            this.label76.TabIndex = 42;
            this.label76.Text = "Classes.......................................";
            // 
            // teacherAddConfirmPasswordTextBox
            // 
            this.teacherAddConfirmPasswordTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherAddConfirmPasswordTextBox.Location = new System.Drawing.Point(189, 230);
            this.teacherAddConfirmPasswordTextBox.Name = "teacherAddConfirmPasswordTextBox";
            this.teacherAddConfirmPasswordTextBox.Size = new System.Drawing.Size(226, 26);
            this.teacherAddConfirmPasswordTextBox.TabIndex = 41;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label68.Location = new System.Drawing.Point(47, 234);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(121, 17);
            this.label68.TabIndex = 40;
            this.label68.Text = "Confirm Password";
            // 
            // teacherAddPasswordTextBox
            // 
            this.teacherAddPasswordTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherAddPasswordTextBox.Location = new System.Drawing.Point(189, 198);
            this.teacherAddPasswordTextBox.Name = "teacherAddPasswordTextBox";
            this.teacherAddPasswordTextBox.Size = new System.Drawing.Size(226, 26);
            this.teacherAddPasswordTextBox.TabIndex = 39;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label69.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label69.Location = new System.Drawing.Point(84, 199);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(78, 20);
            this.label69.TabIndex = 38;
            this.label69.Text = "Password";
            // 
            // teacherAddTeacherIDTextBox
            // 
            this.teacherAddTeacherIDTextBox.Enabled = false;
            this.teacherAddTeacherIDTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherAddTeacherIDTextBox.Location = new System.Drawing.Point(188, 84);
            this.teacherAddTeacherIDTextBox.Name = "teacherAddTeacherIDTextBox";
            this.teacherAddTeacherIDTextBox.Size = new System.Drawing.Size(227, 26);
            this.teacherAddTeacherIDTextBox.TabIndex = 33;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label70.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label70.Location = new System.Drawing.Point(97, 87);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(78, 17);
            this.label70.TabIndex = 32;
            this.label70.Text = "Teacher ID";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.BackColor = System.Drawing.Color.White;
            this.label72.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label72.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label72.Location = new System.Drawing.Point(370, 10);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(192, 25);
            this.label72.TabIndex = 31;
            this.label72.Text = "Teacher Registration";
            // 
            // teacherAddBrowseButton
            // 
            this.teacherAddBrowseButton.BackColor = System.Drawing.Color.MistyRose;
            this.teacherAddBrowseButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.teacherAddBrowseButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.teacherAddBrowseButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherAddBrowseButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.teacherAddBrowseButton.Location = new System.Drawing.Point(838, 199);
            this.teacherAddBrowseButton.Name = "teacherAddBrowseButton";
            this.teacherAddBrowseButton.Size = new System.Drawing.Size(99, 26);
            this.teacherAddBrowseButton.TabIndex = 30;
            this.teacherAddBrowseButton.Text = "Browse";
            this.teacherAddBrowseButton.UseVisualStyleBackColor = false;
            this.teacherAddBrowseButton.Click += new System.EventHandler(this.teacherAddBrowseButton_Click);
            // 
            // teacherAddPictureBox
            // 
            this.teacherAddPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.teacherAddPictureBox.Location = new System.Drawing.Point(795, 39);
            this.teacherAddPictureBox.Name = "teacherAddPictureBox";
            this.teacherAddPictureBox.Size = new System.Drawing.Size(153, 143);
            this.teacherAddPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.teacherAddPictureBox.TabIndex = 29;
            this.teacherAddPictureBox.TabStop = false;
            // 
            // teacherAddBGComboBox
            // 
            this.teacherAddBGComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherAddBGComboBox.FormattingEnabled = true;
            this.teacherAddBGComboBox.Items.AddRange(new object[] {
            "A+",
            "A-",
            "B+",
            "B-",
            "AB+",
            "AB-",
            "O+",
            "O-"});
            this.teacherAddBGComboBox.Location = new System.Drawing.Point(597, 154);
            this.teacherAddBGComboBox.Name = "teacherAddBGComboBox";
            this.teacherAddBGComboBox.Size = new System.Drawing.Size(159, 28);
            this.teacherAddBGComboBox.TabIndex = 28;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label73.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label73.Location = new System.Drawing.Point(481, 161);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(99, 20);
            this.label73.TabIndex = 27;
            this.label73.Text = "Blood Group";
            // 
            // teacherAddSubmitButton
            // 
            this.teacherAddSubmitButton.BackColor = System.Drawing.Color.MistyRose;
            this.teacherAddSubmitButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.teacherAddSubmitButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.teacherAddSubmitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherAddSubmitButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.teacherAddSubmitButton.Location = new System.Drawing.Point(729, 460);
            this.teacherAddSubmitButton.Name = "teacherAddSubmitButton";
            this.teacherAddSubmitButton.Size = new System.Drawing.Size(128, 26);
            this.teacherAddSubmitButton.TabIndex = 26;
            this.teacherAddSubmitButton.Text = "Submit";
            this.teacherAddSubmitButton.UseVisualStyleBackColor = false;
            this.teacherAddSubmitButton.Click += new System.EventHandler(this.teacherAddSubmitButton_Click);
            // 
            // teacherAddDOB
            // 
            this.teacherAddDOB.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherAddDOB.Location = new System.Drawing.Point(188, 340);
            this.teacherAddDOB.Name = "teacherAddDOB";
            this.teacherAddDOB.Size = new System.Drawing.Size(228, 26);
            this.teacherAddDOB.TabIndex = 25;
            // 
            // teacherAddDepartmentComboBox
            // 
            this.teacherAddDepartmentComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherAddDepartmentComboBox.FormattingEnabled = true;
            this.teacherAddDepartmentComboBox.Items.AddRange(new object[] {
            "Science",
            "Arts",
            "Commerce"});
            this.teacherAddDepartmentComboBox.Location = new System.Drawing.Point(599, 189);
            this.teacherAddDepartmentComboBox.Name = "teacherAddDepartmentComboBox";
            this.teacherAddDepartmentComboBox.Size = new System.Drawing.Size(157, 28);
            this.teacherAddDepartmentComboBox.TabIndex = 23;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label74.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label74.Location = new System.Drawing.Point(488, 193);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(94, 20);
            this.label74.TabIndex = 22;
            this.label74.Text = "Department";
            // 
            // teacherAddSubjectComboBox
            // 
            this.teacherAddSubjectComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherAddSubjectComboBox.FormattingEnabled = true;
            this.teacherAddSubjectComboBox.Items.AddRange(new object[] {
            "Bangla",
            "English",
            "Mathemetics",
            "Physics",
            "Chemistry",
            "Biology",
            "History",
            "Social Science",
            "Accounting"});
            this.teacherAddSubjectComboBox.Location = new System.Drawing.Point(596, 118);
            this.teacherAddSubjectComboBox.Name = "teacherAddSubjectComboBox";
            this.teacherAddSubjectComboBox.Size = new System.Drawing.Size(160, 28);
            this.teacherAddSubjectComboBox.TabIndex = 20;
            // 
            // teacherAddGenderComboBox
            // 
            this.teacherAddGenderComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherAddGenderComboBox.FormattingEnabled = true;
            this.teacherAddGenderComboBox.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Others"});
            this.teacherAddGenderComboBox.Location = new System.Drawing.Point(188, 159);
            this.teacherAddGenderComboBox.Name = "teacherAddGenderComboBox";
            this.teacherAddGenderComboBox.Size = new System.Drawing.Size(227, 28);
            this.teacherAddGenderComboBox.TabIndex = 18;
            // 
            // teacherAddAddressTextBox
            // 
            this.teacherAddAddressTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherAddAddressTextBox.Location = new System.Drawing.Point(133, 395);
            this.teacherAddAddressTextBox.Name = "teacherAddAddressTextBox";
            this.teacherAddAddressTextBox.Size = new System.Drawing.Size(545, 63);
            this.teacherAddAddressTextBox.TabIndex = 17;
            this.teacherAddAddressTextBox.Text = "";
            // 
            // teacherAddEmailTextBox
            // 
            this.teacherAddEmailTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherAddEmailTextBox.Location = new System.Drawing.Point(188, 268);
            this.teacherAddEmailTextBox.Name = "teacherAddEmailTextBox";
            this.teacherAddEmailTextBox.Size = new System.Drawing.Size(227, 26);
            this.teacherAddEmailTextBox.TabIndex = 16;
            // 
            // teacherAddPhoneTextBox
            // 
            this.teacherAddPhoneTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherAddPhoneTextBox.Location = new System.Drawing.Point(188, 307);
            this.teacherAddPhoneTextBox.Name = "teacherAddPhoneTextBox";
            this.teacherAddPhoneTextBox.Size = new System.Drawing.Size(228, 26);
            this.teacherAddPhoneTextBox.TabIndex = 16;
            // 
            // teacherAddNameTextBox
            // 
            this.teacherAddNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherAddNameTextBox.Location = new System.Drawing.Point(189, 126);
            this.teacherAddNameTextBox.Name = "teacherAddNameTextBox";
            this.teacherAddNameTextBox.Size = new System.Drawing.Size(227, 26);
            this.teacherAddNameTextBox.TabIndex = 16;
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label75.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label75.Location = new System.Drawing.Point(55, 412);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(62, 18);
            this.label75.TabIndex = 14;
            this.label75.Text = "Address";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label79.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label79.Location = new System.Drawing.Point(54, 310);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(115, 20);
            this.label79.TabIndex = 10;
            this.label79.Text = "Phone Number";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label80.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label80.Location = new System.Drawing.Point(94, 268);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(48, 20);
            this.label80.TabIndex = 9;
            this.label80.Text = "Email";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label84.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label84.Location = new System.Drawing.Point(111, 132);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(51, 20);
            this.label84.TabIndex = 5;
            this.label84.Text = "Name";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label85.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label85.Location = new System.Drawing.Point(64, 344);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(102, 20);
            this.label85.TabIndex = 4;
            this.label85.Text = "Date Of Birth";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label86.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label86.Location = new System.Drawing.Point(103, 165);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(63, 20);
            this.label86.TabIndex = 3;
            this.label86.Text = "Gender";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label87.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label87.Location = new System.Drawing.Point(516, 126);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(63, 20);
            this.label87.TabIndex = 2;
            this.label87.Text = "Subject";
            // 
            // searchUserButton
            // 
            this.searchUserButton.BackColor = System.Drawing.Color.MistyRose;
            this.searchUserButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.searchUserButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.searchUserButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchUserButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.searchUserButton.Location = new System.Drawing.Point(137, 3);
            this.searchUserButton.Name = "searchUserButton";
            this.searchUserButton.Size = new System.Drawing.Size(128, 26);
            this.searchUserButton.TabIndex = 0;
            this.searchUserButton.Text = "Search";
            this.searchUserButton.UseVisualStyleBackColor = false;
            this.searchUserButton.Click += new System.EventHandler(this.searchUserButton_Click);
            // 
            // addUserButton
            // 
            this.addUserButton.BackColor = System.Drawing.Color.MistyRose;
            this.addUserButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.addUserButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.addUserButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addUserButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.addUserButton.Location = new System.Drawing.Point(3, 3);
            this.addUserButton.Name = "addUserButton";
            this.addUserButton.Size = new System.Drawing.Size(128, 26);
            this.addUserButton.TabIndex = 0;
            this.addUserButton.Text = "Add";
            this.addUserButton.UseVisualStyleBackColor = false;
            this.addUserButton.Click += new System.EventHandler(this.addUserButton_Click);
            // 
            // teacherSearchPanel
            // 
            this.teacherSearchPanel.AutoScroll = true;
            this.teacherSearchPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(52)))), ((int)(((byte)(118)))));
            this.teacherSearchPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.teacherSearchPanel.Controls.Add(this.button6);
            this.teacherSearchPanel.Controls.Add(this.teacherSearchSearchButton);
            this.teacherSearchPanel.Controls.Add(this.label99);
            this.teacherSearchPanel.Controls.Add(this.teacherSearchTextBox);
            this.teacherSearchPanel.Controls.Add(this.label98);
            this.teacherSearchPanel.Controls.Add(this.teacherSearchDelateButton);
            this.teacherSearchPanel.Controls.Add(this.label97);
            this.teacherSearchPanel.Controls.Add(this.label96);
            this.teacherSearchPanel.Controls.Add(this.teacherSearchStd6);
            this.teacherSearchPanel.Controls.Add(this.teacherSearchStd10);
            this.teacherSearchPanel.Controls.Add(this.teacherSearchStd2);
            this.teacherSearchPanel.Controls.Add(this.teacherSearchStd5);
            this.teacherSearchPanel.Controls.Add(this.teacherSearchStd8);
            this.teacherSearchPanel.Controls.Add(this.teacherSearchStd7);
            this.teacherSearchPanel.Controls.Add(this.teacherSearchStd1);
            this.teacherSearchPanel.Controls.Add(this.teacherSearchStd3);
            this.teacherSearchPanel.Controls.Add(this.teacherSearchStd9);
            this.teacherSearchPanel.Controls.Add(this.teacherSearchNursary);
            this.teacherSearchPanel.Controls.Add(this.teacherSearchStd4);
            this.teacherSearchPanel.Controls.Add(this.label77);
            this.teacherSearchPanel.Controls.Add(this.teacherSearchConfirmPasswordTextBox);
            this.teacherSearchPanel.Controls.Add(this.label78);
            this.teacherSearchPanel.Controls.Add(this.teacherSearchPasswordTextBox);
            this.teacherSearchPanel.Controls.Add(this.label81);
            this.teacherSearchPanel.Controls.Add(this.teacherSearchTeacherIdTextBox);
            this.teacherSearchPanel.Controls.Add(this.label82);
            this.teacherSearchPanel.Controls.Add(this.teacherSearchBrowseButton);
            this.teacherSearchPanel.Controls.Add(this.teacherSearchPictureBox);
            this.teacherSearchPanel.Controls.Add(this.teacherSearchBGComboBox);
            this.teacherSearchPanel.Controls.Add(this.label83);
            this.teacherSearchPanel.Controls.Add(this.teacherSearchUpdateButton);
            this.teacherSearchPanel.Controls.Add(this.teacherSearchDOB);
            this.teacherSearchPanel.Controls.Add(this.teacherSearchDepartmentComboBox);
            this.teacherSearchPanel.Controls.Add(this.label88);
            this.teacherSearchPanel.Controls.Add(this.teacherSearchSubjectComboBox);
            this.teacherSearchPanel.Controls.Add(this.teacherSearchGenderComboBox);
            this.teacherSearchPanel.Controls.Add(this.teacherSearchAddressTextBox);
            this.teacherSearchPanel.Controls.Add(this.teacherSearchEmailTextBox);
            this.teacherSearchPanel.Controls.Add(this.teacherSearchPhoneTextBox);
            this.teacherSearchPanel.Controls.Add(this.teacherSearchNameTextBox);
            this.teacherSearchPanel.Controls.Add(this.label89);
            this.teacherSearchPanel.Controls.Add(this.label90);
            this.teacherSearchPanel.Controls.Add(this.label91);
            this.teacherSearchPanel.Controls.Add(this.label92);
            this.teacherSearchPanel.Controls.Add(this.label93);
            this.teacherSearchPanel.Controls.Add(this.label94);
            this.teacherSearchPanel.Controls.Add(this.label95);
            this.teacherSearchPanel.Controls.Add(this.label43);
            this.teacherSearchPanel.Controls.Add(this.searchInUserSearchPanelButton);
            this.teacherSearchPanel.Controls.Add(this.teacherSearchDataGrid);
            this.teacherSearchPanel.Controls.Add(this.idTextBoxSearch);
            this.teacherSearchPanel.Controls.Add(this.bunifuCustomLabel13);
            this.teacherSearchPanel.Location = new System.Drawing.Point(209, 55);
            this.teacherSearchPanel.Name = "teacherSearchPanel";
            this.teacherSearchPanel.Size = new System.Drawing.Size(185, 77);
            this.teacherSearchPanel.TabIndex = 9;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.MistyRose;
            this.button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button6.Location = new System.Drawing.Point(872, 166);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(96, 26);
            this.button6.TabIndex = 100;
            this.button6.Text = "Cancel Search";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // teacherSearchSearchButton
            // 
            this.teacherSearchSearchButton.BackColor = System.Drawing.Color.MistyRose;
            this.teacherSearchSearchButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.teacherSearchSearchButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.teacherSearchSearchButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherSearchSearchButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.teacherSearchSearchButton.Location = new System.Drawing.Point(873, 131);
            this.teacherSearchSearchButton.Name = "teacherSearchSearchButton";
            this.teacherSearchSearchButton.Size = new System.Drawing.Size(96, 26);
            this.teacherSearchSearchButton.TabIndex = 99;
            this.teacherSearchSearchButton.Text = "Search";
            this.teacherSearchSearchButton.UseVisualStyleBackColor = false;
            this.teacherSearchSearchButton.Click += new System.EventHandler(this.teacherSearchSearchButton_Click);
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label99.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label99.Location = new System.Drawing.Point(805, 58);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(96, 20);
            this.label99.TabIndex = 98;
            this.label99.Text = "Teacher ID :";
            // 
            // teacherSearchTextBox
            // 
            this.teacherSearchTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherSearchTextBox.Location = new System.Drawing.Point(809, 87);
            this.teacherSearchTextBox.Name = "teacherSearchTextBox";
            this.teacherSearchTextBox.Size = new System.Drawing.Size(158, 26);
            this.teacherSearchTextBox.TabIndex = 97;
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.BackColor = System.Drawing.Color.White;
            this.label98.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label98.ForeColor = System.Drawing.Color.Maroon;
            this.label98.Location = new System.Drawing.Point(383, 6);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(171, 26);
            this.label98.TabIndex = 96;
            this.label98.Text = "Search Teacher ";
            // 
            // teacherSearchDelateButton
            // 
            this.teacherSearchDelateButton.BackColor = System.Drawing.Color.MistyRose;
            this.teacherSearchDelateButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.teacherSearchDelateButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.teacherSearchDelateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherSearchDelateButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.teacherSearchDelateButton.Location = new System.Drawing.Point(845, 656);
            this.teacherSearchDelateButton.Name = "teacherSearchDelateButton";
            this.teacherSearchDelateButton.Size = new System.Drawing.Size(128, 26);
            this.teacherSearchDelateButton.TabIndex = 95;
            this.teacherSearchDelateButton.Text = "Delete";
            this.teacherSearchDelateButton.UseVisualStyleBackColor = false;
            this.teacherSearchDelateButton.Click += new System.EventHandler(this.teacherSearchDelateButton_Click);
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label97.Location = new System.Drawing.Point(196, 681);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(0, 20);
            this.label97.TabIndex = 94;
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label96.Location = new System.Drawing.Point(192, 663);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(0, 20);
            this.label96.TabIndex = 93;
            // 
            // teacherSearchStd6
            // 
            this.teacherSearchStd6.AutoSize = true;
            this.teacherSearchStd6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherSearchStd6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.teacherSearchStd6.Location = new System.Drawing.Point(488, 510);
            this.teacherSearchStd6.Name = "teacherSearchStd6";
            this.teacherSearchStd6.Size = new System.Drawing.Size(61, 19);
            this.teacherSearchStd6.TabIndex = 92;
            this.teacherSearchStd6.Text = "STD-6";
            this.teacherSearchStd6.UseVisualStyleBackColor = true;
            // 
            // teacherSearchStd10
            // 
            this.teacherSearchStd10.AutoSize = true;
            this.teacherSearchStd10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherSearchStd10.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.teacherSearchStd10.Location = new System.Drawing.Point(579, 533);
            this.teacherSearchStd10.Name = "teacherSearchStd10";
            this.teacherSearchStd10.Size = new System.Drawing.Size(68, 19);
            this.teacherSearchStd10.TabIndex = 91;
            this.teacherSearchStd10.Text = "STD-10";
            this.teacherSearchStd10.UseVisualStyleBackColor = true;
            // 
            // teacherSearchStd2
            // 
            this.teacherSearchStd2.AutoSize = true;
            this.teacherSearchStd2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherSearchStd2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.teacherSearchStd2.Location = new System.Drawing.Point(675, 467);
            this.teacherSearchStd2.Name = "teacherSearchStd2";
            this.teacherSearchStd2.Size = new System.Drawing.Size(61, 19);
            this.teacherSearchStd2.TabIndex = 90;
            this.teacherSearchStd2.Text = "STD-2";
            this.teacherSearchStd2.UseVisualStyleBackColor = true;
            // 
            // teacherSearchStd5
            // 
            this.teacherSearchStd5.AutoSize = true;
            this.teacherSearchStd5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherSearchStd5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.teacherSearchStd5.Location = new System.Drawing.Point(675, 489);
            this.teacherSearchStd5.Name = "teacherSearchStd5";
            this.teacherSearchStd5.Size = new System.Drawing.Size(61, 19);
            this.teacherSearchStd5.TabIndex = 89;
            this.teacherSearchStd5.Text = "STD-5";
            this.teacherSearchStd5.UseVisualStyleBackColor = true;
            // 
            // teacherSearchStd8
            // 
            this.teacherSearchStd8.AutoSize = true;
            this.teacherSearchStd8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherSearchStd8.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.teacherSearchStd8.Location = new System.Drawing.Point(675, 514);
            this.teacherSearchStd8.Name = "teacherSearchStd8";
            this.teacherSearchStd8.Size = new System.Drawing.Size(61, 19);
            this.teacherSearchStd8.TabIndex = 88;
            this.teacherSearchStd8.Text = "STD-8";
            this.teacherSearchStd8.UseVisualStyleBackColor = true;
            // 
            // teacherSearchStd7
            // 
            this.teacherSearchStd7.AutoSize = true;
            this.teacherSearchStd7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherSearchStd7.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.teacherSearchStd7.Location = new System.Drawing.Point(579, 513);
            this.teacherSearchStd7.Name = "teacherSearchStd7";
            this.teacherSearchStd7.Size = new System.Drawing.Size(61, 19);
            this.teacherSearchStd7.TabIndex = 87;
            this.teacherSearchStd7.Text = "STD-7";
            this.teacherSearchStd7.UseVisualStyleBackColor = true;
            // 
            // teacherSearchStd1
            // 
            this.teacherSearchStd1.AutoSize = true;
            this.teacherSearchStd1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherSearchStd1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.teacherSearchStd1.Location = new System.Drawing.Point(579, 468);
            this.teacherSearchStd1.Name = "teacherSearchStd1";
            this.teacherSearchStd1.Size = new System.Drawing.Size(61, 19);
            this.teacherSearchStd1.TabIndex = 86;
            this.teacherSearchStd1.Text = "STD-1";
            this.teacherSearchStd1.UseVisualStyleBackColor = true;
            // 
            // teacherSearchStd3
            // 
            this.teacherSearchStd3.AutoSize = true;
            this.teacherSearchStd3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherSearchStd3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.teacherSearchStd3.Location = new System.Drawing.Point(487, 490);
            this.teacherSearchStd3.Name = "teacherSearchStd3";
            this.teacherSearchStd3.Size = new System.Drawing.Size(61, 19);
            this.teacherSearchStd3.TabIndex = 85;
            this.teacherSearchStd3.Text = "STD-3";
            this.teacherSearchStd3.UseVisualStyleBackColor = true;
            // 
            // teacherSearchStd9
            // 
            this.teacherSearchStd9.AutoSize = true;
            this.teacherSearchStd9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherSearchStd9.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.teacherSearchStd9.Location = new System.Drawing.Point(488, 535);
            this.teacherSearchStd9.Name = "teacherSearchStd9";
            this.teacherSearchStd9.Size = new System.Drawing.Size(61, 19);
            this.teacherSearchStd9.TabIndex = 84;
            this.teacherSearchStd9.Text = "STD-9";
            this.teacherSearchStd9.UseVisualStyleBackColor = true;
            // 
            // teacherSearchNursary
            // 
            this.teacherSearchNursary.AutoSize = true;
            this.teacherSearchNursary.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherSearchNursary.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.teacherSearchNursary.Location = new System.Drawing.Point(487, 469);
            this.teacherSearchNursary.Name = "teacherSearchNursary";
            this.teacherSearchNursary.Size = new System.Drawing.Size(68, 19);
            this.teacherSearchNursary.TabIndex = 83;
            this.teacherSearchNursary.Text = "Nursary";
            this.teacherSearchNursary.UseVisualStyleBackColor = true;
            // 
            // teacherSearchStd4
            // 
            this.teacherSearchStd4.AutoSize = true;
            this.teacherSearchStd4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherSearchStd4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.teacherSearchStd4.Location = new System.Drawing.Point(579, 492);
            this.teacherSearchStd4.Name = "teacherSearchStd4";
            this.teacherSearchStd4.Size = new System.Drawing.Size(61, 19);
            this.teacherSearchStd4.TabIndex = 82;
            this.teacherSearchStd4.Text = "STD-4";
            this.teacherSearchStd4.UseVisualStyleBackColor = true;
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label77.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label77.Location = new System.Drawing.Point(438, 430);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(221, 20);
            this.label77.TabIndex = 81;
            this.label77.Text = "Classes.......................................";
            // 
            // teacherSearchConfirmPasswordTextBox
            // 
            this.teacherSearchConfirmPasswordTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherSearchConfirmPasswordTextBox.Location = new System.Drawing.Point(153, 427);
            this.teacherSearchConfirmPasswordTextBox.Name = "teacherSearchConfirmPasswordTextBox";
            this.teacherSearchConfirmPasswordTextBox.Size = new System.Drawing.Size(226, 26);
            this.teacherSearchConfirmPasswordTextBox.TabIndex = 80;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label78.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label78.Location = new System.Drawing.Point(6, 431);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(121, 17);
            this.label78.TabIndex = 79;
            this.label78.Text = "Confirm Password";
            // 
            // teacherSearchPasswordTextBox
            // 
            this.teacherSearchPasswordTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherSearchPasswordTextBox.Location = new System.Drawing.Point(153, 395);
            this.teacherSearchPasswordTextBox.Name = "teacherSearchPasswordTextBox";
            this.teacherSearchPasswordTextBox.Size = new System.Drawing.Size(226, 26);
            this.teacherSearchPasswordTextBox.TabIndex = 78;
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label81.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label81.Location = new System.Drawing.Point(49, 396);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(78, 20);
            this.label81.TabIndex = 77;
            this.label81.Text = "Password";
            // 
            // teacherSearchTeacherIdTextBox
            // 
            this.teacherSearchTeacherIdTextBox.Enabled = false;
            this.teacherSearchTeacherIdTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherSearchTeacherIdTextBox.Location = new System.Drawing.Point(152, 281);
            this.teacherSearchTeacherIdTextBox.Name = "teacherSearchTeacherIdTextBox";
            this.teacherSearchTeacherIdTextBox.Size = new System.Drawing.Size(227, 26);
            this.teacherSearchTeacherIdTextBox.TabIndex = 76;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label82.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label82.Location = new System.Drawing.Point(51, 284);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(78, 17);
            this.label82.TabIndex = 75;
            this.label82.Text = "Teacher ID";
            // 
            // teacherSearchBrowseButton
            // 
            this.teacherSearchBrowseButton.BackColor = System.Drawing.Color.MistyRose;
            this.teacherSearchBrowseButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.teacherSearchBrowseButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.teacherSearchBrowseButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherSearchBrowseButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.teacherSearchBrowseButton.Location = new System.Drawing.Point(834, 438);
            this.teacherSearchBrowseButton.Name = "teacherSearchBrowseButton";
            this.teacherSearchBrowseButton.Size = new System.Drawing.Size(99, 26);
            this.teacherSearchBrowseButton.TabIndex = 74;
            this.teacherSearchBrowseButton.Text = "Browse";
            this.teacherSearchBrowseButton.UseVisualStyleBackColor = false;
            this.teacherSearchBrowseButton.Click += new System.EventHandler(this.teacherSearchBrowseButton_Click);
            // 
            // teacherSearchPictureBox
            // 
            this.teacherSearchPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.teacherSearchPictureBox.Location = new System.Drawing.Point(791, 278);
            this.teacherSearchPictureBox.Name = "teacherSearchPictureBox";
            this.teacherSearchPictureBox.Size = new System.Drawing.Size(153, 143);
            this.teacherSearchPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.teacherSearchPictureBox.TabIndex = 73;
            this.teacherSearchPictureBox.TabStop = false;
            // 
            // teacherSearchBGComboBox
            // 
            this.teacherSearchBGComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherSearchBGComboBox.FormattingEnabled = true;
            this.teacherSearchBGComboBox.Items.AddRange(new object[] {
            "A+",
            "A-",
            "B+",
            "B-",
            "AB+",
            "AB-",
            "O+",
            "O-"});
            this.teacherSearchBGComboBox.Location = new System.Drawing.Point(563, 351);
            this.teacherSearchBGComboBox.Name = "teacherSearchBGComboBox";
            this.teacherSearchBGComboBox.Size = new System.Drawing.Size(157, 28);
            this.teacherSearchBGComboBox.TabIndex = 72;
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label83.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label83.Location = new System.Drawing.Point(448, 355);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(99, 20);
            this.label83.TabIndex = 71;
            this.label83.Text = "Blood Group";
            // 
            // teacherSearchUpdateButton
            // 
            this.teacherSearchUpdateButton.BackColor = System.Drawing.Color.MistyRose;
            this.teacherSearchUpdateButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.teacherSearchUpdateButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.teacherSearchUpdateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherSearchUpdateButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.teacherSearchUpdateButton.Location = new System.Drawing.Point(693, 657);
            this.teacherSearchUpdateButton.Name = "teacherSearchUpdateButton";
            this.teacherSearchUpdateButton.Size = new System.Drawing.Size(128, 26);
            this.teacherSearchUpdateButton.TabIndex = 70;
            this.teacherSearchUpdateButton.Text = "Update";
            this.teacherSearchUpdateButton.UseVisualStyleBackColor = false;
            this.teacherSearchUpdateButton.Click += new System.EventHandler(this.teacherSearchUpdateButton_Click);
            // 
            // teacherSearchDOB
            // 
            this.teacherSearchDOB.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherSearchDOB.Location = new System.Drawing.Point(563, 277);
            this.teacherSearchDOB.Name = "teacherSearchDOB";
            this.teacherSearchDOB.Size = new System.Drawing.Size(156, 26);
            this.teacherSearchDOB.TabIndex = 69;
            // 
            // teacherSearchDepartmentComboBox
            // 
            this.teacherSearchDepartmentComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherSearchDepartmentComboBox.FormattingEnabled = true;
            this.teacherSearchDepartmentComboBox.Items.AddRange(new object[] {
            "Science",
            "Arts",
            "Commerce"});
            this.teacherSearchDepartmentComboBox.Location = new System.Drawing.Point(563, 386);
            this.teacherSearchDepartmentComboBox.Name = "teacherSearchDepartmentComboBox";
            this.teacherSearchDepartmentComboBox.Size = new System.Drawing.Size(157, 28);
            this.teacherSearchDepartmentComboBox.TabIndex = 68;
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label88.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label88.Location = new System.Drawing.Point(452, 390);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(94, 20);
            this.label88.TabIndex = 67;
            this.label88.Text = "Department";
            // 
            // teacherSearchSubjectComboBox
            // 
            this.teacherSearchSubjectComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherSearchSubjectComboBox.FormattingEnabled = true;
            this.teacherSearchSubjectComboBox.Items.AddRange(new object[] {
            "Bangla",
            "English",
            "Mathemetics",
            "Physics",
            "Chemistry",
            "Biology",
            "History",
            "Social Science",
            "Accounting"});
            this.teacherSearchSubjectComboBox.Location = new System.Drawing.Point(563, 315);
            this.teacherSearchSubjectComboBox.Name = "teacherSearchSubjectComboBox";
            this.teacherSearchSubjectComboBox.Size = new System.Drawing.Size(157, 28);
            this.teacherSearchSubjectComboBox.TabIndex = 66;
            // 
            // teacherSearchGenderComboBox
            // 
            this.teacherSearchGenderComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherSearchGenderComboBox.FormattingEnabled = true;
            this.teacherSearchGenderComboBox.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Others"});
            this.teacherSearchGenderComboBox.Location = new System.Drawing.Point(152, 356);
            this.teacherSearchGenderComboBox.Name = "teacherSearchGenderComboBox";
            this.teacherSearchGenderComboBox.Size = new System.Drawing.Size(227, 28);
            this.teacherSearchGenderComboBox.TabIndex = 65;
            // 
            // teacherSearchAddressTextBox
            // 
            this.teacherSearchAddressTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherSearchAddressTextBox.Location = new System.Drawing.Point(97, 592);
            this.teacherSearchAddressTextBox.Name = "teacherSearchAddressTextBox";
            this.teacherSearchAddressTextBox.Size = new System.Drawing.Size(545, 63);
            this.teacherSearchAddressTextBox.TabIndex = 64;
            this.teacherSearchAddressTextBox.Text = "";
            // 
            // teacherSearchEmailTextBox
            // 
            this.teacherSearchEmailTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherSearchEmailTextBox.Location = new System.Drawing.Point(152, 465);
            this.teacherSearchEmailTextBox.Name = "teacherSearchEmailTextBox";
            this.teacherSearchEmailTextBox.Size = new System.Drawing.Size(227, 26);
            this.teacherSearchEmailTextBox.TabIndex = 63;
            // 
            // teacherSearchPhoneTextBox
            // 
            this.teacherSearchPhoneTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherSearchPhoneTextBox.Location = new System.Drawing.Point(152, 504);
            this.teacherSearchPhoneTextBox.Name = "teacherSearchPhoneTextBox";
            this.teacherSearchPhoneTextBox.Size = new System.Drawing.Size(228, 26);
            this.teacherSearchPhoneTextBox.TabIndex = 62;
            // 
            // teacherSearchNameTextBox
            // 
            this.teacherSearchNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherSearchNameTextBox.Location = new System.Drawing.Point(153, 323);
            this.teacherSearchNameTextBox.Name = "teacherSearchNameTextBox";
            this.teacherSearchNameTextBox.Size = new System.Drawing.Size(227, 26);
            this.teacherSearchNameTextBox.TabIndex = 61;
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label89.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label89.Location = new System.Drawing.Point(19, 609);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(68, 20);
            this.label89.TabIndex = 60;
            this.label89.Text = "Address";
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label90.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label90.Location = new System.Drawing.Point(10, 507);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(115, 20);
            this.label90.TabIndex = 59;
            this.label90.Text = "Phone Number";
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label91.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label91.Location = new System.Drawing.Point(76, 465);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(48, 20);
            this.label91.TabIndex = 58;
            this.label91.Text = "Email";
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label92.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label92.Location = new System.Drawing.Point(76, 329);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(51, 20);
            this.label92.TabIndex = 57;
            this.label92.Text = "Name";
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label93.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label93.Location = new System.Drawing.Point(443, 281);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(102, 20);
            this.label93.TabIndex = 56;
            this.label93.Text = "Date Of Birth";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label94.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label94.Location = new System.Drawing.Point(65, 362);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(63, 20);
            this.label94.TabIndex = 55;
            this.label94.Text = "Gender";
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label95.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label95.Location = new System.Drawing.Point(481, 319);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(63, 20);
            this.label95.TabIndex = 54;
            this.label95.Text = "Subject";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label43.Location = new System.Drawing.Point(365, -153);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(133, 26);
            this.label43.TabIndex = 33;
            this.label43.Text = "Search User";
            // 
            // searchInUserSearchPanelButton
            // 
            this.searchInUserSearchPanelButton.BackColor = System.Drawing.Color.Silver;
            this.searchInUserSearchPanelButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.searchInUserSearchPanelButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.searchInUserSearchPanelButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchInUserSearchPanelButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.searchInUserSearchPanelButton.Location = new System.Drawing.Point(719, -134);
            this.searchInUserSearchPanelButton.Name = "searchInUserSearchPanelButton";
            this.searchInUserSearchPanelButton.Size = new System.Drawing.Size(99, 26);
            this.searchInUserSearchPanelButton.TabIndex = 5;
            this.searchInUserSearchPanelButton.Text = "Search";
            this.searchInUserSearchPanelButton.UseVisualStyleBackColor = false;
            // 
            // teacherSearchDataGrid
            // 
            this.teacherSearchDataGrid.AllowUserToAddRows = false;
            this.teacherSearchDataGrid.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.teacherSearchDataGrid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.teacherSearchDataGrid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(52)))), ((int)(((byte)(118)))));
            this.teacherSearchDataGrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.teacherSearchDataGrid.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.teacherSearchDataGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.teacherSearchDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.teacherSearchDataGrid.EnableHeadersVisualStyles = false;
            this.teacherSearchDataGrid.Location = new System.Drawing.Point(12, 65);
            this.teacherSearchDataGrid.Name = "teacherSearchDataGrid";
            this.teacherSearchDataGrid.ReadOnly = true;
            this.teacherSearchDataGrid.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.teacherSearchDataGrid.Size = new System.Drawing.Size(768, 185);
            this.teacherSearchDataGrid.TabIndex = 4;
            this.teacherSearchDataGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.teacherSearchDataGrid_CellClick);
            // 
            // idTextBoxSearch
            // 
            this.idTextBoxSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idTextBoxSearch.Location = new System.Drawing.Point(577, -131);
            this.idTextBoxSearch.Name = "idTextBoxSearch";
            this.idTextBoxSearch.Size = new System.Drawing.Size(93, 26);
            this.idTextBoxSearch.TabIndex = 3;
            // 
            // bunifuCustomLabel13
            // 
            this.bunifuCustomLabel13.AutoSize = true;
            this.bunifuCustomLabel13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.bunifuCustomLabel13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel13.Location = new System.Drawing.Point(521, -128);
            this.bunifuCustomLabel13.Name = "bunifuCustomLabel13";
            this.bunifuCustomLabel13.Size = new System.Drawing.Size(26, 20);
            this.bunifuCustomLabel13.TabIndex = 2;
            this.bunifuCustomLabel13.Text = "ID";
            // 
            // studentPromotionPanel
            // 
            this.studentPromotionPanel.AutoScroll = true;
            this.studentPromotionPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.studentPromotionPanel.Controls.Add(this.button3);
            this.studentPromotionPanel.Controls.Add(this.label105);
            this.studentPromotionPanel.Controls.Add(this.label104);
            this.studentPromotionPanel.Controls.Add(this.studentPromotionClassUpdateComboBox);
            this.studentPromotionPanel.Controls.Add(this.label64);
            this.studentPromotionPanel.Controls.Add(this.studentPromotionClassComboBox);
            this.studentPromotionPanel.Controls.Add(this.studentPromotionSearchButton);
            this.studentPromotionPanel.Controls.Add(this.label50);
            this.studentPromotionPanel.Controls.Add(this.studentPromotionPromoteButton);
            this.studentPromotionPanel.Controls.Add(this.studentPromotionDataGrid);
            this.studentPromotionPanel.Location = new System.Drawing.Point(163, 44);
            this.studentPromotionPanel.Name = "studentPromotionPanel";
            this.studentPromotionPanel.Size = new System.Drawing.Size(95, 65);
            this.studentPromotionPanel.TabIndex = 6;
            this.studentPromotionPanel.Visible = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.MistyRose;
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button3.Cursor = System.Windows.Forms.Cursors.Default;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button3.Location = new System.Drawing.Point(400, 174);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(128, 26);
            this.button3.TabIndex = 68;
            this.button3.Text = "Cancel Search";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label105.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label105.Location = new System.Drawing.Point(506, 473);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(0, 20);
            this.label105.TabIndex = 67;
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.BackColor = System.Drawing.Color.White;
            this.label104.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label104.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label104.Location = new System.Drawing.Point(376, 41);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(165, 24);
            this.label104.TabIndex = 66;
            this.label104.Text = "Student Promotion";
            // 
            // studentPromotionClassUpdateComboBox
            // 
            this.studentPromotionClassUpdateComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentPromotionClassUpdateComboBox.FormattingEnabled = true;
            this.studentPromotionClassUpdateComboBox.Items.AddRange(new object[] {
            "Nursary",
            "STD-1",
            "STD-2",
            "STD-3",
            "STD-4",
            "STD-5",
            "STD-6",
            "STD-7",
            "STD-8",
            "STD-9",
            "STD-10"});
            this.studentPromotionClassUpdateComboBox.Location = new System.Drawing.Point(640, 324);
            this.studentPromotionClassUpdateComboBox.Name = "studentPromotionClassUpdateComboBox";
            this.studentPromotionClassUpdateComboBox.Size = new System.Drawing.Size(151, 24);
            this.studentPromotionClassUpdateComboBox.TabIndex = 65;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label64.Location = new System.Drawing.Point(579, 324);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(48, 20);
            this.label64.TabIndex = 64;
            this.label64.Text = "Class";
            // 
            // studentPromotionClassComboBox
            // 
            this.studentPromotionClassComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentPromotionClassComboBox.FormattingEnabled = true;
            this.studentPromotionClassComboBox.Items.AddRange(new object[] {
            "Nursary",
            "STD-1",
            "STD-2",
            "STD-3",
            "STD-4",
            "STD-5",
            "STD-6",
            "STD-7",
            "STD-8",
            "STD-9",
            "STD-10"});
            this.studentPromotionClassComboBox.Location = new System.Drawing.Point(208, 135);
            this.studentPromotionClassComboBox.Name = "studentPromotionClassComboBox";
            this.studentPromotionClassComboBox.Size = new System.Drawing.Size(151, 24);
            this.studentPromotionClassComboBox.TabIndex = 63;
            // 
            // studentPromotionSearchButton
            // 
            this.studentPromotionSearchButton.BackColor = System.Drawing.Color.MistyRose;
            this.studentPromotionSearchButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.studentPromotionSearchButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.studentPromotionSearchButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentPromotionSearchButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.studentPromotionSearchButton.Location = new System.Drawing.Point(400, 135);
            this.studentPromotionSearchButton.Name = "studentPromotionSearchButton";
            this.studentPromotionSearchButton.Size = new System.Drawing.Size(128, 26);
            this.studentPromotionSearchButton.TabIndex = 62;
            this.studentPromotionSearchButton.Text = "Search";
            this.studentPromotionSearchButton.UseVisualStyleBackColor = false;
            this.studentPromotionSearchButton.Click += new System.EventHandler(this.studentPromotionSearchButton_Click);
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label50.Location = new System.Drawing.Point(90, 138);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(94, 20);
            this.label50.TabIndex = 60;
            this.label50.Text = "Class Name";
            // 
            // studentPromotionPromoteButton
            // 
            this.studentPromotionPromoteButton.BackColor = System.Drawing.Color.MistyRose;
            this.studentPromotionPromoteButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.studentPromotionPromoteButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.studentPromotionPromoteButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentPromotionPromoteButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.studentPromotionPromoteButton.Location = new System.Drawing.Point(686, 381);
            this.studentPromotionPromoteButton.Name = "studentPromotionPromoteButton";
            this.studentPromotionPromoteButton.Size = new System.Drawing.Size(103, 26);
            this.studentPromotionPromoteButton.TabIndex = 58;
            this.studentPromotionPromoteButton.Text = "Promote";
            this.studentPromotionPromoteButton.UseVisualStyleBackColor = false;
            this.studentPromotionPromoteButton.Click += new System.EventHandler(this.studentPromotionPromoteButton_Click);
            // 
            // studentPromotionDataGrid
            // 
            this.studentPromotionDataGrid.AllowUserToAddRows = false;
            this.studentPromotionDataGrid.AllowUserToDeleteRows = false;
            this.studentPromotionDataGrid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(52)))), ((int)(((byte)(118)))));
            this.studentPromotionDataGrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.studentPromotionDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.studentPromotionDataGrid.Location = new System.Drawing.Point(108, 229);
            this.studentPromotionDataGrid.Name = "studentPromotionDataGrid";
            this.studentPromotionDataGrid.ReadOnly = true;
            this.studentPromotionDataGrid.Size = new System.Drawing.Size(426, 236);
            this.studentPromotionDataGrid.TabIndex = 0;
            // 
            // studentRegistrationPanel
            // 
            this.studentRegistrationPanel.AutoScroll = true;
            this.studentRegistrationPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.studentRegistrationPanel.Controls.Add(this.studentRegistrationSearchPanel);
            this.studentRegistrationPanel.Controls.Add(this.studentRegistrationRegisterPanel);
            this.studentRegistrationPanel.Controls.Add(this.studentRegistrationSearchButton);
            this.studentRegistrationPanel.Controls.Add(this.studentRegistrationRegisterButton);
            this.studentRegistrationPanel.Location = new System.Drawing.Point(28, 44);
            this.studentRegistrationPanel.Name = "studentRegistrationPanel";
            this.studentRegistrationPanel.Size = new System.Drawing.Size(96, 65);
            this.studentRegistrationPanel.TabIndex = 3;
            this.studentRegistrationPanel.Visible = false;
            // 
            // studentRegistrationSearchPanel
            // 
            this.studentRegistrationSearchPanel.AutoScroll = true;
            this.studentRegistrationSearchPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchDataGrid);
            this.studentRegistrationSearchPanel.Controls.Add(this.label117);
            this.studentRegistrationSearchPanel.Controls.Add(this.button4);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchPasswordTextBox);
            this.studentRegistrationSearchPanel.Controls.Add(this.label62);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchConfirmPasswordTextBox);
            this.studentRegistrationSearchPanel.Controls.Add(this.label61);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchBGComboBox);
            this.studentRegistrationSearchPanel.Controls.Add(this.label57);
            this.studentRegistrationSearchPanel.Controls.Add(this.label49);
            this.studentRegistrationSearchPanel.Controls.Add(this.button1);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchPictudeBox);
            this.studentRegistrationSearchPanel.Controls.Add(this.label34);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchSearchButton);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchIDTextBox);
            this.studentRegistrationSearchPanel.Controls.Add(this.label33);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchUpdateButton);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchDeleteButton);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchDOBUpdate);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchAdmissionDateUpdate);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchDepartmentUpdateComboBox);
            this.studentRegistrationSearchPanel.Controls.Add(this.label17);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchClassUpdateComboBox);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchGenderUpdateComboBox);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchAddressUpdateTextBox);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchEmailUpdateTextBox);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchPhoneUpdateTextBox);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchMotherOccupationUpdateTextBox);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchMotherNameUpdateTextBox);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchFatherOccupationUpdateTextBox);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchFatherNameUpdateTextBox);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchNameUpdateTextBox);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchAdmissionNumberUpdateTextBox);
            this.studentRegistrationSearchPanel.Controls.Add(this.label18);
            this.studentRegistrationSearchPanel.Controls.Add(this.label19);
            this.studentRegistrationSearchPanel.Controls.Add(this.label20);
            this.studentRegistrationSearchPanel.Controls.Add(this.label21);
            this.studentRegistrationSearchPanel.Controls.Add(this.label22);
            this.studentRegistrationSearchPanel.Controls.Add(this.label23);
            this.studentRegistrationSearchPanel.Controls.Add(this.label24);
            this.studentRegistrationSearchPanel.Controls.Add(this.label25);
            this.studentRegistrationSearchPanel.Controls.Add(this.label26);
            this.studentRegistrationSearchPanel.Controls.Add(this.label27);
            this.studentRegistrationSearchPanel.Controls.Add(this.label28);
            this.studentRegistrationSearchPanel.Controls.Add(this.label29);
            this.studentRegistrationSearchPanel.Controls.Add(this.label30);
            this.studentRegistrationSearchPanel.Controls.Add(this.label32);
            this.studentRegistrationSearchPanel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationSearchPanel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.studentRegistrationSearchPanel.Location = new System.Drawing.Point(34, 51);
            this.studentRegistrationSearchPanel.Name = "studentRegistrationSearchPanel";
            this.studentRegistrationSearchPanel.Size = new System.Drawing.Size(94, 50);
            this.studentRegistrationSearchPanel.TabIndex = 6;
            this.studentRegistrationSearchPanel.Visible = false;
            // 
            // studentRegistrationSearchDataGrid
            // 
            this.studentRegistrationSearchDataGrid.AllowUserToAddRows = false;
            this.studentRegistrationSearchDataGrid.AllowUserToDeleteRows = false;
            this.studentRegistrationSearchDataGrid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(52)))), ((int)(((byte)(118)))));
            this.studentRegistrationSearchDataGrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.studentRegistrationSearchDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.studentRegistrationSearchDataGrid.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.studentRegistrationSearchDataGrid.Location = new System.Drawing.Point(23, 159);
            this.studentRegistrationSearchDataGrid.Name = "studentRegistrationSearchDataGrid";
            this.studentRegistrationSearchDataGrid.ReadOnly = true;
            this.studentRegistrationSearchDataGrid.Size = new System.Drawing.Size(861, 192);
            this.studentRegistrationSearchDataGrid.TabIndex = 75;
            this.studentRegistrationSearchDataGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.studentRegistrationSearchDataGrid_CellContentClick);
            // 
            // label117
            // 
            this.label117.AutoSize = true;
            this.label117.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label117.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label117.Location = new System.Drawing.Point(761, 743);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(0, 20);
            this.label117.TabIndex = 74;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.MistyRose;
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button4.Location = new System.Drawing.Point(797, 107);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(128, 26);
            this.button4.TabIndex = 73;
            this.button4.Text = "Cancel Search";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // studentRegistrationSearchPasswordTextBox
            // 
            this.studentRegistrationSearchPasswordTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationSearchPasswordTextBox.Location = new System.Drawing.Point(191, 482);
            this.studentRegistrationSearchPasswordTextBox.Name = "studentRegistrationSearchPasswordTextBox";
            this.studentRegistrationSearchPasswordTextBox.Size = new System.Drawing.Size(195, 23);
            this.studentRegistrationSearchPasswordTextBox.TabIndex = 72;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label62.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label62.Location = new System.Drawing.Point(105, 484);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(78, 20);
            this.label62.TabIndex = 71;
            this.label62.Text = "Password";
            // 
            // studentRegistrationSearchConfirmPasswordTextBox
            // 
            this.studentRegistrationSearchConfirmPasswordTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationSearchConfirmPasswordTextBox.Location = new System.Drawing.Point(191, 517);
            this.studentRegistrationSearchConfirmPasswordTextBox.Name = "studentRegistrationSearchConfirmPasswordTextBox";
            this.studentRegistrationSearchConfirmPasswordTextBox.Size = new System.Drawing.Size(195, 23);
            this.studentRegistrationSearchConfirmPasswordTextBox.TabIndex = 70;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label61.Location = new System.Drawing.Point(52, 520);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(137, 20);
            this.label61.TabIndex = 69;
            this.label61.Text = "Confirm Password";
            // 
            // studentRegistrationSearchBGComboBox
            // 
            this.studentRegistrationSearchBGComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationSearchBGComboBox.FormattingEnabled = true;
            this.studentRegistrationSearchBGComboBox.Items.AddRange(new object[] {
            "A+",
            "A-",
            "B+",
            "B-",
            "AB+",
            "AB-",
            "O+",
            "O-"});
            this.studentRegistrationSearchBGComboBox.Location = new System.Drawing.Point(554, 491);
            this.studentRegistrationSearchBGComboBox.Name = "studentRegistrationSearchBGComboBox";
            this.studentRegistrationSearchBGComboBox.Size = new System.Drawing.Size(187, 23);
            this.studentRegistrationSearchBGComboBox.TabIndex = 68;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label57.Location = new System.Drawing.Point(439, 491);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(99, 20);
            this.label57.TabIndex = 67;
            this.label57.Text = "Blood Group";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.BackColor = System.Drawing.Color.White;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.ForeColor = System.Drawing.Color.Maroon;
            this.label49.Location = new System.Drawing.Point(348, 12);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(322, 24);
            this.label49.TabIndex = 66;
            this.label49.Text = "Search and Update or Delete Student";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.MistyRose;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button1.Location = new System.Drawing.Point(847, 499);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(87, 26);
            this.button1.TabIndex = 65;
            this.button1.Text = "Browse";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.studentRegistrationSearchBrowseButton_Click);
            // 
            // studentRegistrationSearchPictudeBox
            // 
            this.studentRegistrationSearchPictudeBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.studentRegistrationSearchPictudeBox.Location = new System.Drawing.Point(799, 369);
            this.studentRegistrationSearchPictudeBox.Name = "studentRegistrationSearchPictudeBox";
            this.studentRegistrationSearchPictudeBox.Size = new System.Drawing.Size(144, 123);
            this.studentRegistrationSearchPictudeBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.studentRegistrationSearchPictudeBox.TabIndex = 64;
            this.studentRegistrationSearchPictudeBox.TabStop = false;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(175, 916);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(0, 15);
            this.label34.TabIndex = 63;
            // 
            // studentRegistrationSearchSearchButton
            // 
            this.studentRegistrationSearchSearchButton.BackColor = System.Drawing.Color.MistyRose;
            this.studentRegistrationSearchSearchButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.studentRegistrationSearchSearchButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.studentRegistrationSearchSearchButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationSearchSearchButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.studentRegistrationSearchSearchButton.Location = new System.Drawing.Point(654, 108);
            this.studentRegistrationSearchSearchButton.Name = "studentRegistrationSearchSearchButton";
            this.studentRegistrationSearchSearchButton.Size = new System.Drawing.Size(128, 26);
            this.studentRegistrationSearchSearchButton.TabIndex = 62;
            this.studentRegistrationSearchSearchButton.Text = "Search";
            this.studentRegistrationSearchSearchButton.UseVisualStyleBackColor = false;
            this.studentRegistrationSearchSearchButton.Click += new System.EventHandler(this.studentRegistrationSearchSearchButton_Click);
            // 
            // studentRegistrationSearchIDTextBox
            // 
            this.studentRegistrationSearchIDTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationSearchIDTextBox.Location = new System.Drawing.Point(454, 110);
            this.studentRegistrationSearchIDTextBox.Name = "studentRegistrationSearchIDTextBox";
            this.studentRegistrationSearchIDTextBox.Size = new System.Drawing.Size(151, 22);
            this.studentRegistrationSearchIDTextBox.TabIndex = 61;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label33.Location = new System.Drawing.Point(348, 110);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(87, 20);
            this.label33.TabIndex = 60;
            this.label33.Text = "Student ID";
            // 
            // studentRegistrationSearchUpdateButton
            // 
            this.studentRegistrationSearchUpdateButton.BackColor = System.Drawing.Color.MistyRose;
            this.studentRegistrationSearchUpdateButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.studentRegistrationSearchUpdateButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.studentRegistrationSearchUpdateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationSearchUpdateButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.studentRegistrationSearchUpdateButton.Location = new System.Drawing.Point(486, 867);
            this.studentRegistrationSearchUpdateButton.Name = "studentRegistrationSearchUpdateButton";
            this.studentRegistrationSearchUpdateButton.Size = new System.Drawing.Size(128, 26);
            this.studentRegistrationSearchUpdateButton.TabIndex = 59;
            this.studentRegistrationSearchUpdateButton.Text = "Update";
            this.studentRegistrationSearchUpdateButton.UseVisualStyleBackColor = false;
            this.studentRegistrationSearchUpdateButton.Click += new System.EventHandler(this.studentRegistrationSearchUpdateButton_Click);
            // 
            // studentRegistrationSearchDeleteButton
            // 
            this.studentRegistrationSearchDeleteButton.BackColor = System.Drawing.Color.MistyRose;
            this.studentRegistrationSearchDeleteButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.studentRegistrationSearchDeleteButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.studentRegistrationSearchDeleteButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationSearchDeleteButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.studentRegistrationSearchDeleteButton.Location = new System.Drawing.Point(640, 867);
            this.studentRegistrationSearchDeleteButton.Name = "studentRegistrationSearchDeleteButton";
            this.studentRegistrationSearchDeleteButton.Size = new System.Drawing.Size(128, 26);
            this.studentRegistrationSearchDeleteButton.TabIndex = 58;
            this.studentRegistrationSearchDeleteButton.Text = "Delete";
            this.studentRegistrationSearchDeleteButton.UseVisualStyleBackColor = false;
            this.studentRegistrationSearchDeleteButton.Click += new System.EventHandler(this.studentRegistrationSearchDeleteButton_Click);
            // 
            // studentRegistrationSearchDOBUpdate
            // 
            this.studentRegistrationSearchDOBUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationSearchDOBUpdate.Location = new System.Drawing.Point(551, 410);
            this.studentRegistrationSearchDOBUpdate.Name = "studentRegistrationSearchDOBUpdate";
            this.studentRegistrationSearchDOBUpdate.Size = new System.Drawing.Size(190, 21);
            this.studentRegistrationSearchDOBUpdate.TabIndex = 57;
            // 
            // studentRegistrationSearchAdmissionDateUpdate
            // 
            this.studentRegistrationSearchAdmissionDateUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationSearchAdmissionDateUpdate.Location = new System.Drawing.Point(551, 369);
            this.studentRegistrationSearchAdmissionDateUpdate.Name = "studentRegistrationSearchAdmissionDateUpdate";
            this.studentRegistrationSearchAdmissionDateUpdate.Size = new System.Drawing.Size(190, 21);
            this.studentRegistrationSearchAdmissionDateUpdate.TabIndex = 56;
            // 
            // studentRegistrationSearchDepartmentUpdateComboBox
            // 
            this.studentRegistrationSearchDepartmentUpdateComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationSearchDepartmentUpdateComboBox.FormattingEnabled = true;
            this.studentRegistrationSearchDepartmentUpdateComboBox.Items.AddRange(new object[] {
            "Science",
            "Arts",
            "Commerce"});
            this.studentRegistrationSearchDepartmentUpdateComboBox.Location = new System.Drawing.Point(554, 528);
            this.studentRegistrationSearchDepartmentUpdateComboBox.Name = "studentRegistrationSearchDepartmentUpdateComboBox";
            this.studentRegistrationSearchDepartmentUpdateComboBox.Size = new System.Drawing.Size(187, 23);
            this.studentRegistrationSearchDepartmentUpdateComboBox.TabIndex = 55;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label17.Location = new System.Drawing.Point(438, 528);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(94, 20);
            this.label17.TabIndex = 54;
            this.label17.Text = "Department";
            // 
            // studentRegistrationSearchClassUpdateComboBox
            // 
            this.studentRegistrationSearchClassUpdateComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationSearchClassUpdateComboBox.FormattingEnabled = true;
            this.studentRegistrationSearchClassUpdateComboBox.Items.AddRange(new object[] {
            "Nursary",
            "STD-1",
            "STD-2",
            "STD-3",
            "STD-4",
            "STD-5",
            "STD-6",
            "STD-7",
            "STD-8",
            "STD-9",
            "STD-10"});
            this.studentRegistrationSearchClassUpdateComboBox.Location = new System.Drawing.Point(553, 450);
            this.studentRegistrationSearchClassUpdateComboBox.Name = "studentRegistrationSearchClassUpdateComboBox";
            this.studentRegistrationSearchClassUpdateComboBox.Size = new System.Drawing.Size(187, 23);
            this.studentRegistrationSearchClassUpdateComboBox.TabIndex = 52;
            // 
            // studentRegistrationSearchGenderUpdateComboBox
            // 
            this.studentRegistrationSearchGenderUpdateComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationSearchGenderUpdateComboBox.FormattingEnabled = true;
            this.studentRegistrationSearchGenderUpdateComboBox.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Others"});
            this.studentRegistrationSearchGenderUpdateComboBox.Location = new System.Drawing.Point(191, 441);
            this.studentRegistrationSearchGenderUpdateComboBox.Name = "studentRegistrationSearchGenderUpdateComboBox";
            this.studentRegistrationSearchGenderUpdateComboBox.Size = new System.Drawing.Size(195, 24);
            this.studentRegistrationSearchGenderUpdateComboBox.TabIndex = 51;
            // 
            // studentRegistrationSearchAddressUpdateTextBox
            // 
            this.studentRegistrationSearchAddressUpdateTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationSearchAddressUpdateTextBox.Location = new System.Drawing.Point(159, 777);
            this.studentRegistrationSearchAddressUpdateTextBox.Name = "studentRegistrationSearchAddressUpdateTextBox";
            this.studentRegistrationSearchAddressUpdateTextBox.Size = new System.Drawing.Size(476, 63);
            this.studentRegistrationSearchAddressUpdateTextBox.TabIndex = 50;
            this.studentRegistrationSearchAddressUpdateTextBox.Text = "";
            // 
            // studentRegistrationSearchEmailUpdateTextBox
            // 
            this.studentRegistrationSearchEmailUpdateTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationSearchEmailUpdateTextBox.Location = new System.Drawing.Point(577, 703);
            this.studentRegistrationSearchEmailUpdateTextBox.Name = "studentRegistrationSearchEmailUpdateTextBox";
            this.studentRegistrationSearchEmailUpdateTextBox.Size = new System.Drawing.Size(165, 24);
            this.studentRegistrationSearchEmailUpdateTextBox.TabIndex = 48;
            // 
            // studentRegistrationSearchPhoneUpdateTextBox
            // 
            this.studentRegistrationSearchPhoneUpdateTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationSearchPhoneUpdateTextBox.Location = new System.Drawing.Point(189, 698);
            this.studentRegistrationSearchPhoneUpdateTextBox.Name = "studentRegistrationSearchPhoneUpdateTextBox";
            this.studentRegistrationSearchPhoneUpdateTextBox.Size = new System.Drawing.Size(196, 24);
            this.studentRegistrationSearchPhoneUpdateTextBox.TabIndex = 47;
            // 
            // studentRegistrationSearchMotherOccupationUpdateTextBox
            // 
            this.studentRegistrationSearchMotherOccupationUpdateTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationSearchMotherOccupationUpdateTextBox.Location = new System.Drawing.Point(577, 664);
            this.studentRegistrationSearchMotherOccupationUpdateTextBox.Name = "studentRegistrationSearchMotherOccupationUpdateTextBox";
            this.studentRegistrationSearchMotherOccupationUpdateTextBox.Size = new System.Drawing.Size(165, 24);
            this.studentRegistrationSearchMotherOccupationUpdateTextBox.TabIndex = 46;
            // 
            // studentRegistrationSearchMotherNameUpdateTextBox
            // 
            this.studentRegistrationSearchMotherNameUpdateTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationSearchMotherNameUpdateTextBox.Location = new System.Drawing.Point(189, 659);
            this.studentRegistrationSearchMotherNameUpdateTextBox.Name = "studentRegistrationSearchMotherNameUpdateTextBox";
            this.studentRegistrationSearchMotherNameUpdateTextBox.Size = new System.Drawing.Size(196, 24);
            this.studentRegistrationSearchMotherNameUpdateTextBox.TabIndex = 45;
            // 
            // studentRegistrationSearchFatherOccupationUpdateTextBox
            // 
            this.studentRegistrationSearchFatherOccupationUpdateTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationSearchFatherOccupationUpdateTextBox.Location = new System.Drawing.Point(577, 626);
            this.studentRegistrationSearchFatherOccupationUpdateTextBox.Name = "studentRegistrationSearchFatherOccupationUpdateTextBox";
            this.studentRegistrationSearchFatherOccupationUpdateTextBox.Size = new System.Drawing.Size(165, 24);
            this.studentRegistrationSearchFatherOccupationUpdateTextBox.TabIndex = 44;
            // 
            // studentRegistrationSearchFatherNameUpdateTextBox
            // 
            this.studentRegistrationSearchFatherNameUpdateTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationSearchFatherNameUpdateTextBox.Location = new System.Drawing.Point(189, 621);
            this.studentRegistrationSearchFatherNameUpdateTextBox.Name = "studentRegistrationSearchFatherNameUpdateTextBox";
            this.studentRegistrationSearchFatherNameUpdateTextBox.Size = new System.Drawing.Size(196, 24);
            this.studentRegistrationSearchFatherNameUpdateTextBox.TabIndex = 49;
            // 
            // studentRegistrationSearchNameUpdateTextBox
            // 
            this.studentRegistrationSearchNameUpdateTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationSearchNameUpdateTextBox.Location = new System.Drawing.Point(191, 405);
            this.studentRegistrationSearchNameUpdateTextBox.Name = "studentRegistrationSearchNameUpdateTextBox";
            this.studentRegistrationSearchNameUpdateTextBox.Size = new System.Drawing.Size(195, 23);
            this.studentRegistrationSearchNameUpdateTextBox.TabIndex = 43;
            // 
            // studentRegistrationSearchAdmissionNumberUpdateTextBox
            // 
            this.studentRegistrationSearchAdmissionNumberUpdateTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationSearchAdmissionNumberUpdateTextBox.Location = new System.Drawing.Point(191, 365);
            this.studentRegistrationSearchAdmissionNumberUpdateTextBox.Name = "studentRegistrationSearchAdmissionNumberUpdateTextBox";
            this.studentRegistrationSearchAdmissionNumberUpdateTextBox.Size = new System.Drawing.Size(195, 23);
            this.studentRegistrationSearchAdmissionNumberUpdateTextBox.TabIndex = 42;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label18.Location = new System.Drawing.Point(79, 797);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(68, 20);
            this.label18.TabIndex = 41;
            this.label18.Text = "Address";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label19.Location = new System.Drawing.Point(425, 629);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(152, 20);
            this.label19.TabIndex = 40;
            this.label19.Text = "Father\'s Occupation";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label20.Location = new System.Drawing.Point(67, 657);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(116, 20);
            this.label20.TabIndex = 39;
            this.label20.Text = "Mother\'s Name";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label21.Location = new System.Drawing.Point(425, 666);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(155, 20);
            this.label21.TabIndex = 38;
            this.label21.Text = "Mother\'s Occupation";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label22.Location = new System.Drawing.Point(67, 695);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(115, 20);
            this.label22.TabIndex = 37;
            this.label22.Text = "Phone Number";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label23.Location = new System.Drawing.Point(470, 702);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(48, 20);
            this.label23.TabIndex = 36;
            this.label23.Text = "Email";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label24.Location = new System.Drawing.Point(67, 623);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(113, 20);
            this.label24.TabIndex = 35;
            this.label24.Text = "Father\'s Name";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label25.Location = new System.Drawing.Point(13, 574);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(920, 20);
            this.label25.TabIndex = 34;
            this.label25.Text = "Guardian Information ____________________________________________________________" +
    "________________________";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label26.Location = new System.Drawing.Point(431, 370);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(121, 20);
            this.label26.TabIndex = 33;
            this.label26.Text = "Admission Date";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label27.Location = new System.Drawing.Point(117, 407);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(51, 20);
            this.label27.TabIndex = 32;
            this.label27.Text = "Name";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label28.Location = new System.Drawing.Point(441, 413);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(102, 20);
            this.label28.TabIndex = 31;
            this.label28.Text = "Date Of Birth";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label29.Location = new System.Drawing.Point(113, 445);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(63, 20);
            this.label29.TabIndex = 30;
            this.label29.Text = "Gender";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label30.Location = new System.Drawing.Point(461, 452);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(48, 20);
            this.label30.TabIndex = 29;
            this.label30.Text = "Class";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label32.Location = new System.Drawing.Point(48, 365);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(142, 20);
            this.label32.TabIndex = 27;
            this.label32.Text = "Admission Number";
            // 
            // studentRegistrationRegisterPanel
            // 
            this.studentRegistrationRegisterPanel.AutoScroll = true;
            this.studentRegistrationRegisterPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.studentRegistrationRegisterPanel.Controls.Add(this.studentRegistrationRegisterConfirmPasswordTextBox);
            this.studentRegistrationRegisterPanel.Controls.Add(this.label31);
            this.studentRegistrationRegisterPanel.Controls.Add(this.studentRegistrationRegisterPasswordTextBox);
            this.studentRegistrationRegisterPanel.Controls.Add(this.label2);
            this.studentRegistrationRegisterPanel.Controls.Add(this.studentRegistrationRegisterStudentIdTextBox);
            this.studentRegistrationRegisterPanel.Controls.Add(this.label56);
            this.studentRegistrationRegisterPanel.Controls.Add(this.label48);
            this.studentRegistrationRegisterPanel.Controls.Add(this.studentRegistrationRegisterBrowseButton);
            this.studentRegistrationRegisterPanel.Controls.Add(this.studentRegistrationRegisterPictureBox);
            this.studentRegistrationRegisterPanel.Controls.Add(this.studentRegistrationRegisterBGComboBox);
            this.studentRegistrationRegisterPanel.Controls.Add(this.label39);
            this.studentRegistrationRegisterPanel.Controls.Add(this.studentRegistrationRegisterSubmitButton);
            this.studentRegistrationRegisterPanel.Controls.Add(this.studentRegistrationRegisterDOB);
            this.studentRegistrationRegisterPanel.Controls.Add(this.studentRegistrationRegisterAdmissionDate);
            this.studentRegistrationRegisterPanel.Controls.Add(this.studentRegistrationRegisterDepartmentComboBox);
            this.studentRegistrationRegisterPanel.Controls.Add(this.label16);
            this.studentRegistrationRegisterPanel.Controls.Add(this.studentRegistrationRegisterClassComboBox);
            this.studentRegistrationRegisterPanel.Controls.Add(this.studentRegistrationRegisterGenderComboBox);
            this.studentRegistrationRegisterPanel.Controls.Add(this.studentRegistrationRegisterAddressTextBox);
            this.studentRegistrationRegisterPanel.Controls.Add(this.studentRegistrationRegisterEmailTextBox);
            this.studentRegistrationRegisterPanel.Controls.Add(this.studentRegistrationRegisterPhoneTextBox);
            this.studentRegistrationRegisterPanel.Controls.Add(this.studentRegistrationRegisterMotherOccupationTextBox);
            this.studentRegistrationRegisterPanel.Controls.Add(this.studentRegistrationRegisterMotherNameTextBox);
            this.studentRegistrationRegisterPanel.Controls.Add(this.studentRegistrationRegisterFatherOccupationTextBox);
            this.studentRegistrationRegisterPanel.Controls.Add(this.studentRegistrationRegisterFatherNameTextBox);
            this.studentRegistrationRegisterPanel.Controls.Add(this.studentRegistrationRegisterNameTextBox);
            this.studentRegistrationRegisterPanel.Controls.Add(this.studentRegistrationRegisterAdmissionNumberTextBox);
            this.studentRegistrationRegisterPanel.Controls.Add(this.label15);
            this.studentRegistrationRegisterPanel.Controls.Add(this.label9);
            this.studentRegistrationRegisterPanel.Controls.Add(this.label10);
            this.studentRegistrationRegisterPanel.Controls.Add(this.label11);
            this.studentRegistrationRegisterPanel.Controls.Add(this.label12);
            this.studentRegistrationRegisterPanel.Controls.Add(this.label13);
            this.studentRegistrationRegisterPanel.Controls.Add(this.label14);
            this.studentRegistrationRegisterPanel.Controls.Add(this.label8);
            this.studentRegistrationRegisterPanel.Controls.Add(this.label7);
            this.studentRegistrationRegisterPanel.Controls.Add(this.label6);
            this.studentRegistrationRegisterPanel.Controls.Add(this.label5);
            this.studentRegistrationRegisterPanel.Controls.Add(this.label4);
            this.studentRegistrationRegisterPanel.Controls.Add(this.label3);
            this.studentRegistrationRegisterPanel.Controls.Add(this.label1);
            this.studentRegistrationRegisterPanel.Location = new System.Drawing.Point(274, 5);
            this.studentRegistrationRegisterPanel.Name = "studentRegistrationRegisterPanel";
            this.studentRegistrationRegisterPanel.Size = new System.Drawing.Size(105, 60);
            this.studentRegistrationRegisterPanel.TabIndex = 4;
            this.studentRegistrationRegisterPanel.Visible = false;
            // 
            // studentRegistrationRegisterConfirmPasswordTextBox
            // 
            this.studentRegistrationRegisterConfirmPasswordTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationRegisterConfirmPasswordTextBox.Location = new System.Drawing.Point(189, 230);
            this.studentRegistrationRegisterConfirmPasswordTextBox.Name = "studentRegistrationRegisterConfirmPasswordTextBox";
            this.studentRegistrationRegisterConfirmPasswordTextBox.Size = new System.Drawing.Size(226, 26);
            this.studentRegistrationRegisterConfirmPasswordTextBox.TabIndex = 41;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label31.Location = new System.Drawing.Point(43, 234);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(137, 20);
            this.label31.TabIndex = 40;
            this.label31.Text = "Confirm Password";
            // 
            // studentRegistrationRegisterPasswordTextBox
            // 
            this.studentRegistrationRegisterPasswordTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationRegisterPasswordTextBox.Location = new System.Drawing.Point(189, 198);
            this.studentRegistrationRegisterPasswordTextBox.Name = "studentRegistrationRegisterPasswordTextBox";
            this.studentRegistrationRegisterPasswordTextBox.Size = new System.Drawing.Size(226, 26);
            this.studentRegistrationRegisterPasswordTextBox.TabIndex = 39;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(80, 199);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 20);
            this.label2.TabIndex = 38;
            this.label2.Text = "Password";
            // 
            // studentRegistrationRegisterStudentIdTextBox
            // 
            this.studentRegistrationRegisterStudentIdTextBox.Enabled = false;
            this.studentRegistrationRegisterStudentIdTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationRegisterStudentIdTextBox.Location = new System.Drawing.Point(188, 59);
            this.studentRegistrationRegisterStudentIdTextBox.Name = "studentRegistrationRegisterStudentIdTextBox";
            this.studentRegistrationRegisterStudentIdTextBox.Size = new System.Drawing.Size(227, 26);
            this.studentRegistrationRegisterStudentIdTextBox.TabIndex = 33;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label56.Location = new System.Drawing.Point(93, 62);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(87, 20);
            this.label56.TabIndex = 32;
            this.label56.Text = "Student ID";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.BackColor = System.Drawing.Color.White;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label48.Location = new System.Drawing.Point(333, 5);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(187, 25);
            this.label48.TabIndex = 31;
            this.label48.Text = "Student Registration";
            // 
            // studentRegistrationRegisterBrowseButton
            // 
            this.studentRegistrationRegisterBrowseButton.BackColor = System.Drawing.Color.MistyRose;
            this.studentRegistrationRegisterBrowseButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.studentRegistrationRegisterBrowseButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.studentRegistrationRegisterBrowseButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationRegisterBrowseButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.studentRegistrationRegisterBrowseButton.Location = new System.Drawing.Point(838, 199);
            this.studentRegistrationRegisterBrowseButton.Name = "studentRegistrationRegisterBrowseButton";
            this.studentRegistrationRegisterBrowseButton.Size = new System.Drawing.Size(99, 26);
            this.studentRegistrationRegisterBrowseButton.TabIndex = 30;
            this.studentRegistrationRegisterBrowseButton.Text = "Browse";
            this.studentRegistrationRegisterBrowseButton.UseVisualStyleBackColor = false;
            this.studentRegistrationRegisterBrowseButton.Click += new System.EventHandler(this.studentRegistrationRegisterBrowseButton_Click);
            // 
            // studentRegistrationRegisterPictureBox
            // 
            this.studentRegistrationRegisterPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.studentRegistrationRegisterPictureBox.Location = new System.Drawing.Point(795, 39);
            this.studentRegistrationRegisterPictureBox.Name = "studentRegistrationRegisterPictureBox";
            this.studentRegistrationRegisterPictureBox.Size = new System.Drawing.Size(153, 143);
            this.studentRegistrationRegisterPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.studentRegistrationRegisterPictureBox.TabIndex = 29;
            this.studentRegistrationRegisterPictureBox.TabStop = false;
            // 
            // studentRegistrationRegisterBGComboBox
            // 
            this.studentRegistrationRegisterBGComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationRegisterBGComboBox.FormattingEnabled = true;
            this.studentRegistrationRegisterBGComboBox.Items.AddRange(new object[] {
            "A+",
            "A-",
            "B+",
            "B-",
            "AB+",
            "AB-",
            "O+",
            "O-"});
            this.studentRegistrationRegisterBGComboBox.Location = new System.Drawing.Point(588, 181);
            this.studentRegistrationRegisterBGComboBox.Name = "studentRegistrationRegisterBGComboBox";
            this.studentRegistrationRegisterBGComboBox.Size = new System.Drawing.Size(164, 28);
            this.studentRegistrationRegisterBGComboBox.TabIndex = 28;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label39.Location = new System.Drawing.Point(469, 184);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(99, 20);
            this.label39.TabIndex = 27;
            this.label39.Text = "Blood Group";
            // 
            // studentRegistrationRegisterSubmitButton
            // 
            this.studentRegistrationRegisterSubmitButton.BackColor = System.Drawing.Color.MistyRose;
            this.studentRegistrationRegisterSubmitButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.studentRegistrationRegisterSubmitButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.studentRegistrationRegisterSubmitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationRegisterSubmitButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.studentRegistrationRegisterSubmitButton.Location = new System.Drawing.Point(781, 477);
            this.studentRegistrationRegisterSubmitButton.Name = "studentRegistrationRegisterSubmitButton";
            this.studentRegistrationRegisterSubmitButton.Size = new System.Drawing.Size(128, 26);
            this.studentRegistrationRegisterSubmitButton.TabIndex = 26;
            this.studentRegistrationRegisterSubmitButton.Text = "Submit";
            this.studentRegistrationRegisterSubmitButton.UseVisualStyleBackColor = false;
            this.studentRegistrationRegisterSubmitButton.Click += new System.EventHandler(this.studentRegistrationRegisterSubmitButton_Click);
            // 
            // studentRegistrationRegisterDOB
            // 
            this.studentRegistrationRegisterDOB.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationRegisterDOB.Location = new System.Drawing.Point(588, 104);
            this.studentRegistrationRegisterDOB.Name = "studentRegistrationRegisterDOB";
            this.studentRegistrationRegisterDOB.Size = new System.Drawing.Size(164, 26);
            this.studentRegistrationRegisterDOB.TabIndex = 25;
            // 
            // studentRegistrationRegisterAdmissionDate
            // 
            this.studentRegistrationRegisterAdmissionDate.Enabled = false;
            this.studentRegistrationRegisterAdmissionDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationRegisterAdmissionDate.Location = new System.Drawing.Point(588, 72);
            this.studentRegistrationRegisterAdmissionDate.Name = "studentRegistrationRegisterAdmissionDate";
            this.studentRegistrationRegisterAdmissionDate.Size = new System.Drawing.Size(165, 26);
            this.studentRegistrationRegisterAdmissionDate.TabIndex = 24;
            // 
            // studentRegistrationRegisterDepartmentComboBox
            // 
            this.studentRegistrationRegisterDepartmentComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationRegisterDepartmentComboBox.FormattingEnabled = true;
            this.studentRegistrationRegisterDepartmentComboBox.Items.AddRange(new object[] {
            "Science",
            "Arts",
            "Commerce"});
            this.studentRegistrationRegisterDepartmentComboBox.Location = new System.Drawing.Point(588, 213);
            this.studentRegistrationRegisterDepartmentComboBox.Name = "studentRegistrationRegisterDepartmentComboBox";
            this.studentRegistrationRegisterDepartmentComboBox.Size = new System.Drawing.Size(165, 28);
            this.studentRegistrationRegisterDepartmentComboBox.TabIndex = 23;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label16.Location = new System.Drawing.Point(468, 217);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(94, 20);
            this.label16.TabIndex = 22;
            this.label16.Text = "Department";
            // 
            // studentRegistrationRegisterClassComboBox
            // 
            this.studentRegistrationRegisterClassComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationRegisterClassComboBox.FormattingEnabled = true;
            this.studentRegistrationRegisterClassComboBox.Items.AddRange(new object[] {
            "Nursary",
            "STD-1",
            "STD-2",
            "STD-3",
            "STD-4",
            "STD-5",
            "STD-6",
            "STD-7",
            "STD-8",
            "STD-9",
            "STD-10"});
            this.studentRegistrationRegisterClassComboBox.Location = new System.Drawing.Point(588, 142);
            this.studentRegistrationRegisterClassComboBox.Name = "studentRegistrationRegisterClassComboBox";
            this.studentRegistrationRegisterClassComboBox.Size = new System.Drawing.Size(162, 28);
            this.studentRegistrationRegisterClassComboBox.TabIndex = 20;
            // 
            // studentRegistrationRegisterGenderComboBox
            // 
            this.studentRegistrationRegisterGenderComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationRegisterGenderComboBox.FormattingEnabled = true;
            this.studentRegistrationRegisterGenderComboBox.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Others"});
            this.studentRegistrationRegisterGenderComboBox.Location = new System.Drawing.Point(188, 159);
            this.studentRegistrationRegisterGenderComboBox.Name = "studentRegistrationRegisterGenderComboBox";
            this.studentRegistrationRegisterGenderComboBox.Size = new System.Drawing.Size(227, 28);
            this.studentRegistrationRegisterGenderComboBox.TabIndex = 18;
            // 
            // studentRegistrationRegisterAddressTextBox
            // 
            this.studentRegistrationRegisterAddressTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationRegisterAddressTextBox.Location = new System.Drawing.Point(125, 419);
            this.studentRegistrationRegisterAddressTextBox.Name = "studentRegistrationRegisterAddressTextBox";
            this.studentRegistrationRegisterAddressTextBox.Size = new System.Drawing.Size(545, 63);
            this.studentRegistrationRegisterAddressTextBox.TabIndex = 17;
            this.studentRegistrationRegisterAddressTextBox.Text = "";
            // 
            // studentRegistrationRegisterEmailTextBox
            // 
            this.studentRegistrationRegisterEmailTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationRegisterEmailTextBox.Location = new System.Drawing.Point(616, 352);
            this.studentRegistrationRegisterEmailTextBox.Name = "studentRegistrationRegisterEmailTextBox";
            this.studentRegistrationRegisterEmailTextBox.Size = new System.Drawing.Size(244, 26);
            this.studentRegistrationRegisterEmailTextBox.TabIndex = 16;
            // 
            // studentRegistrationRegisterPhoneTextBox
            // 
            this.studentRegistrationRegisterPhoneTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationRegisterPhoneTextBox.Location = new System.Drawing.Point(155, 358);
            this.studentRegistrationRegisterPhoneTextBox.Name = "studentRegistrationRegisterPhoneTextBox";
            this.studentRegistrationRegisterPhoneTextBox.Size = new System.Drawing.Size(234, 26);
            this.studentRegistrationRegisterPhoneTextBox.TabIndex = 16;
            // 
            // studentRegistrationRegisterMotherOccupationTextBox
            // 
            this.studentRegistrationRegisterMotherOccupationTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationRegisterMotherOccupationTextBox.Location = new System.Drawing.Point(616, 320);
            this.studentRegistrationRegisterMotherOccupationTextBox.Name = "studentRegistrationRegisterMotherOccupationTextBox";
            this.studentRegistrationRegisterMotherOccupationTextBox.Size = new System.Drawing.Size(244, 26);
            this.studentRegistrationRegisterMotherOccupationTextBox.TabIndex = 16;
            // 
            // studentRegistrationRegisterMotherNameTextBox
            // 
            this.studentRegistrationRegisterMotherNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationRegisterMotherNameTextBox.Location = new System.Drawing.Point(155, 324);
            this.studentRegistrationRegisterMotherNameTextBox.Name = "studentRegistrationRegisterMotherNameTextBox";
            this.studentRegistrationRegisterMotherNameTextBox.Size = new System.Drawing.Size(235, 26);
            this.studentRegistrationRegisterMotherNameTextBox.TabIndex = 16;
            // 
            // studentRegistrationRegisterFatherOccupationTextBox
            // 
            this.studentRegistrationRegisterFatherOccupationTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationRegisterFatherOccupationTextBox.Location = new System.Drawing.Point(616, 289);
            this.studentRegistrationRegisterFatherOccupationTextBox.Name = "studentRegistrationRegisterFatherOccupationTextBox";
            this.studentRegistrationRegisterFatherOccupationTextBox.Size = new System.Drawing.Size(244, 26);
            this.studentRegistrationRegisterFatherOccupationTextBox.TabIndex = 16;
            // 
            // studentRegistrationRegisterFatherNameTextBox
            // 
            this.studentRegistrationRegisterFatherNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationRegisterFatherNameTextBox.Location = new System.Drawing.Point(155, 292);
            this.studentRegistrationRegisterFatherNameTextBox.Name = "studentRegistrationRegisterFatherNameTextBox";
            this.studentRegistrationRegisterFatherNameTextBox.Size = new System.Drawing.Size(235, 26);
            this.studentRegistrationRegisterFatherNameTextBox.TabIndex = 16;
            // 
            // studentRegistrationRegisterNameTextBox
            // 
            this.studentRegistrationRegisterNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationRegisterNameTextBox.Location = new System.Drawing.Point(189, 126);
            this.studentRegistrationRegisterNameTextBox.Name = "studentRegistrationRegisterNameTextBox";
            this.studentRegistrationRegisterNameTextBox.Size = new System.Drawing.Size(227, 26);
            this.studentRegistrationRegisterNameTextBox.TabIndex = 16;
            // 
            // studentRegistrationRegisterAdmissionNumberTextBox
            // 
            this.studentRegistrationRegisterAdmissionNumberTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationRegisterAdmissionNumberTextBox.Location = new System.Drawing.Point(188, 93);
            this.studentRegistrationRegisterAdmissionNumberTextBox.Name = "studentRegistrationRegisterAdmissionNumberTextBox";
            this.studentRegistrationRegisterAdmissionNumberTextBox.Size = new System.Drawing.Size(227, 26);
            this.studentRegistrationRegisterAdmissionNumberTextBox.TabIndex = 15;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label15.Location = new System.Drawing.Point(43, 436);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(68, 20);
            this.label15.TabIndex = 14;
            this.label15.Text = "Address";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label9.Location = new System.Drawing.Point(434, 295);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(152, 20);
            this.label9.TabIndex = 13;
            this.label9.Text = "Father\'s Occupation";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label10.Location = new System.Drawing.Point(17, 327);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(116, 20);
            this.label10.TabIndex = 12;
            this.label10.Text = "Mother\'s Name";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label11.Location = new System.Drawing.Point(434, 321);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(155, 20);
            this.label11.TabIndex = 11;
            this.label11.Text = "Mother\'s Occupation";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label12.Location = new System.Drawing.Point(23, 361);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(115, 20);
            this.label12.TabIndex = 10;
            this.label12.Text = "Phone Number";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label13.Location = new System.Drawing.Point(535, 352);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(48, 20);
            this.label13.TabIndex = 9;
            this.label13.Text = "Email";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label14.Location = new System.Drawing.Point(17, 295);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(113, 20);
            this.label14.TabIndex = 8;
            this.label14.Text = "Father\'s Name";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label8.Location = new System.Drawing.Point(24, 263);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(938, 20);
            this.label8.TabIndex = 7;
            this.label8.Text = "Guardian Information ____________________________________________________________" +
    "__________________________";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label7.Location = new System.Drawing.Point(465, 74);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(121, 20);
            this.label7.TabIndex = 6;
            this.label7.Text = "Admission Date";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label6.Location = new System.Drawing.Point(107, 132);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(51, 20);
            this.label6.TabIndex = 5;
            this.label6.Text = "Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label5.Location = new System.Drawing.Point(468, 106);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(102, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Date Of Birth";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label4.Location = new System.Drawing.Point(99, 165);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Gender";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Location = new System.Drawing.Point(494, 146);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Class";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(44, 97);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(142, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Admission Number";
            // 
            // studentRegistrationSearchButton
            // 
            this.studentRegistrationSearchButton.BackColor = System.Drawing.Color.MistyRose;
            this.studentRegistrationSearchButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.studentRegistrationSearchButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.studentRegistrationSearchButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationSearchButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.studentRegistrationSearchButton.Location = new System.Drawing.Point(129, 2);
            this.studentRegistrationSearchButton.Name = "studentRegistrationSearchButton";
            this.studentRegistrationSearchButton.Size = new System.Drawing.Size(128, 26);
            this.studentRegistrationSearchButton.TabIndex = 2;
            this.studentRegistrationSearchButton.Text = "Search";
            this.studentRegistrationSearchButton.UseVisualStyleBackColor = false;
            this.studentRegistrationSearchButton.Click += new System.EventHandler(this.studentRegistrationSearchButton_Click);
            // 
            // studentRegistrationRegisterButton
            // 
            this.studentRegistrationRegisterButton.BackColor = System.Drawing.Color.MistyRose;
            this.studentRegistrationRegisterButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.studentRegistrationRegisterButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.studentRegistrationRegisterButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationRegisterButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.studentRegistrationRegisterButton.Location = new System.Drawing.Point(0, 2);
            this.studentRegistrationRegisterButton.Name = "studentRegistrationRegisterButton";
            this.studentRegistrationRegisterButton.Size = new System.Drawing.Size(128, 26);
            this.studentRegistrationRegisterButton.TabIndex = 1;
            this.studentRegistrationRegisterButton.Text = "Register";
            this.studentRegistrationRegisterButton.UseVisualStyleBackColor = false;
            this.studentRegistrationRegisterButton.Click += new System.EventHandler(this.studentRegistrationRegisterButton_Click);
            // 
            // studentPanel
            // 
            this.studentPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.studentPanel.Controls.Add(this.label51);
            this.studentPanel.Controls.Add(this.studentPromotionPanel);
            this.studentPanel.Controls.Add(this.studentRegistrationPanel);
            this.studentPanel.Controls.Add(this.studentPromotion);
            this.studentPanel.Controls.Add(this.studentRegistrationButton);
            this.studentPanel.Location = new System.Drawing.Point(531, 34);
            this.studentPanel.Name = "studentPanel";
            this.studentPanel.Size = new System.Drawing.Size(83, 40);
            this.studentPanel.TabIndex = 2;
            this.studentPanel.Visible = false;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.BackColor = System.Drawing.Color.White;
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label51.Location = new System.Drawing.Point(455, 5);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(79, 24);
            this.label51.TabIndex = 32;
            this.label51.Text = "Student ";
            // 
            // studentPromotion
            // 
            this.studentPromotion.BackColor = System.Drawing.Color.MistyRose;
            this.studentPromotion.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.studentPromotion.Cursor = System.Windows.Forms.Cursors.Hand;
            this.studentPromotion.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentPromotion.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.studentPromotion.Location = new System.Drawing.Point(933, 1);
            this.studentPromotion.Name = "studentPromotion";
            this.studentPromotion.Size = new System.Drawing.Size(128, 26);
            this.studentPromotion.TabIndex = 2;
            this.studentPromotion.Text = "Promotion";
            this.studentPromotion.UseVisualStyleBackColor = false;
            this.studentPromotion.Click += new System.EventHandler(this.studentPromotion_Click);
            // 
            // studentRegistrationButton
            // 
            this.studentRegistrationButton.BackColor = System.Drawing.Color.MistyRose;
            this.studentRegistrationButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.studentRegistrationButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.studentRegistrationButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.studentRegistrationButton.Location = new System.Drawing.Point(801, 1);
            this.studentRegistrationButton.Name = "studentRegistrationButton";
            this.studentRegistrationButton.Size = new System.Drawing.Size(128, 26);
            this.studentRegistrationButton.TabIndex = 1;
            this.studentRegistrationButton.Text = "Student Data";
            this.studentRegistrationButton.UseVisualStyleBackColor = false;
            this.studentRegistrationButton.Click += new System.EventHandler(this.studentRegistrationButton_Click);
            // 
            // Id
            // 
            this.Id.HeaderText = "ID";
            this.Id.Name = "Id";
            this.Id.ReadOnly = true;
            // 
            // BloodGroup
            // 
            this.BloodGroup.HeaderText = "Blood Group";
            this.BloodGroup.Name = "BloodGroup";
            this.BloodGroup.ReadOnly = true;
            // 
            // Gender
            // 
            this.Gender.HeaderText = "Gender";
            this.Gender.Name = "Gender";
            this.Gender.ReadOnly = true;
            // 
            // DOB
            // 
            this.DOB.HeaderText = "Date of Birth";
            this.DOB.Name = "DOB";
            this.DOB.ReadOnly = true;
            // 
            // usersFullName
            // 
            this.usersFullName.HeaderText = "Name";
            this.usersFullName.Name = "usersFullName";
            this.usersFullName.ReadOnly = true;
            // 
            // UserName
            // 
            this.UserName.HeaderText = "User Name";
            this.UserName.Name = "UserName";
            this.UserName.ReadOnly = true;
            // 
            // Email
            // 
            this.Email.HeaderText = "Email";
            this.Email.Name = "Email";
            this.Email.ReadOnly = true;
            // 
            // Password
            // 
            this.Password.HeaderText = "Password";
            this.Password.Name = "Password";
            this.Password.ReadOnly = true;
            // 
            // Phone
            // 
            this.Phone.HeaderText = "Phone Number";
            this.Phone.Name = "Phone";
            this.Phone.ReadOnly = true;
            // 
            // tileBarPanel
            // 
            this.tileBarPanel.BackColor = System.Drawing.Color.Silver;
            this.tileBarPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tileBarPanel.Controls.Add(this.crossButton);
            this.tileBarPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.tileBarPanel.Location = new System.Drawing.Point(185, 0);
            this.tileBarPanel.Name = "tileBarPanel";
            this.tileBarPanel.Size = new System.Drawing.Size(1075, 20);
            this.tileBarPanel.TabIndex = 2;
            // 
            // crossButton
            // 
            this.crossButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.crossButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("crossButton.BackgroundImage")));
            this.crossButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.crossButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.crossButton.Location = new System.Drawing.Point(1043, 0);
            this.crossButton.Name = "crossButton";
            this.crossButton.Size = new System.Drawing.Size(32, 20);
            this.crossButton.TabIndex = 0;
            this.crossButton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.crossButton.UseVisualStyleBackColor = false;
            this.crossButton.Click += new System.EventHandler(this.crossButton_Click);
            // 
            // termExamPanel
            // 
            this.termExamPanel.Controls.Add(this.termExamDepartmentComboBox);
            this.termExamPanel.Controls.Add(this.label103);
            this.termExamPanel.Controls.Add(this.termExamUpdateButton);
            this.termExamPanel.Controls.Add(this.termExamDeleteButton);
            this.termExamPanel.Controls.Add(this.termExamDataGrid);
            this.termExamPanel.Controls.Add(this.termExamAddButton);
            this.termExamPanel.Controls.Add(this.termExamDate);
            this.termExamPanel.Controls.Add(this.label102);
            this.termExamPanel.Controls.Add(this.termExamSubjectComboBox);
            this.termExamPanel.Controls.Add(this.label101);
            this.termExamPanel.Controls.Add(this.termExamClassNameComboBox);
            this.termExamPanel.Controls.Add(this.label58);
            this.termExamPanel.Controls.Add(this.label42);
            this.termExamPanel.Location = new System.Drawing.Point(629, 33);
            this.termExamPanel.Name = "termExamPanel";
            this.termExamPanel.Size = new System.Drawing.Size(49, 38);
            this.termExamPanel.TabIndex = 5;
            // 
            // termExamDepartmentComboBox
            // 
            this.termExamDepartmentComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.termExamDepartmentComboBox.FormattingEnabled = true;
            this.termExamDepartmentComboBox.Items.AddRange(new object[] {
            "Science",
            "Arts",
            "Commerce"});
            this.termExamDepartmentComboBox.Location = new System.Drawing.Point(170, 283);
            this.termExamDepartmentComboBox.Name = "termExamDepartmentComboBox";
            this.termExamDepartmentComboBox.Size = new System.Drawing.Size(142, 24);
            this.termExamDepartmentComboBox.TabIndex = 12;
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label103.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label103.Location = new System.Drawing.Point(67, 287);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(94, 20);
            this.label103.TabIndex = 11;
            this.label103.Text = "Department";
            // 
            // termExamUpdateButton
            // 
            this.termExamUpdateButton.BackColor = System.Drawing.Color.MistyRose;
            this.termExamUpdateButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.termExamUpdateButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.termExamUpdateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.termExamUpdateButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.termExamUpdateButton.Location = new System.Drawing.Point(766, 473);
            this.termExamUpdateButton.Name = "termExamUpdateButton";
            this.termExamUpdateButton.Size = new System.Drawing.Size(103, 26);
            this.termExamUpdateButton.TabIndex = 10;
            this.termExamUpdateButton.Text = "Update";
            this.termExamUpdateButton.UseVisualStyleBackColor = false;
            this.termExamUpdateButton.Click += new System.EventHandler(this.termExamUpdateButton_Click);
            // 
            // termExamDeleteButton
            // 
            this.termExamDeleteButton.BackColor = System.Drawing.Color.MistyRose;
            this.termExamDeleteButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.termExamDeleteButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.termExamDeleteButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.termExamDeleteButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.termExamDeleteButton.Location = new System.Drawing.Point(896, 473);
            this.termExamDeleteButton.Name = "termExamDeleteButton";
            this.termExamDeleteButton.Size = new System.Drawing.Size(103, 26);
            this.termExamDeleteButton.TabIndex = 9;
            this.termExamDeleteButton.Text = "Delete";
            this.termExamDeleteButton.UseVisualStyleBackColor = false;
            this.termExamDeleteButton.Click += new System.EventHandler(this.termExamDeleteButton_Click);
            // 
            // termExamDataGrid
            // 
            this.termExamDataGrid.AllowUserToAddRows = false;
            this.termExamDataGrid.AllowUserToDeleteRows = false;
            this.termExamDataGrid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(52)))), ((int)(((byte)(118)))));
            this.termExamDataGrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.termExamDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.termExamDataGrid.Location = new System.Drawing.Point(545, 189);
            this.termExamDataGrid.Name = "termExamDataGrid";
            this.termExamDataGrid.ReadOnly = true;
            this.termExamDataGrid.Size = new System.Drawing.Size(463, 251);
            this.termExamDataGrid.TabIndex = 8;
            this.termExamDataGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.termExamDataGrid_CellContentClick);
            // 
            // termExamAddButton
            // 
            this.termExamAddButton.BackColor = System.Drawing.Color.MistyRose;
            this.termExamAddButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.termExamAddButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.termExamAddButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.termExamAddButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.termExamAddButton.Location = new System.Drawing.Point(209, 344);
            this.termExamAddButton.Name = "termExamAddButton";
            this.termExamAddButton.Size = new System.Drawing.Size(103, 26);
            this.termExamAddButton.TabIndex = 7;
            this.termExamAddButton.Text = "Add";
            this.termExamAddButton.UseVisualStyleBackColor = false;
            this.termExamAddButton.Click += new System.EventHandler(this.termExamAddButton_Click);
            // 
            // termExamDate
            // 
            this.termExamDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.termExamDate.Location = new System.Drawing.Point(170, 232);
            this.termExamDate.Name = "termExamDate";
            this.termExamDate.Size = new System.Drawing.Size(142, 21);
            this.termExamDate.TabIndex = 6;
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label102.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label102.Location = new System.Drawing.Point(67, 235);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(44, 20);
            this.label102.TabIndex = 5;
            this.label102.Text = "Date";
            // 
            // termExamSubjectComboBox
            // 
            this.termExamSubjectComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.termExamSubjectComboBox.FormattingEnabled = true;
            this.termExamSubjectComboBox.Items.AddRange(new object[] {
            "Bangla",
            "English",
            "Mathemetics",
            "Physics",
            "Chemistry",
            "Biology",
            "History",
            "Social Science",
            "Accounting"});
            this.termExamSubjectComboBox.Location = new System.Drawing.Point(170, 183);
            this.termExamSubjectComboBox.Name = "termExamSubjectComboBox";
            this.termExamSubjectComboBox.Size = new System.Drawing.Size(142, 24);
            this.termExamSubjectComboBox.TabIndex = 4;
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label101.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label101.Location = new System.Drawing.Point(67, 187);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(63, 20);
            this.label101.TabIndex = 3;
            this.label101.Text = "Subject";
            // 
            // termExamClassNameComboBox
            // 
            this.termExamClassNameComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.termExamClassNameComboBox.FormattingEnabled = true;
            this.termExamClassNameComboBox.Items.AddRange(new object[] {
            "Nursary",
            "STD-1",
            "STD-2",
            "STD-3",
            "STD-4",
            "STD-5",
            "STD-6",
            "STD-7",
            "STD-8",
            "STD-9",
            "STD-10"});
            this.termExamClassNameComboBox.Location = new System.Drawing.Point(170, 130);
            this.termExamClassNameComboBox.Name = "termExamClassNameComboBox";
            this.termExamClassNameComboBox.Size = new System.Drawing.Size(142, 24);
            this.termExamClassNameComboBox.TabIndex = 2;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label58.Location = new System.Drawing.Point(67, 134);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(94, 20);
            this.label58.TabIndex = 1;
            this.label58.Text = "Class Name";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.BackColor = System.Drawing.Color.White;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.ForeColor = System.Drawing.Color.Maroon;
            this.label42.Location = new System.Drawing.Point(409, 12);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(125, 26);
            this.label42.TabIndex = 0;
            this.label42.Text = "Term Exam";
            // 
            // adminPanel
            // 
            this.adminPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(52)))), ((int)(((byte)(118)))));
            this.adminPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.adminPanel.Controls.Add(this.adminAddPanel);
            this.adminPanel.Controls.Add(this.adminSearchButton);
            this.adminPanel.Controls.Add(this.adminAddButton);
            this.adminPanel.Controls.Add(this.adminSearchPanel);
            this.adminPanel.Location = new System.Drawing.Point(709, 34);
            this.adminPanel.Name = "adminPanel";
            this.adminPanel.Size = new System.Drawing.Size(81, 49);
            this.adminPanel.TabIndex = 6;
            // 
            // adminAddPanel
            // 
            this.adminAddPanel.AutoScroll = true;
            this.adminAddPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(52)))), ((int)(((byte)(118)))));
            this.adminAddPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.adminAddPanel.Controls.Add(this.adminAddRegisterDate);
            this.adminAddPanel.Controls.Add(this.label116);
            this.adminAddPanel.Controls.Add(this.adminAddConfirmPasswordTextBox);
            this.adminAddPanel.Controls.Add(this.label118);
            this.adminAddPanel.Controls.Add(this.adminAddPasswordTextBox);
            this.adminAddPanel.Controls.Add(this.label119);
            this.adminAddPanel.Controls.Add(this.adminAddAdminIdTextBox);
            this.adminAddPanel.Controls.Add(this.label120);
            this.adminAddPanel.Controls.Add(this.label121);
            this.adminAddPanel.Controls.Add(this.adminAddBrowseButton);
            this.adminAddPanel.Controls.Add(this.adminAddPicture);
            this.adminAddPanel.Controls.Add(this.adminAddBGComboBox);
            this.adminAddPanel.Controls.Add(this.label122);
            this.adminAddPanel.Controls.Add(this.adminAddSubmitButton);
            this.adminAddPanel.Controls.Add(this.adminAddDOB);
            this.adminAddPanel.Controls.Add(this.adminAddGenderComboBox);
            this.adminAddPanel.Controls.Add(this.adminAddAddressTextBox);
            this.adminAddPanel.Controls.Add(this.adminAddEmailTextBox);
            this.adminAddPanel.Controls.Add(this.adminAddPhoneNumberTextBox);
            this.adminAddPanel.Controls.Add(this.adminAddNameTextBox);
            this.adminAddPanel.Controls.Add(this.label124);
            this.adminAddPanel.Controls.Add(this.label125);
            this.adminAddPanel.Controls.Add(this.label126);
            this.adminAddPanel.Controls.Add(this.label127);
            this.adminAddPanel.Controls.Add(this.label128);
            this.adminAddPanel.Controls.Add(this.label129);
            this.adminAddPanel.Location = new System.Drawing.Point(281, 10);
            this.adminAddPanel.Name = "adminAddPanel";
            this.adminAddPanel.Size = new System.Drawing.Size(134, 36);
            this.adminAddPanel.TabIndex = 10;
            this.adminAddPanel.Visible = false;
            // 
            // adminAddRegisterDate
            // 
            this.adminAddRegisterDate.Enabled = false;
            this.adminAddRegisterDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminAddRegisterDate.Location = new System.Drawing.Point(596, 124);
            this.adminAddRegisterDate.Name = "adminAddRegisterDate";
            this.adminAddRegisterDate.Size = new System.Drawing.Size(188, 26);
            this.adminAddRegisterDate.TabIndex = 55;
            // 
            // label116
            // 
            this.label116.AutoSize = true;
            this.label116.Enabled = false;
            this.label116.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label116.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label116.Location = new System.Drawing.Point(472, 128);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(108, 20);
            this.label116.TabIndex = 54;
            this.label116.Text = "Register Date";
            // 
            // adminAddConfirmPasswordTextBox
            // 
            this.adminAddConfirmPasswordTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminAddConfirmPasswordTextBox.Location = new System.Drawing.Point(197, 307);
            this.adminAddConfirmPasswordTextBox.Name = "adminAddConfirmPasswordTextBox";
            this.adminAddConfirmPasswordTextBox.Size = new System.Drawing.Size(226, 26);
            this.adminAddConfirmPasswordTextBox.TabIndex = 41;
            // 
            // label118
            // 
            this.label118.AutoSize = true;
            this.label118.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label118.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label118.Location = new System.Drawing.Point(55, 311);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(121, 17);
            this.label118.TabIndex = 40;
            this.label118.Text = "Confirm Password";
            // 
            // adminAddPasswordTextBox
            // 
            this.adminAddPasswordTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminAddPasswordTextBox.Location = new System.Drawing.Point(197, 266);
            this.adminAddPasswordTextBox.Name = "adminAddPasswordTextBox";
            this.adminAddPasswordTextBox.Size = new System.Drawing.Size(226, 26);
            this.adminAddPasswordTextBox.TabIndex = 39;
            // 
            // label119
            // 
            this.label119.AutoSize = true;
            this.label119.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label119.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label119.Location = new System.Drawing.Point(92, 267);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(78, 20);
            this.label119.TabIndex = 38;
            this.label119.Text = "Password";
            // 
            // adminAddAdminIdTextBox
            // 
            this.adminAddAdminIdTextBox.Enabled = false;
            this.adminAddAdminIdTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminAddAdminIdTextBox.Location = new System.Drawing.Point(197, 128);
            this.adminAddAdminIdTextBox.Name = "adminAddAdminIdTextBox";
            this.adminAddAdminIdTextBox.Size = new System.Drawing.Size(227, 26);
            this.adminAddAdminIdTextBox.TabIndex = 33;
            // 
            // label120
            // 
            this.label120.AutoSize = true;
            this.label120.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label120.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label120.Location = new System.Drawing.Point(106, 131);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(64, 17);
            this.label120.TabIndex = 32;
            this.label120.Text = "Admin ID";
            // 
            // label121
            // 
            this.label121.AutoSize = true;
            this.label121.BackColor = System.Drawing.Color.White;
            this.label121.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label121.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label121.Location = new System.Drawing.Point(370, 10);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(175, 25);
            this.label121.TabIndex = 31;
            this.label121.Text = "Admin Registration";
            // 
            // adminAddBrowseButton
            // 
            this.adminAddBrowseButton.BackColor = System.Drawing.Color.MistyRose;
            this.adminAddBrowseButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.adminAddBrowseButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.adminAddBrowseButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminAddBrowseButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.adminAddBrowseButton.Location = new System.Drawing.Point(879, 284);
            this.adminAddBrowseButton.Name = "adminAddBrowseButton";
            this.adminAddBrowseButton.Size = new System.Drawing.Size(99, 26);
            this.adminAddBrowseButton.TabIndex = 30;
            this.adminAddBrowseButton.Text = "Browse";
            this.adminAddBrowseButton.UseVisualStyleBackColor = false;
            this.adminAddBrowseButton.Click += new System.EventHandler(this.adminAddBrowseButton_Click);
            // 
            // adminAddPicture
            // 
            this.adminAddPicture.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.adminAddPicture.Location = new System.Drawing.Point(836, 124);
            this.adminAddPicture.Name = "adminAddPicture";
            this.adminAddPicture.Size = new System.Drawing.Size(153, 143);
            this.adminAddPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.adminAddPicture.TabIndex = 29;
            this.adminAddPicture.TabStop = false;
            // 
            // adminAddBGComboBox
            // 
            this.adminAddBGComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminAddBGComboBox.FormattingEnabled = true;
            this.adminAddBGComboBox.Items.AddRange(new object[] {
            "A+",
            "A-",
            "B+",
            "B-",
            "AB+",
            "AB-",
            "O+",
            "O-"});
            this.adminAddBGComboBox.Location = new System.Drawing.Point(597, 170);
            this.adminAddBGComboBox.Name = "adminAddBGComboBox";
            this.adminAddBGComboBox.Size = new System.Drawing.Size(187, 28);
            this.adminAddBGComboBox.TabIndex = 28;
            // 
            // label122
            // 
            this.label122.AutoSize = true;
            this.label122.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label122.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label122.Location = new System.Drawing.Point(481, 177);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(99, 20);
            this.label122.TabIndex = 27;
            this.label122.Text = "Blood Group";
            // 
            // adminAddSubmitButton
            // 
            this.adminAddSubmitButton.BackColor = System.Drawing.Color.MistyRose;
            this.adminAddSubmitButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.adminAddSubmitButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.adminAddSubmitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminAddSubmitButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.adminAddSubmitButton.Location = new System.Drawing.Point(729, 460);
            this.adminAddSubmitButton.Name = "adminAddSubmitButton";
            this.adminAddSubmitButton.Size = new System.Drawing.Size(128, 26);
            this.adminAddSubmitButton.TabIndex = 26;
            this.adminAddSubmitButton.Text = "Submit";
            this.adminAddSubmitButton.UseVisualStyleBackColor = false;
            this.adminAddSubmitButton.Click += new System.EventHandler(this.adminAddSubmitButton_Click);
            // 
            // adminAddDOB
            // 
            this.adminAddDOB.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminAddDOB.Location = new System.Drawing.Point(599, 301);
            this.adminAddDOB.Name = "adminAddDOB";
            this.adminAddDOB.Size = new System.Drawing.Size(185, 26);
            this.adminAddDOB.TabIndex = 25;
            // 
            // adminAddGenderComboBox
            // 
            this.adminAddGenderComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminAddGenderComboBox.FormattingEnabled = true;
            this.adminAddGenderComboBox.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Others"});
            this.adminAddGenderComboBox.Location = new System.Drawing.Point(197, 220);
            this.adminAddGenderComboBox.Name = "adminAddGenderComboBox";
            this.adminAddGenderComboBox.Size = new System.Drawing.Size(227, 28);
            this.adminAddGenderComboBox.TabIndex = 18;
            // 
            // adminAddAddressTextBox
            // 
            this.adminAddAddressTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminAddAddressTextBox.Location = new System.Drawing.Point(133, 395);
            this.adminAddAddressTextBox.Name = "adminAddAddressTextBox";
            this.adminAddAddressTextBox.Size = new System.Drawing.Size(545, 63);
            this.adminAddAddressTextBox.TabIndex = 17;
            this.adminAddAddressTextBox.Text = "";
            // 
            // adminAddEmailTextBox
            // 
            this.adminAddEmailTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminAddEmailTextBox.Location = new System.Drawing.Point(599, 216);
            this.adminAddEmailTextBox.Name = "adminAddEmailTextBox";
            this.adminAddEmailTextBox.Size = new System.Drawing.Size(184, 26);
            this.adminAddEmailTextBox.TabIndex = 16;
            // 
            // adminAddPhoneNumberTextBox
            // 
            this.adminAddPhoneNumberTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminAddPhoneNumberTextBox.Location = new System.Drawing.Point(599, 260);
            this.adminAddPhoneNumberTextBox.Name = "adminAddPhoneNumberTextBox";
            this.adminAddPhoneNumberTextBox.Size = new System.Drawing.Size(185, 26);
            this.adminAddPhoneNumberTextBox.TabIndex = 16;
            // 
            // adminAddNameTextBox
            // 
            this.adminAddNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminAddNameTextBox.Location = new System.Drawing.Point(197, 175);
            this.adminAddNameTextBox.Name = "adminAddNameTextBox";
            this.adminAddNameTextBox.Size = new System.Drawing.Size(227, 26);
            this.adminAddNameTextBox.TabIndex = 16;
            // 
            // label124
            // 
            this.label124.AutoSize = true;
            this.label124.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label124.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label124.Location = new System.Drawing.Point(55, 412);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(62, 18);
            this.label124.TabIndex = 14;
            this.label124.Text = "Address";
            // 
            // label125
            // 
            this.label125.AutoSize = true;
            this.label125.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label125.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label125.Location = new System.Drawing.Point(465, 263);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(115, 20);
            this.label125.TabIndex = 10;
            this.label125.Text = "Phone Number";
            // 
            // label126
            // 
            this.label126.AutoSize = true;
            this.label126.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label126.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label126.Location = new System.Drawing.Point(505, 216);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(48, 20);
            this.label126.TabIndex = 9;
            this.label126.Text = "Email";
            // 
            // label127
            // 
            this.label127.AutoSize = true;
            this.label127.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label127.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label127.Location = new System.Drawing.Point(119, 181);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(51, 20);
            this.label127.TabIndex = 5;
            this.label127.Text = "Name";
            // 
            // label128
            // 
            this.label128.AutoSize = true;
            this.label128.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label128.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label128.Location = new System.Drawing.Point(475, 305);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(102, 20);
            this.label128.TabIndex = 4;
            this.label128.Text = "Date Of Birth";
            // 
            // label129
            // 
            this.label129.AutoSize = true;
            this.label129.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label129.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label129.Location = new System.Drawing.Point(112, 226);
            this.label129.Name = "label129";
            this.label129.Size = new System.Drawing.Size(63, 20);
            this.label129.TabIndex = 3;
            this.label129.Text = "Gender";
            // 
            // adminSearchButton
            // 
            this.adminSearchButton.BackColor = System.Drawing.Color.MistyRose;
            this.adminSearchButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.adminSearchButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.adminSearchButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminSearchButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.adminSearchButton.Location = new System.Drawing.Point(137, 3);
            this.adminSearchButton.Name = "adminSearchButton";
            this.adminSearchButton.Size = new System.Drawing.Size(128, 26);
            this.adminSearchButton.TabIndex = 0;
            this.adminSearchButton.Text = "Search";
            this.adminSearchButton.UseVisualStyleBackColor = false;
            this.adminSearchButton.Click += new System.EventHandler(this.adminSearchButton_Click);
            // 
            // adminAddButton
            // 
            this.adminAddButton.BackColor = System.Drawing.Color.MistyRose;
            this.adminAddButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.adminAddButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.adminAddButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminAddButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.adminAddButton.Location = new System.Drawing.Point(3, 3);
            this.adminAddButton.Name = "adminAddButton";
            this.adminAddButton.Size = new System.Drawing.Size(128, 26);
            this.adminAddButton.TabIndex = 0;
            this.adminAddButton.Text = "Add";
            this.adminAddButton.UseVisualStyleBackColor = false;
            this.adminAddButton.Click += new System.EventHandler(this.adminAddButton_Click);
            // 
            // adminSearchPanel
            // 
            this.adminSearchPanel.AutoScroll = true;
            this.adminSearchPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(52)))), ((int)(((byte)(118)))));
            this.adminSearchPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.adminSearchPanel.Controls.Add(this.button2);
            this.adminSearchPanel.Controls.Add(this.adminSearchSearchButton);
            this.adminSearchPanel.Controls.Add(this.label131);
            this.adminSearchPanel.Controls.Add(this.adminSearchByIdTextBox);
            this.adminSearchPanel.Controls.Add(this.label132);
            this.adminSearchPanel.Controls.Add(this.adminSearchDeleteButton);
            this.adminSearchPanel.Controls.Add(this.label133);
            this.adminSearchPanel.Controls.Add(this.label134);
            this.adminSearchPanel.Controls.Add(this.adminSearchConfirmPasswordTextBox);
            this.adminSearchPanel.Controls.Add(this.label136);
            this.adminSearchPanel.Controls.Add(this.adminSearchPasswordTextBox);
            this.adminSearchPanel.Controls.Add(this.label137);
            this.adminSearchPanel.Controls.Add(this.adminSearchAdminIDTextBox);
            this.adminSearchPanel.Controls.Add(this.label138);
            this.adminSearchPanel.Controls.Add(this.adminSearchBrowseButton);
            this.adminSearchPanel.Controls.Add(this.adminSearchPicture);
            this.adminSearchPanel.Controls.Add(this.adminSearchBGComboBox);
            this.adminSearchPanel.Controls.Add(this.label139);
            this.adminSearchPanel.Controls.Add(this.adminSearchUpdateButton);
            this.adminSearchPanel.Controls.Add(this.adminSearchDOBTextBox);
            this.adminSearchPanel.Controls.Add(this.adminSearchGenderComboBox);
            this.adminSearchPanel.Controls.Add(this.adminSearchAddressTextBox);
            this.adminSearchPanel.Controls.Add(this.adminSearchEmailTextBox);
            this.adminSearchPanel.Controls.Add(this.adminSearchPhoneNumberTextBox);
            this.adminSearchPanel.Controls.Add(this.adminSearchNameTextBox);
            this.adminSearchPanel.Controls.Add(this.label141);
            this.adminSearchPanel.Controls.Add(this.label142);
            this.adminSearchPanel.Controls.Add(this.label143);
            this.adminSearchPanel.Controls.Add(this.label144);
            this.adminSearchPanel.Controls.Add(this.label145);
            this.adminSearchPanel.Controls.Add(this.label146);
            this.adminSearchPanel.Controls.Add(this.label148);
            this.adminSearchPanel.Controls.Add(this.button10);
            this.adminSearchPanel.Controls.Add(this.adminSearchData);
            this.adminSearchPanel.Controls.Add(this.textBox14);
            this.adminSearchPanel.Controls.Add(this.label149);
            this.adminSearchPanel.Location = new System.Drawing.Point(425, 12);
            this.adminSearchPanel.Name = "adminSearchPanel";
            this.adminSearchPanel.Size = new System.Drawing.Size(74, 46);
            this.adminSearchPanel.TabIndex = 9;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.MistyRose;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button2.Location = new System.Drawing.Point(873, 169);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(96, 26);
            this.button2.TabIndex = 100;
            this.button2.Text = "Cancel Search";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // adminSearchSearchButton
            // 
            this.adminSearchSearchButton.BackColor = System.Drawing.Color.MistyRose;
            this.adminSearchSearchButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.adminSearchSearchButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.adminSearchSearchButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminSearchSearchButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.adminSearchSearchButton.Location = new System.Drawing.Point(873, 131);
            this.adminSearchSearchButton.Name = "adminSearchSearchButton";
            this.adminSearchSearchButton.Size = new System.Drawing.Size(96, 26);
            this.adminSearchSearchButton.TabIndex = 99;
            this.adminSearchSearchButton.Text = "Search";
            this.adminSearchSearchButton.UseVisualStyleBackColor = false;
            this.adminSearchSearchButton.Click += new System.EventHandler(this.adminSearchSearchButton_Click);
            // 
            // label131
            // 
            this.label131.AutoSize = true;
            this.label131.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label131.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label131.Location = new System.Drawing.Point(805, 58);
            this.label131.Name = "label131";
            this.label131.Size = new System.Drawing.Size(83, 20);
            this.label131.TabIndex = 98;
            this.label131.Text = "Admin ID :";
            // 
            // adminSearchByIdTextBox
            // 
            this.adminSearchByIdTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminSearchByIdTextBox.Location = new System.Drawing.Point(809, 87);
            this.adminSearchByIdTextBox.Name = "adminSearchByIdTextBox";
            this.adminSearchByIdTextBox.Size = new System.Drawing.Size(158, 26);
            this.adminSearchByIdTextBox.TabIndex = 97;
            // 
            // label132
            // 
            this.label132.AutoSize = true;
            this.label132.BackColor = System.Drawing.Color.White;
            this.label132.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label132.ForeColor = System.Drawing.Color.Maroon;
            this.label132.Location = new System.Drawing.Point(424, 6);
            this.label132.Name = "label132";
            this.label132.Size = new System.Drawing.Size(150, 26);
            this.label132.TabIndex = 96;
            this.label132.Text = "Search Admin";
            // 
            // adminSearchDeleteButton
            // 
            this.adminSearchDeleteButton.BackColor = System.Drawing.Color.MistyRose;
            this.adminSearchDeleteButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.adminSearchDeleteButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.adminSearchDeleteButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminSearchDeleteButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.adminSearchDeleteButton.Location = new System.Drawing.Point(845, 656);
            this.adminSearchDeleteButton.Name = "adminSearchDeleteButton";
            this.adminSearchDeleteButton.Size = new System.Drawing.Size(128, 26);
            this.adminSearchDeleteButton.TabIndex = 95;
            this.adminSearchDeleteButton.Text = "Delete";
            this.adminSearchDeleteButton.UseVisualStyleBackColor = false;
            this.adminSearchDeleteButton.Click += new System.EventHandler(this.adminSearchDeleteButton_Click);
            // 
            // label133
            // 
            this.label133.AutoSize = true;
            this.label133.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label133.Location = new System.Drawing.Point(196, 681);
            this.label133.Name = "label133";
            this.label133.Size = new System.Drawing.Size(0, 20);
            this.label133.TabIndex = 94;
            // 
            // label134
            // 
            this.label134.AutoSize = true;
            this.label134.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label134.Location = new System.Drawing.Point(192, 663);
            this.label134.Name = "label134";
            this.label134.Size = new System.Drawing.Size(0, 20);
            this.label134.TabIndex = 93;
            // 
            // adminSearchConfirmPasswordTextBox
            // 
            this.adminSearchConfirmPasswordTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminSearchConfirmPasswordTextBox.Location = new System.Drawing.Point(168, 443);
            this.adminSearchConfirmPasswordTextBox.Name = "adminSearchConfirmPasswordTextBox";
            this.adminSearchConfirmPasswordTextBox.Size = new System.Drawing.Size(226, 26);
            this.adminSearchConfirmPasswordTextBox.TabIndex = 80;
            // 
            // label136
            // 
            this.label136.AutoSize = true;
            this.label136.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label136.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label136.Location = new System.Drawing.Point(21, 447);
            this.label136.Name = "label136";
            this.label136.Size = new System.Drawing.Size(121, 17);
            this.label136.TabIndex = 79;
            this.label136.Text = "Confirm Password";
            // 
            // adminSearchPasswordTextBox
            // 
            this.adminSearchPasswordTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminSearchPasswordTextBox.Location = new System.Drawing.Point(168, 408);
            this.adminSearchPasswordTextBox.Name = "adminSearchPasswordTextBox";
            this.adminSearchPasswordTextBox.Size = new System.Drawing.Size(226, 26);
            this.adminSearchPasswordTextBox.TabIndex = 78;
            // 
            // label137
            // 
            this.label137.AutoSize = true;
            this.label137.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label137.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label137.Location = new System.Drawing.Point(64, 412);
            this.label137.Name = "label137";
            this.label137.Size = new System.Drawing.Size(78, 20);
            this.label137.TabIndex = 77;
            this.label137.Text = "Password";
            // 
            // adminSearchAdminIDTextBox
            // 
            this.adminSearchAdminIDTextBox.Enabled = false;
            this.adminSearchAdminIDTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminSearchAdminIDTextBox.Location = new System.Drawing.Point(167, 297);
            this.adminSearchAdminIDTextBox.Name = "adminSearchAdminIDTextBox";
            this.adminSearchAdminIDTextBox.Size = new System.Drawing.Size(227, 26);
            this.adminSearchAdminIDTextBox.TabIndex = 76;
            // 
            // label138
            // 
            this.label138.AutoSize = true;
            this.label138.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label138.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label138.Location = new System.Drawing.Point(72, 301);
            this.label138.Name = "label138";
            this.label138.Size = new System.Drawing.Size(64, 17);
            this.label138.TabIndex = 75;
            this.label138.Text = "Admin ID";
            // 
            // adminSearchBrowseButton
            // 
            this.adminSearchBrowseButton.BackColor = System.Drawing.Color.MistyRose;
            this.adminSearchBrowseButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.adminSearchBrowseButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.adminSearchBrowseButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminSearchBrowseButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.adminSearchBrowseButton.Location = new System.Drawing.Point(837, 462);
            this.adminSearchBrowseButton.Name = "adminSearchBrowseButton";
            this.adminSearchBrowseButton.Size = new System.Drawing.Size(99, 26);
            this.adminSearchBrowseButton.TabIndex = 74;
            this.adminSearchBrowseButton.Text = "Browse";
            this.adminSearchBrowseButton.UseVisualStyleBackColor = false;
            this.adminSearchBrowseButton.Click += new System.EventHandler(this.adminSearchBrowseButton_Click);
            // 
            // adminSearchPicture
            // 
            this.adminSearchPicture.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.adminSearchPicture.Location = new System.Drawing.Point(794, 302);
            this.adminSearchPicture.Name = "adminSearchPicture";
            this.adminSearchPicture.Size = new System.Drawing.Size(153, 143);
            this.adminSearchPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.adminSearchPicture.TabIndex = 73;
            this.adminSearchPicture.TabStop = false;
            // 
            // adminSearchBGComboBox
            // 
            this.adminSearchBGComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminSearchBGComboBox.FormattingEnabled = true;
            this.adminSearchBGComboBox.Items.AddRange(new object[] {
            "A+",
            "A-",
            "B+",
            "B-",
            "AB+",
            "AB-",
            "O+",
            "O-"});
            this.adminSearchBGComboBox.Location = new System.Drawing.Point(563, 350);
            this.adminSearchBGComboBox.Name = "adminSearchBGComboBox";
            this.adminSearchBGComboBox.Size = new System.Drawing.Size(181, 28);
            this.adminSearchBGComboBox.TabIndex = 72;
            // 
            // label139
            // 
            this.label139.AutoSize = true;
            this.label139.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label139.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label139.Location = new System.Drawing.Point(448, 354);
            this.label139.Name = "label139";
            this.label139.Size = new System.Drawing.Size(99, 20);
            this.label139.TabIndex = 71;
            this.label139.Text = "Blood Group";
            // 
            // adminSearchUpdateButton
            // 
            this.adminSearchUpdateButton.BackColor = System.Drawing.Color.MistyRose;
            this.adminSearchUpdateButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.adminSearchUpdateButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.adminSearchUpdateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminSearchUpdateButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.adminSearchUpdateButton.Location = new System.Drawing.Point(704, 657);
            this.adminSearchUpdateButton.Name = "adminSearchUpdateButton";
            this.adminSearchUpdateButton.Size = new System.Drawing.Size(128, 26);
            this.adminSearchUpdateButton.TabIndex = 70;
            this.adminSearchUpdateButton.Text = "Update";
            this.adminSearchUpdateButton.UseVisualStyleBackColor = false;
            this.adminSearchUpdateButton.Click += new System.EventHandler(this.adminSearchUpdateButton_Click);
            // 
            // adminSearchDOBTextBox
            // 
            this.adminSearchDOBTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminSearchDOBTextBox.Location = new System.Drawing.Point(559, 302);
            this.adminSearchDOBTextBox.Name = "adminSearchDOBTextBox";
            this.adminSearchDOBTextBox.Size = new System.Drawing.Size(185, 26);
            this.adminSearchDOBTextBox.TabIndex = 69;
            // 
            // adminSearchGenderComboBox
            // 
            this.adminSearchGenderComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminSearchGenderComboBox.FormattingEnabled = true;
            this.adminSearchGenderComboBox.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Others"});
            this.adminSearchGenderComboBox.Location = new System.Drawing.Point(167, 372);
            this.adminSearchGenderComboBox.Name = "adminSearchGenderComboBox";
            this.adminSearchGenderComboBox.Size = new System.Drawing.Size(227, 28);
            this.adminSearchGenderComboBox.TabIndex = 65;
            // 
            // adminSearchAddressTextBox
            // 
            this.adminSearchAddressTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminSearchAddressTextBox.Location = new System.Drawing.Point(146, 520);
            this.adminSearchAddressTextBox.Name = "adminSearchAddressTextBox";
            this.adminSearchAddressTextBox.Size = new System.Drawing.Size(545, 63);
            this.adminSearchAddressTextBox.TabIndex = 64;
            this.adminSearchAddressTextBox.Text = "";
            // 
            // adminSearchEmailTextBox
            // 
            this.adminSearchEmailTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminSearchEmailTextBox.Location = new System.Drawing.Point(562, 400);
            this.adminSearchEmailTextBox.Name = "adminSearchEmailTextBox";
            this.adminSearchEmailTextBox.Size = new System.Drawing.Size(180, 26);
            this.adminSearchEmailTextBox.TabIndex = 63;
            // 
            // adminSearchPhoneNumberTextBox
            // 
            this.adminSearchPhoneNumberTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminSearchPhoneNumberTextBox.Location = new System.Drawing.Point(562, 439);
            this.adminSearchPhoneNumberTextBox.Name = "adminSearchPhoneNumberTextBox";
            this.adminSearchPhoneNumberTextBox.Size = new System.Drawing.Size(181, 26);
            this.adminSearchPhoneNumberTextBox.TabIndex = 62;
            // 
            // adminSearchNameTextBox
            // 
            this.adminSearchNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminSearchNameTextBox.Location = new System.Drawing.Point(168, 336);
            this.adminSearchNameTextBox.Name = "adminSearchNameTextBox";
            this.adminSearchNameTextBox.Size = new System.Drawing.Size(227, 26);
            this.adminSearchNameTextBox.TabIndex = 61;
            // 
            // label141
            // 
            this.label141.AutoSize = true;
            this.label141.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label141.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label141.Location = new System.Drawing.Point(68, 537);
            this.label141.Name = "label141";
            this.label141.Size = new System.Drawing.Size(68, 20);
            this.label141.TabIndex = 60;
            this.label141.Text = "Address";
            // 
            // label142
            // 
            this.label142.AutoSize = true;
            this.label142.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label142.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label142.Location = new System.Drawing.Point(420, 442);
            this.label142.Name = "label142";
            this.label142.Size = new System.Drawing.Size(115, 20);
            this.label142.TabIndex = 59;
            this.label142.Text = "Phone Number";
            // 
            // label143
            // 
            this.label143.AutoSize = true;
            this.label143.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label143.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label143.Location = new System.Drawing.Point(486, 400);
            this.label143.Name = "label143";
            this.label143.Size = new System.Drawing.Size(48, 20);
            this.label143.TabIndex = 58;
            this.label143.Text = "Email";
            // 
            // label144
            // 
            this.label144.AutoSize = true;
            this.label144.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label144.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label144.Location = new System.Drawing.Point(91, 340);
            this.label144.Name = "label144";
            this.label144.Size = new System.Drawing.Size(51, 20);
            this.label144.TabIndex = 57;
            this.label144.Text = "Name";
            // 
            // label145
            // 
            this.label145.AutoSize = true;
            this.label145.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label145.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label145.Location = new System.Drawing.Point(439, 306);
            this.label145.Name = "label145";
            this.label145.Size = new System.Drawing.Size(102, 20);
            this.label145.TabIndex = 56;
            this.label145.Text = "Date Of Birth";
            // 
            // label146
            // 
            this.label146.AutoSize = true;
            this.label146.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label146.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label146.Location = new System.Drawing.Point(80, 378);
            this.label146.Name = "label146";
            this.label146.Size = new System.Drawing.Size(63, 20);
            this.label146.TabIndex = 55;
            this.label146.Text = "Gender";
            // 
            // label148
            // 
            this.label148.AutoSize = true;
            this.label148.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.label148.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label148.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label148.Location = new System.Drawing.Point(365, -153);
            this.label148.Name = "label148";
            this.label148.Size = new System.Drawing.Size(133, 26);
            this.label148.TabIndex = 33;
            this.label148.Text = "Search User";
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.Silver;
            this.button10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button10.Cursor = System.Windows.Forms.Cursors.Default;
            this.button10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button10.Location = new System.Drawing.Point(719, -134);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(99, 26);
            this.button10.TabIndex = 5;
            this.button10.Text = "Search";
            this.button10.UseVisualStyleBackColor = false;
            // 
            // adminSearchData
            // 
            this.adminSearchData.AllowUserToAddRows = false;
            this.adminSearchData.AllowUserToDeleteRows = false;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.adminSearchData.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.adminSearchData.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(52)))), ((int)(((byte)(118)))));
            this.adminSearchData.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.adminSearchData.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.adminSearchData.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.adminSearchData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.adminSearchData.EnableHeadersVisualStyles = false;
            this.adminSearchData.Location = new System.Drawing.Point(12, 65);
            this.adminSearchData.Name = "adminSearchData";
            this.adminSearchData.ReadOnly = true;
            this.adminSearchData.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.adminSearchData.Size = new System.Drawing.Size(768, 185);
            this.adminSearchData.TabIndex = 4;
            this.adminSearchData.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.adminSearchData_CellClick);
            // 
            // textBox14
            // 
            this.textBox14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox14.Location = new System.Drawing.Point(577, -131);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(93, 26);
            this.textBox14.TabIndex = 3;
            // 
            // label149
            // 
            this.label149.AutoSize = true;
            this.label149.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.label149.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label149.Location = new System.Drawing.Point(521, -128);
            this.label149.Name = "label149";
            this.label149.Size = new System.Drawing.Size(26, 20);
            this.label149.TabIndex = 2;
            this.label149.Text = "ID";
            // 
            // menu
            // 
            this.menu.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("menu.BackgroundImage")));
            this.menu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.menu.Controls.Add(this.adminMenuButton);
            this.menu.Controls.Add(this.LogoutBotton);
            this.menu.Controls.Add(this.termExamMenuButton);
            this.menu.Controls.Add(this.teacherMenuButton);
            this.menu.Controls.Add(this.employeeMenuButton);
            this.menu.Controls.Add(this.attendanceMenuButton);
            this.menu.Controls.Add(this.studentMenuButton);
            this.menu.Dock = System.Windows.Forms.DockStyle.Left;
            this.menu.Location = new System.Drawing.Point(0, 0);
            this.menu.Name = "menu";
            this.menu.Size = new System.Drawing.Size(185, 670);
            this.menu.TabIndex = 0;
            // 
            // adminMenuButton
            // 
            this.adminMenuButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(48)))), ((int)(((byte)(146)))));
            this.adminMenuButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.adminMenuButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.adminMenuButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminMenuButton.ForeColor = System.Drawing.Color.White;
            this.adminMenuButton.Location = new System.Drawing.Point(0, 400);
            this.adminMenuButton.Name = "adminMenuButton";
            this.adminMenuButton.Size = new System.Drawing.Size(186, 33);
            this.adminMenuButton.TabIndex = 10;
            this.adminMenuButton.Text = "Administrator";
            this.adminMenuButton.UseVisualStyleBackColor = false;
            this.adminMenuButton.Click += new System.EventHandler(this.adminMenuButton_Click);
            // 
            // LogoutBotton
            // 
            this.LogoutBotton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(48)))), ((int)(((byte)(146)))));
            this.LogoutBotton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.LogoutBotton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.LogoutBotton.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)), true);
            this.LogoutBotton.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.LogoutBotton.Location = new System.Drawing.Point(4, 564);
            this.LogoutBotton.Name = "LogoutBotton";
            this.LogoutBotton.Size = new System.Drawing.Size(176, 76);
            this.LogoutBotton.TabIndex = 9;
            this.LogoutBotton.Text = "Log Out";
            this.LogoutBotton.UseVisualStyleBackColor = false;
            this.LogoutBotton.Click += new System.EventHandler(this.LogoutBotton_Click);
            // 
            // termExamMenuButton
            // 
            this.termExamMenuButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(48)))), ((int)(((byte)(146)))));
            this.termExamMenuButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.termExamMenuButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.termExamMenuButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.termExamMenuButton.ForeColor = System.Drawing.Color.White;
            this.termExamMenuButton.Location = new System.Drawing.Point(0, 346);
            this.termExamMenuButton.Name = "termExamMenuButton";
            this.termExamMenuButton.Size = new System.Drawing.Size(186, 33);
            this.termExamMenuButton.TabIndex = 6;
            this.termExamMenuButton.Text = "Term Exam";
            this.termExamMenuButton.UseVisualStyleBackColor = false;
            this.termExamMenuButton.Click += new System.EventHandler(this.termExamMenuButton_Click);
            // 
            // teacherMenuButton
            // 
            this.teacherMenuButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(48)))), ((int)(((byte)(146)))));
            this.teacherMenuButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.teacherMenuButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.teacherMenuButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.teacherMenuButton.ForeColor = System.Drawing.Color.White;
            this.teacherMenuButton.Location = new System.Drawing.Point(-1, 290);
            this.teacherMenuButton.Name = "teacherMenuButton";
            this.teacherMenuButton.Size = new System.Drawing.Size(186, 33);
            this.teacherMenuButton.TabIndex = 5;
            this.teacherMenuButton.Text = "Teacher";
            this.teacherMenuButton.UseVisualStyleBackColor = false;
            this.teacherMenuButton.Click += new System.EventHandler(this.teacherMenuButton_Click);
            // 
            // employeeMenuButton
            // 
            this.employeeMenuButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(48)))), ((int)(((byte)(146)))));
            this.employeeMenuButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.employeeMenuButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.employeeMenuButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.employeeMenuButton.ForeColor = System.Drawing.Color.White;
            this.employeeMenuButton.Location = new System.Drawing.Point(-1, 172);
            this.employeeMenuButton.Name = "employeeMenuButton";
            this.employeeMenuButton.Size = new System.Drawing.Size(186, 33);
            this.employeeMenuButton.TabIndex = 4;
            this.employeeMenuButton.Text = "Employee ";
            this.employeeMenuButton.UseVisualStyleBackColor = false;
            this.employeeMenuButton.Click += new System.EventHandler(this.employeeMenuButton_Click);
            // 
            // attendanceMenuButton
            // 
            this.attendanceMenuButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(48)))), ((int)(((byte)(146)))));
            this.attendanceMenuButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.attendanceMenuButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.attendanceMenuButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.attendanceMenuButton.ForeColor = System.Drawing.Color.White;
            this.attendanceMenuButton.Location = new System.Drawing.Point(0, 230);
            this.attendanceMenuButton.Name = "attendanceMenuButton";
            this.attendanceMenuButton.Size = new System.Drawing.Size(185, 33);
            this.attendanceMenuButton.TabIndex = 3;
            this.attendanceMenuButton.Text = "Employee Attendance";
            this.attendanceMenuButton.UseVisualStyleBackColor = false;
            this.attendanceMenuButton.Click += new System.EventHandler(this.attendanceMenuButton_Click);
            // 
            // studentMenuButton
            // 
            this.studentMenuButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(48)))), ((int)(((byte)(146)))));
            this.studentMenuButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.studentMenuButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.studentMenuButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentMenuButton.ForeColor = System.Drawing.Color.White;
            this.studentMenuButton.Location = new System.Drawing.Point(0, 112);
            this.studentMenuButton.Name = "studentMenuButton";
            this.studentMenuButton.Size = new System.Drawing.Size(185, 33);
            this.studentMenuButton.TabIndex = 0;
            this.studentMenuButton.Text = "Students";
            this.studentMenuButton.UseVisualStyleBackColor = false;
            this.studentMenuButton.Click += new System.EventHandler(this.studentMenuButton_Click);
            // 
            // Admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(52)))), ((int)(((byte)(118)))));
            this.ClientSize = new System.Drawing.Size(1260, 670);
            this.Controls.Add(this.adminPanel);
            this.Controls.Add(this.termExamPanel);
            this.Controls.Add(this.teacherPanel);
            this.Controls.Add(this.employeePanel);
            this.Controls.Add(this.tileBarPanel);
            this.Controls.Add(this.menu);
            this.Controls.Add(this.attendancePanel);
            this.Controls.Add(this.studentPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Admin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.attendancePanel.ResumeLayout(false);
            this.employeeAttendanceUpdatePanel.ResumeLayout(false);
            this.employeeAttendanceUpdatePanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.employeeAttendanceData2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeAttendanceUpdateDataGrid)).EndInit();
            this.employeeAttendancePanel.ResumeLayout(false);
            this.employeeAttendancePanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.attendanceEmployeeDataGrid)).EndInit();
            this.employeePanel.ResumeLayout(false);
            this.employeeRegisterPanel.ResumeLayout(false);
            this.employeeRegisterPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.employeeRegisterPictureBox)).EndInit();
            this.employeeSearchPanel.ResumeLayout(false);
            this.employeeSearchPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.employeeSearchPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeSearchDataGrid)).EndInit();
            this.teacherPanel.ResumeLayout(false);
            this.teacherAddPanel.ResumeLayout(false);
            this.teacherAddPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.teacherAddPictureBox)).EndInit();
            this.teacherSearchPanel.ResumeLayout(false);
            this.teacherSearchPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.teacherSearchPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacherSearchDataGrid)).EndInit();
            this.studentPromotionPanel.ResumeLayout(false);
            this.studentPromotionPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.studentPromotionDataGrid)).EndInit();
            this.studentRegistrationPanel.ResumeLayout(false);
            this.studentRegistrationSearchPanel.ResumeLayout(false);
            this.studentRegistrationSearchPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.studentRegistrationSearchDataGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.studentRegistrationSearchPictudeBox)).EndInit();
            this.studentRegistrationRegisterPanel.ResumeLayout(false);
            this.studentRegistrationRegisterPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.studentRegistrationRegisterPictureBox)).EndInit();
            this.studentPanel.ResumeLayout(false);
            this.studentPanel.PerformLayout();
            this.tileBarPanel.ResumeLayout(false);
            this.termExamPanel.ResumeLayout(false);
            this.termExamPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.termExamDataGrid)).EndInit();
            this.adminPanel.ResumeLayout(false);
            this.adminAddPanel.ResumeLayout(false);
            this.adminAddPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.adminAddPicture)).EndInit();
            this.adminSearchPanel.ResumeLayout(false);
            this.adminSearchPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.adminSearchPicture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.adminSearchData)).EndInit();
            this.menu.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        

        

        

        #endregion

        private System.Windows.Forms.Panel menu;
        private System.Windows.Forms.Button studentMenuButton;
        private System.Windows.Forms.Panel studentPanel;
        private System.Windows.Forms.Panel teacherPanel;
        private System.Windows.Forms.Button searchUserButton;
        private System.Windows.Forms.Button addUserButton;
        private System.Windows.Forms.Panel teacherSearchPanel;
        private System.Windows.Forms.DataGridView teacherSearchDataGrid;
        private System.Windows.Forms.TextBox idTextBoxSearch;
        private System.Windows.Forms.Label bunifuCustomLabel13;
        private System.Windows.Forms.Button searchInUserSearchPanelButton;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id;
        private System.Windows.Forms.DataGridViewTextBoxColumn BloodGroup;
        private System.Windows.Forms.DataGridViewTextBoxColumn Gender;
        private System.Windows.Forms.DataGridViewTextBoxColumn DOB;
        private System.Windows.Forms.DataGridViewTextBoxColumn usersFullName;
        private System.Windows.Forms.DataGridViewTextBoxColumn UserName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Email;
        private System.Windows.Forms.DataGridViewTextBoxColumn Password;
        private System.Windows.Forms.DataGridViewTextBoxColumn Phone;
        private System.Windows.Forms.Button studentPromotion;
        private System.Windows.Forms.Button studentRegistrationButton;
        private System.Windows.Forms.Panel studentRegistrationPanel;
        private System.Windows.Forms.Button studentRegistrationSearchButton;
        private System.Windows.Forms.Button studentRegistrationRegisterButton;
        private System.Windows.Forms.Panel studentRegistrationRegisterPanel;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button studentRegistrationRegisterSubmitButton;
        private System.Windows.Forms.DateTimePicker studentRegistrationRegisterDOB;
        private System.Windows.Forms.DateTimePicker studentRegistrationRegisterAdmissionDate;
        private System.Windows.Forms.ComboBox studentRegistrationRegisterDepartmentComboBox;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox studentRegistrationRegisterClassComboBox;
        private System.Windows.Forms.ComboBox studentRegistrationRegisterGenderComboBox;
        private System.Windows.Forms.RichTextBox studentRegistrationRegisterAddressTextBox;
        private System.Windows.Forms.TextBox studentRegistrationRegisterEmailTextBox;
        private System.Windows.Forms.TextBox studentRegistrationRegisterPhoneTextBox;
        private System.Windows.Forms.TextBox studentRegistrationRegisterMotherOccupationTextBox;
        private System.Windows.Forms.TextBox studentRegistrationRegisterMotherNameTextBox;
        private System.Windows.Forms.TextBox studentRegistrationRegisterFatherOccupationTextBox;
        private System.Windows.Forms.TextBox studentRegistrationRegisterFatherNameTextBox;
        private System.Windows.Forms.TextBox studentRegistrationRegisterNameTextBox;
        private System.Windows.Forms.TextBox studentRegistrationRegisterAdmissionNumberTextBox;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel studentPromotionPanel;
        private System.Windows.Forms.ComboBox studentPromotionClassUpdateComboBox;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.ComboBox studentPromotionClassComboBox;
        private System.Windows.Forms.Button studentPromotionSearchButton;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Button studentPromotionPromoteButton;
        private System.Windows.Forms.DataGridView studentPromotionDataGrid;
        private System.Windows.Forms.Panel attendancePanel;
        private System.Windows.Forms.Button attendanceMenuButton;
        private Button crossButton;
        private Panel tileBarPanel;
        private Button employeeMenuButton;
        private ComboBox studentRegistrationRegisterBGComboBox;
        private Label label39;
        private Panel employeePanel;
        private Panel employeeRegisterPanel;
        private Label label71;
        private Button employeeRegisterSubmitButton;
        private DateTimePicker employeeRegisterDOB;
        private DateTimePicker employeeRegisterDate;
        private ComboBox employeeRegisterBGComboBox;
        private Label label35;
        private ComboBox employeeRegisterGenderComboBox;
        private RichTextBox employeeRegisterAddressTextBox;
        private TextBox employeeRegisterEmailTextBox;
        private TextBox employeeRegisterPhoneTextBox;
        private TextBox employeeRegisterNameTextBox;
        private Label label36;
        private Label label40;
        private Label label41;
        private Label label44;
        private Label label45;
        private Label label46;
        private Label label47;
        private Panel employeeSearchPanel;
        private Label label38;
        private Label label52;
        private Button employeeSearchSearchButton;
        private TextBox employeeSearchTextBox;
        private Label label53;
        private Button employeeSearchUpdateButton;
        private Button employeeSearchDeleteButton;
        private DateTimePicker employeeSearchDOBUpdate;
        private DateTimePicker employeeSearchRegisterDateUpdate;
        private ComboBox employeeSearchBGUpdateComboBox;
        private Label label54;
        private ComboBox employeeSearchGenderUpdateComboBox;
        private RichTextBox employeeSearchAddressUpdateTextBox;
        private TextBox employeeSearchEmailUpdateTextBox;
        private TextBox employeeSearchPhoneUpdateTextBox;
        private TextBox employeeSearchNameUpdateTextBox;
        private Label label55;
        private Label label59;
        private Label label60;
        private Label label63;
        private Label label65;
        private Label label66;
        private Label label67;
        private Button employeeSearchButton;
        private Button employeeRegisterButton;
        private Label label43;
        private Label label48;
        private Button studentRegistrationRegisterBrowseButton;
        public PictureBox studentRegistrationRegisterPictureBox;
        private Label label51;
        private TextBox studentRegistrationRegisterStudentIdTextBox;
        private Label label56;
        private Button teacherMenuButton;
        private TextBox studentRegistrationRegisterConfirmPasswordTextBox;
        private Label label31;
        private TextBox studentRegistrationRegisterPasswordTextBox;
        private Label label2;
        private Panel teacherAddPanel;
        private CheckBox teacherAddStd6;
        private CheckBox teacherAddStd10;
        private CheckBox teacherAddStd2;
        private CheckBox teacherAddStd5;
        private CheckBox teacherAddStd8;
        private CheckBox teacherAddStd7;
        private CheckBox teacherAddStd1;
        private CheckBox teacherAddStd3;
        private CheckBox teacherAddStd9;
        private CheckBox teacherAddNursary;
        private CheckBox teacherAddStd4;
        private Label label76;
        private TextBox teacherAddConfirmPasswordTextBox;
        private Label label68;
        private TextBox teacherAddPasswordTextBox;
        private Label label69;
        private TextBox teacherAddTeacherIDTextBox;
        private Label label70;
        private Label label72;
        private Button teacherAddBrowseButton;
        public PictureBox teacherAddPictureBox;
        private ComboBox teacherAddBGComboBox;
        private Label label73;
        private Button teacherAddSubmitButton;
        private DateTimePicker teacherAddDOB;
        private ComboBox teacherAddDepartmentComboBox;
        private Label label74;
        private ComboBox teacherAddSubjectComboBox;
        private ComboBox teacherAddGenderComboBox;
        private RichTextBox teacherAddAddressTextBox;
        private TextBox teacherAddEmailTextBox;
        private TextBox teacherAddPhoneTextBox;
        private TextBox teacherAddNameTextBox;
        private Label label75;
        private Label label79;
        private Label label80;
        private Label label84;
        private Label label85;
        private Label label86;
        private Label label87;
        private Button teacherSearchSearchButton;
        private Label label99;
        private TextBox teacherSearchTextBox;
        private Label label98;
        private Button teacherSearchDelateButton;
        private Label label97;
        private Label label96;
        private CheckBox teacherSearchStd6;
        private CheckBox teacherSearchStd10;
        private CheckBox teacherSearchStd2;
        private CheckBox teacherSearchStd5;
        private CheckBox teacherSearchStd8;
        private CheckBox teacherSearchStd7;
        private CheckBox teacherSearchStd1;
        private CheckBox teacherSearchStd3;
        private CheckBox teacherSearchStd9;
        private CheckBox teacherSearchNursary;
        private CheckBox teacherSearchStd4;
        private Label label77;
        private TextBox teacherSearchConfirmPasswordTextBox;
        private Label label78;
        private TextBox teacherSearchPasswordTextBox;
        private Label label81;
        private TextBox teacherSearchTeacherIdTextBox;
        private Label label82;
        private Button teacherSearchBrowseButton;
        public PictureBox teacherSearchPictureBox;
        private ComboBox teacherSearchBGComboBox;
        private Label label83;
        private Button teacherSearchUpdateButton;
        private DateTimePicker teacherSearchDOB;
        private ComboBox teacherSearchDepartmentComboBox;
        private Label label88;
        private ComboBox teacherSearchSubjectComboBox;
        private ComboBox teacherSearchGenderComboBox;
        private RichTextBox teacherSearchAddressTextBox;
        private TextBox teacherSearchEmailTextBox;
        private TextBox teacherSearchPhoneTextBox;
        private TextBox teacherSearchNameTextBox;
        private Label label89;
        private Label label90;
        private Label label91;
        private Label label92;
        private Label label93;
        private Label label94;
        private Label label95;
        private TextBox employeeRegisterEmployeeIdTextBox;
        private Label label37;
        private Button employeeRegisterBrowseButton;
        private PictureBox employeeRegisterPictureBox;
        private TextBox employeeSearchEmployeeIdTextBox;
        private Button employeeSearchBrowseButton;
        private PictureBox employeeSearchPictureBox;
        private DateTimePicker teacherRegisterRegisterDate;
        private Label label100;
        private Button termExamMenuButton;
        private Panel termExamPanel;
        private ComboBox termExamClassNameComboBox;
        private Label label58;
        private Label label42;
        private DateTimePicker termExamDate;
        private Label label102;
        private ComboBox termExamSubjectComboBox;
        private Label label101;
        private Button termExamUpdateButton;
        private Button termExamDeleteButton;
        private DataGridView termExamDataGrid;
        private Button termExamAddButton;
        private ComboBox termExamDepartmentComboBox;
        private Label label103;
        private Button LogoutBotton;
        private Label label104;
        private Label label105;
        private Label label106;
        private Label label107;
        private Label label108;
        private Label label109;
        private Label label112;
        private Label label111;
        private Label label110;
        private Panel employeeAttendancePanel;
        private DateTimePicker employeeAttendanceDate;
        private Label label113;
        private DataGridView attendanceEmployeeDataGrid;
        private DataGridViewCheckBoxColumn attendance;
        private Button employeeAttendanceDoneButton;
        private Panel employeeAttendanceUpdatePanel;
        private Button employeeAttendanceUpdateButton;
        private DateTimePicker employeeAttendanceUpdateDate;
        private Label label114;
        private DataGridView employeeAttendanceUpdateDataGrid;
        private DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn1;
        private Label label115;
        private Button employeeAttendaceButton;
        private Button employeeAttendanceUpdate;
        private Button employeeAttendanceUpdateSearchButton;
        private DataGridView employeeAttendanceData2;
        private DataGridView employeeSearchDataGrid;
        private Panel adminPanel;
        private Panel adminAddPanel;
        private DateTimePicker adminAddRegisterDate;
        private Label label116;
        private TextBox adminAddConfirmPasswordTextBox;
        private Label label118;
        private TextBox adminAddPasswordTextBox;
        private Label label119;
        private TextBox adminAddAdminIdTextBox;
        private Label label120;
        private Label label121;
        private Button adminAddBrowseButton;
        public PictureBox adminAddPicture;
        private ComboBox adminAddBGComboBox;
        private Label label122;
        private Button adminAddSubmitButton;
        private DateTimePicker adminAddDOB;
        private ComboBox adminAddGenderComboBox;
        private RichTextBox adminAddAddressTextBox;
        private TextBox adminAddEmailTextBox;
        private TextBox adminAddPhoneNumberTextBox;
        private TextBox adminAddNameTextBox;
        private Label label124;
        private Label label125;
        private Label label126;
        private Label label127;
        private Label label128;
        private Label label129;
        private Button adminSearchButton;
        private Button adminAddButton;
        private Panel adminSearchPanel;
        private Button adminSearchSearchButton;
        private Label label131;
        private TextBox adminSearchByIdTextBox;
        private Label label132;
        private Button adminSearchDeleteButton;
        private Label label133;
        private Label label134;
        private TextBox adminSearchConfirmPasswordTextBox;
        private Label label136;
        private TextBox adminSearchPasswordTextBox;
        private Label label137;
        private TextBox adminSearchAdminIDTextBox;
        private Label label138;
        private Button adminSearchBrowseButton;
        public PictureBox adminSearchPicture;
        private ComboBox adminSearchBGComboBox;
        private Label label139;
        private Button adminSearchUpdateButton;
        private DateTimePicker adminSearchDOBTextBox;
        private ComboBox adminSearchGenderComboBox;
        private RichTextBox adminSearchAddressTextBox;
        private TextBox adminSearchEmailTextBox;
        private TextBox adminSearchPhoneNumberTextBox;
        private TextBox adminSearchNameTextBox;
        private Label label141;
        private Label label142;
        private Label label143;
        private Label label144;
        private Label label145;
        private Label label146;
        private Label label148;
        private Button button10;
        private DataGridView adminSearchData;
        private TextBox textBox14;
        private Label label149;
        private Button adminMenuButton;
        private Button button2;
        private Button button3;
        private Button button5;
        private Button button6;
        private Button button7;
        private Panel studentRegistrationSearchPanel;
        private Button button4;
        private TextBox studentRegistrationSearchPasswordTextBox;
        private Label label62;
        private TextBox studentRegistrationSearchConfirmPasswordTextBox;
        private Label label61;
        private ComboBox studentRegistrationSearchBGComboBox;
        private Label label57;
        private Label label49;
        private Button button1;
        private PictureBox studentRegistrationSearchPictudeBox;
        private Label label34;
        private Button studentRegistrationSearchSearchButton;
        private TextBox studentRegistrationSearchIDTextBox;
        private Label label33;
        private Button studentRegistrationSearchUpdateButton;
        private Button studentRegistrationSearchDeleteButton;
        private DateTimePicker studentRegistrationSearchDOBUpdate;
        private DateTimePicker studentRegistrationSearchAdmissionDateUpdate;
        private ComboBox studentRegistrationSearchDepartmentUpdateComboBox;
        private Label label17;
        private ComboBox studentRegistrationSearchClassUpdateComboBox;
        private ComboBox studentRegistrationSearchGenderUpdateComboBox;
        private RichTextBox studentRegistrationSearchAddressUpdateTextBox;
        private TextBox studentRegistrationSearchEmailUpdateTextBox;
        private TextBox studentRegistrationSearchPhoneUpdateTextBox;
        private TextBox studentRegistrationSearchMotherOccupationUpdateTextBox;
        private TextBox studentRegistrationSearchMotherNameUpdateTextBox;
        private TextBox studentRegistrationSearchFatherOccupationUpdateTextBox;
        private TextBox studentRegistrationSearchFatherNameUpdateTextBox;
        private TextBox studentRegistrationSearchNameUpdateTextBox;
        private TextBox studentRegistrationSearchAdmissionNumberUpdateTextBox;
        private Label label18;
        private Label label19;
        private Label label20;
        private Label label21;
        private Label label22;
        private Label label23;
        private Label label24;
        private Label label25;
        private Label label26;
        private Label label27;
        private Label label28;
        private Label label29;
        private Label label30;
        private Label label32;
        private Label label117;
        private DataGridView studentRegistrationSearchDataGrid;
    }
}

