﻿namespace Projectwork111
{
    partial class StudentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StudentForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            this.menu = new System.Windows.Forms.Panel();
            this.profileMenuButton = new System.Windows.Forms.Button();
            this.LogoutBotton = new System.Windows.Forms.Button();
            this.termExamMenuButton = new System.Windows.Forms.Button();
            this.resultMenuButton = new System.Windows.Forms.Button();
            this.examMenuButton = new System.Windows.Forms.Button();
            this.tileBarPanel = new System.Windows.Forms.Panel();
            this.crossButton = new System.Windows.Forms.Button();
            this.examSchedulePanel = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.examScheduleClassTestDataGrid = new System.Windows.Forms.DataGridView();
            this.examScheduleDataGrid = new System.Windows.Forms.DataGridView();
            this.resultPanel = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.resultClassTestDataGrid = new System.Windows.Forms.DataGridView();
            this.resultTermExamDataGrid = new System.Windows.Forms.DataGridView();
            this.termExamPanel = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.termExamListDataGrid = new System.Windows.Forms.DataGridView();
            this.termExamMarksDataGrid = new System.Windows.Forms.DataGridView();
            this.profilePanel = new System.Windows.Forms.Panel();
            this.profileData = new System.Windows.Forms.DataGridView();
            this.profileAdmissionDateTextBox = new System.Windows.Forms.TextBox();
            this.profileDOBTextBox = new System.Windows.Forms.TextBox();
            this.profileClassTextBox = new System.Windows.Forms.TextBox();
            this.profileBGTextBox = new System.Windows.Forms.TextBox();
            this.profileDepartmentTextBox = new System.Windows.Forms.TextBox();
            this.profileGenderTextBox = new System.Windows.Forms.TextBox();
            this.profileConfirmPasswordTextBox = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.profilePasswordTextBox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.profileStudentIdTextBox = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.profilePic = new System.Windows.Forms.PictureBox();
            this.label39 = new System.Windows.Forms.Label();
            this.profileDoneButton = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.profileAddressTextBox = new System.Windows.Forms.RichTextBox();
            this.profileEmailTextBox = new System.Windows.Forms.TextBox();
            this.profilePhoneTextBox = new System.Windows.Forms.TextBox();
            this.profileMotherOccupationTextBox = new System.Windows.Forms.TextBox();
            this.profileMotherNameTextBox = new System.Windows.Forms.TextBox();
            this.profileFatherOccupationTextBox = new System.Windows.Forms.TextBox();
            this.profileFatherNameTextBox = new System.Windows.Forms.TextBox();
            this.profileNameTextBox = new System.Windows.Forms.TextBox();
            this.profileAdmissionNumberTextBox = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.menu.SuspendLayout();
            this.tileBarPanel.SuspendLayout();
            this.examSchedulePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.examScheduleClassTestDataGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.examScheduleDataGrid)).BeginInit();
            this.resultPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.resultClassTestDataGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resultTermExamDataGrid)).BeginInit();
            this.termExamPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.termExamListDataGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.termExamMarksDataGrid)).BeginInit();
            this.profilePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.profileData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.profilePic)).BeginInit();
            this.SuspendLayout();
            // 
            // menu
            // 
            this.menu.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("menu.BackgroundImage")));
            this.menu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.menu.Controls.Add(this.profileMenuButton);
            this.menu.Controls.Add(this.LogoutBotton);
            this.menu.Controls.Add(this.termExamMenuButton);
            this.menu.Controls.Add(this.resultMenuButton);
            this.menu.Controls.Add(this.examMenuButton);
            this.menu.Dock = System.Windows.Forms.DockStyle.Left;
            this.menu.Location = new System.Drawing.Point(0, 0);
            this.menu.Name = "menu";
            this.menu.Size = new System.Drawing.Size(185, 670);
            this.menu.TabIndex = 2;
            // 
            // profileMenuButton
            // 
            this.profileMenuButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(48)))), ((int)(((byte)(146)))));
            this.profileMenuButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.profileMenuButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.profileMenuButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileMenuButton.ForeColor = System.Drawing.Color.White;
            this.profileMenuButton.Location = new System.Drawing.Point(0, 317);
            this.profileMenuButton.Name = "profileMenuButton";
            this.profileMenuButton.Size = new System.Drawing.Size(185, 44);
            this.profileMenuButton.TabIndex = 9;
            this.profileMenuButton.Text = "Profile";
            this.profileMenuButton.UseVisualStyleBackColor = false;
            this.profileMenuButton.Click += new System.EventHandler(this.profileMenuButton_Click);
            // 
            // LogoutBotton
            // 
            this.LogoutBotton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(48)))), ((int)(((byte)(146)))));
            this.LogoutBotton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.LogoutBotton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.LogoutBotton.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)), true);
            this.LogoutBotton.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.LogoutBotton.Location = new System.Drawing.Point(3, 558);
            this.LogoutBotton.Name = "LogoutBotton";
            this.LogoutBotton.Size = new System.Drawing.Size(176, 76);
            this.LogoutBotton.TabIndex = 8;
            this.LogoutBotton.Text = "Log Out";
            this.LogoutBotton.UseVisualStyleBackColor = false;
            this.LogoutBotton.Click += new System.EventHandler(this.LogoutBotton_Click);
            // 
            // termExamMenuButton
            // 
            this.termExamMenuButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(48)))), ((int)(((byte)(146)))));
            this.termExamMenuButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.termExamMenuButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.termExamMenuButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.termExamMenuButton.ForeColor = System.Drawing.Color.White;
            this.termExamMenuButton.Location = new System.Drawing.Point(0, 258);
            this.termExamMenuButton.Name = "termExamMenuButton";
            this.termExamMenuButton.Size = new System.Drawing.Size(185, 44);
            this.termExamMenuButton.TabIndex = 7;
            this.termExamMenuButton.Text = "Term Exam";
            this.termExamMenuButton.UseVisualStyleBackColor = false;
            this.termExamMenuButton.Click += new System.EventHandler(this.termExamMenuButton_Click);
            // 
            // resultMenuButton
            // 
            this.resultMenuButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(48)))), ((int)(((byte)(146)))));
            this.resultMenuButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.resultMenuButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.resultMenuButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resultMenuButton.ForeColor = System.Drawing.Color.White;
            this.resultMenuButton.Location = new System.Drawing.Point(0, 204);
            this.resultMenuButton.Name = "resultMenuButton";
            this.resultMenuButton.Size = new System.Drawing.Size(184, 44);
            this.resultMenuButton.TabIndex = 6;
            this.resultMenuButton.Text = "Class Test Result";
            this.resultMenuButton.UseVisualStyleBackColor = false;
            this.resultMenuButton.Click += new System.EventHandler(this.resultMenuButton_Click);
            // 
            // examMenuButton
            // 
            this.examMenuButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(48)))), ((int)(((byte)(146)))));
            this.examMenuButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.examMenuButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.examMenuButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.examMenuButton.ForeColor = System.Drawing.Color.White;
            this.examMenuButton.Location = new System.Drawing.Point(1, 148);
            this.examMenuButton.Name = "examMenuButton";
            this.examMenuButton.Size = new System.Drawing.Size(183, 44);
            this.examMenuButton.TabIndex = 5;
            this.examMenuButton.Text = "Exam Scheduel";
            this.examMenuButton.UseVisualStyleBackColor = false;
            this.examMenuButton.Click += new System.EventHandler(this.examMenuButton_Click);
            // 
            // tileBarPanel
            // 
            this.tileBarPanel.BackColor = System.Drawing.Color.Silver;
            this.tileBarPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tileBarPanel.Controls.Add(this.crossButton);
            this.tileBarPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.tileBarPanel.Location = new System.Drawing.Point(185, 0);
            this.tileBarPanel.Name = "tileBarPanel";
            this.tileBarPanel.Size = new System.Drawing.Size(1075, 20);
            this.tileBarPanel.TabIndex = 8;
            // 
            // crossButton
            // 
            this.crossButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.crossButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("crossButton.BackgroundImage")));
            this.crossButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.crossButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.crossButton.Location = new System.Drawing.Point(1049, 0);
            this.crossButton.Name = "crossButton";
            this.crossButton.Size = new System.Drawing.Size(26, 20);
            this.crossButton.TabIndex = 0;
            this.crossButton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.crossButton.UseVisualStyleBackColor = false;
            this.crossButton.Click += new System.EventHandler(this.crossButton_Click);
            // 
            // examSchedulePanel
            // 
            this.examSchedulePanel.AutoScroll = true;
            this.examSchedulePanel.Controls.Add(this.label3);
            this.examSchedulePanel.Controls.Add(this.label2);
            this.examSchedulePanel.Controls.Add(this.label1);
            this.examSchedulePanel.Controls.Add(this.examScheduleClassTestDataGrid);
            this.examSchedulePanel.Controls.Add(this.examScheduleDataGrid);
            this.examSchedulePanel.Location = new System.Drawing.Point(200, 40);
            this.examSchedulePanel.Name = "examSchedulePanel";
            this.examSchedulePanel.Size = new System.Drawing.Size(106, 55);
            this.examSchedulePanel.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label3.Location = new System.Drawing.Point(288, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(166, 26);
            this.label3.TabIndex = 85;
            this.label3.Text = "Exam Schedule";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(57, 281);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 20);
            this.label2.TabIndex = 84;
            this.label2.Text = "Term Exam";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(58, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 20);
            this.label1.TabIndex = 83;
            this.label1.Text = "Class Test";
            // 
            // examScheduleClassTestDataGrid
            // 
            this.examScheduleClassTestDataGrid.AllowUserToAddRows = false;
            this.examScheduleClassTestDataGrid.AllowUserToDeleteRows = false;
            this.examScheduleClassTestDataGrid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(52)))), ((int)(((byte)(118)))));
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.examScheduleClassTestDataGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.examScheduleClassTestDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.examScheduleClassTestDataGrid.DefaultCellStyle = dataGridViewCellStyle2;
            this.examScheduleClassTestDataGrid.Location = new System.Drawing.Point(61, 99);
            this.examScheduleClassTestDataGrid.Name = "examScheduleClassTestDataGrid";
            this.examScheduleClassTestDataGrid.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.examScheduleClassTestDataGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.examScheduleClassTestDataGrid.Size = new System.Drawing.Size(513, 167);
            this.examScheduleClassTestDataGrid.TabIndex = 82;
            // 
            // examScheduleDataGrid
            // 
            this.examScheduleDataGrid.AllowUserToAddRows = false;
            this.examScheduleDataGrid.AllowUserToDeleteRows = false;
            this.examScheduleDataGrid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(52)))), ((int)(((byte)(118)))));
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.examScheduleDataGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.examScheduleDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.examScheduleDataGrid.DefaultCellStyle = dataGridViewCellStyle5;
            this.examScheduleDataGrid.Location = new System.Drawing.Point(61, 304);
            this.examScheduleDataGrid.Name = "examScheduleDataGrid";
            this.examScheduleDataGrid.ReadOnly = true;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.examScheduleDataGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.examScheduleDataGrid.Size = new System.Drawing.Size(513, 167);
            this.examScheduleDataGrid.TabIndex = 81;
            // 
            // resultPanel
            // 
            this.resultPanel.AutoScroll = true;
            this.resultPanel.Controls.Add(this.label4);
            this.resultPanel.Controls.Add(this.label5);
            this.resultPanel.Controls.Add(this.label6);
            this.resultPanel.Controls.Add(this.resultClassTestDataGrid);
            this.resultPanel.Controls.Add(this.resultTermExamDataGrid);
            this.resultPanel.Location = new System.Drawing.Point(331, 31);
            this.resultPanel.Name = "resultPanel";
            this.resultPanel.Size = new System.Drawing.Size(123, 46);
            this.resultPanel.TabIndex = 86;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label4.Location = new System.Drawing.Point(288, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(148, 26);
            this.label4.TabIndex = 85;
            this.label4.Text = "Exam Results";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(57, 344);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(133, 20);
            this.label5.TabIndex = 84;
            this.label5.Text = "Class Test Result";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(58, 69);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 20);
            this.label6.TabIndex = 83;
            this.label6.Text = "Class Test";
            // 
            // resultClassTestDataGrid
            // 
            this.resultClassTestDataGrid.AllowUserToAddRows = false;
            this.resultClassTestDataGrid.AllowUserToDeleteRows = false;
            this.resultClassTestDataGrid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(52)))), ((int)(((byte)(118)))));
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.resultClassTestDataGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.resultClassTestDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.resultClassTestDataGrid.DefaultCellStyle = dataGridViewCellStyle8;
            this.resultClassTestDataGrid.Location = new System.Drawing.Point(61, 99);
            this.resultClassTestDataGrid.Name = "resultClassTestDataGrid";
            this.resultClassTestDataGrid.ReadOnly = true;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.resultClassTestDataGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.resultClassTestDataGrid.Size = new System.Drawing.Size(747, 167);
            this.resultClassTestDataGrid.TabIndex = 82;
            this.resultClassTestDataGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.resultClassTestDataGrid_CellClick);
            // 
            // resultTermExamDataGrid
            // 
            this.resultTermExamDataGrid.AllowUserToAddRows = false;
            this.resultTermExamDataGrid.AllowUserToDeleteRows = false;
            this.resultTermExamDataGrid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(52)))), ((int)(((byte)(118)))));
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.resultTermExamDataGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.resultTermExamDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.resultTermExamDataGrid.DefaultCellStyle = dataGridViewCellStyle11;
            this.resultTermExamDataGrid.Location = new System.Drawing.Point(61, 367);
            this.resultTermExamDataGrid.Name = "resultTermExamDataGrid";
            this.resultTermExamDataGrid.ReadOnly = true;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.resultTermExamDataGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.resultTermExamDataGrid.Size = new System.Drawing.Size(747, 167);
            this.resultTermExamDataGrid.TabIndex = 81;
            // 
            // termExamPanel
            // 
            this.termExamPanel.AutoScroll = true;
            this.termExamPanel.Controls.Add(this.label7);
            this.termExamPanel.Controls.Add(this.label8);
            this.termExamPanel.Controls.Add(this.label9);
            this.termExamPanel.Controls.Add(this.termExamListDataGrid);
            this.termExamPanel.Controls.Add(this.termExamMarksDataGrid);
            this.termExamPanel.Location = new System.Drawing.Point(473, 31);
            this.termExamPanel.Name = "termExamPanel";
            this.termExamPanel.Size = new System.Drawing.Size(113, 41);
            this.termExamPanel.TabIndex = 87;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label7.Location = new System.Drawing.Point(386, 7);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(204, 26);
            this.label7.TabIndex = 85;
            this.label7.Text = "Term Exam Results";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label8.Location = new System.Drawing.Point(57, 344);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(95, 20);
            this.label8.TabIndex = 84;
            this.label8.Text = "Term Result";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label9.Location = new System.Drawing.Point(58, 69);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(160, 20);
            this.label9.TabIndex = 83;
            this.label9.Text = "Term Exam Scheduel";
            // 
            // termExamListDataGrid
            // 
            this.termExamListDataGrid.AllowUserToAddRows = false;
            this.termExamListDataGrid.AllowUserToDeleteRows = false;
            this.termExamListDataGrid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(52)))), ((int)(((byte)(118)))));
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.termExamListDataGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.termExamListDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.termExamListDataGrid.DefaultCellStyle = dataGridViewCellStyle14;
            this.termExamListDataGrid.Location = new System.Drawing.Point(61, 99);
            this.termExamListDataGrid.Name = "termExamListDataGrid";
            this.termExamListDataGrid.ReadOnly = true;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.termExamListDataGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle15;
            this.termExamListDataGrid.Size = new System.Drawing.Size(747, 167);
            this.termExamListDataGrid.TabIndex = 82;
            this.termExamListDataGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.termExamListDataGrid_CellClick);
            // 
            // termExamMarksDataGrid
            // 
            this.termExamMarksDataGrid.AllowUserToAddRows = false;
            this.termExamMarksDataGrid.AllowUserToDeleteRows = false;
            this.termExamMarksDataGrid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(52)))), ((int)(((byte)(118)))));
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.termExamMarksDataGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle16;
            this.termExamMarksDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.termExamMarksDataGrid.DefaultCellStyle = dataGridViewCellStyle17;
            this.termExamMarksDataGrid.Location = new System.Drawing.Point(61, 367);
            this.termExamMarksDataGrid.Name = "termExamMarksDataGrid";
            this.termExamMarksDataGrid.ReadOnly = true;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.termExamMarksDataGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle18;
            this.termExamMarksDataGrid.Size = new System.Drawing.Size(747, 167);
            this.termExamMarksDataGrid.TabIndex = 81;
            // 
            // profilePanel
            // 
            this.profilePanel.AutoScroll = true;
            this.profilePanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.profilePanel.Controls.Add(this.profileData);
            this.profilePanel.Controls.Add(this.profileAdmissionDateTextBox);
            this.profilePanel.Controls.Add(this.profileDOBTextBox);
            this.profilePanel.Controls.Add(this.profileClassTextBox);
            this.profilePanel.Controls.Add(this.profileBGTextBox);
            this.profilePanel.Controls.Add(this.profileDepartmentTextBox);
            this.profilePanel.Controls.Add(this.profileGenderTextBox);
            this.profilePanel.Controls.Add(this.profileConfirmPasswordTextBox);
            this.profilePanel.Controls.Add(this.label31);
            this.profilePanel.Controls.Add(this.profilePasswordTextBox);
            this.profilePanel.Controls.Add(this.label10);
            this.profilePanel.Controls.Add(this.profileStudentIdTextBox);
            this.profilePanel.Controls.Add(this.label56);
            this.profilePanel.Controls.Add(this.label48);
            this.profilePanel.Controls.Add(this.profilePic);
            this.profilePanel.Controls.Add(this.label39);
            this.profilePanel.Controls.Add(this.profileDoneButton);
            this.profilePanel.Controls.Add(this.label16);
            this.profilePanel.Controls.Add(this.profileAddressTextBox);
            this.profilePanel.Controls.Add(this.profileEmailTextBox);
            this.profilePanel.Controls.Add(this.profilePhoneTextBox);
            this.profilePanel.Controls.Add(this.profileMotherOccupationTextBox);
            this.profilePanel.Controls.Add(this.profileMotherNameTextBox);
            this.profilePanel.Controls.Add(this.profileFatherOccupationTextBox);
            this.profilePanel.Controls.Add(this.profileFatherNameTextBox);
            this.profilePanel.Controls.Add(this.profileNameTextBox);
            this.profilePanel.Controls.Add(this.profileAdmissionNumberTextBox);
            this.profilePanel.Controls.Add(this.label15);
            this.profilePanel.Controls.Add(this.label11);
            this.profilePanel.Controls.Add(this.label12);
            this.profilePanel.Controls.Add(this.label13);
            this.profilePanel.Controls.Add(this.label14);
            this.profilePanel.Controls.Add(this.label17);
            this.profilePanel.Controls.Add(this.label18);
            this.profilePanel.Controls.Add(this.label19);
            this.profilePanel.Controls.Add(this.label20);
            this.profilePanel.Controls.Add(this.label21);
            this.profilePanel.Controls.Add(this.label22);
            this.profilePanel.Controls.Add(this.label23);
            this.profilePanel.Controls.Add(this.label24);
            this.profilePanel.Controls.Add(this.label25);
            this.profilePanel.Location = new System.Drawing.Point(200, 123);
            this.profilePanel.Name = "profilePanel";
            this.profilePanel.Size = new System.Drawing.Size(1048, 535);
            this.profilePanel.TabIndex = 88;
            this.profilePanel.Visible = false;
            // 
            // profileData
            // 
            this.profileData.AllowUserToAddRows = false;
            this.profileData.AllowUserToDeleteRows = false;
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle19.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle19.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.profileData.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle19;
            this.profileData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle20.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle20.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.profileData.DefaultCellStyle = dataGridViewCellStyle20;
            this.profileData.Location = new System.Drawing.Point(12, 16);
            this.profileData.Name = "profileData";
            this.profileData.ReadOnly = true;
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle21.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle21.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle21.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle21.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle21.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.profileData.RowHeadersDefaultCellStyle = dataGridViewCellStyle21;
            this.profileData.Size = new System.Drawing.Size(75, 48);
            this.profileData.TabIndex = 48;
            this.profileData.Visible = false;
            // 
            // profileAdmissionDateTextBox
            // 
            this.profileAdmissionDateTextBox.Enabled = false;
            this.profileAdmissionDateTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileAdmissionDateTextBox.Location = new System.Drawing.Point(592, 71);
            this.profileAdmissionDateTextBox.Name = "profileAdmissionDateTextBox";
            this.profileAdmissionDateTextBox.Size = new System.Drawing.Size(184, 26);
            this.profileAdmissionDateTextBox.TabIndex = 47;
            // 
            // profileDOBTextBox
            // 
            this.profileDOBTextBox.Enabled = false;
            this.profileDOBTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileDOBTextBox.Location = new System.Drawing.Point(592, 106);
            this.profileDOBTextBox.Name = "profileDOBTextBox";
            this.profileDOBTextBox.Size = new System.Drawing.Size(184, 26);
            this.profileDOBTextBox.TabIndex = 46;
            // 
            // profileClassTextBox
            // 
            this.profileClassTextBox.Enabled = false;
            this.profileClassTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileClassTextBox.Location = new System.Drawing.Point(592, 143);
            this.profileClassTextBox.Name = "profileClassTextBox";
            this.profileClassTextBox.Size = new System.Drawing.Size(184, 26);
            this.profileClassTextBox.TabIndex = 45;
            // 
            // profileBGTextBox
            // 
            this.profileBGTextBox.Enabled = false;
            this.profileBGTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileBGTextBox.Location = new System.Drawing.Point(592, 178);
            this.profileBGTextBox.Name = "profileBGTextBox";
            this.profileBGTextBox.Size = new System.Drawing.Size(184, 26);
            this.profileBGTextBox.TabIndex = 44;
            // 
            // profileDepartmentTextBox
            // 
            this.profileDepartmentTextBox.Enabled = false;
            this.profileDepartmentTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileDepartmentTextBox.Location = new System.Drawing.Point(592, 214);
            this.profileDepartmentTextBox.Name = "profileDepartmentTextBox";
            this.profileDepartmentTextBox.Size = new System.Drawing.Size(184, 26);
            this.profileDepartmentTextBox.TabIndex = 43;
            // 
            // profileGenderTextBox
            // 
            this.profileGenderTextBox.Enabled = false;
            this.profileGenderTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileGenderTextBox.Location = new System.Drawing.Point(188, 160);
            this.profileGenderTextBox.Name = "profileGenderTextBox";
            this.profileGenderTextBox.Size = new System.Drawing.Size(227, 26);
            this.profileGenderTextBox.TabIndex = 42;
            // 
            // profileConfirmPasswordTextBox
            // 
            this.profileConfirmPasswordTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileConfirmPasswordTextBox.Location = new System.Drawing.Point(189, 230);
            this.profileConfirmPasswordTextBox.Name = "profileConfirmPasswordTextBox";
            this.profileConfirmPasswordTextBox.Size = new System.Drawing.Size(226, 26);
            this.profileConfirmPasswordTextBox.TabIndex = 41;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label31.Location = new System.Drawing.Point(43, 234);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(137, 20);
            this.label31.TabIndex = 40;
            this.label31.Text = "Confirm Password";
            // 
            // profilePasswordTextBox
            // 
            this.profilePasswordTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profilePasswordTextBox.Location = new System.Drawing.Point(189, 195);
            this.profilePasswordTextBox.Name = "profilePasswordTextBox";
            this.profilePasswordTextBox.Size = new System.Drawing.Size(226, 26);
            this.profilePasswordTextBox.TabIndex = 39;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label10.Location = new System.Drawing.Point(80, 199);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(78, 20);
            this.label10.TabIndex = 38;
            this.label10.Text = "Password";
            // 
            // profileStudentIdTextBox
            // 
            this.profileStudentIdTextBox.Enabled = false;
            this.profileStudentIdTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileStudentIdTextBox.Location = new System.Drawing.Point(188, 59);
            this.profileStudentIdTextBox.Name = "profileStudentIdTextBox";
            this.profileStudentIdTextBox.Size = new System.Drawing.Size(227, 26);
            this.profileStudentIdTextBox.TabIndex = 33;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label56.Location = new System.Drawing.Point(93, 62);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(87, 20);
            this.label56.TabIndex = 32;
            this.label56.Text = "Student ID";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.BackColor = System.Drawing.Color.White;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label48.Location = new System.Drawing.Point(412, 12);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(66, 25);
            this.label48.TabIndex = 31;
            this.label48.Text = "Profile";
            // 
            // profilePic
            // 
            this.profilePic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.profilePic.Enabled = false;
            this.profilePic.Location = new System.Drawing.Point(809, 71);
            this.profilePic.Name = "profilePic";
            this.profilePic.Size = new System.Drawing.Size(153, 143);
            this.profilePic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.profilePic.TabIndex = 29;
            this.profilePic.TabStop = false;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label39.Location = new System.Drawing.Point(469, 184);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(99, 20);
            this.label39.TabIndex = 27;
            this.label39.Text = "Blood Group";
            // 
            // profileDoneButton
            // 
            this.profileDoneButton.BackColor = System.Drawing.Color.MistyRose;
            this.profileDoneButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.profileDoneButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.profileDoneButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileDoneButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.profileDoneButton.Location = new System.Drawing.Point(781, 477);
            this.profileDoneButton.Name = "profileDoneButton";
            this.profileDoneButton.Size = new System.Drawing.Size(128, 26);
            this.profileDoneButton.TabIndex = 26;
            this.profileDoneButton.Text = "Update";
            this.profileDoneButton.UseVisualStyleBackColor = false;
            this.profileDoneButton.Click += new System.EventHandler(this.profileDoneButton_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label16.Location = new System.Drawing.Point(468, 217);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(94, 20);
            this.label16.TabIndex = 22;
            this.label16.Text = "Department";
            // 
            // profileAddressTextBox
            // 
            this.profileAddressTextBox.Enabled = false;
            this.profileAddressTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileAddressTextBox.Location = new System.Drawing.Point(125, 419);
            this.profileAddressTextBox.Name = "profileAddressTextBox";
            this.profileAddressTextBox.Size = new System.Drawing.Size(545, 63);
            this.profileAddressTextBox.TabIndex = 17;
            this.profileAddressTextBox.Text = "";
            // 
            // profileEmailTextBox
            // 
            this.profileEmailTextBox.Enabled = false;
            this.profileEmailTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileEmailTextBox.Location = new System.Drawing.Point(616, 352);
            this.profileEmailTextBox.Name = "profileEmailTextBox";
            this.profileEmailTextBox.Size = new System.Drawing.Size(244, 26);
            this.profileEmailTextBox.TabIndex = 16;
            // 
            // profilePhoneTextBox
            // 
            this.profilePhoneTextBox.Enabled = false;
            this.profilePhoneTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profilePhoneTextBox.Location = new System.Drawing.Point(155, 358);
            this.profilePhoneTextBox.Name = "profilePhoneTextBox";
            this.profilePhoneTextBox.Size = new System.Drawing.Size(234, 26);
            this.profilePhoneTextBox.TabIndex = 16;
            // 
            // profileMotherOccupationTextBox
            // 
            this.profileMotherOccupationTextBox.Enabled = false;
            this.profileMotherOccupationTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileMotherOccupationTextBox.Location = new System.Drawing.Point(616, 320);
            this.profileMotherOccupationTextBox.Name = "profileMotherOccupationTextBox";
            this.profileMotherOccupationTextBox.Size = new System.Drawing.Size(244, 26);
            this.profileMotherOccupationTextBox.TabIndex = 16;
            // 
            // profileMotherNameTextBox
            // 
            this.profileMotherNameTextBox.Enabled = false;
            this.profileMotherNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileMotherNameTextBox.Location = new System.Drawing.Point(155, 324);
            this.profileMotherNameTextBox.Name = "profileMotherNameTextBox";
            this.profileMotherNameTextBox.Size = new System.Drawing.Size(235, 26);
            this.profileMotherNameTextBox.TabIndex = 16;
            // 
            // profileFatherOccupationTextBox
            // 
            this.profileFatherOccupationTextBox.Enabled = false;
            this.profileFatherOccupationTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileFatherOccupationTextBox.Location = new System.Drawing.Point(616, 289);
            this.profileFatherOccupationTextBox.Name = "profileFatherOccupationTextBox";
            this.profileFatherOccupationTextBox.Size = new System.Drawing.Size(244, 26);
            this.profileFatherOccupationTextBox.TabIndex = 16;
            // 
            // profileFatherNameTextBox
            // 
            this.profileFatherNameTextBox.Enabled = false;
            this.profileFatherNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileFatherNameTextBox.Location = new System.Drawing.Point(155, 292);
            this.profileFatherNameTextBox.Name = "profileFatherNameTextBox";
            this.profileFatherNameTextBox.Size = new System.Drawing.Size(235, 26);
            this.profileFatherNameTextBox.TabIndex = 16;
            // 
            // profileNameTextBox
            // 
            this.profileNameTextBox.Enabled = false;
            this.profileNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileNameTextBox.Location = new System.Drawing.Point(189, 126);
            this.profileNameTextBox.Name = "profileNameTextBox";
            this.profileNameTextBox.Size = new System.Drawing.Size(227, 26);
            this.profileNameTextBox.TabIndex = 16;
            // 
            // profileAdmissionNumberTextBox
            // 
            this.profileAdmissionNumberTextBox.Enabled = false;
            this.profileAdmissionNumberTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileAdmissionNumberTextBox.Location = new System.Drawing.Point(188, 93);
            this.profileAdmissionNumberTextBox.Name = "profileAdmissionNumberTextBox";
            this.profileAdmissionNumberTextBox.Size = new System.Drawing.Size(227, 26);
            this.profileAdmissionNumberTextBox.TabIndex = 15;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label15.Location = new System.Drawing.Point(43, 436);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(68, 20);
            this.label15.TabIndex = 14;
            this.label15.Text = "Address";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label11.Location = new System.Drawing.Point(434, 295);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(152, 20);
            this.label11.TabIndex = 13;
            this.label11.Text = "Father\'s Occupation";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label12.Location = new System.Drawing.Point(17, 327);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(116, 20);
            this.label12.TabIndex = 12;
            this.label12.Text = "Mother\'s Name";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label13.Location = new System.Drawing.Point(434, 321);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(155, 20);
            this.label13.TabIndex = 11;
            this.label13.Text = "Mother\'s Occupation";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label14.Location = new System.Drawing.Point(23, 361);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(115, 20);
            this.label14.TabIndex = 10;
            this.label14.Text = "Phone Number";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label17.Location = new System.Drawing.Point(535, 352);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(48, 20);
            this.label17.TabIndex = 9;
            this.label17.Text = "Email";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label18.Location = new System.Drawing.Point(17, 295);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(113, 20);
            this.label18.TabIndex = 8;
            this.label18.Text = "Father\'s Name";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label19.Location = new System.Drawing.Point(8, 263);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(938, 20);
            this.label19.TabIndex = 7;
            this.label19.Text = "Guardian Information ____________________________________________________________" +
    "__________________________";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label20.Location = new System.Drawing.Point(465, 74);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(121, 20);
            this.label20.TabIndex = 6;
            this.label20.Text = "Admission Date";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label21.Location = new System.Drawing.Point(107, 132);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(51, 20);
            this.label21.TabIndex = 5;
            this.label21.Text = "Name";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label22.Location = new System.Drawing.Point(468, 106);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(102, 20);
            this.label22.TabIndex = 4;
            this.label22.Text = "Date Of Birth";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label23.Location = new System.Drawing.Point(99, 165);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(63, 20);
            this.label23.TabIndex = 3;
            this.label23.Text = "Gender";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label24.Location = new System.Drawing.Point(494, 146);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(48, 20);
            this.label24.TabIndex = 2;
            this.label24.Text = "Class";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label25.Location = new System.Drawing.Point(44, 97);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(142, 20);
            this.label25.TabIndex = 0;
            this.label25.Text = "Admission Number";
            // 
            // StudentForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(52)))), ((int)(((byte)(118)))));
            this.ClientSize = new System.Drawing.Size(1260, 670);
            this.Controls.Add(this.profilePanel);
            this.Controls.Add(this.termExamPanel);
            this.Controls.Add(this.resultPanel);
            this.Controls.Add(this.tileBarPanel);
            this.Controls.Add(this.menu);
            this.Controls.Add(this.examSchedulePanel);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "StudentForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Student";
            this.menu.ResumeLayout(false);
            this.tileBarPanel.ResumeLayout(false);
            this.examSchedulePanel.ResumeLayout(false);
            this.examSchedulePanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.examScheduleClassTestDataGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.examScheduleDataGrid)).EndInit();
            this.resultPanel.ResumeLayout(false);
            this.resultPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.resultClassTestDataGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resultTermExamDataGrid)).EndInit();
            this.termExamPanel.ResumeLayout(false);
            this.termExamPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.termExamListDataGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.termExamMarksDataGrid)).EndInit();
            this.profilePanel.ResumeLayout(false);
            this.profilePanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.profileData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.profilePic)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel menu;
        private System.Windows.Forms.Button resultMenuButton;
        private System.Windows.Forms.Button examMenuButton;
        private System.Windows.Forms.Panel tileBarPanel;
        private System.Windows.Forms.Button crossButton;
        private System.Windows.Forms.Panel examSchedulePanel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView examScheduleClassTestDataGrid;
        private System.Windows.Forms.DataGridView examScheduleDataGrid;
        private System.Windows.Forms.Panel resultPanel;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView resultClassTestDataGrid;
        private System.Windows.Forms.DataGridView resultTermExamDataGrid;
        private System.Windows.Forms.Button termExamMenuButton;
        private System.Windows.Forms.Panel termExamPanel;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DataGridView termExamListDataGrid;
        private System.Windows.Forms.DataGridView termExamMarksDataGrid;
        private System.Windows.Forms.Button LogoutBotton;
        private System.Windows.Forms.Button profileMenuButton;
        private System.Windows.Forms.Panel profilePanel;
        private System.Windows.Forms.TextBox profileGenderTextBox;
        private System.Windows.Forms.TextBox profileConfirmPasswordTextBox;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox profilePasswordTextBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox profileStudentIdTextBox;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label48;
        public System.Windows.Forms.PictureBox profilePic;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Button profileDoneButton;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.RichTextBox profileAddressTextBox;
        private System.Windows.Forms.TextBox profileEmailTextBox;
        private System.Windows.Forms.TextBox profilePhoneTextBox;
        private System.Windows.Forms.TextBox profileMotherOccupationTextBox;
        private System.Windows.Forms.TextBox profileMotherNameTextBox;
        private System.Windows.Forms.TextBox profileFatherOccupationTextBox;
        private System.Windows.Forms.TextBox profileFatherNameTextBox;
        private System.Windows.Forms.TextBox profileNameTextBox;
        private System.Windows.Forms.TextBox profileAdmissionNumberTextBox;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox profileAdmissionDateTextBox;
        private System.Windows.Forms.TextBox profileDOBTextBox;
        private System.Windows.Forms.TextBox profileClassTextBox;
        private System.Windows.Forms.TextBox profileBGTextBox;
        private System.Windows.Forms.TextBox profileDepartmentTextBox;
        private System.Windows.Forms.DataGridView profileData;

    }
}