﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bussiness_Logic_Layer;
using System.IO;

namespace Projectwork111
{
    public partial class StudentForm : Form
    {
        string userId, password;
        Login l;
        public StudentForm(string uid,string pass,Login lo)
        {
            this.l = lo;
            this.userId = uid; this.password = pass;
            InitializeComponent();
            
            //exam schedule panel
            this.examSchedulePanel.SetBounds(185, 20, 1075, 644);
            this.examSchedulePanel.Visible = false;

            //result panel
            this.resultPanel.SetBounds(185, 20, 1075 , 644);
            this.resultPanel.Visible = false;
            //termExamPanel
            this.termExamPanel.SetBounds(185, 20, 1075, 644);
            this.termExamPanel.Visible = false;
            //profile Panel
            this.profilePanel.SetBounds(185, 20, 1075, 644);
            this.profilePanel.Visible = false;
        }

        private void examMenuButton_Click(object sender, EventArgs e)
        {
            this.profilePanel.Visible = false;
            this.termExamPanel.Visible = false;
            this.resultPanel.Visible = false;
            this.examSchedulePanel.Visible = true;

            Exam ex = new Exam();
            Student s = new Student();
            examScheduleClassTestDataGrid.DataSource = ex.GetListForStudent(s.ClassName(userId));
        }

        private void resultMenuButton_Click(object sender, EventArgs e)
        {
            this.profilePanel.Visible = false;
            this.termExamPanel.Visible = false;
            this.resultPanel.Visible = true;
            this.examSchedulePanel.Visible = false;
            Exam ex = new Exam();
            Student s = new Student();
            resultClassTestDataGrid.DataSource = ex.GetListForStudent(s.ClassName(userId));
        }

        private void crossButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void resultClassTestDataGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            Marks m = new Marks();
            int eid = Convert.ToInt32(resultClassTestDataGrid.CurrentRow.Cells[5].Value);
            resultTermExamDataGrid.DataSource = m.GetMarks(eid,userId);
        }

        private void termExamMenuButton_Click(object sender, EventArgs e)
        {
            this.profilePanel.Visible = false;
            this.termExamPanel.Visible = true;
            this.resultPanel.Visible = false;
            this.examSchedulePanel.Visible = false;
            Exam ex = new Exam();
            termExamListDataGrid.DataSource = ex.GetTermExamListForStudents(userId);
        }

        private void termExamListDataGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int exid = Convert.ToInt32(termExamListDataGrid.CurrentRow.Cells[0].Value);
            char[] del = { 'S', '-' };
            Exam ex = new Exam();
            termExamMarksDataGrid.DataSource = ex.GetTermExamMarksForStudents(userId.Split(del,StringSplitOptions.RemoveEmptyEntries)[0], exid);
        }

        private void LogoutBotton_Click(object sender, EventArgs e)
        {
            l.Show();
            this.Hide();
        }

        private void profileMenuButton_Click(object sender, EventArgs e)
        {
            this.profilePanel.Visible = true;
            this.termExamPanel.Visible = false;
            this.resultPanel.Visible = false;
            this.examSchedulePanel.Visible = false;

            ProData();

        }
        void ProData()
        {
            Student t = new Student();
            profileData.DataSource = t.SearchStudent(userId);

            try { profileStudentIdTextBox.Text = profileData.Rows[0].Cells[0].Value.ToString(); }
            catch (Exception ec) { }
            try { profileAdmissionNumberTextBox.Text = profileData.Rows[0].Cells[1].Value.ToString(); }
            catch (Exception ec) { }
            try { profileNameTextBox.Text = profileData.Rows[0].Cells[2].Value.ToString(); }
            catch (Exception ec) { }
            try { profileFatherNameTextBox.Text = profileData.Rows[0].Cells[3].Value.ToString(); }
            catch (Exception ec) { }
            try { profileMotherNameTextBox.Text = profileData.Rows[0].Cells[4].Value.ToString(); }
            catch (Exception ec) { }
            try { profileFatherOccupationTextBox.Text = profileData.Rows[0].Cells[5].Value.ToString(); }
            catch (Exception ec) { }
            try { profileMotherOccupationTextBox.Text = profileData.Rows[0].Cells[6].Value.ToString(); }
            catch (Exception ec) { }
            try { profilePhoneTextBox.Text = profileData.Rows[0].Cells[7].Value.ToString(); }
            catch (Exception ec) { }
            try { profileEmailTextBox.Text = profileData.Rows[0].Cells[8].Value.ToString(); }
            catch (Exception ec) { }
            try { profileBGTextBox.Text = profileData.Rows[0].Cells[9].Value.ToString(); }
            catch (Exception ec) { }
            try { profileGenderTextBox.Text = profileData.Rows[0].Cells[10].Value.ToString(); }
            catch (Exception ec) { }
            try { profileClassTextBox.Text = profileData.Rows[0].Cells[11].Value.ToString(); }
            catch (Exception ec) { }
            try { profileAdmissionDateTextBox.Text = profileData.Rows[0].Cells[12].Value.ToString(); }
            catch (Exception ec) { }
            try { profileDOBTextBox.Text = profileData.Rows[0].Cells[13].Value.ToString(); }
            catch (Exception ec) { }
            try { profileDepartmentTextBox.Text = profileData.Rows[0].Cells[14].Value.ToString(); }
            catch (Exception ec) { }
            try { profileAddressTextBox.Text = profileData.Rows[0].Cells[15].Value.ToString(); }
            catch (Exception ec) { }
            try { profilePasswordTextBox.Text = profileData.Rows[0].Cells[16].Value.ToString(); }
            catch (Exception ec) { }
            try { profileConfirmPasswordTextBox.Text = profileData.Rows[0].Cells[16].Value.ToString(); }
            catch (Exception ec) { }
            try { profilePic.Image = (byteArrayToImage(t.GetPhoto(userId))); }
            catch (Exception ec) { }    
        }

        public Image byteArrayToImage(byte[] byteArrayIn)
        {
            MemoryStream ms = new MemoryStream(byteArrayIn);
            Image returnImage = Image.FromStream(ms);
            return returnImage;
        }

        private void profileDoneButton_Click(object sender, EventArgs e)
        {
            if (profilePasswordTextBox.Text == profileConfirmPasswordTextBox.Text)
            {
                Student s = new Student();
                s.UpdatePassword(userId, profilePasswordTextBox.Text);
                MessageBox.Show("Password Updated.");
            }
            else
            {
                MessageBox.Show("Password Did not Matched.");
            }
        }
    }
}
