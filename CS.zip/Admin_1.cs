﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bussiness_Logic_Layer;
using System.IO;

namespace Projectwork111
{
    public partial class Admin : Form
    {
        UserDbDataContext mdc = new UserDbDataContext(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\Taha\Documents\UserDB.mdf;Integrated Security=True;Connect Timeout=30");
        Login l;
        public Admin(Login lo)
        {
            this.l = lo;
            InitializeComponent();

            //userPanel
            this.teacherPanel.SetBounds(185, 20, 1075, 644);
            this.teacherPanel.Visible = false;

            this.teacherAddPanel.SetBounds(0, 28, 1075, 605);
            this.teacherAddPanel.Visible = false;
            this.teacherSearchPanel.SetBounds(0, 28, 1075, 605);
            this.teacherSearchPanel.Visible = false;
            
            //student Panel
            this.studentPanel.SetBounds(185, 20, 1075, 644);
            this.Controls.Add(studentPanel);
            this.studentPanel.Visible = false;
            
            // Student registration Panel
            this.studentRegistrationPanel.SetBounds(0, 28, 1075, 605);
            this.studentRegistrationPanel.Visible = false;

            this.studentPromotionPanel.SetBounds(0, 28, 1075, 605);
            this.studentPromotionPanel.Visible = false;

            this.studentRegistrationRegisterPanel.SetBounds(0, 35, 1075, 565);
            this.studentRegistrationRegisterPanel.Visible = false;
            this.studentRegistrationSearchPanel.SetBounds(0, 35, 1075, 565);
            this.studentRegistrationSearchPanel.Visible = false;

            //attendance Panel
            this.Controls.Add(attendancePanel);
            this.attendancePanel.SetBounds(185, 20, 1075, 644);
            this.attendancePanel.Visible = false;

            
            //employee Panel
            this.employeePanel.SetBounds(185, 20, 1075, 644);
            this.employeePanel.Visible = false;
            this.employeeRegisterPanel.SetBounds(0, 28, 1075, 605);
            this.employeeRegisterPanel.Visible = false;
            this.employeeSearchPanel.SetBounds(0, 28, 1075, 605);
            this.employeeSearchPanel.Visible = false;
            this.employeeAttendancePanel.SetBounds(0, 35, 1075, 565);
            this.employeeAttendancePanel.Visible = false;
            this.employeeAttendanceUpdatePanel.SetBounds(0, 35, 1075, 565);
            this.employeeAttendanceUpdatePanel.Visible = false;

            //term Exam panel
            this.termExamPanel.SetBounds(185, 20, 1075, 644);
            this.termExamPanel.Visible = false;
            //admin Panel
            this.adminPanel.SetBounds(185, 20, 1075, 644);
            this.adminPanel.Visible = false;
            this.adminAddPanel.SetBounds(0, 28, 1075, 605);
            this.adminAddPanel.Visible = false;
            this.adminSearchPanel.SetBounds(0, 28, 1075, 605);
            this.adminSearchPanel.Visible = false;
            
        }

        private void crossButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        #region Student Panel

        private void button3_Click(object sender, EventArgs e)
        {
            studentPromotionDataGrid.DataSource = null;
        }

        private void studentMenuButton_Click(object sender, EventArgs e)
        {
            this.adminPanel.Visible = false;
            this.termExamPanel.Visible = false;
            this.studentPanel.Visible = true;
            this.employeePanel.Visible = false;
            this.attendancePanel.Visible = false;
            this.teacherPanel.Visible = false;
        }

        private void studentRegistrationButton_Click(object sender, EventArgs e)
        {
            this.studentRegistrationPanel.Visible = true;
            this.studentPromotionPanel.Visible = false;
        }

        private void studentPromotion_Click(object sender, EventArgs e)
        {
            this.studentRegistrationPanel.Visible = false;
            this.studentPromotionPanel.Visible = true;
        }

        private void studentRegistrationRegisterButton_Click(object sender, EventArgs e)
        {
            Student stu = new Student();
            studentRegistrationRegisterStudentIdTextBox.Text = "S-" + Convert.ToString(stu.GetLastStudentId() + 1);
            this.studentRegistrationRegisterPanel.Visible = true;
            this.studentRegistrationSearchPanel.Visible = false;


        }

        private void studentRegistrationSearchButton_Click(object sender, EventArgs e)
        {
            Student stu = new Student();
            studentRegistrationSearchDataGrid.ForeColor = Color.Black;
            studentRegistrationSearchDataGrid.DataSource = stu.GetList();
            this.studentRegistrationRegisterPanel.Visible = false;
            this.studentRegistrationSearchPanel.Visible = true;
        }
        private void studentRegistrationSearchBrowseButton_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog dlg = new OpenFileDialog();
                dlg.Multiselect = false;
                dlg.Filter = "JPG Files (*.JPG)|*.jpg";
                dlg.Title = "Select Picture";
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    studentImgLoc = dlg.FileName.ToString();
                    studentRegistrationSearchPictudeBox.ImageLocation = studentImgLoc;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        string studentImgLoc;
        private void studentRegistrationRegisterBrowseButton_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog dlg = new OpenFileDialog();
                dlg.Multiselect = false;
                dlg.Filter = "JPG Files (*.JPG)|*.jpg";
                dlg.Title = "Select Picture";
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                     studentImgLoc = dlg.FileName.ToString();
                     studentRegistrationRegisterPictureBox.ImageLocation = studentImgLoc;
                     
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void studentRegistrationRegisterSubmitButton_Click(object sender, EventArgs e)
        {
            if (studentRegistrationRegisterPasswordTextBox.Text == studentRegistrationRegisterConfirmPasswordTextBox.Text)
            {
                Student stu = new Student();
                try { stu.AdmissionNumber = Convert.ToInt32(studentRegistrationRegisterAdmissionNumberTextBox.Text); }
                catch (Exception ec) { stu.AdmissionNumber = 0; }
                try { stu.AdmissionDate = studentRegistrationRegisterAdmissionDate.Value.ToShortDateString().ToString(); }
                catch (Exception) { stu.AdmissionDate = ""; }
                try { stu.Name = studentRegistrationRegisterNameTextBox.Text; }
                catch (Exception ec) { stu.Name = ""; }
                try { stu.Gender = studentRegistrationRegisterGenderComboBox.Text; }
                catch (Exception ec) { stu.Gender = ""; }
                try { stu.Class = studentRegistrationRegisterClassComboBox.Text; }
                catch (Exception ec) { stu.Class = ""; }
                try { stu.DateOfBirth = studentRegistrationRegisterDOB.Value.ToShortDateString().ToString(); }
                catch (Exception ec) { stu.DateOfBirth = ""; }
                try { stu.Department = studentRegistrationRegisterDepartmentComboBox.Text; }
                catch (Exception ec) { stu.Department = ""; }
                try { stu.BloodGroup = studentRegistrationRegisterBGComboBox.Text; }
                catch (Exception ec) { stu.BloodGroup =""; }
                try { stu.FatherName = studentRegistrationRegisterFatherNameTextBox.Text; }
                catch (Exception ec) { stu.FatherName = ""; }
                try { stu.FatherOccupation = studentRegistrationRegisterFatherOccupationTextBox.Text; }
                catch (Exception ec) { stu.FatherOccupation = ""; }
                try { stu.MotherName = studentRegistrationRegisterMotherNameTextBox.Text; }
                catch (Exception ec) { stu.MotherName = ""; }
                try { stu.MotherOccupation = studentRegistrationRegisterMotherOccupationTextBox.Text; }
                catch (Exception ec) { stu.MotherOccupation = ""; }
                try { stu.PhoneNumber = studentRegistrationRegisterPhoneTextBox.Text; }
                catch (Exception ec) { stu.PhoneNumber = ""; }
                try { stu.Email = studentRegistrationRegisterEmailTextBox.Text; }
                catch (Exception ec) { stu.Email =""; }
                try { stu.Address = studentRegistrationRegisterAddressTextBox.Text; }
                catch (Exception ec) { stu.Address = ""; }
                try { stu.Photo = imageToByteArray(studentRegistrationRegisterPictureBox.Image); }
                catch (Exception ec) { stu.Photo = null; }
                try { stu.Password = studentRegistrationRegisterPasswordTextBox.Text; }
                catch (Exception ec) { stu.Password = ""; }
                stu.ID = stu.GetLastStudentId() + 1;
                MessageBox.Show("Student Added Successfully");
                studentRegistrationRegisterAdmissionNumberTextBox.Text = studentRegistrationRegisterNameTextBox.Text = studentRegistrationRegisterGenderComboBox.Text
                    = studentRegistrationRegisterClassComboBox.Text = studentRegistrationRegisterDepartmentComboBox.Text =
                     studentRegistrationRegisterBGComboBox.Text =
                    studentRegistrationRegisterFatherNameTextBox.Text = studentRegistrationRegisterFatherOccupationTextBox.Text
                    = studentRegistrationRegisterMotherNameTextBox.Text = studentRegistrationRegisterMotherOccupationTextBox.Text
                    = studentRegistrationRegisterPhoneTextBox.Text = studentRegistrationRegisterEmailTextBox.Text
                    = studentRegistrationRegisterAddressTextBox.Text = studentRegistrationRegisterPasswordTextBox.Text = studentRegistrationRegisterConfirmPasswordTextBox.Text =
                    studentRegistrationRegisterDOB.Text = "";
                studentRegistrationRegisterPictureBox.Image = null;

                stu.AddStudent();
                studentRegistrationSearchDataGrid.DataSource = stu.GetList();
                studentRegistrationRegisterStudentIdTextBox.Text = "S-"+Convert.ToString(stu.GetLastStudentId() + 1);
            }
            else {
                MessageBox.Show("Password did not Matched");
            }
        }

        int sId;
        private void studentRegistrationSearchUpdateButton_Click(object sender, EventArgs e)
        {
            if (studentRegistrationSearchPasswordTextBox.Text == studentRegistrationSearchConfirmPasswordTextBox.Text)
            {
                Student stu = new Student();
                try { stu.AdmissionNumber = Convert.ToInt32(studentRegistrationSearchAdmissionNumberUpdateTextBox.Text); }
                catch (Exception ec) { stu.AdmissionNumber = 0; }
                try { stu.AdmissionDate = studentRegistrationSearchAdmissionDateUpdate.Value.ToShortDateString().ToString(); }
                catch (Exception ec) { stu.AdmissionDate = ""; }
                try { stu.Name = studentRegistrationSearchNameUpdateTextBox.Text; }
                catch (Exception ec) { stu.Name = ""; }
                try { stu.Gender = studentRegistrationSearchGenderUpdateComboBox.Text; }
                catch (Exception ec) { stu.Gender = ""; }
                try { stu.Class = studentRegistrationSearchClassUpdateComboBox.Text; }
                catch (Exception ec) { stu.Class = ""; }
                try { stu.DateOfBirth = studentRegistrationSearchDOBUpdate.Value.ToShortDateString().ToString(); }
                catch (Exception ec) { stu.DateOfBirth = ""; }
                try { stu.Department = studentRegistrationSearchDepartmentUpdateComboBox.Text; }
                catch (Exception ec) { stu.Department = ""; }
                try { stu.BloodGroup = studentRegistrationSearchBGComboBox.Text; }
                catch (Exception ec) { stu.BloodGroup = ""; }
                try { stu.FatherName = studentRegistrationSearchFatherNameUpdateTextBox.Text; }
                catch (Exception ec) { stu.FatherName = ""; }
                try { stu.FatherOccupation = studentRegistrationSearchFatherOccupationUpdateTextBox.Text; }
                catch (Exception ec) { stu.FatherOccupation = ""; }
                try { stu.MotherName = studentRegistrationSearchMotherNameUpdateTextBox.Text; }
                catch (Exception ec) { stu.MotherName = ""; }
                try { stu.MotherOccupation = studentRegistrationSearchMotherOccupationUpdateTextBox.Text; }
                catch (Exception ec) { stu.MotherOccupation = ""; }
                try { stu.PhoneNumber = studentRegistrationSearchPhoneUpdateTextBox.Text; }
                catch (Exception ec) { stu.PhoneNumber = ""; }
                try { stu.Email = studentRegistrationSearchEmailUpdateTextBox.Text; }
                catch (Exception ec) { stu.Email = ""; }
                try { stu.Password = studentRegistrationSearchPasswordTextBox.Text; }
                catch (Exception ec) { stu.Password = ""; }
                try { stu.Address = studentRegistrationSearchAddressUpdateTextBox.Text; }
                catch (Exception ec) { stu.Address = ""; }
                try { stu.Photo = imageToByteArray(studentRegistrationSearchPictudeBox.Image); }
                catch (Exception ec) { stu.Photo = null; }
                stu.ID = sId;
               
                stu.UpdateStudent(sId);
                MessageBox.Show("Student Updated Successfully");
                studentRegistrationSearchDataGrid.DataSource = stu.GetList();

                studentRegistrationSearchAdmissionNumberUpdateTextBox.Text = studentRegistrationSearchBGComboBox.Text = studentRegistrationSearchClassUpdateComboBox.Text
                    = studentRegistrationSearchConfirmPasswordTextBox.Text = studentRegistrationSearchDepartmentUpdateComboBox.Text =
                    studentRegistrationSearchDOBUpdate.Text = studentRegistrationSearchEmailUpdateTextBox.Text = studentRegistrationSearchFatherNameUpdateTextBox.Text =
                    studentRegistrationSearchFatherOccupationUpdateTextBox.Text = studentRegistrationSearchGenderUpdateComboBox.Text =
                    studentRegistrationSearchMotherNameUpdateTextBox.Text = studentRegistrationSearchMotherOccupationUpdateTextBox.Text =
                    studentRegistrationSearchNameUpdateTextBox.Text = studentRegistrationSearchPasswordTextBox.Text = studentRegistrationSearchPhoneUpdateTextBox.Text = "";
                studentRegistrationSearchPictudeBox.Image = null;
                    

            }
            else {
                MessageBox.Show("Password did not Matched.");
            }
        }

        private void studentRegistrationSearchDeleteButton_Click(object sender, EventArgs e)
        {
            try
            {
                Student stu = new Student();
                stu.DeleteStudent(sId);
                MessageBox.Show("Student Details Deleted.");
                studentRegistrationSearchDataGrid.DataSource = stu.GetList();
                studentRegistrationSearchAdmissionNumberUpdateTextBox.Text = studentRegistrationSearchBGComboBox.Text = studentRegistrationSearchClassUpdateComboBox.Text
                        = studentRegistrationSearchConfirmPasswordTextBox.Text = studentRegistrationSearchDepartmentUpdateComboBox.Text =
                        studentRegistrationSearchDOBUpdate.Text = studentRegistrationSearchEmailUpdateTextBox.Text = studentRegistrationSearchFatherNameUpdateTextBox.Text =
                        studentRegistrationSearchFatherOccupationUpdateTextBox.Text = studentRegistrationSearchGenderUpdateComboBox.Text =
                        studentRegistrationSearchMotherNameUpdateTextBox.Text = studentRegistrationSearchMotherOccupationUpdateTextBox.Text =
                        studentRegistrationSearchNameUpdateTextBox.Text = studentRegistrationSearchPasswordTextBox.Text = studentRegistrationSearchPhoneUpdateTextBox.Text = "";
                studentRegistrationSearchPictudeBox.Image = null;
            }
            catch (Exception ec) { MessageBox.Show("Select a Student First."); }
        }

        private void studentRegistrationSearchDataGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            Student stu = new Student();
            char[] del = { 'S', '-' };
            sId = Convert.ToInt32(studentRegistrationSearchDataGrid.CurrentRow.Cells[0].Value.ToString().Split(del, StringSplitOptions.RemoveEmptyEntries)[0]);
            try { studentRegistrationSearchAdmissionNumberUpdateTextBox.Text = studentRegistrationSearchDataGrid.CurrentRow.Cells[1].Value.ToString(); }
            catch (Exception ec) { studentRegistrationSearchAdmissionNumberUpdateTextBox.Text = ""; }
            try { studentRegistrationSearchNameUpdateTextBox.Text = studentRegistrationSearchDataGrid.CurrentRow.Cells[2].Value.ToString(); }
            catch (Exception ec) { studentRegistrationSearchNameUpdateTextBox.Text = ""; }
            try { studentRegistrationSearchFatherNameUpdateTextBox.Text = studentRegistrationSearchDataGrid.CurrentRow.Cells[3].Value.ToString(); }
            catch (Exception ec) { studentRegistrationSearchFatherNameUpdateTextBox.Text = ""; }
            try { studentRegistrationSearchMotherNameUpdateTextBox.Text = studentRegistrationSearchDataGrid.CurrentRow.Cells[4].Value.ToString(); }
            catch (Exception ec) { studentRegistrationSearchMotherNameUpdateTextBox.Text = ""; }
            try { studentRegistrationSearchFatherOccupationUpdateTextBox.Text = studentRegistrationSearchDataGrid.CurrentRow.Cells[5].Value.ToString(); }
            catch (Exception ec) { studentRegistrationSearchFatherOccupationUpdateTextBox.Text = ""; }
            try { studentRegistrationSearchMotherOccupationUpdateTextBox.Text = studentRegistrationSearchDataGrid.CurrentRow.Cells[6].Value.ToString(); }
            catch (Exception ec) { studentRegistrationSearchMotherOccupationUpdateTextBox.Text = ""; }
            try { studentRegistrationSearchPhoneUpdateTextBox.Text = studentRegistrationSearchDataGrid.CurrentRow.Cells[7].Value.ToString(); }
            catch (Exception ec) { studentRegistrationSearchPhoneUpdateTextBox.Text = ""; }
            try { studentRegistrationSearchEmailUpdateTextBox.Text = studentRegistrationSearchDataGrid.CurrentRow.Cells[8].Value.ToString(); }
            catch (Exception ec) { studentRegistrationSearchEmailUpdateTextBox.Text = ""; }
            try { studentRegistrationSearchBGComboBox.Text = studentRegistrationSearchDataGrid.CurrentRow.Cells[9].Value.ToString(); }
            catch (Exception ec) { studentRegistrationSearchBGComboBox.Text = ""; }
            try { studentRegistrationSearchGenderUpdateComboBox.Text = studentRegistrationSearchDataGrid.CurrentRow.Cells[10].Value.ToString(); }
            catch (Exception ec) { studentRegistrationSearchGenderUpdateComboBox.Text = ""; }
            try { studentRegistrationSearchClassUpdateComboBox.Text = studentRegistrationSearchDataGrid.CurrentRow.Cells[11].Value.ToString(); }
            catch (Exception ec) { studentRegistrationSearchClassUpdateComboBox.Text = ""; }
            try { studentRegistrationSearchAdmissionDateUpdate.Text = studentRegistrationSearchDataGrid.CurrentRow.Cells[12].Value.ToString(); }
            catch (Exception ec) { studentRegistrationSearchAdmissionDateUpdate.Text = ""; }
            try { studentRegistrationSearchDOBUpdate.Text = studentRegistrationSearchDataGrid.CurrentRow.Cells[13].Value.ToString(); }
            catch (Exception ec) { studentRegistrationSearchDOBUpdate.Text = ""; }
            try
            {
                studentRegistrationSearchDepartmentUpdateComboBox.Text = studentRegistrationSearchDataGrid.CurrentRow.Cells[14].Value.ToString();

            }
            catch (Exception ex)
            {
                studentRegistrationSearchDepartmentUpdateComboBox.Text = "";
            }
            try { studentRegistrationSearchAddressUpdateTextBox.Text = studentRegistrationSearchDataGrid.CurrentRow.Cells[15].Value.ToString(); }
            catch (Exception ec) { studentRegistrationSearchAddressUpdateTextBox.Text = ""; }
            try { studentRegistrationSearchPasswordTextBox.Text = studentRegistrationSearchDataGrid.CurrentRow.Cells[16].Value.ToString(); }
            catch (Exception ec) { studentRegistrationSearchPasswordTextBox.Text = ""; }
            try { studentRegistrationSearchConfirmPasswordTextBox.Text = studentRegistrationSearchDataGrid.CurrentRow.Cells[16].Value.ToString(); }
            catch (Exception ec) { studentRegistrationSearchConfirmPasswordTextBox.Text = ""; }
            try { studentRegistrationSearchPictudeBox.Image = byteArrayToImage(stu.GetPhoto(sId)); }
            catch (Exception ec) { studentRegistrationSearchPictudeBox.Image = null; }
        }

        private void studentRegistrationSearchSearchButton_Click(object sender, EventArgs e)
        {
            Student stu = new Student();
            studentRegistrationSearchDataGrid.DataSource = stu.SearchStudent(studentRegistrationSearchIDTextBox.Text);
            studentRegistrationSearchIDTextBox.Text = "";
        }
        private void studentPromotionPromoteButton_Click(object sender, EventArgs e)
        {
            try
            {
                Student stu = new Student();
                stu.PromoteStudent(studentPromotionClassComboBox.Text, studentPromotionClassUpdateComboBox.Text);
                studentPromotionDataGrid.DataSource = stu.SearchByClassName(studentPromotionClassUpdateComboBox.Text);
            }
            catch (Exception ec) { MessageBox.Show("Select a Class Name to Promote."); }
        }

        private void studentPromotionSearchButton_Click(object sender, EventArgs e)
        {
            try
            {
                Student stu = new Student();
                studentPromotionDataGrid.DataSource = stu.SearchByClassName(studentPromotionClassComboBox.Text);
            }
            catch { MessageBox.Show("Select a Class Name First."); }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            Student stu = new Student();
            studentRegistrationSearchDataGrid.DataSource = stu.GetList();
        }
        #endregion

        public static byte[] imageToByteArray(System.Drawing.Image imageIn)
        {
            MemoryStream ms = new MemoryStream();
            imageIn.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
            return ms.ToArray();
        }

        public Image byteArrayToImage(byte[] byteArrayIn)
        {
            MemoryStream ms = new MemoryStream(byteArrayIn);
            Image returnImage = Image.FromStream(ms);
            return returnImage;
        }

        #region Teacher Panel

        private void addUserButton_Click(object sender, System.EventArgs e)
        {
            Teacher t = new Teacher();
            teacherAddTeacherIDTextBox.Text = "T-" + Convert.ToString(t.LastTeacherID() + 1);
            this.teacherAddPanel.Visible = true;
            this.teacherSearchPanel.Visible = false;
        }


        private void searchUserButton_Click(object sender, System.EventArgs e)
        {
            Teacher t = new Teacher();
            teacherSearchDataGrid.DataSource = t.GetList();
            this.teacherAddPanel.Visible = false;
            this.teacherSearchPanel.Visible = true;
        }
        private void teacherMenuButton_Click(object sender, EventArgs e)
        {
            this.adminPanel.Visible = false;
            this.termExamPanel.Visible = false;
            this.studentPanel.Visible = false;
            this.attendancePanel.Visible = false;
            this.employeePanel.Visible = false;
            this.teacherPanel.Visible = true;
        }
        private void teacherAddSubmitButton_Click(object sender, EventArgs e)
        {
            if (teacherAddPasswordTextBox.Text == teacherAddConfirmPasswordTextBox.Text)
            {
                Teacher t = new Teacher();
                try { t.Name = teacherAddNameTextBox.Text; }
                catch (Exception ec) { t.Name = ""; }
                t.ID = t.LastTeacherID() + 1;
                try { t.Gender = teacherAddGenderComboBox.Text; }
                catch (Exception) { t.Gender = ""; }
                try { t.Password = teacherAddPasswordTextBox.Text; }
                catch (Exception ec) { t.Password = ""; }
                try { t.Email = teacherAddEmailTextBox.Text; }
                catch (Exception ec) { t.Email = ""; }
                try { t.Phone = teacherAddPhoneTextBox.Text; }
                catch (Exception ec) { t.Phone = ""; }
                try { t.RegisterDate = teacherRegisterRegisterDate.Text; }
                catch (Exception ec) { t.RegisterDate = ""; }
                try { t.Photo = imageToByteArray(teacherAddPictureBox.Image); }
                catch (Exception ec) { t.Photo = null; }
                try { t.DateOfBirth = teacherAddDOB.Value.ToShortDateString(); }
                catch (Exception ec) { t.DateOfBirth = ""; }
                try { t.Subject = teacherAddSubjectComboBox.Text; }
                catch (Exception ec) { t.Subject = ""; }
                try { t.Address = teacherAddAddressTextBox.Text; }
                catch (Exception ec) { t.Address = ""; }
                try { t.Department = teacherAddDepartmentComboBox.Text; }
                catch (Exception ec) { t.Department = " "; }
                try { t.BloodGroup = teacherAddBGComboBox.Text; }
                catch (Exception ec) { t.BloodGroup = ""; }
                t.Nursary = teacherAddNursary.Checked ? true : false;
                t.STD1 = teacherAddStd1.Checked ? true : false;
                t.STD2 = teacherAddStd2.Checked ? true : false;
                t.STD3 = teacherAddStd3.Checked ? true : false;
                t.STD4 = teacherAddStd4.Checked ? true : false;
                t.STD5 = teacherAddStd5.Checked ? true : false;
                t.STD6 = teacherAddStd6.Checked ? true : false;
                t.STD7 = teacherAddStd7.Checked ? true : false;
                t.STD8 = teacherAddStd8.Checked ? true : false;
                t.STD9 = teacherAddStd9.Checked ? true : false;
                t.STD10 = teacherAddStd10.Checked ? true : false;

                t.AddTeacher();
                MessageBox.Show("New Teacher Added.");
                teacherSearchDataGrid.DataSource = t.GetList();

                teacherAddTeacherIDTextBox.Text = "T-" + Convert.ToString(t.LastTeacherID() + 1);
                teacherAddPictureBox.Image=null;
                teacherAddNameTextBox.Text = teacherAddGenderComboBox.Text = teacherAddPasswordTextBox.Text = teacherAddConfirmPasswordTextBox.Text
                    = teacherAddEmailTextBox.Text = teacherAddPhoneTextBox.Text = teacherAddDOB.Text = teacherAddSubjectComboBox.Text =
                    teacherAddAddressTextBox.Text = teacherAddDepartmentComboBox.Text = teacherAddBGComboBox.Text = teacherAddDOB.Text= "";
                teacherAddNursary.Checked = teacherAddStd1.Checked = teacherAddStd2.Checked =teacherAddStd3.Checked =teacherAddStd4.Checked 
                    =teacherAddStd5.Checked =teacherAddStd6.Checked =teacherAddStd7.Checked =teacherAddStd8.Checked =teacherAddStd9.Checked 
                    =teacherAddStd10.Checked = false;
            }
            else {
                MessageBox.Show("Password did not Matched.");
            }
        }

        private void teacherSearchUpdateButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (teacherSearchPasswordTextBox.Text == teacherSearchConfirmPasswordTextBox.Text)
                {
                    Teacher t = new Teacher();
                    try { t.Name = teacherSearchNameTextBox.Text; }
                    catch (Exception ec) { t.Name = ""; }
                    t.ID = teacherSearchId;
                    try { t.Gender = teacherSearchGenderComboBox.Text; }
                    catch (Exception ec) { t.Gender = ""; }
                    try { t.Password = teacherSearchPasswordTextBox.Text; }
                    catch (Exception ec) { t.Password = ""; }
                    try { t.Email = teacherSearchEmailTextBox.Text; }
                    catch (Exception ec) { t.Email = ""; }
                    try { t.Phone = teacherSearchPhoneTextBox.Text; }
                    catch (Exception ec) { t.Phone = ""; }
                    try { t.Address = teacherSearchAddressTextBox.Text; }
                    catch (Exception ec) { t.Address = ""; }
                    try { t.Photo = imageToByteArray(teacherSearchPictureBox.Image); }
                    catch (Exception ec) { t.Photo = null; }
                    try { t.DateOfBirth = teacherSearchDOB.Value.ToShortDateString(); }
                    catch (Exception) { t.DateOfBirth = ""; }
                    try { t.Subject = teacherSearchSubjectComboBox.Text; }
                    catch (Exception ec) { t.Subject = ""; }
                    try { t.Department = teacherSearchDepartmentComboBox.Text; }
                    catch (Exception ec) { t.Department = " "; }
                    try { t.BloodGroup = teacherSearchBGComboBox.Text; }
                    catch (Exception ec) { t.BloodGroup = ""; }
                    t.Nursary = teacherSearchNursary.Checked ? true : false;
                    t.STD1 = teacherSearchStd1.Checked ? true : false;
                    t.STD2 = teacherSearchStd2.Checked ? true : false;
                    t.STD3 = teacherSearchStd3.Checked ? true : false;
                    t.STD4 = teacherSearchStd4.Checked ? true : false;
                    t.STD5 = teacherSearchStd5.Checked ? true : false;
                    t.STD6 = teacherSearchStd6.Checked ? true : false;
                    t.STD7 = teacherSearchStd7.Checked ? true : false;
                    t.STD8 = teacherSearchStd8.Checked ? true : false;
                    t.STD9 = teacherSearchStd9.Checked ? true : false;
                    t.STD10 = teacherSearchStd10.Checked ? true : false;
                    t.UpdateTeacher(teacherSearchId);
                    MessageBox.Show("Teacher Details Updated.");
                    teacherSearchDataGrid.DataSource = t.GetList();

                    teacherSearchPictureBox.Image = null;
                    teacherSearchNameTextBox.Text = teacherSearchGenderComboBox.Text = teacherSearchPasswordTextBox.Text = teacherSearchConfirmPasswordTextBox.Text
                        = teacherSearchEmailTextBox.Text = teacherSearchPhoneTextBox.Text = teacherSearchDOB.Text = teacherSearchSubjectComboBox.Text =
                        teacherSearchAddressTextBox.Text = teacherSearchDepartmentComboBox.Text = teacherSearchBGComboBox.Text = teacherSearchDOB.Text = "";
                    teacherSearchNursary.Checked = teacherSearchStd1.Checked = teacherSearchStd2.Checked = teacherSearchStd3.Checked = teacherSearchStd4.Checked
                        = teacherSearchStd5.Checked = teacherSearchStd6.Checked = teacherSearchStd7.Checked = teacherSearchStd8.Checked = teacherSearchStd9.Checked
                        = teacherSearchStd10.Checked = false;

                }
                else
                {
                    MessageBox.Show("Password did not Matched.");
                }
            }
            catch (Exception ec) { MessageBox.Show("Select a Teacher First."); }
        }

        private void teacherSearchDelateButton_Click(object sender, EventArgs e)
        {
            try
            {
                Teacher t = new Teacher();
                t.DeleteTeacher(teacherSearchId);
                MessageBox.Show("Teacher Deleted.");
                teacherSearchDataGrid.DataSource = t.GetList();
                teacherSearchPictureBox.Image = null;
                teacherSearchNameTextBox.Text = teacherSearchGenderComboBox.Text = teacherSearchPasswordTextBox.Text = teacherSearchConfirmPasswordTextBox.Text
                    = teacherSearchEmailTextBox.Text = teacherSearchPhoneTextBox.Text = teacherSearchDOB.Text = teacherSearchSubjectComboBox.Text =
                    teacherSearchAddressTextBox.Text = teacherSearchDepartmentComboBox.Text = teacherSearchBGComboBox.Text = teacherSearchDOB.Text = "";
                teacherSearchNursary.Checked = teacherSearchStd1.Checked = teacherSearchStd2.Checked = teacherSearchStd3.Checked = teacherSearchStd4.Checked
                    = teacherSearchStd5.Checked = teacherSearchStd6.Checked = teacherSearchStd7.Checked = teacherSearchStd8.Checked = teacherSearchStd9.Checked
                    = teacherSearchStd10.Checked = false;
            }
            catch (Exception ec) { MessageBox.Show("Select A Teacher First."); }
        }
        int teacherSearchId;
        private void teacherSearchDataGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            Teacher t = new Teacher();
            char[] del = { 'T','-'};
            teacherSearchId = Convert.ToInt32(teacherSearchDataGrid.CurrentRow.Cells[0].Value.ToString().Split(del,StringSplitOptions.RemoveEmptyEntries)[0]);
            try { teacherSearchTeacherIdTextBox.Text = teacherSearchDataGrid.CurrentRow.Cells[0].Value.ToString(); }
            catch (Exception ec) { teacherSearchTeacherIdTextBox.Text = ""; }
            try { teacherSearchNameTextBox.Text = teacherSearchDataGrid.CurrentRow.Cells[1].Value.ToString(); }
            catch (Exception ec) { teacherSearchNameTextBox.Text = ""; }
            try { teacherSearchGenderComboBox.Text = teacherSearchDataGrid.CurrentRow.Cells[2].Value.ToString(); }
            catch (Exception ec) { teacherSearchGenderComboBox.Text = ""; }
            try { teacherSearchPasswordTextBox.Text = teacherSearchDataGrid.CurrentRow.Cells[3].Value.ToString(); }
            catch (Exception ec) {teacherSearchPasswordTextBox.Text =""; }
            try { teacherSearchConfirmPasswordTextBox.Text = teacherSearchDataGrid.CurrentRow.Cells[3].Value.ToString(); }
            catch (Exception ec) { teacherSearchConfirmPasswordTextBox.Text =""; }
            try { teacherSearchEmailTextBox.Text = teacherSearchDataGrid.CurrentRow.Cells[4].Value.ToString(); }
            catch (Exception ec) { teacherSearchEmailTextBox.Text ="";}
            try { teacherSearchPhoneTextBox.Text = teacherSearchDataGrid.CurrentRow.Cells[5].Value.ToString(); }
            catch (Exception ec) { teacherSearchPhoneTextBox.Text = ""; }
            try { teacherSearchDOB.Text = teacherSearchDataGrid.CurrentRow.Cells[6].Value.ToString(); }
            catch (Exception ec) { teacherSearchDOB.Text = ""; }
            try { teacherSearchSubjectComboBox.Text = teacherSearchDataGrid.CurrentRow.Cells[7].Value.ToString(); }
            catch (Exception ec) { teacherSearchSubjectComboBox.Text = ""; }
            try
            {
                teacherSearchDepartmentComboBox.Text = teacherSearchDataGrid.CurrentRow.Cells[8].Value.ToString();
            }
            catch (Exception ec) { teacherSearchDepartmentComboBox.Text = ""; }
            try { teacherSearchBGComboBox.Text = teacherSearchDataGrid.CurrentRow.Cells[9].Value.ToString(); }
            catch (Exception ec) { teacherSearchBGComboBox.Text = ""; }
            try { teacherSearchAddressTextBox.Text = teacherSearchDataGrid.CurrentRow.Cells[10].Value.ToString(); }
            catch (Exception ec) { teacherSearchAddressTextBox.Text = ""; }
            teacherSearchNursary.Checked = Convert.ToInt32(teacherSearchDataGrid.CurrentRow.Cells[12].Value) == 1 ? true : false;
            teacherSearchStd1.Checked = Convert.ToInt32(teacherSearchDataGrid.CurrentRow.Cells[13].Value) == 1 ? true : false;
            teacherSearchStd2.Checked = Convert.ToInt32(teacherSearchDataGrid.CurrentRow.Cells[14].Value) == 1 ? true : false;
            teacherSearchStd3.Checked = Convert.ToInt32(teacherSearchDataGrid.CurrentRow.Cells[15].Value) == 1 ? true : false;
            teacherSearchStd4.Checked = Convert.ToInt32(teacherSearchDataGrid.CurrentRow.Cells[16].Value) == 1 ? true : false;
            teacherSearchStd5.Checked = Convert.ToInt32(teacherSearchDataGrid.CurrentRow.Cells[17].Value) == 1 ? true : false;
            teacherSearchStd6.Checked = Convert.ToInt32(teacherSearchDataGrid.CurrentRow.Cells[18].Value) == 1 ? true : false;
            teacherSearchStd7.Checked = Convert.ToInt32(teacherSearchDataGrid.CurrentRow.Cells[19].Value) == 1 ? true : false;
            teacherSearchStd8.Checked = Convert.ToInt32(teacherSearchDataGrid.CurrentRow.Cells[20].Value) == 1 ? true : false;
            teacherSearchStd9.Checked = Convert.ToInt32(teacherSearchDataGrid.CurrentRow.Cells[21].Value) == 1 ? true : false;
            teacherSearchStd10.Checked = Convert.ToInt32(teacherSearchDataGrid.CurrentRow.Cells[22].Value) == 1 ? true : false;
            try { teacherSearchPictureBox.Image = byteArrayToImage(t.GetPhoto(teacherSearchId)); }
            catch (Exception ec) { teacherSearchPictureBox.Image = null; }

        }

        

        private void teacherAddBrowseButton_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog dlg = new OpenFileDialog();
                dlg.Multiselect = false;
                dlg.Filter = "JPG Files (*.JPG)|*.jpg";
                dlg.Title = "Select Picture";
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    studentImgLoc = dlg.FileName.ToString();
                    teacherAddPictureBox.ImageLocation = studentImgLoc;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void teacherSearchBrowseButton_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog dlg = new OpenFileDialog();
                dlg.Multiselect = false;
                dlg.Filter = "JPG Files (*.JPG)|*.jpg";
                dlg.Title = "Select Picture";
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    studentImgLoc = dlg.FileName.ToString();
                    teacherSearchPictureBox.ImageLocation = studentImgLoc;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void teacherSearchSearchButton_Click(object sender, EventArgs e)
        {
            try
            {
                Teacher t = new Teacher();
                teacherSearchDataGrid.DataSource = t.SearchTeacher(teacherSearchTextBox.Text);
            }
            catch (Exception ec) {}
        }
        private void button6_Click(object sender, EventArgs e)
        {
            Teacher t = new Teacher();
            teacherSearchDataGrid.DataSource = t.GetList();
        }

        #endregion

        #region Employee Panel

        private void button5_Click(object sender, EventArgs e)
        {
            Employee em = new Employee();
            employeeSearchDataGrid.DataSource = em.GetList();
        }
       

        private void employeeMenuButton_Click(object sender, EventArgs e)
        {
            this.adminPanel.Visible = false;
            this.termExamPanel.Visible = false;
            this.studentPanel.Visible = false;
            this.attendancePanel.Visible = false;
            this.employeePanel.Visible = true;
            this.teacherPanel.Visible = false;
        }

        private void employeeRegisterButton_Click(object sender, EventArgs e)
        {
            Employee em = new Employee();
            employeeRegisterEmployeeIdTextBox.Text = "E-" + Convert.ToString(em.GetLastEmployeeId() + 1);
            this.employeeRegisterPanel.Visible = true;
            this.employeeSearchPanel.Visible = false;
        }

        private void employeeSearchButton_Click(object sender, EventArgs e)
        {
            Employee em = new Employee();
            employeeSearchDataGrid.ForeColor = Color.Black;
            employeeSearchDataGrid.DataSource = em.GetList();
            this.employeeRegisterPanel.Visible = false;
            this.employeeSearchPanel.Visible = true;
        }
        private void employeeRegisterBrowseButton_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog dlg = new OpenFileDialog();
                dlg.Multiselect = false;
                dlg.Filter = "JPG Files (*.JPG)|*.jpg";
                dlg.Title = "Select Picture";
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    studentImgLoc = dlg.FileName.ToString();
                    employeeRegisterPictureBox.ImageLocation = studentImgLoc;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void employeeRegisterSubmitButton_Click(object sender, EventArgs e)
        {
            Employee em = new Employee();
            employeeRegisterEmployeeIdTextBox.Text = "E-"+Convert.ToString(em.GetLastEmployeeId()+1);
            try { em.Name = employeeRegisterNameTextBox.Text; }
            catch (Exception ec) { em.Name = ""; }
            try { em.Gender = employeeRegisterGenderComboBox.Text; }
            catch (Exception ec) { em.Gender= ""; }
            try { em.Phone = employeeRegisterPhoneTextBox.Text; }
            catch (Exception ec) { em.Phone = ""; }
            try { em.Address = employeeRegisterAddressTextBox.Text; }
            catch (Exception ec) { em.Address = ""; }
            try { em.RegisterDate = employeeRegisterDate.Value.ToShortDateString(); }
            catch (Exception ec) { em.RegisterDate = ""; }
            try { em.DateOfBirth = employeeRegisterDOB.Value.ToShortDateString(); }
            catch (Exception ec) { em.DateOfBirth = ""; }
            try { em.BloodGroup = employeeRegisterBGComboBox.Text; }
            catch (Exception ec) { em.BloodGroup = ""; }
            try { em.Email = employeeRegisterEmailTextBox.Text; }
            catch (Exception ec) { em.Email = ""; }
            try { em.Photo = imageToByteArray(employeeRegisterPictureBox.Image); }
            catch (Exception ec) { em.Photo=null; }
            try { em.ID = Convert.ToInt32(em.GetLastEmployeeId() + 1); }
            catch (Exception ec) { em.ID = 1001; }

            em.AddEmployee();
            MessageBox.Show("New Employee Added.");
            employeeRegisterNameTextBox.Text = employeeRegisterGenderComboBox.Text = employeeRegisterPhoneTextBox.Text
                = employeeRegisterAddressTextBox.Text = employeeRegisterDate.Text = employeeRegisterDOB.Text = employeeRegisterBGComboBox.Text
                = employeeRegisterEmailTextBox.Text = "";
            employeeRegisterPictureBox.Image = null;
            employeeRegisterEmployeeIdTextBox.Text = "E-" + Convert.ToString(em.GetLastEmployeeId() + 1);

            employeeSearchDataGrid.DataSource = em.GetList();
        }

        private void employeeSearchSearchButton_Click(object sender, EventArgs e)
        {
            Employee em = new Employee();
            employeeSearchDataGrid.DataSource = em.SearchEmployee(employeeSearchTextBox.Text);
        }

        int empId;
        private void employeeSearchDataGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            Employee em = new Employee();
            char[] del = { 'E', '-' };
            empId = Convert.ToInt32(employeeSearchDataGrid.CurrentRow.Cells[0].Value.ToString().Split(del,StringSplitOptions.RemoveEmptyEntries)[0]);
            try { employeeSearchEmployeeIdTextBox.Text = employeeSearchDataGrid.CurrentRow.Cells[0].Value.ToString(); }
            catch (Exception ec) { employeeSearchEmployeeIdTextBox.Text = ""; }
            try { employeeSearchNameUpdateTextBox.Text = employeeSearchDataGrid.CurrentRow.Cells[1].Value.ToString(); }
            catch (Exception ec) { employeeSearchNameUpdateTextBox.Text = ""; }
            try { employeeSearchGenderUpdateComboBox.Text = employeeSearchDataGrid.CurrentRow.Cells[2].Value.ToString(); }
            catch (Exception ec) { employeeSearchGenderUpdateComboBox.Text = ""; }
            try { employeeSearchPhoneUpdateTextBox.Text = employeeSearchDataGrid.CurrentRow.Cells[3].Value.ToString(); }
            catch (Exception ec) { employeeSearchPhoneUpdateTextBox.Text = ""; }
            try { employeeSearchAddressUpdateTextBox.Text = employeeSearchDataGrid.CurrentRow.Cells[4].Value.ToString(); }
            catch (Exception ec) { employeeSearchAddressUpdateTextBox.Text = ""; }
            try { employeeSearchRegisterDateUpdate.Text = employeeSearchDataGrid.CurrentRow.Cells[5].Value.ToString(); }
            catch (Exception ec) { employeeSearchRegisterDateUpdate.Text = ""; }
            try { employeeSearchDOBUpdate.Text = employeeSearchDataGrid.CurrentRow.Cells[6].Value.ToString(); }
            catch (Exception ec) { employeeSearchDOBUpdate.Text = ""; }
            try { employeeSearchBGUpdateComboBox.Text = employeeSearchDataGrid.CurrentRow.Cells[7].Value.ToString(); }
            catch (Exception ec) { employeeSearchBGUpdateComboBox.Text = ""; }
            try { employeeSearchEmailUpdateTextBox.Text = employeeSearchDataGrid.CurrentRow.Cells[8].Value.ToString(); }
            catch (Exception ec) { employeeSearchEmailUpdateTextBox.Text = ""; }
            try { employeeSearchPictureBox.Image = byteArrayToImage(em.GetPhoto(empId)); }
            catch (Exception ec) { employeeSearchPictureBox.Image = null; }
        }

        private void employeeSearchBrowseButton_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog dlg = new OpenFileDialog();
                dlg.Multiselect = false;
                dlg.Filter = "JPG Files (*.JPG)|*.jpg";
                dlg.Title = "Select Picture";
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    studentImgLoc = dlg.FileName.ToString();
                    employeeSearchPictureBox.ImageLocation = studentImgLoc;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void employeeSearchUpdateButton_Click(object sender, EventArgs e)
        {
            Employee em = new Employee();
            try { em.ID = empId; }
            catch (Exception ec) { em.ID = 1001; }
            try { em.Name = employeeSearchNameUpdateTextBox.Text; }
            catch (Exception ec) { em.Name = ""; }
            try { em.Gender = employeeSearchGenderUpdateComboBox.Text; }
            catch (Exception ec) { em.Gender = ""; }
            try { em.Phone = employeeSearchPhoneUpdateTextBox.Text; }
            catch (Exception ec) { em.Phone = ""; }
            try { em.Address = employeeSearchAddressUpdateTextBox.Text; }
            catch (Exception ec) { em.Address = ""; }
            try { em.RegisterDate = employeeSearchRegisterDateUpdate.Value.ToShortDateString(); }
            catch (Exception ec) { em.RegisterDate = ""; }
            try { em.DateOfBirth = employeeSearchDOBUpdate.Value.ToShortDateString(); }
            catch (Exception ec) { em.DateOfBirth = ""; }
            try { em.BloodGroup = employeeSearchBGUpdateComboBox.Text; }
            catch (Exception ec) { em.BloodGroup = ""; }
            try { em.Email = employeeSearchEmailUpdateTextBox.Text; }
            catch (Exception ec) { em.Email = ""; }
            try { em.Photo = imageToByteArray(employeeSearchPictureBox.Image); }
            catch (Exception ec) { em.Photo = null; }

            em.UpdateEmployee();
            MessageBox.Show("Employee Updated.");
            employeeSearchNameUpdateTextBox.Text = employeeSearchGenderUpdateComboBox.Text = employeeSearchPhoneUpdateTextBox.Text
                = employeeSearchAddressUpdateTextBox.Text = employeeSearchRegisterDateUpdate.Text = employeeSearchDOBUpdate.Text = employeeSearchBGUpdateComboBox.Text
                = employeeSearchEmailUpdateTextBox.Text = "";
            employeeSearchPictureBox.Image = null;

            employeeSearchDataGrid.DataSource = em.GetList();

        }

        private void employeeSearchDeleteButton_Click(object sender, EventArgs e)
        {
            try
            {
                Employee em = new Employee();
                em.DeleteEmployee(empId);
                MessageBox.Show("Employee Deleted.");
                employeeSearchNameUpdateTextBox.Text = employeeSearchGenderUpdateComboBox.Text = employeeSearchPhoneUpdateTextBox.Text
                    = employeeSearchAddressUpdateTextBox.Text = employeeSearchRegisterDateUpdate.Text = employeeSearchDOBUpdate.Text = employeeSearchBGUpdateComboBox.Text
                    = employeeSearchEmailUpdateTextBox.Text = "";
                employeeSearchPictureBox.Image = null;

                employeeSearchDataGrid.DataSource = em.GetList();
            }
            catch (Exception ec) { MessageBox.Show("Select a Employee First."); }
        }

        #endregion


        #region Term Exam Panel
        private void termExamMenuButton_Click(object sender, EventArgs e)
        {
            this.adminPanel.Visible = false;
            this.termExamPanel.Visible = true;
            this.studentPanel.Visible = false;
            this.attendancePanel.Visible = false;
            this.employeePanel.Visible = false;
            this.teacherPanel.Visible = false;
            Exam ex = new Exam();
            termExamDataGrid.DataSource = ex.GetTermExamList();
        }

        private void termExamAddButton_Click(object sender, EventArgs e)
        {
            Exam ex = new Exam();
            try { ex.AddTermExam(termExamDate.Value.ToShortDateString(), termExamSubjectComboBox.Text, termExamClassNameComboBox.Text
                                    ,termExamDepartmentComboBox.Text); }
            catch (Exception ec) { ex.AddTermExam("", "", "",""); }
            MessageBox.Show("New Term Exam Schedule Added");
            termExamClassNameComboBox.Text = termExamSubjectComboBox.Text = termExamDate.Text = termExamDepartmentComboBox.Text= "";
            termExamDataGrid.DataSource = ex.GetTermExamList();
        }

        int termExamId;
        private void termExamDataGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            termExamId = Convert.ToInt32(termExamDataGrid.CurrentRow.Cells[0].Value);
            termExamDate.Text = termExamDataGrid.CurrentRow.Cells[1].Value.ToString();
            termExamClassNameComboBox.Text = termExamDataGrid.CurrentRow.Cells[3].Value.ToString();
            termExamSubjectComboBox.Text = termExamDataGrid.CurrentRow.Cells[2].Value.ToString();
            termExamDepartmentComboBox.Text = termExamDataGrid.CurrentRow.Cells[4].Value.ToString();
        }

        private void termExamUpdateButton_Click(object sender, EventArgs e)
        {
            Exam ex = new Exam();
            try
            {
                ex.UpdateTermExam(termExamDate.Value.ToShortDateString(), termExamSubjectComboBox.Text, termExamClassNameComboBox.Text, termExamDepartmentComboBox.Text,
                                      termExamId);

                MessageBox.Show("Term Exam Schedule Updated");
                termExamClassNameComboBox.Text = termExamSubjectComboBox.Text = termExamDate.Text = termExamDepartmentComboBox.Text = "";
                termExamDataGrid.DataSource = ex.GetTermExamList();
            }
            catch (Exception ec) { MessageBox.Show("Select an exam First."); }
        }

        private void termExamDeleteButton_Click(object sender, EventArgs e)
        {
            try
            {
                Exam ex = new Exam();
                try { ex.DeleteTermExam(termExamId); }
                catch (Exception ec) { MessageBox.Show("Select First"); }
                MessageBox.Show("Term Exam Schedule Deleted");
                termExamClassNameComboBox.Text = termExamSubjectComboBox.Text = termExamDate.Text = termExamDepartmentComboBox.Text = "";
                termExamDataGrid.DataSource = ex.GetTermExamList();
            }
            catch (Exception ec) { MessageBox.Show("Select an exam First."); }
        }
        #endregion

        private void LogoutBotton_Click(object sender, EventArgs e)
        {
            this.l.Show();
            this.Hide();
        }
        #region Employee Attendance

        private void attendanceMenuButton_Click(object sender, EventArgs e)
        {
            this.adminPanel.Visible = false;
            this.termExamPanel.Visible = false;
            this.studentPanel.Visible = false;
            this.attendancePanel.Visible = true;
            this.employeePanel.Visible = false;
            this.teacherPanel.Visible = false;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            employeeAttendanceUpdateDataGrid.DataSource = null;
        }
        private void employeeAttendaceButton_Click(object sender, EventArgs e)
        {
            this.employeeAttendancePanel.Visible = true;
            this.employeeAttendanceUpdatePanel.Visible = false;
            try
            {
                Employee em = new Employee();
                attendanceEmployeeDataGrid.DataSource = em.GetEmployeeListForAttendance();
            }
            catch (Exception ec) { }
        }

        private void employeeAttendanceUpdate_Click(object sender, EventArgs e)
        {
            this.employeeAttendancePanel.Visible = false;
            this.employeeAttendanceUpdatePanel.Visible = true;
            
        }

        private void employeeAttendanceDoneButton_Click(object sender, EventArgs e)
        {
            int p;
            string d = employeeAttendanceDate.Value.ToShortDateString();
            Employee em = new Employee();
            for (int i = 0; i < attendanceEmployeeDataGrid.Rows.Count; i++)
            {
                
                string ei = attendanceEmployeeDataGrid.Rows[i].Cells[1].Value.ToString();
                string n = attendanceEmployeeDataGrid.Rows[i].Cells[2].Value.ToString();
                

                if (Convert.ToBoolean(attendanceEmployeeDataGrid.Rows[i].Cells[0].Value) == true)
                {
                    p = 1;
                    em.AddInEmployeeAttendance(ei, n, d, p);
                }
                else
                {
                    p = 0;
                    em.AddInEmployeeAttendance(ei, n, d, p);
                }
                
            }
            MessageBox.Show("Employee Attendance Data Uploaded.");
            attendanceEmployeeDataGrid.DataSource = null;
        }

        private void employeeAttendanceUpdateSearchButton_Click(object sender, EventArgs e)
        {
            Employee em = new Employee();
            employeeAttendanceUpdateDataGrid.DataSource = em.SearchAttendanceByDate(employeeAttendanceUpdateDate.Value.ToShortDateString());
            employeeAttendanceData2.DataSource = em.GetAttendance(employeeAttendanceUpdateDate.Value.ToShortDateString());
            for (int i = 0; i < employeeAttendanceUpdateDataGrid.Rows.Count; i++)
            {
                if (Convert.ToInt32(employeeAttendanceData2.Rows[i].Cells[0].Value) == 1)
                {
                    employeeAttendanceUpdateDataGrid.Rows[i].Cells[0].Value = true;

                }
                else
                {
                    employeeAttendanceUpdateDataGrid.Rows[i].Cells[0].Value = false;

                }
            }
        }

        private void employeeAttendanceUpdateButton_Click(object sender, EventArgs e)
        {
            int p;
            Employee em = new Employee();
            for (int i = 0; i < employeeAttendanceUpdateDataGrid.Rows.Count; i++)
            {

                string ei = employeeAttendanceUpdateDataGrid.Rows[i].Cells[1].Value.ToString();
                string n = employeeAttendanceUpdateDataGrid.Rows[i].Cells[2].Value.ToString();
                string d = employeeAttendanceUpdateDataGrid.Rows[i].Cells[3].Value.ToString();
                if (Convert.ToInt32(employeeAttendanceUpdateDataGrid.Rows[i].Cells[0].Value) == 1)
                {
                    p = 1;
                    em.UpdateInEmployeeAttendance(ei, n, d, p);
                }
                else
                {
                    p = 0;
                    em.UpdateInEmployeeAttendance(ei, n, d, p);
                }
                MessageBox.Show("Employee Attendance Data Uploaded.");
                employeeAttendanceUpdateDataGrid.DataSource = null;
            }
        }
        private void attendanceEmployeeDataGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (Convert.ToBoolean(attendanceEmployeeDataGrid.CurrentRow.Cells[0].Value) == true)
            {
                attendanceEmployeeDataGrid.CurrentRow.Cells[0].Value = false;
            }
            else
            {
                attendanceEmployeeDataGrid.CurrentRow.Cells[0].Value = true;
            }
        }

        #endregion


        #region Admin Panel
        private void adminAddButton_Click(object sender, EventArgs e)
        {
            AdminClass a = new AdminClass();
            adminAddAdminIdTextBox.Text = "A-" + Convert.ToString(a.GetLastID() + 1);
            this.adminAddPanel.Visible = true;
            this.adminSearchPanel.Visible = false;
        }

        private void adminSearchButton_Click(object sender, EventArgs e)
        {
            AdminClass a = new AdminClass();
            adminSearchData.DataSource = a.GetList();
            this.adminAddPanel.Visible = false;
            this.adminSearchPanel.Visible = true;
        }

        private void adminMenuButton_Click(object sender, EventArgs e)
        {
            this.adminPanel.Visible = true;
            this.termExamPanel.Visible = false;
            this.studentPanel.Visible = false;
            this.attendancePanel.Visible = false;
            this.employeePanel.Visible = false;
            this.teacherPanel.Visible = false;
        }

        private void adminAddBrowseButton_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog dlg = new OpenFileDialog();
                dlg.Multiselect = false;
                dlg.Filter = "JPG Files (*.JPG)|*.jpg";
                dlg.Title = "Select Picture";
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    studentImgLoc = dlg.FileName.ToString();
                    adminAddPicture.ImageLocation = studentImgLoc;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        
        }

        private void adminAddSubmitButton_Click(object sender, EventArgs e)
        {
            if (adminAddPasswordTextBox.Text == adminAddConfirmPasswordTextBox.Text)
            {
                AdminClass a = new AdminClass();
                try { a.Name = adminAddNameTextBox.Text; }
                catch (Exception ec) { a.Name = ""; }
                try { a.Gender = adminAddGenderComboBox.Text; }
                catch (Exception ec) { a.Gender = ""; }
                try { a.Password = adminAddPasswordTextBox.Text; }
                catch (Exception ec) { a.Password = ""; }
                try { a.Address = adminAddAddressTextBox.Text; }
                catch (Exception ec) { a.Address = ""; }
                try { a.RegisterDate = adminAddRegisterDate.Value.ToShortDateString(); }
                catch (Exception ec) { a.RegisterDate = ""; }
                try { a.BloodGroup = adminAddBGComboBox.Text; }
                catch (Exception ec) { a.BloodGroup = ""; }
                try { a.Email = adminAddEmailTextBox.Text; }
                catch (Exception ec) { a.Email = ""; }
                try { a.Phone = adminAddPhoneNumberTextBox.Text; }
                catch (Exception ec) { a.Phone = ""; }
                try { a.DOB = adminAddDOB.Value.ToShortDateString(); }
                catch (Exception ec) { a.DOB = ""; }
                try { a.Photo = imageToByteArray(adminAddPicture.Image); }
                catch (Exception ec) { a.Photo = null; }
                a.AddAdmin();
                MessageBox.Show("New Admin Added.");
                adminAddAdminIdTextBox.Text = "A-"+Convert.ToString(a.GetLastID() + 1);
                adminAddNameTextBox.Text = adminAddGenderComboBox.Text = adminAddPasswordTextBox.Text = adminAddConfirmPasswordTextBox.Text =
                    adminAddAddressTextBox.Text = adminAddRegisterDate.Text = adminAddBGComboBox.Text = adminAddEmailTextBox.Text =
                    adminAddPhoneNumberTextBox.Text = adminAddDOB.Text = "";
                adminAddPicture.Image = null;
            }
            else
            {
                MessageBox.Show("Password Did not Matched.");
            }
        }

        string adminID;
        private void adminSearchData_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            AdminClass a = new AdminClass();
            adminID = adminSearchData.CurrentRow.Cells[0].Value.ToString();
            try { adminSearchAdminIDTextBox.Text = adminSearchData.CurrentRow.Cells[0].Value.ToString(); }
            catch (Exception ec) { adminSearchAdminIDTextBox.Text = ""; }
            try { adminSearchNameTextBox.Text = adminSearchData.CurrentRow.Cells[1].Value.ToString(); }
            catch (Exception ec) { adminSearchNameTextBox.Text = ""; }
            try { adminSearchGenderComboBox.Text = adminSearchData.CurrentRow.Cells[2].Value.ToString(); }
            catch (Exception ec) { adminSearchGenderComboBox.Text = ""; }
            try { adminSearchPasswordTextBox.Text = adminSearchData.CurrentRow.Cells[3].Value.ToString(); }
            catch (Exception ec) { adminSearchPasswordTextBox.Text = ""; }
            try { adminSearchConfirmPasswordTextBox.Text = adminSearchData.CurrentRow.Cells[3].Value.ToString(); }
            catch (Exception ec) { adminSearchConfirmPasswordTextBox.Text = ""; }
            try { adminSearchAddressTextBox.Text = adminSearchData.CurrentRow.Cells[4].Value.ToString(); }
            catch (Exception ec) { adminSearchAddressTextBox.Text = ""; }
            try {  adminSearchBGComboBox.Text = adminSearchData.CurrentRow.Cells[6].Value.ToString(); }
            catch (Exception ec) { adminSearchBGComboBox.Text = ""; }
            try { adminSearchEmailTextBox.Text = adminSearchData.CurrentRow.Cells[7].Value.ToString(); }
            catch (Exception ec) { adminSearchEmailTextBox.Text = ""; }
            try { adminSearchPhoneNumberTextBox.Text = adminSearchData.CurrentRow.Cells[8].Value.ToString(); }
            catch (Exception ec) { adminSearchPhoneNumberTextBox.Text = ""; }
            try { adminSearchDOBTextBox.Text = adminSearchData.CurrentRow.Cells[9].Value.ToString(); }
            catch (Exception ec) { adminSearchDOBTextBox.Text = ""; }
            try { adminSearchPicture.Image = byteArrayToImage(a.GetPhoto(adminSearchAdminIDTextBox.Text)); }
            catch (Exception ec) { adminSearchPicture = null; }
        }

        private void adminSearchSearchButton_Click(object sender, EventArgs e)
        {
            AdminClass a = new AdminClass();
            adminSearchData.DataSource = a.SearchAdmin(adminSearchByIdTextBox.Text);
        }

        private void adminSearchBrowseButton_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog dlg = new OpenFileDialog();
                dlg.Multiselect = false;
                dlg.Filter = "JPG Files (*.JPG)|*.jpg";
                dlg.Title = "Select Picture";
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    studentImgLoc = dlg.FileName.ToString();
                    adminSearchPicture.ImageLocation = studentImgLoc;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void adminSearchUpdateButton_Click(object sender, EventArgs e)
        {
           if(adminSearchConfirmPasswordTextBox.Text == adminSearchPasswordTextBox.Text)
             {
                AdminClass a = new AdminClass();
                try { a.Name = adminSearchNameTextBox.Text; }
                catch (Exception ec) { a.Name = ""; }
                try { a.Gender = adminSearchGenderComboBox.Text; }
                catch (Exception ec) { a.Gender = ""; }
                try { a.Password = adminSearchPasswordTextBox.Text; }
                catch (Exception ec) { a.Password = ""; }
                try { a.Address = adminSearchAddressTextBox.Text; }
                catch (Exception ec) { a.Address = ""; }
                try { a.BloodGroup = adminSearchBGComboBox.Text; }
                catch (Exception ec) { a.BloodGroup = ""; }
                try { a.Email = adminSearchEmailTextBox.Text; }
                catch (Exception ec) { a.Email = ""; }
                try { a.Phone = adminSearchPhoneNumberTextBox.Text; }
                catch (Exception ec) { a.Phone = ""; }
                try { a.DOB = adminSearchDOBTextBox.Value.ToShortDateString(); }
                catch (Exception ec) { a.DOB = ""; }
                try { a.Photo = imageToByteArray(adminSearchPicture.Image); }
                catch (Exception ec) { a.Photo = null; }
                a.UpdateAdmin(adminSearchAdminIDTextBox.Text);
                MessageBox.Show("New Admin Updated.");
                adminSearchData.DataSource = a.GetList();
                adminSearchAdminIDTextBox.Text = "";
                adminSearchNameTextBox.Text = adminSearchGenderComboBox.Text = adminSearchPasswordTextBox.Text = adminSearchConfirmPasswordTextBox.Text =
                    adminSearchAddressTextBox.Text =  adminSearchBGComboBox.Text = adminSearchEmailTextBox.Text =
                    adminSearchPhoneNumberTextBox.Text = adminSearchDOBTextBox.Text = "";
                adminSearchPicture.Image = null;
            }
            else
            {
                MessageBox.Show("Password Did not Matched.");
            }
        }

        private void adminSearchDeleteButton_Click(object sender, EventArgs e)
        {
            AdminClass a = new AdminClass();
            a.DeleteAdmin(adminID);
            MessageBox.Show("Admin Details Deleted.");
            adminSearchAdminIDTextBox.Text = "";
            adminSearchNameTextBox.Text = adminSearchGenderComboBox.Text = adminSearchPasswordTextBox.Text = adminSearchConfirmPasswordTextBox.Text =
                adminSearchAddressTextBox.Text = adminSearchBGComboBox.Text = adminSearchEmailTextBox.Text =
                adminSearchPhoneNumberTextBox.Text = adminSearchDOBTextBox.Text = "";
            adminSearchPicture.Image = null;
            adminSearchData.DataSource = a.GetList();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AdminClass a = new AdminClass();
            adminSearchData.DataSource = a.SearchAdmin(adminSearchByIdTextBox.Text);
        }

        #endregion
    }
}
