﻿namespace Projectwork111
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.tileBarPanel = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.path = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.crossButton = new Bunifu.Framework.UI.BunifuFlatButton();
            this.menu = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.attendanceMenuButton = new Bunifu.Framework.UI.BunifuFlatButton();
            this.studentPanel = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.studentRegistrationPanel = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.studentRegistrationRegisterPanel = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.studentRegistrationRegisterSubmitButton = new Bunifu.Framework.UI.BunifuFlatButton();
            this.studentRegistrationRegisterDOB = new System.Windows.Forms.DateTimePicker();
            this.studentRegistrationRegisterAdmissionDate = new System.Windows.Forms.DateTimePicker();
            this.studentRegistrationRegisterDepartmentComboBox = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.studentRegistrationRegisterSectionComboBox = new System.Windows.Forms.ComboBox();
            this.studentRegistrationRegisterClassComboBox = new System.Windows.Forms.ComboBox();
            this.studentRegistrationRegisterGenderComboBox = new System.Windows.Forms.ComboBox();
            this.studentRegistrationRegisterAddressTextBox = new System.Windows.Forms.RichTextBox();
            this.studentRegistrationRegisterEmailTextBox = new System.Windows.Forms.TextBox();
            this.studentRegistrationRegisterPhoneTextBox = new System.Windows.Forms.TextBox();
            this.studentRegistrationRegisterMotherOccupationTextBox = new System.Windows.Forms.TextBox();
            this.studentRegistrationRegisterMotherNameTextBox = new System.Windows.Forms.TextBox();
            this.studentRegistrationRegisterFatherOccupationTextBox = new System.Windows.Forms.TextBox();
            this.studentRegistrationRegisterFatherNameTextBox = new System.Windows.Forms.TextBox();
            this.studentRegistrationRegisterNameTextBox = new System.Windows.Forms.TextBox();
            this.studentRegistrationRegisterAdmissionNumberTextBox = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.studentRegistrationSearchPanel = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.label34 = new System.Windows.Forms.Label();
            this.studentRegistrationSearchSearchButton = new Bunifu.Framework.UI.BunifuFlatButton();
            this.studentRegistrationSearchIDTextBox = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.studentRegistrationSearchUpdateButton = new Bunifu.Framework.UI.BunifuFlatButton();
            this.studentRegistrationSearchDeleteButton = new Bunifu.Framework.UI.BunifuFlatButton();
            this.studentRegistrationSearchDOBUpdate = new System.Windows.Forms.DateTimePicker();
            this.studentRegistrationSearchAdmissionDateUpdate = new System.Windows.Forms.DateTimePicker();
            this.studentRegistrationSearchDepartmentUpdateComboBox = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.studentRegistrationSearchSectionUpdateComboBox = new System.Windows.Forms.ComboBox();
            this.studentRegistrationSearchClassUpdateComboBox = new System.Windows.Forms.ComboBox();
            this.studentRegistrationSearchGenderUpdateComboBox = new System.Windows.Forms.ComboBox();
            this.studentRegistrationSearchAddressUpdateTextBox = new System.Windows.Forms.RichTextBox();
            this.studentRegistrationSearchEmailUpdateTextBox = new System.Windows.Forms.TextBox();
            this.studentRegistrationSearchPhoneUpdateTextBox = new System.Windows.Forms.TextBox();
            this.studentRegistrationSearchMotherOccupationUpdateTextBox = new System.Windows.Forms.TextBox();
            this.studentRegistrationSearchMotherNameUpdateTextBox = new System.Windows.Forms.TextBox();
            this.studentRegistrationSearchFatherOccupationUpdateTextBox = new System.Windows.Forms.TextBox();
            this.studentRegistrationSearchFatherNameUpdateTextBox = new System.Windows.Forms.TextBox();
            this.studentRegistrationSearchNameUpdateTextBox = new System.Windows.Forms.TextBox();
            this.studentRegistrationSearchAdmissionNumberUpdateTextBox = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.studentRegistrationSearchDataGrid = new System.Windows.Forms.DataGridView();
            this.studentRegistrationSearchButton = new Bunifu.Framework.UI.BunifuFlatButton();
            this.studentRegistrationRegisterButton = new Bunifu.Framework.UI.BunifuFlatButton();
            this.studentPromotionPanel = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.studentPromotionClassUpdateComboBox = new System.Windows.Forms.ComboBox();
            this.label64 = new System.Windows.Forms.Label();
            this.studentPromotionClassComboBox = new System.Windows.Forms.ComboBox();
            this.studentPromotionSearchButton = new Bunifu.Framework.UI.BunifuFlatButton();
            this.label50 = new System.Windows.Forms.Label();
            this.studentPromotionPromoteButton = new Bunifu.Framework.UI.BunifuFlatButton();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.studentPromotion = new Bunifu.Framework.UI.BunifuFlatButton();
            this.studentRegistrationButton = new Bunifu.Framework.UI.BunifuFlatButton();
            this.administratorPanel = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.sectionPanel = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.sectionSearchPanel = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.sectionSearchUpdateButton = new Bunifu.Framework.UI.BunifuFlatButton();
            this.sectionSearchDeleteButton = new Bunifu.Framework.UI.BunifuFlatButton();
            this.sectionSearchDataGrid = new Bunifu.Framework.UI.BunifuCustomDataGrid();
            this.className = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.section = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.department = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bunifuCustomLabel28 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.sectionSearchSectionNameTextBox = new System.Windows.Forms.TextBox();
            this.sectionSearchDepartmentComboBox = new System.Windows.Forms.ComboBox();
            this.bunifuCustomLabel29 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.sectionSearchClassComboBox = new System.Windows.Forms.ComboBox();
            this.bunifuCustomLabel30 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.sectionSearchSearchButton = new Bunifu.Framework.UI.BunifuFlatButton();
            this.sectionAddPanel = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.bunifuCustomLabel27 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.sectionNameSectionAddTextBox = new System.Windows.Forms.TextBox();
            this.departmentSectionAddComboBox = new System.Windows.Forms.ComboBox();
            this.bunifuCustomLabel26 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.classSectionAddComboBox = new System.Windows.Forms.ComboBox();
            this.bunifuCustomLabel25 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.sectionAddDoneButton = new Bunifu.Framework.UI.BunifuFlatButton();
            this.sectionSearchButton = new Bunifu.Framework.UI.BunifuFlatButton();
            this.sectionAddButton = new Bunifu.Framework.UI.BunifuFlatButton();
            this.userPanel = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.addUserPanel = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.bunifuCustomLabel10 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.doneAddUserButton = new Bunifu.Framework.UI.BunifuFlatButton();
            this.othersRadioButton = new System.Windows.Forms.RadioButton();
            this.femaleRadioButton = new System.Windows.Forms.RadioButton();
            this.maleRadioButton = new System.Windows.Forms.RadioButton();
            this.userAddPhoneTextBox = new System.Windows.Forms.TextBox();
            this.userAddPasswordTextBox = new System.Windows.Forms.TextBox();
            this.userAddUsernameTextBox = new System.Windows.Forms.TextBox();
            this.userAddConfirmPasswordTextBox = new System.Windows.Forms.TextBox();
            this.userAddEmailTextBox = new System.Windows.Forms.TextBox();
            this.userAddNameTextBox = new System.Windows.Forms.TextBox();
            this.bgComboBox = new System.Windows.Forms.ComboBox();
            this.userTypeComboBox = new System.Windows.Forms.ComboBox();
            this.bunifuCustomLabel11 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bgLabel = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel9 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel6 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel8 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel7 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel4 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel5 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel3 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.searchUserButton = new Bunifu.Framework.UI.BunifuFlatButton();
            this.addUserButton = new Bunifu.Framework.UI.BunifuFlatButton();
            this.userSearchPanel = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.deleteButton = new Bunifu.Framework.UI.BunifuFlatButton();
            this.datePickerUserUpdate = new System.Windows.Forms.DateTimePicker();
            this.bunifuCustomLabel14 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.updateButton = new Bunifu.Framework.UI.BunifuFlatButton();
            this.othersUpdate = new System.Windows.Forms.RadioButton();
            this.femaleUpdate = new System.Windows.Forms.RadioButton();
            this.maleUpdate = new System.Windows.Forms.RadioButton();
            this.phoneUpdateTextBox = new System.Windows.Forms.TextBox();
            this.passwordUpdateTextBox = new System.Windows.Forms.TextBox();
            this.userNameUpdateTextBox = new System.Windows.Forms.TextBox();
            this.confirmPasswordUpdateTextBox = new System.Windows.Forms.TextBox();
            this.emailUpdateTextBox = new System.Windows.Forms.TextBox();
            this.nameUpdateTectBox = new System.Windows.Forms.TextBox();
            this.bgUpdateTextBox = new System.Windows.Forms.ComboBox();
            this.userTypeUpdateComboBox = new System.Windows.Forms.ComboBox();
            this.bunifuCustomLabel15 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel16 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel17 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel18 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel19 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel20 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel22 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel23 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel24 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.searchInUserSearchPanelButton = new Bunifu.Framework.UI.BunifuFlatButton();
            this.userSearchDataGrid = new Bunifu.Framework.UI.BunifuCustomDataGrid();
            this.idTextBoxSearch = new System.Windows.Forms.TextBox();
            this.nameTextBoxSearch = new System.Windows.Forms.TextBox();
            this.bunifuCustomLabel13 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel12 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.userTypeComboBoxSearch = new System.Windows.Forms.ComboBox();
            this.bunifuCustomLabel21 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.sectionButton = new Bunifu.Framework.UI.BunifuFlatButton();
            this.userButton = new Bunifu.Framework.UI.BunifuFlatButton();
            this.academicYearButton = new Bunifu.Framework.UI.BunifuFlatButton();
            this.academicYearPanel = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.academicYearTextBox = new WindowsFormsControlLibrary1.BunifuCustomTextbox();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.addAcademicYearButton = new Bunifu.Framework.UI.BunifuFlatButton();
            this.studentMenuButton = new Bunifu.Framework.UI.BunifuFlatButton();
            this.administratorsMenuButton = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BloodGroup = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Gender = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DOB = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.usersFullName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UserName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Email = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Password = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Phone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.attendancePanel = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.attendanceStudentPanel = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.attendanceStudentSectionComboBox = new System.Windows.Forms.ComboBox();
            this.label35 = new System.Windows.Forms.Label();
            this.attendanceStudentClassComboBox = new System.Windows.Forms.ComboBox();
            this.attendanceStudentSearchButton = new Bunifu.Framework.UI.BunifuFlatButton();
            this.label72 = new System.Windows.Forms.Label();
            this.attendanceStudentDataGrid = new System.Windows.Forms.DataGridView();
            this.attendanceStudentButton = new Bunifu.Framework.UI.BunifuFlatButton();
            this.tileBarPanel.SuspendLayout();
            this.menu.SuspendLayout();
            this.studentPanel.SuspendLayout();
            this.studentRegistrationPanel.SuspendLayout();
            this.studentRegistrationRegisterPanel.SuspendLayout();
            this.studentRegistrationSearchPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.studentRegistrationSearchDataGrid)).BeginInit();
            this.studentPromotionPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.administratorPanel.SuspendLayout();
            this.sectionPanel.SuspendLayout();
            this.sectionSearchPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sectionSearchDataGrid)).BeginInit();
            this.sectionAddPanel.SuspendLayout();
            this.userPanel.SuspendLayout();
            this.addUserPanel.SuspendLayout();
            this.userSearchPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.userSearchDataGrid)).BeginInit();
            this.academicYearPanel.SuspendLayout();
            this.attendancePanel.SuspendLayout();
            this.attendanceStudentPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.attendanceStudentDataGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 5;
            this.bunifuElipse1.TargetControl = this;
            // 
            // bunifuDragControl1
            // 
            this.bunifuDragControl1.Fixed = true;
            this.bunifuDragControl1.Horizontal = true;
            this.bunifuDragControl1.TargetControl = this.tileBarPanel;
            this.bunifuDragControl1.Vertical = true;
            // 
            // tileBarPanel
            // 
            this.tileBarPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.tileBarPanel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tileBarPanel.BackgroundImage")));
            this.tileBarPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tileBarPanel.Controls.Add(this.path);
            this.tileBarPanel.Controls.Add(this.crossButton);
            this.tileBarPanel.GradientBottomLeft = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.tileBarPanel.GradientBottomRight = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.tileBarPanel.GradientTopLeft = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.tileBarPanel.GradientTopRight = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.tileBarPanel.Location = new System.Drawing.Point(185, 0);
            this.tileBarPanel.Name = "tileBarPanel";
            this.tileBarPanel.Quality = 10;
            this.tileBarPanel.Size = new System.Drawing.Size(825, 20);
            this.tileBarPanel.TabIndex = 2;
            // 
            // path
            // 
            this.path.AutoSize = true;
            this.path.BackColor = System.Drawing.Color.White;
            this.path.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.path.Location = new System.Drawing.Point(2, 1);
            this.path.Name = "path";
            this.path.Size = new System.Drawing.Size(0, 17);
            this.path.TabIndex = 4;
            // 
            // crossButton
            // 
            this.crossButton.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.crossButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.crossButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.crossButton.BorderRadius = 0;
            this.crossButton.ButtonText = "";
            this.crossButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.crossButton.DisabledColor = System.Drawing.Color.Gray;
            this.crossButton.Iconcolor = System.Drawing.Color.Transparent;
            this.crossButton.Iconimage = ((System.Drawing.Image)(resources.GetObject("crossButton.Iconimage")));
            this.crossButton.Iconimage_right = null;
            this.crossButton.Iconimage_right_Selected = null;
            this.crossButton.Iconimage_Selected = null;
            this.crossButton.IconMarginLeft = 0;
            this.crossButton.IconMarginRight = 0;
            this.crossButton.IconRightVisible = true;
            this.crossButton.IconRightZoom = 0D;
            this.crossButton.IconVisible = true;
            this.crossButton.IconZoom = 90D;
            this.crossButton.IsTab = false;
            this.crossButton.Location = new System.Drawing.Point(803, 0);
            this.crossButton.Name = "crossButton";
            this.crossButton.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.crossButton.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.crossButton.OnHoverTextColor = System.Drawing.Color.White;
            this.crossButton.selected = false;
            this.crossButton.Size = new System.Drawing.Size(22, 20);
            this.crossButton.TabIndex = 0;
            this.crossButton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.crossButton.Textcolor = System.Drawing.Color.White;
            this.crossButton.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.crossButton.Click += new System.EventHandler(this.crossButton_Click);
            // 
            // menu
            // 
            this.menu.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("menu.BackgroundImage")));
            this.menu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.menu.Controls.Add(this.attendanceMenuButton);
            this.menu.Controls.Add(this.studentMenuButton);
            this.menu.Controls.Add(this.administratorsMenuButton);
            this.menu.Dock = System.Windows.Forms.DockStyle.Left;
            this.menu.GradientBottomLeft = System.Drawing.Color.DimGray;
            this.menu.GradientBottomRight = System.Drawing.Color.SlateBlue;
            this.menu.GradientTopLeft = System.Drawing.Color.Indigo;
            this.menu.GradientTopRight = System.Drawing.Color.Navy;
            this.menu.Location = new System.Drawing.Point(0, 0);
            this.menu.Name = "menu";
            this.menu.Quality = 10;
            this.menu.Size = new System.Drawing.Size(185, 489);
            this.menu.TabIndex = 0;
            // 
            // attendanceMenuButton
            // 
            this.attendanceMenuButton.Activecolor = System.Drawing.Color.Silver;
            this.attendanceMenuButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(48)))), ((int)(((byte)(146)))));
            this.attendanceMenuButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.attendanceMenuButton.BorderRadius = 0;
            this.attendanceMenuButton.ButtonText = "Attendance";
            this.attendanceMenuButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.attendanceMenuButton.DisabledColor = System.Drawing.Color.Gray;
            this.attendanceMenuButton.Iconcolor = System.Drawing.Color.Transparent;
            this.attendanceMenuButton.Iconimage = null;
            this.attendanceMenuButton.Iconimage_right = null;
            this.attendanceMenuButton.Iconimage_right_Selected = null;
            this.attendanceMenuButton.Iconimage_Selected = null;
            this.attendanceMenuButton.IconMarginLeft = 0;
            this.attendanceMenuButton.IconMarginRight = 0;
            this.attendanceMenuButton.IconRightVisible = true;
            this.attendanceMenuButton.IconRightZoom = 0D;
            this.attendanceMenuButton.IconVisible = true;
            this.attendanceMenuButton.IconZoom = 90D;
            this.attendanceMenuButton.IsTab = false;
            this.attendanceMenuButton.Location = new System.Drawing.Point(2, 180);
            this.attendanceMenuButton.Name = "attendanceMenuButton";
            this.attendanceMenuButton.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(48)))), ((int)(((byte)(146)))));
            this.attendanceMenuButton.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(48)))), ((int)(((byte)(146)))));
            this.attendanceMenuButton.OnHoverTextColor = System.Drawing.Color.White;
            this.attendanceMenuButton.selected = false;
            this.attendanceMenuButton.Size = new System.Drawing.Size(182, 33);
            this.attendanceMenuButton.TabIndex = 3;
            this.attendanceMenuButton.Text = "Attendance";
            this.attendanceMenuButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.attendanceMenuButton.Textcolor = System.Drawing.Color.White;
            this.attendanceMenuButton.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.attendanceMenuButton.Click += new System.EventHandler(this.attendanceMenuButton_Click);
            // 
            // studentPanel
            // 
            this.studentPanel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("studentPanel.BackgroundImage")));
            this.studentPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.studentPanel.Controls.Add(this.studentRegistrationPanel);
            this.studentPanel.Controls.Add(this.studentPromotionPanel);
            this.studentPanel.Controls.Add(this.studentPromotion);
            this.studentPanel.Controls.Add(this.studentRegistrationButton);
            this.studentPanel.GradientBottomLeft = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.studentPanel.GradientBottomRight = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.studentPanel.GradientTopLeft = System.Drawing.Color.White;
            this.studentPanel.GradientTopRight = System.Drawing.Color.White;
            this.studentPanel.Location = new System.Drawing.Point(205, 103);
            this.studentPanel.Name = "studentPanel";
            this.studentPanel.Quality = 10;
            this.studentPanel.Size = new System.Drawing.Size(67, 42);
            this.studentPanel.TabIndex = 2;
            this.studentPanel.Visible = false;
            // 
            // studentRegistrationPanel
            // 
            this.studentRegistrationPanel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("studentRegistrationPanel.BackgroundImage")));
            this.studentRegistrationPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.studentRegistrationPanel.Controls.Add(this.studentRegistrationRegisterPanel);
            this.studentRegistrationPanel.Controls.Add(this.studentRegistrationSearchPanel);
            this.studentRegistrationPanel.Controls.Add(this.studentRegistrationSearchButton);
            this.studentRegistrationPanel.Controls.Add(this.studentRegistrationRegisterButton);
            this.studentRegistrationPanel.GradientBottomLeft = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.studentRegistrationPanel.GradientBottomRight = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.studentRegistrationPanel.GradientTopLeft = System.Drawing.Color.White;
            this.studentRegistrationPanel.GradientTopRight = System.Drawing.Color.White;
            this.studentRegistrationPanel.Location = new System.Drawing.Point(14, 18);
            this.studentRegistrationPanel.Name = "studentRegistrationPanel";
            this.studentRegistrationPanel.Quality = 10;
            this.studentRegistrationPanel.Size = new System.Drawing.Size(107, 88);
            this.studentRegistrationPanel.TabIndex = 3;
            this.studentRegistrationPanel.Visible = false;
            // 
            // studentRegistrationRegisterPanel
            // 
            this.studentRegistrationRegisterPanel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("studentRegistrationRegisterPanel.BackgroundImage")));
            this.studentRegistrationRegisterPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.studentRegistrationRegisterPanel.Controls.Add(this.studentRegistrationRegisterSubmitButton);
            this.studentRegistrationRegisterPanel.Controls.Add(this.studentRegistrationRegisterDOB);
            this.studentRegistrationRegisterPanel.Controls.Add(this.studentRegistrationRegisterAdmissionDate);
            this.studentRegistrationRegisterPanel.Controls.Add(this.studentRegistrationRegisterDepartmentComboBox);
            this.studentRegistrationRegisterPanel.Controls.Add(this.label16);
            this.studentRegistrationRegisterPanel.Controls.Add(this.studentRegistrationRegisterSectionComboBox);
            this.studentRegistrationRegisterPanel.Controls.Add(this.studentRegistrationRegisterClassComboBox);
            this.studentRegistrationRegisterPanel.Controls.Add(this.studentRegistrationRegisterGenderComboBox);
            this.studentRegistrationRegisterPanel.Controls.Add(this.studentRegistrationRegisterAddressTextBox);
            this.studentRegistrationRegisterPanel.Controls.Add(this.studentRegistrationRegisterEmailTextBox);
            this.studentRegistrationRegisterPanel.Controls.Add(this.studentRegistrationRegisterPhoneTextBox);
            this.studentRegistrationRegisterPanel.Controls.Add(this.studentRegistrationRegisterMotherOccupationTextBox);
            this.studentRegistrationRegisterPanel.Controls.Add(this.studentRegistrationRegisterMotherNameTextBox);
            this.studentRegistrationRegisterPanel.Controls.Add(this.studentRegistrationRegisterFatherOccupationTextBox);
            this.studentRegistrationRegisterPanel.Controls.Add(this.studentRegistrationRegisterFatherNameTextBox);
            this.studentRegistrationRegisterPanel.Controls.Add(this.studentRegistrationRegisterNameTextBox);
            this.studentRegistrationRegisterPanel.Controls.Add(this.studentRegistrationRegisterAdmissionNumberTextBox);
            this.studentRegistrationRegisterPanel.Controls.Add(this.label15);
            this.studentRegistrationRegisterPanel.Controls.Add(this.label9);
            this.studentRegistrationRegisterPanel.Controls.Add(this.label10);
            this.studentRegistrationRegisterPanel.Controls.Add(this.label11);
            this.studentRegistrationRegisterPanel.Controls.Add(this.label12);
            this.studentRegistrationRegisterPanel.Controls.Add(this.label13);
            this.studentRegistrationRegisterPanel.Controls.Add(this.label14);
            this.studentRegistrationRegisterPanel.Controls.Add(this.label8);
            this.studentRegistrationRegisterPanel.Controls.Add(this.label7);
            this.studentRegistrationRegisterPanel.Controls.Add(this.label6);
            this.studentRegistrationRegisterPanel.Controls.Add(this.label5);
            this.studentRegistrationRegisterPanel.Controls.Add(this.label4);
            this.studentRegistrationRegisterPanel.Controls.Add(this.label3);
            this.studentRegistrationRegisterPanel.Controls.Add(this.label2);
            this.studentRegistrationRegisterPanel.Controls.Add(this.label1);
            this.studentRegistrationRegisterPanel.GradientBottomLeft = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.studentRegistrationRegisterPanel.GradientBottomRight = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.studentRegistrationRegisterPanel.GradientTopLeft = System.Drawing.Color.White;
            this.studentRegistrationRegisterPanel.GradientTopRight = System.Drawing.Color.White;
            this.studentRegistrationRegisterPanel.Location = new System.Drawing.Point(21, 52);
            this.studentRegistrationRegisterPanel.Name = "studentRegistrationRegisterPanel";
            this.studentRegistrationRegisterPanel.Quality = 10;
            this.studentRegistrationRegisterPanel.Size = new System.Drawing.Size(100, 92);
            this.studentRegistrationRegisterPanel.TabIndex = 4;
            this.studentRegistrationRegisterPanel.Visible = false;
            // 
            // studentRegistrationRegisterSubmitButton
            // 
            this.studentRegistrationRegisterSubmitButton.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.studentRegistrationRegisterSubmitButton.BackColor = System.Drawing.Color.Silver;
            this.studentRegistrationRegisterSubmitButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.studentRegistrationRegisterSubmitButton.BorderRadius = 7;
            this.studentRegistrationRegisterSubmitButton.ButtonText = "Submit";
            this.studentRegistrationRegisterSubmitButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.studentRegistrationRegisterSubmitButton.DisabledColor = System.Drawing.Color.DimGray;
            this.studentRegistrationRegisterSubmitButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.studentRegistrationRegisterSubmitButton.Iconcolor = System.Drawing.Color.Transparent;
            this.studentRegistrationRegisterSubmitButton.Iconimage = null;
            this.studentRegistrationRegisterSubmitButton.Iconimage_right = null;
            this.studentRegistrationRegisterSubmitButton.Iconimage_right_Selected = null;
            this.studentRegistrationRegisterSubmitButton.Iconimage_Selected = null;
            this.studentRegistrationRegisterSubmitButton.IconMarginLeft = 0;
            this.studentRegistrationRegisterSubmitButton.IconMarginRight = 0;
            this.studentRegistrationRegisterSubmitButton.IconRightVisible = false;
            this.studentRegistrationRegisterSubmitButton.IconRightZoom = 0D;
            this.studentRegistrationRegisterSubmitButton.IconVisible = true;
            this.studentRegistrationRegisterSubmitButton.IconZoom = 90D;
            this.studentRegistrationRegisterSubmitButton.IsTab = false;
            this.studentRegistrationRegisterSubmitButton.Location = new System.Drawing.Point(639, 350);
            this.studentRegistrationRegisterSubmitButton.Name = "studentRegistrationRegisterSubmitButton";
            this.studentRegistrationRegisterSubmitButton.Normalcolor = System.Drawing.Color.Silver;
            this.studentRegistrationRegisterSubmitButton.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.studentRegistrationRegisterSubmitButton.OnHoverTextColor = System.Drawing.Color.White;
            this.studentRegistrationRegisterSubmitButton.selected = false;
            this.studentRegistrationRegisterSubmitButton.Size = new System.Drawing.Size(128, 26);
            this.studentRegistrationRegisterSubmitButton.TabIndex = 26;
            this.studentRegistrationRegisterSubmitButton.Text = "Submit";
            this.studentRegistrationRegisterSubmitButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.studentRegistrationRegisterSubmitButton.Textcolor = System.Drawing.Color.Black;
            this.studentRegistrationRegisterSubmitButton.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // studentRegistrationRegisterDOB
            // 
            this.studentRegistrationRegisterDOB.Location = new System.Drawing.Point(495, 44);
            this.studentRegistrationRegisterDOB.Name = "studentRegistrationRegisterDOB";
            this.studentRegistrationRegisterDOB.Size = new System.Drawing.Size(154, 20);
            this.studentRegistrationRegisterDOB.TabIndex = 25;
            // 
            // studentRegistrationRegisterAdmissionDate
            // 
            this.studentRegistrationRegisterAdmissionDate.Location = new System.Drawing.Point(495, 17);
            this.studentRegistrationRegisterAdmissionDate.Name = "studentRegistrationRegisterAdmissionDate";
            this.studentRegistrationRegisterAdmissionDate.Size = new System.Drawing.Size(154, 20);
            this.studentRegistrationRegisterAdmissionDate.TabIndex = 24;
            // 
            // studentRegistrationRegisterDepartmentComboBox
            // 
            this.studentRegistrationRegisterDepartmentComboBox.FormattingEnabled = true;
            this.studentRegistrationRegisterDepartmentComboBox.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Others"});
            this.studentRegistrationRegisterDepartmentComboBox.Location = new System.Drawing.Point(135, 94);
            this.studentRegistrationRegisterDepartmentComboBox.Name = "studentRegistrationRegisterDepartmentComboBox";
            this.studentRegistrationRegisterDepartmentComboBox.Size = new System.Drawing.Size(151, 21);
            this.studentRegistrationRegisterDepartmentComboBox.TabIndex = 23;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(41, 95);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(72, 15);
            this.label16.TabIndex = 22;
            this.label16.Text = "Department";
            // 
            // studentRegistrationRegisterSectionComboBox
            // 
            this.studentRegistrationRegisterSectionComboBox.FormattingEnabled = true;
            this.studentRegistrationRegisterSectionComboBox.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Others"});
            this.studentRegistrationRegisterSectionComboBox.Location = new System.Drawing.Point(498, 105);
            this.studentRegistrationRegisterSectionComboBox.Name = "studentRegistrationRegisterSectionComboBox";
            this.studentRegistrationRegisterSectionComboBox.Size = new System.Drawing.Size(151, 21);
            this.studentRegistrationRegisterSectionComboBox.TabIndex = 21;
            // 
            // studentRegistrationRegisterClassComboBox
            // 
            this.studentRegistrationRegisterClassComboBox.FormattingEnabled = true;
            this.studentRegistrationRegisterClassComboBox.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Others"});
            this.studentRegistrationRegisterClassComboBox.Location = new System.Drawing.Point(498, 73);
            this.studentRegistrationRegisterClassComboBox.Name = "studentRegistrationRegisterClassComboBox";
            this.studentRegistrationRegisterClassComboBox.Size = new System.Drawing.Size(151, 21);
            this.studentRegistrationRegisterClassComboBox.TabIndex = 20;
            // 
            // studentRegistrationRegisterGenderComboBox
            // 
            this.studentRegistrationRegisterGenderComboBox.FormattingEnabled = true;
            this.studentRegistrationRegisterGenderComboBox.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Others"});
            this.studentRegistrationRegisterGenderComboBox.Location = new System.Drawing.Point(135, 64);
            this.studentRegistrationRegisterGenderComboBox.Name = "studentRegistrationRegisterGenderComboBox";
            this.studentRegistrationRegisterGenderComboBox.Size = new System.Drawing.Size(151, 21);
            this.studentRegistrationRegisterGenderComboBox.TabIndex = 18;
            // 
            // studentRegistrationRegisterAddressTextBox
            // 
            this.studentRegistrationRegisterAddressTextBox.Location = new System.Drawing.Point(135, 267);
            this.studentRegistrationRegisterAddressTextBox.Name = "studentRegistrationRegisterAddressTextBox";
            this.studentRegistrationRegisterAddressTextBox.Size = new System.Drawing.Size(545, 63);
            this.studentRegistrationRegisterAddressTextBox.TabIndex = 17;
            this.studentRegistrationRegisterAddressTextBox.Text = "";
            // 
            // studentRegistrationRegisterEmailTextBox
            // 
            this.studentRegistrationRegisterEmailTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationRegisterEmailTextBox.Location = new System.Drawing.Point(523, 226);
            this.studentRegistrationRegisterEmailTextBox.Name = "studentRegistrationRegisterEmailTextBox";
            this.studentRegistrationRegisterEmailTextBox.Size = new System.Drawing.Size(151, 20);
            this.studentRegistrationRegisterEmailTextBox.TabIndex = 16;
            // 
            // studentRegistrationRegisterPhoneTextBox
            // 
            this.studentRegistrationRegisterPhoneTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationRegisterPhoneTextBox.Location = new System.Drawing.Point(135, 221);
            this.studentRegistrationRegisterPhoneTextBox.Name = "studentRegistrationRegisterPhoneTextBox";
            this.studentRegistrationRegisterPhoneTextBox.Size = new System.Drawing.Size(151, 20);
            this.studentRegistrationRegisterPhoneTextBox.TabIndex = 16;
            // 
            // studentRegistrationRegisterMotherOccupationTextBox
            // 
            this.studentRegistrationRegisterMotherOccupationTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationRegisterMotherOccupationTextBox.Location = new System.Drawing.Point(523, 202);
            this.studentRegistrationRegisterMotherOccupationTextBox.Name = "studentRegistrationRegisterMotherOccupationTextBox";
            this.studentRegistrationRegisterMotherOccupationTextBox.Size = new System.Drawing.Size(151, 20);
            this.studentRegistrationRegisterMotherOccupationTextBox.TabIndex = 16;
            // 
            // studentRegistrationRegisterMotherNameTextBox
            // 
            this.studentRegistrationRegisterMotherNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationRegisterMotherNameTextBox.Location = new System.Drawing.Point(135, 197);
            this.studentRegistrationRegisterMotherNameTextBox.Name = "studentRegistrationRegisterMotherNameTextBox";
            this.studentRegistrationRegisterMotherNameTextBox.Size = new System.Drawing.Size(151, 20);
            this.studentRegistrationRegisterMotherNameTextBox.TabIndex = 16;
            // 
            // studentRegistrationRegisterFatherOccupationTextBox
            // 
            this.studentRegistrationRegisterFatherOccupationTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationRegisterFatherOccupationTextBox.Location = new System.Drawing.Point(523, 175);
            this.studentRegistrationRegisterFatherOccupationTextBox.Name = "studentRegistrationRegisterFatherOccupationTextBox";
            this.studentRegistrationRegisterFatherOccupationTextBox.Size = new System.Drawing.Size(151, 20);
            this.studentRegistrationRegisterFatherOccupationTextBox.TabIndex = 16;
            // 
            // studentRegistrationRegisterFatherNameTextBox
            // 
            this.studentRegistrationRegisterFatherNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationRegisterFatherNameTextBox.Location = new System.Drawing.Point(135, 170);
            this.studentRegistrationRegisterFatherNameTextBox.Name = "studentRegistrationRegisterFatherNameTextBox";
            this.studentRegistrationRegisterFatherNameTextBox.Size = new System.Drawing.Size(151, 20);
            this.studentRegistrationRegisterFatherNameTextBox.TabIndex = 16;
            // 
            // studentRegistrationRegisterNameTextBox
            // 
            this.studentRegistrationRegisterNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationRegisterNameTextBox.Location = new System.Drawing.Point(135, 39);
            this.studentRegistrationRegisterNameTextBox.Name = "studentRegistrationRegisterNameTextBox";
            this.studentRegistrationRegisterNameTextBox.Size = new System.Drawing.Size(151, 20);
            this.studentRegistrationRegisterNameTextBox.TabIndex = 16;
            // 
            // studentRegistrationRegisterAdmissionNumberTextBox
            // 
            this.studentRegistrationRegisterAdmissionNumberTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationRegisterAdmissionNumberTextBox.Location = new System.Drawing.Point(135, 13);
            this.studentRegistrationRegisterAdmissionNumberTextBox.Name = "studentRegistrationRegisterAdmissionNumberTextBox";
            this.studentRegistrationRegisterAdmissionNumberTextBox.Size = new System.Drawing.Size(151, 20);
            this.studentRegistrationRegisterAdmissionNumberTextBox.TabIndex = 15;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(57, 284);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(51, 15);
            this.label15.TabIndex = 14;
            this.label15.Text = "Address";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(392, 178);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(116, 15);
            this.label9.TabIndex = 13;
            this.label9.Text = "Father\'s Occupation";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(17, 198);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(92, 15);
            this.label10.TabIndex = 12;
            this.label10.Text = "Mother\'s Name";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(392, 204);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(120, 15);
            this.label11.TabIndex = 11;
            this.label11.Text = "Mother\'s Occupation";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(17, 221);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(91, 15);
            this.label12.TabIndex = 10;
            this.label12.Text = "Phone Number";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(392, 227);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(39, 15);
            this.label13.TabIndex = 9;
            this.label13.Text = "Email";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(17, 175);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(88, 15);
            this.label14.TabIndex = 8;
            this.label14.Text = "Father\'s Name";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(12, 141);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(791, 15);
            this.label8.TabIndex = 7;
            this.label8.Text = "Guardian Information ____________________________________________________________" +
    "___________________________________";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(379, 18);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(93, 15);
            this.label7.TabIndex = 6;
            this.label7.Text = "Admission Date";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(65, 41);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 15);
            this.label6.TabIndex = 5;
            this.label6.Text = "Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(395, 47);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 15);
            this.label5.TabIndex = 4;
            this.label5.Text = "Date Of Birth";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(61, 68);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "Gender";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(433, 79);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Class";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(426, 108);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Section";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(17, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Admission Number";
            // 
            // studentRegistrationSearchPanel
            // 
            this.studentRegistrationSearchPanel.AutoScroll = true;
            this.studentRegistrationSearchPanel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("studentRegistrationSearchPanel.BackgroundImage")));
            this.studentRegistrationSearchPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.studentRegistrationSearchPanel.Controls.Add(this.label34);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchSearchButton);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchIDTextBox);
            this.studentRegistrationSearchPanel.Controls.Add(this.label33);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchUpdateButton);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchDeleteButton);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchDOBUpdate);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchAdmissionDateUpdate);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchDepartmentUpdateComboBox);
            this.studentRegistrationSearchPanel.Controls.Add(this.label17);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchSectionUpdateComboBox);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchClassUpdateComboBox);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchGenderUpdateComboBox);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchAddressUpdateTextBox);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchEmailUpdateTextBox);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchPhoneUpdateTextBox);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchMotherOccupationUpdateTextBox);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchMotherNameUpdateTextBox);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchFatherOccupationUpdateTextBox);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchFatherNameUpdateTextBox);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchNameUpdateTextBox);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchAdmissionNumberUpdateTextBox);
            this.studentRegistrationSearchPanel.Controls.Add(this.label18);
            this.studentRegistrationSearchPanel.Controls.Add(this.label19);
            this.studentRegistrationSearchPanel.Controls.Add(this.label20);
            this.studentRegistrationSearchPanel.Controls.Add(this.label21);
            this.studentRegistrationSearchPanel.Controls.Add(this.label22);
            this.studentRegistrationSearchPanel.Controls.Add(this.label23);
            this.studentRegistrationSearchPanel.Controls.Add(this.label24);
            this.studentRegistrationSearchPanel.Controls.Add(this.label25);
            this.studentRegistrationSearchPanel.Controls.Add(this.label26);
            this.studentRegistrationSearchPanel.Controls.Add(this.label27);
            this.studentRegistrationSearchPanel.Controls.Add(this.label28);
            this.studentRegistrationSearchPanel.Controls.Add(this.label29);
            this.studentRegistrationSearchPanel.Controls.Add(this.label30);
            this.studentRegistrationSearchPanel.Controls.Add(this.label31);
            this.studentRegistrationSearchPanel.Controls.Add(this.label32);
            this.studentRegistrationSearchPanel.Controls.Add(this.studentRegistrationSearchDataGrid);
            this.studentRegistrationSearchPanel.GradientBottomLeft = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.studentRegistrationSearchPanel.GradientBottomRight = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.studentRegistrationSearchPanel.GradientTopLeft = System.Drawing.Color.White;
            this.studentRegistrationSearchPanel.GradientTopRight = System.Drawing.Color.White;
            this.studentRegistrationSearchPanel.Location = new System.Drawing.Point(160, 34);
            this.studentRegistrationSearchPanel.Name = "studentRegistrationSearchPanel";
            this.studentRegistrationSearchPanel.Quality = 10;
            this.studentRegistrationSearchPanel.Size = new System.Drawing.Size(353, 160);
            this.studentRegistrationSearchPanel.TabIndex = 5;
            this.studentRegistrationSearchPanel.Visible = false;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(181, 656);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(0, 15);
            this.label34.TabIndex = 63;
            // 
            // studentRegistrationSearchSearchButton
            // 
            this.studentRegistrationSearchSearchButton.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.studentRegistrationSearchSearchButton.BackColor = System.Drawing.Color.Silver;
            this.studentRegistrationSearchSearchButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.studentRegistrationSearchSearchButton.BorderRadius = 7;
            this.studentRegistrationSearchSearchButton.ButtonText = "Search";
            this.studentRegistrationSearchSearchButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.studentRegistrationSearchSearchButton.DisabledColor = System.Drawing.Color.DimGray;
            this.studentRegistrationSearchSearchButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.studentRegistrationSearchSearchButton.Iconcolor = System.Drawing.Color.Transparent;
            this.studentRegistrationSearchSearchButton.Iconimage = null;
            this.studentRegistrationSearchSearchButton.Iconimage_right = null;
            this.studentRegistrationSearchSearchButton.Iconimage_right_Selected = null;
            this.studentRegistrationSearchSearchButton.Iconimage_Selected = null;
            this.studentRegistrationSearchSearchButton.IconMarginLeft = 0;
            this.studentRegistrationSearchSearchButton.IconMarginRight = 0;
            this.studentRegistrationSearchSearchButton.IconRightVisible = false;
            this.studentRegistrationSearchSearchButton.IconRightZoom = 0D;
            this.studentRegistrationSearchSearchButton.IconVisible = true;
            this.studentRegistrationSearchSearchButton.IconZoom = 90D;
            this.studentRegistrationSearchSearchButton.IsTab = false;
            this.studentRegistrationSearchSearchButton.Location = new System.Drawing.Point(612, 25);
            this.studentRegistrationSearchSearchButton.Name = "studentRegistrationSearchSearchButton";
            this.studentRegistrationSearchSearchButton.Normalcolor = System.Drawing.Color.Silver;
            this.studentRegistrationSearchSearchButton.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.studentRegistrationSearchSearchButton.OnHoverTextColor = System.Drawing.Color.White;
            this.studentRegistrationSearchSearchButton.selected = false;
            this.studentRegistrationSearchSearchButton.Size = new System.Drawing.Size(128, 26);
            this.studentRegistrationSearchSearchButton.TabIndex = 62;
            this.studentRegistrationSearchSearchButton.Text = "Search";
            this.studentRegistrationSearchSearchButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.studentRegistrationSearchSearchButton.Textcolor = System.Drawing.Color.Black;
            this.studentRegistrationSearchSearchButton.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // studentRegistrationSearchIDTextBox
            // 
            this.studentRegistrationSearchIDTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationSearchIDTextBox.Location = new System.Drawing.Point(426, 30);
            this.studentRegistrationSearchIDTextBox.Name = "studentRegistrationSearchIDTextBox";
            this.studentRegistrationSearchIDTextBox.Size = new System.Drawing.Size(151, 20);
            this.studentRegistrationSearchIDTextBox.TabIndex = 61;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(351, 30);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(64, 15);
            this.label33.TabIndex = 60;
            this.label33.Text = "Student ID";
            // 
            // studentRegistrationSearchUpdateButton
            // 
            this.studentRegistrationSearchUpdateButton.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.studentRegistrationSearchUpdateButton.BackColor = System.Drawing.Color.Silver;
            this.studentRegistrationSearchUpdateButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.studentRegistrationSearchUpdateButton.BorderRadius = 7;
            this.studentRegistrationSearchUpdateButton.ButtonText = "Update";
            this.studentRegistrationSearchUpdateButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.studentRegistrationSearchUpdateButton.DisabledColor = System.Drawing.Color.DimGray;
            this.studentRegistrationSearchUpdateButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.studentRegistrationSearchUpdateButton.Iconcolor = System.Drawing.Color.Transparent;
            this.studentRegistrationSearchUpdateButton.Iconimage = null;
            this.studentRegistrationSearchUpdateButton.Iconimage_right = null;
            this.studentRegistrationSearchUpdateButton.Iconimage_right_Selected = null;
            this.studentRegistrationSearchUpdateButton.Iconimage_Selected = null;
            this.studentRegistrationSearchUpdateButton.IconMarginLeft = 0;
            this.studentRegistrationSearchUpdateButton.IconMarginRight = 0;
            this.studentRegistrationSearchUpdateButton.IconRightVisible = false;
            this.studentRegistrationSearchUpdateButton.IconRightZoom = 0D;
            this.studentRegistrationSearchUpdateButton.IconVisible = true;
            this.studentRegistrationSearchUpdateButton.IconZoom = 90D;
            this.studentRegistrationSearchUpdateButton.IsTab = false;
            this.studentRegistrationSearchUpdateButton.Location = new System.Drawing.Point(429, 619);
            this.studentRegistrationSearchUpdateButton.Name = "studentRegistrationSearchUpdateButton";
            this.studentRegistrationSearchUpdateButton.Normalcolor = System.Drawing.Color.Silver;
            this.studentRegistrationSearchUpdateButton.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.studentRegistrationSearchUpdateButton.OnHoverTextColor = System.Drawing.Color.White;
            this.studentRegistrationSearchUpdateButton.selected = false;
            this.studentRegistrationSearchUpdateButton.Size = new System.Drawing.Size(128, 26);
            this.studentRegistrationSearchUpdateButton.TabIndex = 59;
            this.studentRegistrationSearchUpdateButton.Text = "Update";
            this.studentRegistrationSearchUpdateButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.studentRegistrationSearchUpdateButton.Textcolor = System.Drawing.Color.Black;
            this.studentRegistrationSearchUpdateButton.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // studentRegistrationSearchDeleteButton
            // 
            this.studentRegistrationSearchDeleteButton.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.studentRegistrationSearchDeleteButton.BackColor = System.Drawing.Color.Silver;
            this.studentRegistrationSearchDeleteButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.studentRegistrationSearchDeleteButton.BorderRadius = 7;
            this.studentRegistrationSearchDeleteButton.ButtonText = "Delete";
            this.studentRegistrationSearchDeleteButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.studentRegistrationSearchDeleteButton.DisabledColor = System.Drawing.Color.DimGray;
            this.studentRegistrationSearchDeleteButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.studentRegistrationSearchDeleteButton.Iconcolor = System.Drawing.Color.Transparent;
            this.studentRegistrationSearchDeleteButton.Iconimage = null;
            this.studentRegistrationSearchDeleteButton.Iconimage_right = null;
            this.studentRegistrationSearchDeleteButton.Iconimage_right_Selected = null;
            this.studentRegistrationSearchDeleteButton.Iconimage_Selected = null;
            this.studentRegistrationSearchDeleteButton.IconMarginLeft = 0;
            this.studentRegistrationSearchDeleteButton.IconMarginRight = 0;
            this.studentRegistrationSearchDeleteButton.IconRightVisible = false;
            this.studentRegistrationSearchDeleteButton.IconRightZoom = 0D;
            this.studentRegistrationSearchDeleteButton.IconVisible = true;
            this.studentRegistrationSearchDeleteButton.IconZoom = 90D;
            this.studentRegistrationSearchDeleteButton.IsTab = false;
            this.studentRegistrationSearchDeleteButton.Location = new System.Drawing.Point(583, 619);
            this.studentRegistrationSearchDeleteButton.Name = "studentRegistrationSearchDeleteButton";
            this.studentRegistrationSearchDeleteButton.Normalcolor = System.Drawing.Color.Silver;
            this.studentRegistrationSearchDeleteButton.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.studentRegistrationSearchDeleteButton.OnHoverTextColor = System.Drawing.Color.White;
            this.studentRegistrationSearchDeleteButton.selected = false;
            this.studentRegistrationSearchDeleteButton.Size = new System.Drawing.Size(128, 26);
            this.studentRegistrationSearchDeleteButton.TabIndex = 58;
            this.studentRegistrationSearchDeleteButton.Text = "Delete";
            this.studentRegistrationSearchDeleteButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.studentRegistrationSearchDeleteButton.Textcolor = System.Drawing.Color.Black;
            this.studentRegistrationSearchDeleteButton.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // studentRegistrationSearchDOBUpdate
            // 
            this.studentRegistrationSearchDOBUpdate.Location = new System.Drawing.Point(504, 368);
            this.studentRegistrationSearchDOBUpdate.Name = "studentRegistrationSearchDOBUpdate";
            this.studentRegistrationSearchDOBUpdate.Size = new System.Drawing.Size(154, 20);
            this.studentRegistrationSearchDOBUpdate.TabIndex = 57;
            // 
            // studentRegistrationSearchAdmissionDateUpdate
            // 
            this.studentRegistrationSearchAdmissionDateUpdate.Location = new System.Drawing.Point(504, 341);
            this.studentRegistrationSearchAdmissionDateUpdate.Name = "studentRegistrationSearchAdmissionDateUpdate";
            this.studentRegistrationSearchAdmissionDateUpdate.Size = new System.Drawing.Size(154, 20);
            this.studentRegistrationSearchAdmissionDateUpdate.TabIndex = 56;
            // 
            // studentRegistrationSearchDepartmentUpdateComboBox
            // 
            this.studentRegistrationSearchDepartmentUpdateComboBox.FormattingEnabled = true;
            this.studentRegistrationSearchDepartmentUpdateComboBox.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Others"});
            this.studentRegistrationSearchDepartmentUpdateComboBox.Location = new System.Drawing.Point(144, 418);
            this.studentRegistrationSearchDepartmentUpdateComboBox.Name = "studentRegistrationSearchDepartmentUpdateComboBox";
            this.studentRegistrationSearchDepartmentUpdateComboBox.Size = new System.Drawing.Size(151, 21);
            this.studentRegistrationSearchDepartmentUpdateComboBox.TabIndex = 55;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(50, 419);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(72, 15);
            this.label17.TabIndex = 54;
            this.label17.Text = "Department";
            // 
            // studentRegistrationSearchSectionUpdateComboBox
            // 
            this.studentRegistrationSearchSectionUpdateComboBox.FormattingEnabled = true;
            this.studentRegistrationSearchSectionUpdateComboBox.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Others"});
            this.studentRegistrationSearchSectionUpdateComboBox.Location = new System.Drawing.Point(507, 429);
            this.studentRegistrationSearchSectionUpdateComboBox.Name = "studentRegistrationSearchSectionUpdateComboBox";
            this.studentRegistrationSearchSectionUpdateComboBox.Size = new System.Drawing.Size(151, 21);
            this.studentRegistrationSearchSectionUpdateComboBox.TabIndex = 53;
            // 
            // studentRegistrationSearchClassUpdateComboBox
            // 
            this.studentRegistrationSearchClassUpdateComboBox.FormattingEnabled = true;
            this.studentRegistrationSearchClassUpdateComboBox.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Others"});
            this.studentRegistrationSearchClassUpdateComboBox.Location = new System.Drawing.Point(507, 397);
            this.studentRegistrationSearchClassUpdateComboBox.Name = "studentRegistrationSearchClassUpdateComboBox";
            this.studentRegistrationSearchClassUpdateComboBox.Size = new System.Drawing.Size(151, 21);
            this.studentRegistrationSearchClassUpdateComboBox.TabIndex = 52;
            // 
            // studentRegistrationSearchGenderUpdateComboBox
            // 
            this.studentRegistrationSearchGenderUpdateComboBox.FormattingEnabled = true;
            this.studentRegistrationSearchGenderUpdateComboBox.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Others"});
            this.studentRegistrationSearchGenderUpdateComboBox.Location = new System.Drawing.Point(144, 388);
            this.studentRegistrationSearchGenderUpdateComboBox.Name = "studentRegistrationSearchGenderUpdateComboBox";
            this.studentRegistrationSearchGenderUpdateComboBox.Size = new System.Drawing.Size(151, 21);
            this.studentRegistrationSearchGenderUpdateComboBox.TabIndex = 51;
            // 
            // studentRegistrationSearchAddressUpdateTextBox
            // 
            this.studentRegistrationSearchAddressUpdateTextBox.Location = new System.Drawing.Point(123, 591);
            this.studentRegistrationSearchAddressUpdateTextBox.Name = "studentRegistrationSearchAddressUpdateTextBox";
            this.studentRegistrationSearchAddressUpdateTextBox.Size = new System.Drawing.Size(262, 63);
            this.studentRegistrationSearchAddressUpdateTextBox.TabIndex = 50;
            this.studentRegistrationSearchAddressUpdateTextBox.Text = "";
            // 
            // studentRegistrationSearchEmailUpdateTextBox
            // 
            this.studentRegistrationSearchEmailUpdateTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationSearchEmailUpdateTextBox.Location = new System.Drawing.Point(532, 550);
            this.studentRegistrationSearchEmailUpdateTextBox.Name = "studentRegistrationSearchEmailUpdateTextBox";
            this.studentRegistrationSearchEmailUpdateTextBox.Size = new System.Drawing.Size(151, 20);
            this.studentRegistrationSearchEmailUpdateTextBox.TabIndex = 48;
            // 
            // studentRegistrationSearchPhoneUpdateTextBox
            // 
            this.studentRegistrationSearchPhoneUpdateTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationSearchPhoneUpdateTextBox.Location = new System.Drawing.Point(144, 545);
            this.studentRegistrationSearchPhoneUpdateTextBox.Name = "studentRegistrationSearchPhoneUpdateTextBox";
            this.studentRegistrationSearchPhoneUpdateTextBox.Size = new System.Drawing.Size(151, 20);
            this.studentRegistrationSearchPhoneUpdateTextBox.TabIndex = 47;
            // 
            // studentRegistrationSearchMotherOccupationUpdateTextBox
            // 
            this.studentRegistrationSearchMotherOccupationUpdateTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationSearchMotherOccupationUpdateTextBox.Location = new System.Drawing.Point(532, 526);
            this.studentRegistrationSearchMotherOccupationUpdateTextBox.Name = "studentRegistrationSearchMotherOccupationUpdateTextBox";
            this.studentRegistrationSearchMotherOccupationUpdateTextBox.Size = new System.Drawing.Size(151, 20);
            this.studentRegistrationSearchMotherOccupationUpdateTextBox.TabIndex = 46;
            // 
            // studentRegistrationSearchMotherNameUpdateTextBox
            // 
            this.studentRegistrationSearchMotherNameUpdateTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationSearchMotherNameUpdateTextBox.Location = new System.Drawing.Point(144, 521);
            this.studentRegistrationSearchMotherNameUpdateTextBox.Name = "studentRegistrationSearchMotherNameUpdateTextBox";
            this.studentRegistrationSearchMotherNameUpdateTextBox.Size = new System.Drawing.Size(151, 20);
            this.studentRegistrationSearchMotherNameUpdateTextBox.TabIndex = 45;
            // 
            // studentRegistrationSearchFatherOccupationUpdateTextBox
            // 
            this.studentRegistrationSearchFatherOccupationUpdateTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationSearchFatherOccupationUpdateTextBox.Location = new System.Drawing.Point(532, 499);
            this.studentRegistrationSearchFatherOccupationUpdateTextBox.Name = "studentRegistrationSearchFatherOccupationUpdateTextBox";
            this.studentRegistrationSearchFatherOccupationUpdateTextBox.Size = new System.Drawing.Size(151, 20);
            this.studentRegistrationSearchFatherOccupationUpdateTextBox.TabIndex = 44;
            // 
            // studentRegistrationSearchFatherNameUpdateTextBox
            // 
            this.studentRegistrationSearchFatherNameUpdateTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationSearchFatherNameUpdateTextBox.Location = new System.Drawing.Point(144, 494);
            this.studentRegistrationSearchFatherNameUpdateTextBox.Name = "studentRegistrationSearchFatherNameUpdateTextBox";
            this.studentRegistrationSearchFatherNameUpdateTextBox.Size = new System.Drawing.Size(151, 20);
            this.studentRegistrationSearchFatherNameUpdateTextBox.TabIndex = 49;
            // 
            // studentRegistrationSearchNameUpdateTextBox
            // 
            this.studentRegistrationSearchNameUpdateTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationSearchNameUpdateTextBox.Location = new System.Drawing.Point(144, 363);
            this.studentRegistrationSearchNameUpdateTextBox.Name = "studentRegistrationSearchNameUpdateTextBox";
            this.studentRegistrationSearchNameUpdateTextBox.Size = new System.Drawing.Size(151, 20);
            this.studentRegistrationSearchNameUpdateTextBox.TabIndex = 43;
            // 
            // studentRegistrationSearchAdmissionNumberUpdateTextBox
            // 
            this.studentRegistrationSearchAdmissionNumberUpdateTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationSearchAdmissionNumberUpdateTextBox.Location = new System.Drawing.Point(144, 337);
            this.studentRegistrationSearchAdmissionNumberUpdateTextBox.Name = "studentRegistrationSearchAdmissionNumberUpdateTextBox";
            this.studentRegistrationSearchAdmissionNumberUpdateTextBox.Size = new System.Drawing.Size(151, 20);
            this.studentRegistrationSearchAdmissionNumberUpdateTextBox.TabIndex = 42;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(66, 608);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(51, 15);
            this.label18.TabIndex = 41;
            this.label18.Text = "Address";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(401, 502);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(116, 15);
            this.label19.TabIndex = 40;
            this.label19.Text = "Father\'s Occupation";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(26, 522);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(92, 15);
            this.label20.TabIndex = 39;
            this.label20.Text = "Mother\'s Name";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(401, 528);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(120, 15);
            this.label21.TabIndex = 38;
            this.label21.Text = "Mother\'s Occupation";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(26, 545);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(91, 15);
            this.label22.TabIndex = 37;
            this.label22.Text = "Phone Number";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(401, 551);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(39, 15);
            this.label23.TabIndex = 36;
            this.label23.Text = "Email";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(26, 499);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(88, 15);
            this.label24.TabIndex = 35;
            this.label24.Text = "Father\'s Name";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(21, 465);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(791, 15);
            this.label25.TabIndex = 34;
            this.label25.Text = "Guardian Information ____________________________________________________________" +
    "___________________________________";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(388, 342);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(93, 15);
            this.label26.TabIndex = 33;
            this.label26.Text = "Admission Date";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(74, 365);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(41, 15);
            this.label27.TabIndex = 32;
            this.label27.Text = "Name";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(404, 371);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(76, 15);
            this.label28.TabIndex = 31;
            this.label28.Text = "Date Of Birth";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(70, 392);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(48, 15);
            this.label29.TabIndex = 30;
            this.label29.Text = "Gender";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(442, 403);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(37, 15);
            this.label30.TabIndex = 29;
            this.label30.Text = "Class";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(435, 432);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(48, 15);
            this.label31.TabIndex = 28;
            this.label31.Text = "Section";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(26, 339);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(112, 15);
            this.label32.TabIndex = 27;
            this.label32.Text = "Admission Number";
            // 
            // studentRegistrationSearchDataGrid
            // 
            this.studentRegistrationSearchDataGrid.AllowUserToAddRows = false;
            this.studentRegistrationSearchDataGrid.AllowUserToDeleteRows = false;
            this.studentRegistrationSearchDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.studentRegistrationSearchDataGrid.Location = new System.Drawing.Point(14, 76);
            this.studentRegistrationSearchDataGrid.Name = "studentRegistrationSearchDataGrid";
            this.studentRegistrationSearchDataGrid.ReadOnly = true;
            this.studentRegistrationSearchDataGrid.Size = new System.Drawing.Size(747, 236);
            this.studentRegistrationSearchDataGrid.TabIndex = 0;
            // 
            // studentRegistrationSearchButton
            // 
            this.studentRegistrationSearchButton.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.studentRegistrationSearchButton.BackColor = System.Drawing.Color.Silver;
            this.studentRegistrationSearchButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.studentRegistrationSearchButton.BorderRadius = 7;
            this.studentRegistrationSearchButton.ButtonText = "Search";
            this.studentRegistrationSearchButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.studentRegistrationSearchButton.DisabledColor = System.Drawing.Color.DimGray;
            this.studentRegistrationSearchButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.studentRegistrationSearchButton.Iconcolor = System.Drawing.Color.Transparent;
            this.studentRegistrationSearchButton.Iconimage = null;
            this.studentRegistrationSearchButton.Iconimage_right = null;
            this.studentRegistrationSearchButton.Iconimage_right_Selected = null;
            this.studentRegistrationSearchButton.Iconimage_Selected = null;
            this.studentRegistrationSearchButton.IconMarginLeft = 0;
            this.studentRegistrationSearchButton.IconMarginRight = 0;
            this.studentRegistrationSearchButton.IconRightVisible = false;
            this.studentRegistrationSearchButton.IconRightZoom = 0D;
            this.studentRegistrationSearchButton.IconVisible = true;
            this.studentRegistrationSearchButton.IconZoom = 90D;
            this.studentRegistrationSearchButton.IsTab = false;
            this.studentRegistrationSearchButton.Location = new System.Drawing.Point(129, 2);
            this.studentRegistrationSearchButton.Name = "studentRegistrationSearchButton";
            this.studentRegistrationSearchButton.Normalcolor = System.Drawing.Color.Silver;
            this.studentRegistrationSearchButton.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.studentRegistrationSearchButton.OnHoverTextColor = System.Drawing.Color.White;
            this.studentRegistrationSearchButton.selected = false;
            this.studentRegistrationSearchButton.Size = new System.Drawing.Size(128, 26);
            this.studentRegistrationSearchButton.TabIndex = 2;
            this.studentRegistrationSearchButton.Text = "Search";
            this.studentRegistrationSearchButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.studentRegistrationSearchButton.Textcolor = System.Drawing.Color.Black;
            this.studentRegistrationSearchButton.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationSearchButton.Click += new System.EventHandler(this.studentRegistrationSearchButton_Click);
            // 
            // studentRegistrationRegisterButton
            // 
            this.studentRegistrationRegisterButton.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.studentRegistrationRegisterButton.BackColor = System.Drawing.Color.Silver;
            this.studentRegistrationRegisterButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.studentRegistrationRegisterButton.BorderRadius = 7;
            this.studentRegistrationRegisterButton.ButtonText = "Register";
            this.studentRegistrationRegisterButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.studentRegistrationRegisterButton.DisabledColor = System.Drawing.Color.DimGray;
            this.studentRegistrationRegisterButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.studentRegistrationRegisterButton.Iconcolor = System.Drawing.Color.Transparent;
            this.studentRegistrationRegisterButton.Iconimage = null;
            this.studentRegistrationRegisterButton.Iconimage_right = null;
            this.studentRegistrationRegisterButton.Iconimage_right_Selected = null;
            this.studentRegistrationRegisterButton.Iconimage_Selected = null;
            this.studentRegistrationRegisterButton.IconMarginLeft = 0;
            this.studentRegistrationRegisterButton.IconMarginRight = 0;
            this.studentRegistrationRegisterButton.IconRightVisible = false;
            this.studentRegistrationRegisterButton.IconRightZoom = 0D;
            this.studentRegistrationRegisterButton.IconVisible = true;
            this.studentRegistrationRegisterButton.IconZoom = 90D;
            this.studentRegistrationRegisterButton.IsTab = false;
            this.studentRegistrationRegisterButton.Location = new System.Drawing.Point(0, 2);
            this.studentRegistrationRegisterButton.Name = "studentRegistrationRegisterButton";
            this.studentRegistrationRegisterButton.Normalcolor = System.Drawing.Color.Silver;
            this.studentRegistrationRegisterButton.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.studentRegistrationRegisterButton.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.studentRegistrationRegisterButton.selected = false;
            this.studentRegistrationRegisterButton.Size = new System.Drawing.Size(128, 26);
            this.studentRegistrationRegisterButton.TabIndex = 1;
            this.studentRegistrationRegisterButton.Text = "Register";
            this.studentRegistrationRegisterButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.studentRegistrationRegisterButton.Textcolor = System.Drawing.Color.Black;
            this.studentRegistrationRegisterButton.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationRegisterButton.Click += new System.EventHandler(this.studentRegistrationRegisterButton_Click);
            // 
            // studentPromotionPanel
            // 
            this.studentPromotionPanel.AutoScroll = true;
            this.studentPromotionPanel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("studentPromotionPanel.BackgroundImage")));
            this.studentPromotionPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.studentPromotionPanel.Controls.Add(this.studentPromotionClassUpdateComboBox);
            this.studentPromotionPanel.Controls.Add(this.label64);
            this.studentPromotionPanel.Controls.Add(this.studentPromotionClassComboBox);
            this.studentPromotionPanel.Controls.Add(this.studentPromotionSearchButton);
            this.studentPromotionPanel.Controls.Add(this.label50);
            this.studentPromotionPanel.Controls.Add(this.studentPromotionPromoteButton);
            this.studentPromotionPanel.Controls.Add(this.dataGridView1);
            this.studentPromotionPanel.GradientBottomLeft = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.studentPromotionPanel.GradientBottomRight = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.studentPromotionPanel.GradientTopLeft = System.Drawing.Color.White;
            this.studentPromotionPanel.GradientTopRight = System.Drawing.Color.White;
            this.studentPromotionPanel.Location = new System.Drawing.Point(181, 22);
            this.studentPromotionPanel.Name = "studentPromotionPanel";
            this.studentPromotionPanel.Quality = 10;
            this.studentPromotionPanel.Size = new System.Drawing.Size(110, 90);
            this.studentPromotionPanel.TabIndex = 6;
            this.studentPromotionPanel.Visible = false;
            // 
            // studentPromotionClassUpdateComboBox
            // 
            this.studentPromotionClassUpdateComboBox.FormattingEnabled = true;
            this.studentPromotionClassUpdateComboBox.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Others"});
            this.studentPromotionClassUpdateComboBox.Location = new System.Drawing.Point(337, 379);
            this.studentPromotionClassUpdateComboBox.Name = "studentPromotionClassUpdateComboBox";
            this.studentPromotionClassUpdateComboBox.Size = new System.Drawing.Size(151, 21);
            this.studentPromotionClassUpdateComboBox.TabIndex = 65;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.Location = new System.Drawing.Point(272, 385);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(37, 15);
            this.label64.TabIndex = 64;
            this.label64.Text = "Class";
            // 
            // studentPromotionClassComboBox
            // 
            this.studentPromotionClassComboBox.FormattingEnabled = true;
            this.studentPromotionClassComboBox.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Others"});
            this.studentPromotionClassComboBox.Location = new System.Drawing.Point(409, 30);
            this.studentPromotionClassComboBox.Name = "studentPromotionClassComboBox";
            this.studentPromotionClassComboBox.Size = new System.Drawing.Size(151, 21);
            this.studentPromotionClassComboBox.TabIndex = 63;
            // 
            // studentPromotionSearchButton
            // 
            this.studentPromotionSearchButton.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.studentPromotionSearchButton.BackColor = System.Drawing.Color.Silver;
            this.studentPromotionSearchButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.studentPromotionSearchButton.BorderRadius = 7;
            this.studentPromotionSearchButton.ButtonText = "Search";
            this.studentPromotionSearchButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.studentPromotionSearchButton.DisabledColor = System.Drawing.Color.DimGray;
            this.studentPromotionSearchButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.studentPromotionSearchButton.Iconcolor = System.Drawing.Color.Transparent;
            this.studentPromotionSearchButton.Iconimage = null;
            this.studentPromotionSearchButton.Iconimage_right = null;
            this.studentPromotionSearchButton.Iconimage_right_Selected = null;
            this.studentPromotionSearchButton.Iconimage_Selected = null;
            this.studentPromotionSearchButton.IconMarginLeft = 0;
            this.studentPromotionSearchButton.IconMarginRight = 0;
            this.studentPromotionSearchButton.IconRightVisible = false;
            this.studentPromotionSearchButton.IconRightZoom = 0D;
            this.studentPromotionSearchButton.IconVisible = true;
            this.studentPromotionSearchButton.IconZoom = 90D;
            this.studentPromotionSearchButton.IsTab = false;
            this.studentPromotionSearchButton.Location = new System.Drawing.Point(612, 25);
            this.studentPromotionSearchButton.Name = "studentPromotionSearchButton";
            this.studentPromotionSearchButton.Normalcolor = System.Drawing.Color.Silver;
            this.studentPromotionSearchButton.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.studentPromotionSearchButton.OnHoverTextColor = System.Drawing.Color.White;
            this.studentPromotionSearchButton.selected = false;
            this.studentPromotionSearchButton.Size = new System.Drawing.Size(128, 26);
            this.studentPromotionSearchButton.TabIndex = 62;
            this.studentPromotionSearchButton.Text = "Search";
            this.studentPromotionSearchButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.studentPromotionSearchButton.Textcolor = System.Drawing.Color.Black;
            this.studentPromotionSearchButton.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(329, 33);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(74, 15);
            this.label50.TabIndex = 60;
            this.label50.Text = "Class Name";
            // 
            // studentPromotionPromoteButton
            // 
            this.studentPromotionPromoteButton.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.studentPromotionPromoteButton.BackColor = System.Drawing.Color.Silver;
            this.studentPromotionPromoteButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.studentPromotionPromoteButton.BorderRadius = 7;
            this.studentPromotionPromoteButton.ButtonText = "Promote";
            this.studentPromotionPromoteButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.studentPromotionPromoteButton.DisabledColor = System.Drawing.Color.DimGray;
            this.studentPromotionPromoteButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.studentPromotionPromoteButton.Iconcolor = System.Drawing.Color.Transparent;
            this.studentPromotionPromoteButton.Iconimage = null;
            this.studentPromotionPromoteButton.Iconimage_right = null;
            this.studentPromotionPromoteButton.Iconimage_right_Selected = null;
            this.studentPromotionPromoteButton.Iconimage_Selected = null;
            this.studentPromotionPromoteButton.IconMarginLeft = 0;
            this.studentPromotionPromoteButton.IconMarginRight = 0;
            this.studentPromotionPromoteButton.IconRightVisible = false;
            this.studentPromotionPromoteButton.IconRightZoom = 0D;
            this.studentPromotionPromoteButton.IconVisible = true;
            this.studentPromotionPromoteButton.IconZoom = 90D;
            this.studentPromotionPromoteButton.IsTab = false;
            this.studentPromotionPromoteButton.Location = new System.Drawing.Point(549, 378);
            this.studentPromotionPromoteButton.Name = "studentPromotionPromoteButton";
            this.studentPromotionPromoteButton.Normalcolor = System.Drawing.Color.Silver;
            this.studentPromotionPromoteButton.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.studentPromotionPromoteButton.OnHoverTextColor = System.Drawing.Color.White;
            this.studentPromotionPromoteButton.selected = false;
            this.studentPromotionPromoteButton.Size = new System.Drawing.Size(128, 26);
            this.studentPromotionPromoteButton.TabIndex = 58;
            this.studentPromotionPromoteButton.Text = "Promote";
            this.studentPromotionPromoteButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.studentPromotionPromoteButton.Textcolor = System.Drawing.Color.Black;
            this.studentPromotionPromoteButton.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(14, 76);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(747, 236);
            this.dataGridView1.TabIndex = 0;
            // 
            // studentPromotion
            // 
            this.studentPromotion.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.studentPromotion.BackColor = System.Drawing.Color.Silver;
            this.studentPromotion.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.studentPromotion.BorderRadius = 7;
            this.studentPromotion.ButtonText = "Promotion";
            this.studentPromotion.Cursor = System.Windows.Forms.Cursors.Default;
            this.studentPromotion.DisabledColor = System.Drawing.Color.DimGray;
            this.studentPromotion.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.studentPromotion.Iconcolor = System.Drawing.Color.Transparent;
            this.studentPromotion.Iconimage = null;
            this.studentPromotion.Iconimage_right = null;
            this.studentPromotion.Iconimage_right_Selected = null;
            this.studentPromotion.Iconimage_Selected = null;
            this.studentPromotion.IconMarginLeft = 0;
            this.studentPromotion.IconMarginRight = 0;
            this.studentPromotion.IconRightVisible = false;
            this.studentPromotion.IconRightZoom = 0D;
            this.studentPromotion.IconVisible = true;
            this.studentPromotion.IconZoom = 90D;
            this.studentPromotion.IsTab = false;
            this.studentPromotion.Location = new System.Drawing.Point(693, 2);
            this.studentPromotion.Name = "studentPromotion";
            this.studentPromotion.Normalcolor = System.Drawing.Color.Silver;
            this.studentPromotion.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.studentPromotion.OnHoverTextColor = System.Drawing.Color.White;
            this.studentPromotion.selected = false;
            this.studentPromotion.Size = new System.Drawing.Size(128, 26);
            this.studentPromotion.TabIndex = 2;
            this.studentPromotion.Text = "Promotion";
            this.studentPromotion.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.studentPromotion.Textcolor = System.Drawing.Color.Black;
            this.studentPromotion.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentPromotion.Click += new System.EventHandler(this.studentPromotion_Click);
            // 
            // studentRegistrationButton
            // 
            this.studentRegistrationButton.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.studentRegistrationButton.BackColor = System.Drawing.Color.Silver;
            this.studentRegistrationButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.studentRegistrationButton.BorderRadius = 7;
            this.studentRegistrationButton.ButtonText = "Registration";
            this.studentRegistrationButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.studentRegistrationButton.DisabledColor = System.Drawing.Color.DimGray;
            this.studentRegistrationButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.studentRegistrationButton.Iconcolor = System.Drawing.Color.Transparent;
            this.studentRegistrationButton.Iconimage = null;
            this.studentRegistrationButton.Iconimage_right = null;
            this.studentRegistrationButton.Iconimage_right_Selected = null;
            this.studentRegistrationButton.Iconimage_Selected = null;
            this.studentRegistrationButton.IconMarginLeft = 0;
            this.studentRegistrationButton.IconMarginRight = 0;
            this.studentRegistrationButton.IconRightVisible = false;
            this.studentRegistrationButton.IconRightZoom = 0D;
            this.studentRegistrationButton.IconVisible = true;
            this.studentRegistrationButton.IconZoom = 90D;
            this.studentRegistrationButton.IsTab = false;
            this.studentRegistrationButton.Location = new System.Drawing.Point(561, 2);
            this.studentRegistrationButton.Name = "studentRegistrationButton";
            this.studentRegistrationButton.Normalcolor = System.Drawing.Color.Silver;
            this.studentRegistrationButton.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.studentRegistrationButton.OnHoverTextColor = System.Drawing.Color.White;
            this.studentRegistrationButton.selected = false;
            this.studentRegistrationButton.Size = new System.Drawing.Size(128, 26);
            this.studentRegistrationButton.TabIndex = 1;
            this.studentRegistrationButton.Text = "Registration";
            this.studentRegistrationButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.studentRegistrationButton.Textcolor = System.Drawing.Color.Black;
            this.studentRegistrationButton.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRegistrationButton.Click += new System.EventHandler(this.studentRegistrationButton_Click);
            // 
            // administratorPanel
            // 
            this.administratorPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.administratorPanel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("administratorPanel.BackgroundImage")));
            this.administratorPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.administratorPanel.Controls.Add(this.sectionPanel);
            this.administratorPanel.Controls.Add(this.userPanel);
            this.administratorPanel.Controls.Add(this.sectionButton);
            this.administratorPanel.Controls.Add(this.userButton);
            this.administratorPanel.Controls.Add(this.academicYearButton);
            this.administratorPanel.Controls.Add(this.academicYearPanel);
            this.administratorPanel.GradientBottomLeft = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.administratorPanel.GradientBottomRight = System.Drawing.Color.White;
            this.administratorPanel.GradientTopLeft = System.Drawing.Color.White;
            this.administratorPanel.GradientTopRight = System.Drawing.Color.White;
            this.administratorPanel.Location = new System.Drawing.Point(219, 31);
            this.administratorPanel.Name = "administratorPanel";
            this.administratorPanel.Quality = 10;
            this.administratorPanel.Size = new System.Drawing.Size(66, 66);
            this.administratorPanel.TabIndex = 1;
            this.administratorPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.administratorPanel_Paint);
            // 
            // sectionPanel
            // 
            this.sectionPanel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("sectionPanel.BackgroundImage")));
            this.sectionPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.sectionPanel.Controls.Add(this.sectionSearchPanel);
            this.sectionPanel.Controls.Add(this.sectionAddPanel);
            this.sectionPanel.Controls.Add(this.sectionSearchButton);
            this.sectionPanel.Controls.Add(this.sectionAddButton);
            this.sectionPanel.GradientBottomLeft = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.sectionPanel.GradientBottomRight = System.Drawing.Color.White;
            this.sectionPanel.GradientTopLeft = System.Drawing.Color.White;
            this.sectionPanel.GradientTopRight = System.Drawing.Color.White;
            this.sectionPanel.Location = new System.Drawing.Point(140, 13);
            this.sectionPanel.Name = "sectionPanel";
            this.sectionPanel.Quality = 10;
            this.sectionPanel.Size = new System.Drawing.Size(53, 27);
            this.sectionPanel.TabIndex = 3;
            // 
            // sectionSearchPanel
            // 
            this.sectionSearchPanel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("sectionSearchPanel.BackgroundImage")));
            this.sectionSearchPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.sectionSearchPanel.Controls.Add(this.sectionSearchUpdateButton);
            this.sectionSearchPanel.Controls.Add(this.sectionSearchDeleteButton);
            this.sectionSearchPanel.Controls.Add(this.sectionSearchDataGrid);
            this.sectionSearchPanel.Controls.Add(this.bunifuCustomLabel28);
            this.sectionSearchPanel.Controls.Add(this.sectionSearchSectionNameTextBox);
            this.sectionSearchPanel.Controls.Add(this.sectionSearchDepartmentComboBox);
            this.sectionSearchPanel.Controls.Add(this.bunifuCustomLabel29);
            this.sectionSearchPanel.Controls.Add(this.sectionSearchClassComboBox);
            this.sectionSearchPanel.Controls.Add(this.bunifuCustomLabel30);
            this.sectionSearchPanel.Controls.Add(this.sectionSearchSearchButton);
            this.sectionSearchPanel.GradientBottomLeft = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.sectionSearchPanel.GradientBottomRight = System.Drawing.Color.White;
            this.sectionSearchPanel.GradientTopLeft = System.Drawing.Color.White;
            this.sectionSearchPanel.GradientTopRight = System.Drawing.Color.White;
            this.sectionSearchPanel.Location = new System.Drawing.Point(140, 35);
            this.sectionSearchPanel.Name = "sectionSearchPanel";
            this.sectionSearchPanel.Quality = 10;
            this.sectionSearchPanel.Size = new System.Drawing.Size(102, 55);
            this.sectionSearchPanel.TabIndex = 5;
            // 
            // sectionSearchUpdateButton
            // 
            this.sectionSearchUpdateButton.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.sectionSearchUpdateButton.BackColor = System.Drawing.Color.Silver;
            this.sectionSearchUpdateButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.sectionSearchUpdateButton.BorderRadius = 7;
            this.sectionSearchUpdateButton.ButtonText = "Update";
            this.sectionSearchUpdateButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.sectionSearchUpdateButton.DisabledColor = System.Drawing.Color.DimGray;
            this.sectionSearchUpdateButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sectionSearchUpdateButton.Iconcolor = System.Drawing.Color.Transparent;
            this.sectionSearchUpdateButton.Iconimage = null;
            this.sectionSearchUpdateButton.Iconimage_right = null;
            this.sectionSearchUpdateButton.Iconimage_right_Selected = null;
            this.sectionSearchUpdateButton.Iconimage_Selected = null;
            this.sectionSearchUpdateButton.IconMarginLeft = 0;
            this.sectionSearchUpdateButton.IconMarginRight = 0;
            this.sectionSearchUpdateButton.IconRightVisible = false;
            this.sectionSearchUpdateButton.IconRightZoom = 0D;
            this.sectionSearchUpdateButton.IconVisible = true;
            this.sectionSearchUpdateButton.IconZoom = 90D;
            this.sectionSearchUpdateButton.IsTab = false;
            this.sectionSearchUpdateButton.Location = new System.Drawing.Point(417, 230);
            this.sectionSearchUpdateButton.Name = "sectionSearchUpdateButton";
            this.sectionSearchUpdateButton.Normalcolor = System.Drawing.Color.Silver;
            this.sectionSearchUpdateButton.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.sectionSearchUpdateButton.OnHoverTextColor = System.Drawing.Color.White;
            this.sectionSearchUpdateButton.selected = false;
            this.sectionSearchUpdateButton.Size = new System.Drawing.Size(128, 26);
            this.sectionSearchUpdateButton.TabIndex = 7;
            this.sectionSearchUpdateButton.Text = "Update";
            this.sectionSearchUpdateButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.sectionSearchUpdateButton.Textcolor = System.Drawing.Color.Black;
            this.sectionSearchUpdateButton.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // sectionSearchDeleteButton
            // 
            this.sectionSearchDeleteButton.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.sectionSearchDeleteButton.BackColor = System.Drawing.Color.Silver;
            this.sectionSearchDeleteButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.sectionSearchDeleteButton.BorderRadius = 7;
            this.sectionSearchDeleteButton.ButtonText = "Delete";
            this.sectionSearchDeleteButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.sectionSearchDeleteButton.DisabledColor = System.Drawing.Color.DimGray;
            this.sectionSearchDeleteButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sectionSearchDeleteButton.Iconcolor = System.Drawing.Color.Transparent;
            this.sectionSearchDeleteButton.Iconimage = null;
            this.sectionSearchDeleteButton.Iconimage_right = null;
            this.sectionSearchDeleteButton.Iconimage_right_Selected = null;
            this.sectionSearchDeleteButton.Iconimage_Selected = null;
            this.sectionSearchDeleteButton.IconMarginLeft = 0;
            this.sectionSearchDeleteButton.IconMarginRight = 0;
            this.sectionSearchDeleteButton.IconRightVisible = false;
            this.sectionSearchDeleteButton.IconRightZoom = 0D;
            this.sectionSearchDeleteButton.IconVisible = true;
            this.sectionSearchDeleteButton.IconZoom = 90D;
            this.sectionSearchDeleteButton.IsTab = false;
            this.sectionSearchDeleteButton.Location = new System.Drawing.Point(585, 230);
            this.sectionSearchDeleteButton.Name = "sectionSearchDeleteButton";
            this.sectionSearchDeleteButton.Normalcolor = System.Drawing.Color.Silver;
            this.sectionSearchDeleteButton.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.sectionSearchDeleteButton.OnHoverTextColor = System.Drawing.Color.White;
            this.sectionSearchDeleteButton.selected = false;
            this.sectionSearchDeleteButton.Size = new System.Drawing.Size(128, 26);
            this.sectionSearchDeleteButton.TabIndex = 6;
            this.sectionSearchDeleteButton.Text = "Delete";
            this.sectionSearchDeleteButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.sectionSearchDeleteButton.Textcolor = System.Drawing.Color.Black;
            this.sectionSearchDeleteButton.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // sectionSearchDataGrid
            // 
            this.sectionSearchDataGrid.AllowUserToAddRows = false;
            this.sectionSearchDataGrid.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.sectionSearchDataGrid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.sectionSearchDataGrid.BackgroundColor = System.Drawing.Color.Gainsboro;
            this.sectionSearchDataGrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.sectionSearchDataGrid.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.sectionSearchDataGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.sectionSearchDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.sectionSearchDataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.className,
            this.section,
            this.department});
            this.sectionSearchDataGrid.DoubleBuffered = true;
            this.sectionSearchDataGrid.EnableHeadersVisualStyles = false;
            this.sectionSearchDataGrid.GridColor = System.Drawing.Color.White;
            this.sectionSearchDataGrid.HeaderBgColor = System.Drawing.Color.White;
            this.sectionSearchDataGrid.HeaderForeColor = System.Drawing.Color.Black;
            this.sectionSearchDataGrid.Location = new System.Drawing.Point(375, 39);
            this.sectionSearchDataGrid.Name = "sectionSearchDataGrid";
            this.sectionSearchDataGrid.ReadOnly = true;
            this.sectionSearchDataGrid.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.sectionSearchDataGrid.Size = new System.Drawing.Size(338, 166);
            this.sectionSearchDataGrid.TabIndex = 5;
            this.sectionSearchDataGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.sectionSearchDataGrid_CellClick);
            // 
            // className
            // 
            this.className.HeaderText = "Class";
            this.className.Name = "className";
            this.className.ReadOnly = true;
            // 
            // section
            // 
            this.section.HeaderText = "Section";
            this.section.Name = "section";
            this.section.ReadOnly = true;
            // 
            // department
            // 
            this.department.HeaderText = "Department";
            this.department.Name = "department";
            this.department.ReadOnly = true;
            // 
            // bunifuCustomLabel28
            // 
            this.bunifuCustomLabel28.AutoSize = true;
            this.bunifuCustomLabel28.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel28.Location = new System.Drawing.Point(36, 80);
            this.bunifuCustomLabel28.Name = "bunifuCustomLabel28";
            this.bunifuCustomLabel28.Size = new System.Drawing.Size(96, 17);
            this.bunifuCustomLabel28.TabIndex = 4;
            this.bunifuCustomLabel28.Text = "Section Name";
            // 
            // sectionSearchSectionNameTextBox
            // 
            this.sectionSearchSectionNameTextBox.Location = new System.Drawing.Point(150, 77);
            this.sectionSearchSectionNameTextBox.Name = "sectionSearchSectionNameTextBox";
            this.sectionSearchSectionNameTextBox.Size = new System.Drawing.Size(163, 20);
            this.sectionSearchSectionNameTextBox.TabIndex = 3;
            // 
            // sectionSearchDepartmentComboBox
            // 
            this.sectionSearchDepartmentComboBox.FormattingEnabled = true;
            this.sectionSearchDepartmentComboBox.Items.AddRange(new object[] {
            "Science",
            "Arts",
            "Commerce"});
            this.sectionSearchDepartmentComboBox.Location = new System.Drawing.Point(150, 115);
            this.sectionSearchDepartmentComboBox.Name = "sectionSearchDepartmentComboBox";
            this.sectionSearchDepartmentComboBox.Size = new System.Drawing.Size(163, 21);
            this.sectionSearchDepartmentComboBox.TabIndex = 2;
            // 
            // bunifuCustomLabel29
            // 
            this.bunifuCustomLabel29.AutoSize = true;
            this.bunifuCustomLabel29.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel29.Location = new System.Drawing.Point(33, 119);
            this.bunifuCustomLabel29.Name = "bunifuCustomLabel29";
            this.bunifuCustomLabel29.Size = new System.Drawing.Size(82, 17);
            this.bunifuCustomLabel29.TabIndex = 1;
            this.bunifuCustomLabel29.Text = "Department";
            // 
            // sectionSearchClassComboBox
            // 
            this.sectionSearchClassComboBox.FormattingEnabled = true;
            this.sectionSearchClassComboBox.Items.AddRange(new object[] {
            "Nursary",
            "STD-2",
            "STD-3",
            "STD-4",
            "STD-5",
            "STD-6",
            "STD-7",
            "STD-8",
            "STD-9",
            "STD-10"});
            this.sectionSearchClassComboBox.Location = new System.Drawing.Point(150, 39);
            this.sectionSearchClassComboBox.Name = "sectionSearchClassComboBox";
            this.sectionSearchClassComboBox.Size = new System.Drawing.Size(163, 21);
            this.sectionSearchClassComboBox.TabIndex = 2;
            // 
            // bunifuCustomLabel30
            // 
            this.bunifuCustomLabel30.AutoSize = true;
            this.bunifuCustomLabel30.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel30.Location = new System.Drawing.Point(36, 39);
            this.bunifuCustomLabel30.Name = "bunifuCustomLabel30";
            this.bunifuCustomLabel30.Size = new System.Drawing.Size(42, 17);
            this.bunifuCustomLabel30.TabIndex = 1;
            this.bunifuCustomLabel30.Text = "Class";
            // 
            // sectionSearchSearchButton
            // 
            this.sectionSearchSearchButton.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.sectionSearchSearchButton.BackColor = System.Drawing.Color.Silver;
            this.sectionSearchSearchButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.sectionSearchSearchButton.BorderRadius = 7;
            this.sectionSearchSearchButton.ButtonText = "Search";
            this.sectionSearchSearchButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.sectionSearchSearchButton.DisabledColor = System.Drawing.Color.DimGray;
            this.sectionSearchSearchButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sectionSearchSearchButton.Iconcolor = System.Drawing.Color.Transparent;
            this.sectionSearchSearchButton.Iconimage = null;
            this.sectionSearchSearchButton.Iconimage_right = null;
            this.sectionSearchSearchButton.Iconimage_right_Selected = null;
            this.sectionSearchSearchButton.Iconimage_Selected = null;
            this.sectionSearchSearchButton.IconMarginLeft = 0;
            this.sectionSearchSearchButton.IconMarginRight = 0;
            this.sectionSearchSearchButton.IconRightVisible = false;
            this.sectionSearchSearchButton.IconRightZoom = 0D;
            this.sectionSearchSearchButton.IconVisible = true;
            this.sectionSearchSearchButton.IconZoom = 90D;
            this.sectionSearchSearchButton.IsTab = false;
            this.sectionSearchSearchButton.Location = new System.Drawing.Point(154, 168);
            this.sectionSearchSearchButton.Name = "sectionSearchSearchButton";
            this.sectionSearchSearchButton.Normalcolor = System.Drawing.Color.Silver;
            this.sectionSearchSearchButton.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.sectionSearchSearchButton.OnHoverTextColor = System.Drawing.Color.White;
            this.sectionSearchSearchButton.selected = false;
            this.sectionSearchSearchButton.Size = new System.Drawing.Size(128, 26);
            this.sectionSearchSearchButton.TabIndex = 0;
            this.sectionSearchSearchButton.Text = "Search";
            this.sectionSearchSearchButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.sectionSearchSearchButton.Textcolor = System.Drawing.Color.Black;
            this.sectionSearchSearchButton.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // sectionAddPanel
            // 
            this.sectionAddPanel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("sectionAddPanel.BackgroundImage")));
            this.sectionAddPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.sectionAddPanel.Controls.Add(this.bunifuCustomLabel27);
            this.sectionAddPanel.Controls.Add(this.sectionNameSectionAddTextBox);
            this.sectionAddPanel.Controls.Add(this.departmentSectionAddComboBox);
            this.sectionAddPanel.Controls.Add(this.bunifuCustomLabel26);
            this.sectionAddPanel.Controls.Add(this.classSectionAddComboBox);
            this.sectionAddPanel.Controls.Add(this.bunifuCustomLabel25);
            this.sectionAddPanel.Controls.Add(this.sectionAddDoneButton);
            this.sectionAddPanel.GradientBottomLeft = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.sectionAddPanel.GradientBottomRight = System.Drawing.Color.White;
            this.sectionAddPanel.GradientTopLeft = System.Drawing.Color.White;
            this.sectionAddPanel.GradientTopRight = System.Drawing.Color.White;
            this.sectionAddPanel.Location = new System.Drawing.Point(10, 46);
            this.sectionAddPanel.Name = "sectionAddPanel";
            this.sectionAddPanel.Quality = 10;
            this.sectionAddPanel.Size = new System.Drawing.Size(110, 50);
            this.sectionAddPanel.TabIndex = 4;
            // 
            // bunifuCustomLabel27
            // 
            this.bunifuCustomLabel27.AutoSize = true;
            this.bunifuCustomLabel27.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel27.Location = new System.Drawing.Point(89, 106);
            this.bunifuCustomLabel27.Name = "bunifuCustomLabel27";
            this.bunifuCustomLabel27.Size = new System.Drawing.Size(96, 17);
            this.bunifuCustomLabel27.TabIndex = 4;
            this.bunifuCustomLabel27.Text = "Section Name";
            // 
            // sectionNameSectionAddTextBox
            // 
            this.sectionNameSectionAddTextBox.Location = new System.Drawing.Point(220, 103);
            this.sectionNameSectionAddTextBox.Name = "sectionNameSectionAddTextBox";
            this.sectionNameSectionAddTextBox.Size = new System.Drawing.Size(163, 20);
            this.sectionNameSectionAddTextBox.TabIndex = 3;
            // 
            // departmentSectionAddComboBox
            // 
            this.departmentSectionAddComboBox.FormattingEnabled = true;
            this.departmentSectionAddComboBox.Items.AddRange(new object[] {
            "Science",
            "Arts",
            "Commerce"});
            this.departmentSectionAddComboBox.Location = new System.Drawing.Point(551, 54);
            this.departmentSectionAddComboBox.Name = "departmentSectionAddComboBox";
            this.departmentSectionAddComboBox.Size = new System.Drawing.Size(163, 21);
            this.departmentSectionAddComboBox.TabIndex = 2;
            // 
            // bunifuCustomLabel26
            // 
            this.bunifuCustomLabel26.AutoSize = true;
            this.bunifuCustomLabel26.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel26.Location = new System.Drawing.Point(437, 54);
            this.bunifuCustomLabel26.Name = "bunifuCustomLabel26";
            this.bunifuCustomLabel26.Size = new System.Drawing.Size(82, 17);
            this.bunifuCustomLabel26.TabIndex = 1;
            this.bunifuCustomLabel26.Text = "Department";
            // 
            // classSectionAddComboBox
            // 
            this.classSectionAddComboBox.FormattingEnabled = true;
            this.classSectionAddComboBox.Items.AddRange(new object[] {
            "Nursary",
            "STD-2",
            "STD-3",
            "STD-4",
            "STD-5",
            "STD-6",
            "STD-7",
            "STD-8",
            "STD-9",
            "STD-10"});
            this.classSectionAddComboBox.Location = new System.Drawing.Point(220, 54);
            this.classSectionAddComboBox.Name = "classSectionAddComboBox";
            this.classSectionAddComboBox.Size = new System.Drawing.Size(163, 21);
            this.classSectionAddComboBox.TabIndex = 2;
            // 
            // bunifuCustomLabel25
            // 
            this.bunifuCustomLabel25.AutoSize = true;
            this.bunifuCustomLabel25.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel25.Location = new System.Drawing.Point(106, 54);
            this.bunifuCustomLabel25.Name = "bunifuCustomLabel25";
            this.bunifuCustomLabel25.Size = new System.Drawing.Size(42, 17);
            this.bunifuCustomLabel25.TabIndex = 1;
            this.bunifuCustomLabel25.Text = "Class";
            // 
            // sectionAddDoneButton
            // 
            this.sectionAddDoneButton.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.sectionAddDoneButton.BackColor = System.Drawing.Color.Silver;
            this.sectionAddDoneButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.sectionAddDoneButton.BorderRadius = 7;
            this.sectionAddDoneButton.ButtonText = "Add";
            this.sectionAddDoneButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.sectionAddDoneButton.DisabledColor = System.Drawing.Color.DimGray;
            this.sectionAddDoneButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sectionAddDoneButton.Iconcolor = System.Drawing.Color.Transparent;
            this.sectionAddDoneButton.Iconimage = null;
            this.sectionAddDoneButton.Iconimage_right = null;
            this.sectionAddDoneButton.Iconimage_right_Selected = null;
            this.sectionAddDoneButton.Iconimage_Selected = null;
            this.sectionAddDoneButton.IconMarginLeft = 0;
            this.sectionAddDoneButton.IconMarginRight = 0;
            this.sectionAddDoneButton.IconRightVisible = false;
            this.sectionAddDoneButton.IconRightZoom = 0D;
            this.sectionAddDoneButton.IconVisible = true;
            this.sectionAddDoneButton.IconZoom = 90D;
            this.sectionAddDoneButton.IsTab = false;
            this.sectionAddDoneButton.Location = new System.Drawing.Point(551, 234);
            this.sectionAddDoneButton.Name = "sectionAddDoneButton";
            this.sectionAddDoneButton.Normalcolor = System.Drawing.Color.Silver;
            this.sectionAddDoneButton.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.sectionAddDoneButton.OnHoverTextColor = System.Drawing.Color.White;
            this.sectionAddDoneButton.selected = false;
            this.sectionAddDoneButton.Size = new System.Drawing.Size(128, 26);
            this.sectionAddDoneButton.TabIndex = 0;
            this.sectionAddDoneButton.Text = "Add";
            this.sectionAddDoneButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.sectionAddDoneButton.Textcolor = System.Drawing.Color.Black;
            this.sectionAddDoneButton.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // sectionSearchButton
            // 
            this.sectionSearchButton.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.sectionSearchButton.BackColor = System.Drawing.Color.Silver;
            this.sectionSearchButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.sectionSearchButton.BorderRadius = 7;
            this.sectionSearchButton.ButtonText = "Search";
            this.sectionSearchButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.sectionSearchButton.DisabledColor = System.Drawing.Color.DimGray;
            this.sectionSearchButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sectionSearchButton.Iconcolor = System.Drawing.Color.Transparent;
            this.sectionSearchButton.Iconimage = null;
            this.sectionSearchButton.Iconimage_right = null;
            this.sectionSearchButton.Iconimage_right_Selected = null;
            this.sectionSearchButton.Iconimage_Selected = null;
            this.sectionSearchButton.IconMarginLeft = 0;
            this.sectionSearchButton.IconMarginRight = 0;
            this.sectionSearchButton.IconRightVisible = false;
            this.sectionSearchButton.IconRightZoom = 0D;
            this.sectionSearchButton.IconVisible = true;
            this.sectionSearchButton.IconZoom = 90D;
            this.sectionSearchButton.IsTab = false;
            this.sectionSearchButton.Location = new System.Drawing.Point(137, 3);
            this.sectionSearchButton.Name = "sectionSearchButton";
            this.sectionSearchButton.Normalcolor = System.Drawing.Color.Silver;
            this.sectionSearchButton.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.sectionSearchButton.OnHoverTextColor = System.Drawing.Color.White;
            this.sectionSearchButton.selected = false;
            this.sectionSearchButton.Size = new System.Drawing.Size(128, 26);
            this.sectionSearchButton.TabIndex = 0;
            this.sectionSearchButton.Text = "Search";
            this.sectionSearchButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.sectionSearchButton.Textcolor = System.Drawing.Color.Black;
            this.sectionSearchButton.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sectionSearchButton.Click += new System.EventHandler(this.sectionSearchButton_Click);
            // 
            // sectionAddButton
            // 
            this.sectionAddButton.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.sectionAddButton.BackColor = System.Drawing.Color.Silver;
            this.sectionAddButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.sectionAddButton.BorderRadius = 7;
            this.sectionAddButton.ButtonText = "Add";
            this.sectionAddButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.sectionAddButton.DisabledColor = System.Drawing.Color.DimGray;
            this.sectionAddButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sectionAddButton.Iconcolor = System.Drawing.Color.Transparent;
            this.sectionAddButton.Iconimage = null;
            this.sectionAddButton.Iconimage_right = null;
            this.sectionAddButton.Iconimage_right_Selected = null;
            this.sectionAddButton.Iconimage_Selected = null;
            this.sectionAddButton.IconMarginLeft = 0;
            this.sectionAddButton.IconMarginRight = 0;
            this.sectionAddButton.IconRightVisible = false;
            this.sectionAddButton.IconRightZoom = 0D;
            this.sectionAddButton.IconVisible = true;
            this.sectionAddButton.IconZoom = 90D;
            this.sectionAddButton.IsTab = false;
            this.sectionAddButton.Location = new System.Drawing.Point(3, 3);
            this.sectionAddButton.Name = "sectionAddButton";
            this.sectionAddButton.Normalcolor = System.Drawing.Color.Silver;
            this.sectionAddButton.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.sectionAddButton.OnHoverTextColor = System.Drawing.Color.White;
            this.sectionAddButton.selected = false;
            this.sectionAddButton.Size = new System.Drawing.Size(128, 26);
            this.sectionAddButton.TabIndex = 0;
            this.sectionAddButton.Text = "Add";
            this.sectionAddButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.sectionAddButton.Textcolor = System.Drawing.Color.Black;
            this.sectionAddButton.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sectionAddButton.Click += new System.EventHandler(this.sectionAddButton_Click);
            // 
            // userPanel
            // 
            this.userPanel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("userPanel.BackgroundImage")));
            this.userPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.userPanel.Controls.Add(this.addUserPanel);
            this.userPanel.Controls.Add(this.searchUserButton);
            this.userPanel.Controls.Add(this.addUserButton);
            this.userPanel.Controls.Add(this.userSearchPanel);
            this.userPanel.GradientBottomLeft = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.userPanel.GradientBottomRight = System.Drawing.Color.White;
            this.userPanel.GradientTopLeft = System.Drawing.Color.White;
            this.userPanel.GradientTopRight = System.Drawing.Color.White;
            this.userPanel.Location = new System.Drawing.Point(62, 13);
            this.userPanel.Name = "userPanel";
            this.userPanel.Quality = 10;
            this.userPanel.Size = new System.Drawing.Size(64, 63);
            this.userPanel.TabIndex = 2;
            // 
            // addUserPanel
            // 
            this.addUserPanel.BackColor = System.Drawing.Color.Cyan;
            this.addUserPanel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("addUserPanel.BackgroundImage")));
            this.addUserPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.addUserPanel.Controls.Add(this.dateTimePicker1);
            this.addUserPanel.Controls.Add(this.bunifuCustomLabel10);
            this.addUserPanel.Controls.Add(this.doneAddUserButton);
            this.addUserPanel.Controls.Add(this.othersRadioButton);
            this.addUserPanel.Controls.Add(this.femaleRadioButton);
            this.addUserPanel.Controls.Add(this.maleRadioButton);
            this.addUserPanel.Controls.Add(this.userAddPhoneTextBox);
            this.addUserPanel.Controls.Add(this.userAddPasswordTextBox);
            this.addUserPanel.Controls.Add(this.userAddUsernameTextBox);
            this.addUserPanel.Controls.Add(this.userAddConfirmPasswordTextBox);
            this.addUserPanel.Controls.Add(this.userAddEmailTextBox);
            this.addUserPanel.Controls.Add(this.userAddNameTextBox);
            this.addUserPanel.Controls.Add(this.bgComboBox);
            this.addUserPanel.Controls.Add(this.userTypeComboBox);
            this.addUserPanel.Controls.Add(this.bunifuCustomLabel11);
            this.addUserPanel.Controls.Add(this.bgLabel);
            this.addUserPanel.Controls.Add(this.bunifuCustomLabel9);
            this.addUserPanel.Controls.Add(this.bunifuCustomLabel6);
            this.addUserPanel.Controls.Add(this.bunifuCustomLabel8);
            this.addUserPanel.Controls.Add(this.bunifuCustomLabel7);
            this.addUserPanel.Controls.Add(this.bunifuCustomLabel4);
            this.addUserPanel.Controls.Add(this.bunifuCustomLabel5);
            this.addUserPanel.Controls.Add(this.bunifuCustomLabel3);
            this.addUserPanel.GradientBottomLeft = System.Drawing.Color.Cyan;
            this.addUserPanel.GradientBottomRight = System.Drawing.Color.White;
            this.addUserPanel.GradientTopLeft = System.Drawing.Color.White;
            this.addUserPanel.GradientTopRight = System.Drawing.Color.White;
            this.addUserPanel.Location = new System.Drawing.Point(27, 57);
            this.addUserPanel.Name = "addUserPanel";
            this.addUserPanel.Quality = 10;
            this.addUserPanel.Size = new System.Drawing.Size(104, 111);
            this.addUserPanel.TabIndex = 1;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(503, 63);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(179, 20);
            this.dateTimePicker1.TabIndex = 8;
            // 
            // bunifuCustomLabel10
            // 
            this.bunifuCustomLabel10.AutoSize = true;
            this.bunifuCustomLabel10.BackColor = System.Drawing.Color.Aqua;
            this.bunifuCustomLabel10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel10.Location = new System.Drawing.Point(407, 63);
            this.bunifuCustomLabel10.Name = "bunifuCustomLabel10";
            this.bunifuCustomLabel10.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuCustomLabel10.Size = new System.Drawing.Size(90, 17);
            this.bunifuCustomLabel10.TabIndex = 5;
            this.bunifuCustomLabel10.Text = "Date Of Birth";
            // 
            // doneAddUserButton
            // 
            this.doneAddUserButton.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.doneAddUserButton.BackColor = System.Drawing.Color.Silver;
            this.doneAddUserButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.doneAddUserButton.BorderRadius = 7;
            this.doneAddUserButton.ButtonText = "Done";
            this.doneAddUserButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.doneAddUserButton.DisabledColor = System.Drawing.Color.DimGray;
            this.doneAddUserButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.doneAddUserButton.Iconcolor = System.Drawing.Color.Transparent;
            this.doneAddUserButton.Iconimage = null;
            this.doneAddUserButton.Iconimage_right = null;
            this.doneAddUserButton.Iconimage_right_Selected = null;
            this.doneAddUserButton.Iconimage_Selected = null;
            this.doneAddUserButton.IconMarginLeft = 0;
            this.doneAddUserButton.IconMarginRight = 0;
            this.doneAddUserButton.IconRightVisible = false;
            this.doneAddUserButton.IconRightZoom = 0D;
            this.doneAddUserButton.IconVisible = true;
            this.doneAddUserButton.IconZoom = 90D;
            this.doneAddUserButton.IsTab = false;
            this.doneAddUserButton.Location = new System.Drawing.Point(701, 343);
            this.doneAddUserButton.Name = "doneAddUserButton";
            this.doneAddUserButton.Normalcolor = System.Drawing.Color.Silver;
            this.doneAddUserButton.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.doneAddUserButton.OnHoverTextColor = System.Drawing.Color.White;
            this.doneAddUserButton.selected = false;
            this.doneAddUserButton.Size = new System.Drawing.Size(82, 26);
            this.doneAddUserButton.TabIndex = 4;
            this.doneAddUserButton.Text = "Done";
            this.doneAddUserButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.doneAddUserButton.Textcolor = System.Drawing.Color.Black;
            this.doneAddUserButton.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.doneAddUserButton.Click += new System.EventHandler(this.doneAddUserButton_Click);
            // 
            // othersRadioButton
            // 
            this.othersRadioButton.AutoSize = true;
            this.othersRadioButton.Location = new System.Drawing.Point(280, 316);
            this.othersRadioButton.Name = "othersRadioButton";
            this.othersRadioButton.Size = new System.Drawing.Size(56, 17);
            this.othersRadioButton.TabIndex = 3;
            this.othersRadioButton.TabStop = true;
            this.othersRadioButton.Text = "Others";
            this.othersRadioButton.UseVisualStyleBackColor = true;
            // 
            // femaleRadioButton
            // 
            this.femaleRadioButton.AutoSize = true;
            this.femaleRadioButton.Location = new System.Drawing.Point(201, 316);
            this.femaleRadioButton.Name = "femaleRadioButton";
            this.femaleRadioButton.Size = new System.Drawing.Size(59, 17);
            this.femaleRadioButton.TabIndex = 3;
            this.femaleRadioButton.TabStop = true;
            this.femaleRadioButton.Text = "Female";
            this.femaleRadioButton.UseVisualStyleBackColor = true;
            // 
            // maleRadioButton
            // 
            this.maleRadioButton.AutoSize = true;
            this.maleRadioButton.Location = new System.Drawing.Point(137, 316);
            this.maleRadioButton.Name = "maleRadioButton";
            this.maleRadioButton.Size = new System.Drawing.Size(48, 17);
            this.maleRadioButton.TabIndex = 3;
            this.maleRadioButton.TabStop = true;
            this.maleRadioButton.Text = "Male";
            this.maleRadioButton.UseVisualStyleBackColor = true;
            // 
            // userAddPhoneTextBox
            // 
            this.userAddPhoneTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userAddPhoneTextBox.Location = new System.Drawing.Point(151, 238);
            this.userAddPhoneTextBox.Name = "userAddPhoneTextBox";
            this.userAddPhoneTextBox.Size = new System.Drawing.Size(204, 23);
            this.userAddPhoneTextBox.TabIndex = 2;
            // 
            // userAddPasswordTextBox
            // 
            this.userAddPasswordTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userAddPasswordTextBox.Location = new System.Drawing.Point(151, 166);
            this.userAddPasswordTextBox.Name = "userAddPasswordTextBox";
            this.userAddPasswordTextBox.Size = new System.Drawing.Size(204, 23);
            this.userAddPasswordTextBox.TabIndex = 2;
            // 
            // userAddUsernameTextBox
            // 
            this.userAddUsernameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userAddUsernameTextBox.Location = new System.Drawing.Point(151, 96);
            this.userAddUsernameTextBox.Name = "userAddUsernameTextBox";
            this.userAddUsernameTextBox.Size = new System.Drawing.Size(204, 23);
            this.userAddUsernameTextBox.TabIndex = 2;
            // 
            // userAddConfirmPasswordTextBox
            // 
            this.userAddConfirmPasswordTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userAddConfirmPasswordTextBox.Location = new System.Drawing.Point(151, 205);
            this.userAddConfirmPasswordTextBox.Name = "userAddConfirmPasswordTextBox";
            this.userAddConfirmPasswordTextBox.Size = new System.Drawing.Size(204, 23);
            this.userAddConfirmPasswordTextBox.TabIndex = 2;
            // 
            // userAddEmailTextBox
            // 
            this.userAddEmailTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userAddEmailTextBox.Location = new System.Drawing.Point(151, 133);
            this.userAddEmailTextBox.Name = "userAddEmailTextBox";
            this.userAddEmailTextBox.Size = new System.Drawing.Size(204, 23);
            this.userAddEmailTextBox.TabIndex = 3;
            // 
            // userAddNameTextBox
            // 
            this.userAddNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userAddNameTextBox.Location = new System.Drawing.Point(151, 63);
            this.userAddNameTextBox.Name = "userAddNameTextBox";
            this.userAddNameTextBox.Size = new System.Drawing.Size(204, 23);
            this.userAddNameTextBox.TabIndex = 1;
            // 
            // bgComboBox
            // 
            this.bgComboBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bgComboBox.FormattingEnabled = true;
            this.bgComboBox.Items.AddRange(new object[] {
            "A+",
            "A-",
            "B+",
            "B-",
            "AB+",
            "AB-",
            "O+",
            "O-"});
            this.bgComboBox.Location = new System.Drawing.Point(137, 278);
            this.bgComboBox.Name = "bgComboBox";
            this.bgComboBox.Size = new System.Drawing.Size(218, 21);
            this.bgComboBox.TabIndex = 1;
            // 
            // userTypeComboBox
            // 
            this.userTypeComboBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.userTypeComboBox.FormattingEnabled = true;
            this.userTypeComboBox.Items.AddRange(new object[] {
            "Admin",
            "Teacher",
            "Student"});
            this.userTypeComboBox.Location = new System.Drawing.Point(134, 22);
            this.userTypeComboBox.Name = "userTypeComboBox";
            this.userTypeComboBox.Size = new System.Drawing.Size(221, 21);
            this.userTypeComboBox.TabIndex = 0;
            // 
            // bunifuCustomLabel11
            // 
            this.bunifuCustomLabel11.AutoSize = true;
            this.bunifuCustomLabel11.BackColor = System.Drawing.Color.Aqua;
            this.bunifuCustomLabel11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel11.Location = new System.Drawing.Point(30, 316);
            this.bunifuCustomLabel11.Name = "bunifuCustomLabel11";
            this.bunifuCustomLabel11.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuCustomLabel11.Size = new System.Drawing.Size(56, 17);
            this.bunifuCustomLabel11.TabIndex = 0;
            this.bunifuCustomLabel11.Text = "Gender";
            // 
            // bgLabel
            // 
            this.bgLabel.AutoSize = true;
            this.bgLabel.BackColor = System.Drawing.Color.Aqua;
            this.bgLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bgLabel.Location = new System.Drawing.Point(30, 282);
            this.bgLabel.Name = "bgLabel";
            this.bgLabel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bgLabel.Size = new System.Drawing.Size(88, 17);
            this.bgLabel.TabIndex = 0;
            this.bgLabel.Text = "Blood Group";
            // 
            // bunifuCustomLabel9
            // 
            this.bunifuCustomLabel9.AutoSize = true;
            this.bunifuCustomLabel9.BackColor = System.Drawing.Color.Aqua;
            this.bunifuCustomLabel9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel9.Location = new System.Drawing.Point(30, 245);
            this.bunifuCustomLabel9.Name = "bunifuCustomLabel9";
            this.bunifuCustomLabel9.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuCustomLabel9.Size = new System.Drawing.Size(103, 17);
            this.bunifuCustomLabel9.TabIndex = 0;
            this.bunifuCustomLabel9.Text = "Phone Number";
            // 
            // bunifuCustomLabel6
            // 
            this.bunifuCustomLabel6.AutoSize = true;
            this.bunifuCustomLabel6.BackColor = System.Drawing.Color.Aqua;
            this.bunifuCustomLabel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel6.Location = new System.Drawing.Point(30, 139);
            this.bunifuCustomLabel6.Name = "bunifuCustomLabel6";
            this.bunifuCustomLabel6.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuCustomLabel6.Size = new System.Drawing.Size(42, 17);
            this.bunifuCustomLabel6.TabIndex = 0;
            this.bunifuCustomLabel6.Text = "Email";
            // 
            // bunifuCustomLabel8
            // 
            this.bunifuCustomLabel8.AutoSize = true;
            this.bunifuCustomLabel8.BackColor = System.Drawing.Color.Aqua;
            this.bunifuCustomLabel8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel8.Location = new System.Drawing.Point(30, 175);
            this.bunifuCustomLabel8.Name = "bunifuCustomLabel8";
            this.bunifuCustomLabel8.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuCustomLabel8.Size = new System.Drawing.Size(69, 17);
            this.bunifuCustomLabel8.TabIndex = 0;
            this.bunifuCustomLabel8.Text = "Password";
            // 
            // bunifuCustomLabel7
            // 
            this.bunifuCustomLabel7.AutoSize = true;
            this.bunifuCustomLabel7.BackColor = System.Drawing.Color.Aqua;
            this.bunifuCustomLabel7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel7.Location = new System.Drawing.Point(30, 208);
            this.bunifuCustomLabel7.Name = "bunifuCustomLabel7";
            this.bunifuCustomLabel7.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuCustomLabel7.Size = new System.Drawing.Size(121, 17);
            this.bunifuCustomLabel7.TabIndex = 0;
            this.bunifuCustomLabel7.Text = "Confirm Password";
            // 
            // bunifuCustomLabel4
            // 
            this.bunifuCustomLabel4.AutoSize = true;
            this.bunifuCustomLabel4.BackColor = System.Drawing.Color.Aqua;
            this.bunifuCustomLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel4.Location = new System.Drawing.Point(30, 69);
            this.bunifuCustomLabel4.Name = "bunifuCustomLabel4";
            this.bunifuCustomLabel4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuCustomLabel4.Size = new System.Drawing.Size(45, 17);
            this.bunifuCustomLabel4.TabIndex = 0;
            this.bunifuCustomLabel4.Text = "Name";
            // 
            // bunifuCustomLabel5
            // 
            this.bunifuCustomLabel5.AutoSize = true;
            this.bunifuCustomLabel5.BackColor = System.Drawing.Color.Aqua;
            this.bunifuCustomLabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel5.Location = new System.Drawing.Point(30, 102);
            this.bunifuCustomLabel5.Name = "bunifuCustomLabel5";
            this.bunifuCustomLabel5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuCustomLabel5.Size = new System.Drawing.Size(79, 17);
            this.bunifuCustomLabel5.TabIndex = 0;
            this.bunifuCustomLabel5.Text = "User Name";
            // 
            // bunifuCustomLabel3
            // 
            this.bunifuCustomLabel3.AutoSize = true;
            this.bunifuCustomLabel3.BackColor = System.Drawing.Color.Aqua;
            this.bunifuCustomLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel3.Location = new System.Drawing.Point(30, 22);
            this.bunifuCustomLabel3.Name = "bunifuCustomLabel3";
            this.bunifuCustomLabel3.Size = new System.Drawing.Size(74, 17);
            this.bunifuCustomLabel3.TabIndex = 0;
            this.bunifuCustomLabel3.Text = "User Type";
            // 
            // searchUserButton
            // 
            this.searchUserButton.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.searchUserButton.BackColor = System.Drawing.Color.Silver;
            this.searchUserButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.searchUserButton.BorderRadius = 7;
            this.searchUserButton.ButtonText = "Search";
            this.searchUserButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.searchUserButton.DisabledColor = System.Drawing.Color.DimGray;
            this.searchUserButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.searchUserButton.Iconcolor = System.Drawing.Color.Transparent;
            this.searchUserButton.Iconimage = null;
            this.searchUserButton.Iconimage_right = null;
            this.searchUserButton.Iconimage_right_Selected = null;
            this.searchUserButton.Iconimage_Selected = null;
            this.searchUserButton.IconMarginLeft = 0;
            this.searchUserButton.IconMarginRight = 0;
            this.searchUserButton.IconRightVisible = false;
            this.searchUserButton.IconRightZoom = 0D;
            this.searchUserButton.IconVisible = true;
            this.searchUserButton.IconZoom = 90D;
            this.searchUserButton.IsTab = false;
            this.searchUserButton.Location = new System.Drawing.Point(137, 3);
            this.searchUserButton.Name = "searchUserButton";
            this.searchUserButton.Normalcolor = System.Drawing.Color.Silver;
            this.searchUserButton.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.searchUserButton.OnHoverTextColor = System.Drawing.Color.White;
            this.searchUserButton.selected = false;
            this.searchUserButton.Size = new System.Drawing.Size(128, 26);
            this.searchUserButton.TabIndex = 0;
            this.searchUserButton.Text = "Search";
            this.searchUserButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.searchUserButton.Textcolor = System.Drawing.Color.Black;
            this.searchUserButton.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchUserButton.Click += new System.EventHandler(this.searchUserButton_Click);
            // 
            // addUserButton
            // 
            this.addUserButton.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.addUserButton.BackColor = System.Drawing.Color.Silver;
            this.addUserButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.addUserButton.BorderRadius = 7;
            this.addUserButton.ButtonText = "Add";
            this.addUserButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.addUserButton.DisabledColor = System.Drawing.Color.DimGray;
            this.addUserButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.addUserButton.Iconcolor = System.Drawing.Color.Transparent;
            this.addUserButton.Iconimage = null;
            this.addUserButton.Iconimage_right = null;
            this.addUserButton.Iconimage_right_Selected = null;
            this.addUserButton.Iconimage_Selected = null;
            this.addUserButton.IconMarginLeft = 0;
            this.addUserButton.IconMarginRight = 0;
            this.addUserButton.IconRightVisible = false;
            this.addUserButton.IconRightZoom = 0D;
            this.addUserButton.IconVisible = true;
            this.addUserButton.IconZoom = 90D;
            this.addUserButton.IsTab = false;
            this.addUserButton.Location = new System.Drawing.Point(3, 3);
            this.addUserButton.Name = "addUserButton";
            this.addUserButton.Normalcolor = System.Drawing.Color.Silver;
            this.addUserButton.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.addUserButton.OnHoverTextColor = System.Drawing.Color.White;
            this.addUserButton.selected = false;
            this.addUserButton.Size = new System.Drawing.Size(128, 26);
            this.addUserButton.TabIndex = 0;
            this.addUserButton.Text = "Add";
            this.addUserButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.addUserButton.Textcolor = System.Drawing.Color.Black;
            this.addUserButton.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addUserButton.Click += new System.EventHandler(this.addUserButton_Click);
            // 
            // userSearchPanel
            // 
            this.userSearchPanel.AutoScroll = true;
            this.userSearchPanel.BackColor = System.Drawing.Color.Cyan;
            this.userSearchPanel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("userSearchPanel.BackgroundImage")));
            this.userSearchPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.userSearchPanel.Controls.Add(this.deleteButton);
            this.userSearchPanel.Controls.Add(this.datePickerUserUpdate);
            this.userSearchPanel.Controls.Add(this.bunifuCustomLabel14);
            this.userSearchPanel.Controls.Add(this.updateButton);
            this.userSearchPanel.Controls.Add(this.othersUpdate);
            this.userSearchPanel.Controls.Add(this.femaleUpdate);
            this.userSearchPanel.Controls.Add(this.maleUpdate);
            this.userSearchPanel.Controls.Add(this.phoneUpdateTextBox);
            this.userSearchPanel.Controls.Add(this.passwordUpdateTextBox);
            this.userSearchPanel.Controls.Add(this.userNameUpdateTextBox);
            this.userSearchPanel.Controls.Add(this.confirmPasswordUpdateTextBox);
            this.userSearchPanel.Controls.Add(this.emailUpdateTextBox);
            this.userSearchPanel.Controls.Add(this.nameUpdateTectBox);
            this.userSearchPanel.Controls.Add(this.bgUpdateTextBox);
            this.userSearchPanel.Controls.Add(this.userTypeUpdateComboBox);
            this.userSearchPanel.Controls.Add(this.bunifuCustomLabel15);
            this.userSearchPanel.Controls.Add(this.bunifuCustomLabel16);
            this.userSearchPanel.Controls.Add(this.bunifuCustomLabel17);
            this.userSearchPanel.Controls.Add(this.bunifuCustomLabel18);
            this.userSearchPanel.Controls.Add(this.bunifuCustomLabel19);
            this.userSearchPanel.Controls.Add(this.bunifuCustomLabel20);
            this.userSearchPanel.Controls.Add(this.bunifuCustomLabel22);
            this.userSearchPanel.Controls.Add(this.bunifuCustomLabel23);
            this.userSearchPanel.Controls.Add(this.bunifuCustomLabel24);
            this.userSearchPanel.Controls.Add(this.searchInUserSearchPanelButton);
            this.userSearchPanel.Controls.Add(this.userSearchDataGrid);
            this.userSearchPanel.Controls.Add(this.idTextBoxSearch);
            this.userSearchPanel.Controls.Add(this.nameTextBoxSearch);
            this.userSearchPanel.Controls.Add(this.bunifuCustomLabel13);
            this.userSearchPanel.Controls.Add(this.bunifuCustomLabel12);
            this.userSearchPanel.Controls.Add(this.userTypeComboBoxSearch);
            this.userSearchPanel.Controls.Add(this.bunifuCustomLabel21);
            this.userSearchPanel.GradientBottomLeft = System.Drawing.Color.Cyan;
            this.userSearchPanel.GradientBottomRight = System.Drawing.Color.White;
            this.userSearchPanel.GradientTopLeft = System.Drawing.Color.White;
            this.userSearchPanel.GradientTopRight = System.Drawing.Color.White;
            this.userSearchPanel.Location = new System.Drawing.Point(161, 55);
            this.userSearchPanel.Name = "userSearchPanel";
            this.userSearchPanel.Quality = 10;
            this.userSearchPanel.Size = new System.Drawing.Size(76, 88);
            this.userSearchPanel.TabIndex = 9;
            // 
            // deleteButton
            // 
            this.deleteButton.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.deleteButton.BackColor = System.Drawing.Color.Silver;
            this.deleteButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.deleteButton.BorderRadius = 7;
            this.deleteButton.ButtonText = "Delete";
            this.deleteButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.deleteButton.DisabledColor = System.Drawing.Color.DimGray;
            this.deleteButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.deleteButton.Iconcolor = System.Drawing.Color.Transparent;
            this.deleteButton.Iconimage = null;
            this.deleteButton.Iconimage_right = null;
            this.deleteButton.Iconimage_right_Selected = null;
            this.deleteButton.Iconimage_Selected = null;
            this.deleteButton.IconMarginLeft = 0;
            this.deleteButton.IconMarginRight = 0;
            this.deleteButton.IconRightVisible = false;
            this.deleteButton.IconRightZoom = 0D;
            this.deleteButton.IconVisible = true;
            this.deleteButton.IconZoom = 90D;
            this.deleteButton.IsTab = false;
            this.deleteButton.Location = new System.Drawing.Point(506, 477);
            this.deleteButton.Name = "deleteButton";
            this.deleteButton.Normalcolor = System.Drawing.Color.Silver;
            this.deleteButton.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.deleteButton.OnHoverTextColor = System.Drawing.Color.White;
            this.deleteButton.selected = false;
            this.deleteButton.Size = new System.Drawing.Size(82, 26);
            this.deleteButton.TabIndex = 32;
            this.deleteButton.Text = "Delete";
            this.deleteButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.deleteButton.Textcolor = System.Drawing.Color.Black;
            this.deleteButton.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleteButton.Click += new System.EventHandler(this.deleteButton_Click);
            // 
            // datePickerUserUpdate
            // 
            this.datePickerUserUpdate.Location = new System.Drawing.Point(515, 353);
            this.datePickerUserUpdate.Name = "datePickerUserUpdate";
            this.datePickerUserUpdate.Size = new System.Drawing.Size(179, 20);
            this.datePickerUserUpdate.TabIndex = 31;
            // 
            // bunifuCustomLabel14
            // 
            this.bunifuCustomLabel14.AutoSize = true;
            this.bunifuCustomLabel14.BackColor = System.Drawing.Color.Aqua;
            this.bunifuCustomLabel14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel14.Location = new System.Drawing.Point(419, 353);
            this.bunifuCustomLabel14.Name = "bunifuCustomLabel14";
            this.bunifuCustomLabel14.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuCustomLabel14.Size = new System.Drawing.Size(90, 17);
            this.bunifuCustomLabel14.TabIndex = 30;
            this.bunifuCustomLabel14.Text = "Date Of Birth";
            // 
            // updateButton
            // 
            this.updateButton.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.updateButton.BackColor = System.Drawing.Color.Silver;
            this.updateButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.updateButton.BorderRadius = 7;
            this.updateButton.ButtonText = "Update";
            this.updateButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.updateButton.DisabledColor = System.Drawing.Color.DimGray;
            this.updateButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.updateButton.Iconcolor = System.Drawing.Color.Transparent;
            this.updateButton.Iconimage = null;
            this.updateButton.Iconimage_right = null;
            this.updateButton.Iconimage_right_Selected = null;
            this.updateButton.Iconimage_Selected = null;
            this.updateButton.IconMarginLeft = 0;
            this.updateButton.IconMarginRight = 0;
            this.updateButton.IconRightVisible = false;
            this.updateButton.IconRightZoom = 0D;
            this.updateButton.IconVisible = true;
            this.updateButton.IconZoom = 90D;
            this.updateButton.IsTab = false;
            this.updateButton.Location = new System.Drawing.Point(624, 477);
            this.updateButton.Name = "updateButton";
            this.updateButton.Normalcolor = System.Drawing.Color.Silver;
            this.updateButton.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.updateButton.OnHoverTextColor = System.Drawing.Color.White;
            this.updateButton.selected = false;
            this.updateButton.Size = new System.Drawing.Size(82, 26);
            this.updateButton.TabIndex = 29;
            this.updateButton.Text = "Update";
            this.updateButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.updateButton.Textcolor = System.Drawing.Color.Black;
            this.updateButton.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updateButton.Click += new System.EventHandler(this.updateButton_Click);
            // 
            // othersUpdate
            // 
            this.othersUpdate.AutoSize = true;
            this.othersUpdate.Location = new System.Drawing.Point(650, 420);
            this.othersUpdate.Name = "othersUpdate";
            this.othersUpdate.Size = new System.Drawing.Size(56, 17);
            this.othersUpdate.TabIndex = 28;
            this.othersUpdate.TabStop = true;
            this.othersUpdate.Text = "Others";
            this.othersUpdate.UseVisualStyleBackColor = true;
            // 
            // femaleUpdate
            // 
            this.femaleUpdate.AutoSize = true;
            this.femaleUpdate.Location = new System.Drawing.Point(571, 420);
            this.femaleUpdate.Name = "femaleUpdate";
            this.femaleUpdate.Size = new System.Drawing.Size(59, 17);
            this.femaleUpdate.TabIndex = 27;
            this.femaleUpdate.TabStop = true;
            this.femaleUpdate.Text = "Female";
            this.femaleUpdate.UseVisualStyleBackColor = true;
            // 
            // maleUpdate
            // 
            this.maleUpdate.AutoSize = true;
            this.maleUpdate.Location = new System.Drawing.Point(507, 420);
            this.maleUpdate.Name = "maleUpdate";
            this.maleUpdate.Size = new System.Drawing.Size(48, 17);
            this.maleUpdate.TabIndex = 26;
            this.maleUpdate.TabStop = true;
            this.maleUpdate.Text = "Male";
            this.maleUpdate.UseVisualStyleBackColor = true;
            // 
            // phoneUpdateTextBox
            // 
            this.phoneUpdateTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phoneUpdateTextBox.Location = new System.Drawing.Point(145, 554);
            this.phoneUpdateTextBox.Name = "phoneUpdateTextBox";
            this.phoneUpdateTextBox.Size = new System.Drawing.Size(204, 23);
            this.phoneUpdateTextBox.TabIndex = 24;
            // 
            // passwordUpdateTextBox
            // 
            this.passwordUpdateTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passwordUpdateTextBox.Location = new System.Drawing.Point(145, 482);
            this.passwordUpdateTextBox.Name = "passwordUpdateTextBox";
            this.passwordUpdateTextBox.Size = new System.Drawing.Size(204, 23);
            this.passwordUpdateTextBox.TabIndex = 23;
            // 
            // userNameUpdateTextBox
            // 
            this.userNameUpdateTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userNameUpdateTextBox.Location = new System.Drawing.Point(145, 412);
            this.userNameUpdateTextBox.Name = "userNameUpdateTextBox";
            this.userNameUpdateTextBox.Size = new System.Drawing.Size(204, 23);
            this.userNameUpdateTextBox.TabIndex = 22;
            // 
            // confirmPasswordUpdateTextBox
            // 
            this.confirmPasswordUpdateTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.confirmPasswordUpdateTextBox.Location = new System.Drawing.Point(145, 521);
            this.confirmPasswordUpdateTextBox.Name = "confirmPasswordUpdateTextBox";
            this.confirmPasswordUpdateTextBox.Size = new System.Drawing.Size(204, 23);
            this.confirmPasswordUpdateTextBox.TabIndex = 21;
            // 
            // emailUpdateTextBox
            // 
            this.emailUpdateTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emailUpdateTextBox.Location = new System.Drawing.Point(145, 449);
            this.emailUpdateTextBox.Name = "emailUpdateTextBox";
            this.emailUpdateTextBox.Size = new System.Drawing.Size(204, 23);
            this.emailUpdateTextBox.TabIndex = 25;
            // 
            // nameUpdateTectBox
            // 
            this.nameUpdateTectBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameUpdateTectBox.Location = new System.Drawing.Point(145, 379);
            this.nameUpdateTectBox.Name = "nameUpdateTectBox";
            this.nameUpdateTectBox.Size = new System.Drawing.Size(204, 23);
            this.nameUpdateTectBox.TabIndex = 20;
            // 
            // bgUpdateTextBox
            // 
            this.bgUpdateTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.bgUpdateTextBox.FormattingEnabled = true;
            this.bgUpdateTextBox.Items.AddRange(new object[] {
            "A+",
            "A-",
            "B+",
            "B-",
            "AB+",
            "AB-",
            "O+",
            "O-"});
            this.bgUpdateTextBox.Location = new System.Drawing.Point(529, 385);
            this.bgUpdateTextBox.Name = "bgUpdateTextBox";
            this.bgUpdateTextBox.Size = new System.Drawing.Size(165, 21);
            this.bgUpdateTextBox.TabIndex = 19;
            // 
            // userTypeUpdateComboBox
            // 
            this.userTypeUpdateComboBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.userTypeUpdateComboBox.FormattingEnabled = true;
            this.userTypeUpdateComboBox.Items.AddRange(new object[] {
            "Admin",
            "Teacher",
            "Student"});
            this.userTypeUpdateComboBox.Location = new System.Drawing.Point(128, 338);
            this.userTypeUpdateComboBox.Name = "userTypeUpdateComboBox";
            this.userTypeUpdateComboBox.Size = new System.Drawing.Size(221, 21);
            this.userTypeUpdateComboBox.TabIndex = 18;
            // 
            // bunifuCustomLabel15
            // 
            this.bunifuCustomLabel15.AutoSize = true;
            this.bunifuCustomLabel15.BackColor = System.Drawing.Color.Aqua;
            this.bunifuCustomLabel15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel15.Location = new System.Drawing.Point(422, 423);
            this.bunifuCustomLabel15.Name = "bunifuCustomLabel15";
            this.bunifuCustomLabel15.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuCustomLabel15.Size = new System.Drawing.Size(56, 17);
            this.bunifuCustomLabel15.TabIndex = 16;
            this.bunifuCustomLabel15.Text = "Gender";
            // 
            // bunifuCustomLabel16
            // 
            this.bunifuCustomLabel16.AutoSize = true;
            this.bunifuCustomLabel16.BackColor = System.Drawing.Color.Aqua;
            this.bunifuCustomLabel16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel16.Location = new System.Drawing.Point(422, 389);
            this.bunifuCustomLabel16.Name = "bunifuCustomLabel16";
            this.bunifuCustomLabel16.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuCustomLabel16.Size = new System.Drawing.Size(88, 17);
            this.bunifuCustomLabel16.TabIndex = 15;
            this.bunifuCustomLabel16.Text = "Blood Group";
            // 
            // bunifuCustomLabel17
            // 
            this.bunifuCustomLabel17.AutoSize = true;
            this.bunifuCustomLabel17.BackColor = System.Drawing.Color.Aqua;
            this.bunifuCustomLabel17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel17.Location = new System.Drawing.Point(24, 561);
            this.bunifuCustomLabel17.Name = "bunifuCustomLabel17";
            this.bunifuCustomLabel17.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuCustomLabel17.Size = new System.Drawing.Size(103, 17);
            this.bunifuCustomLabel17.TabIndex = 14;
            this.bunifuCustomLabel17.Text = "Phone Number";
            // 
            // bunifuCustomLabel18
            // 
            this.bunifuCustomLabel18.AutoSize = true;
            this.bunifuCustomLabel18.BackColor = System.Drawing.Color.Aqua;
            this.bunifuCustomLabel18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel18.Location = new System.Drawing.Point(24, 455);
            this.bunifuCustomLabel18.Name = "bunifuCustomLabel18";
            this.bunifuCustomLabel18.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuCustomLabel18.Size = new System.Drawing.Size(42, 17);
            this.bunifuCustomLabel18.TabIndex = 13;
            this.bunifuCustomLabel18.Text = "Email";
            // 
            // bunifuCustomLabel19
            // 
            this.bunifuCustomLabel19.AutoSize = true;
            this.bunifuCustomLabel19.BackColor = System.Drawing.Color.Aqua;
            this.bunifuCustomLabel19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel19.Location = new System.Drawing.Point(24, 491);
            this.bunifuCustomLabel19.Name = "bunifuCustomLabel19";
            this.bunifuCustomLabel19.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuCustomLabel19.Size = new System.Drawing.Size(69, 17);
            this.bunifuCustomLabel19.TabIndex = 12;
            this.bunifuCustomLabel19.Text = "Password";
            // 
            // bunifuCustomLabel20
            // 
            this.bunifuCustomLabel20.AutoSize = true;
            this.bunifuCustomLabel20.BackColor = System.Drawing.Color.Aqua;
            this.bunifuCustomLabel20.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel20.Location = new System.Drawing.Point(24, 524);
            this.bunifuCustomLabel20.Name = "bunifuCustomLabel20";
            this.bunifuCustomLabel20.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuCustomLabel20.Size = new System.Drawing.Size(121, 17);
            this.bunifuCustomLabel20.TabIndex = 11;
            this.bunifuCustomLabel20.Text = "Confirm Password";
            // 
            // bunifuCustomLabel22
            // 
            this.bunifuCustomLabel22.AutoSize = true;
            this.bunifuCustomLabel22.BackColor = System.Drawing.Color.Aqua;
            this.bunifuCustomLabel22.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel22.Location = new System.Drawing.Point(24, 385);
            this.bunifuCustomLabel22.Name = "bunifuCustomLabel22";
            this.bunifuCustomLabel22.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuCustomLabel22.Size = new System.Drawing.Size(45, 17);
            this.bunifuCustomLabel22.TabIndex = 10;
            this.bunifuCustomLabel22.Text = "Name";
            // 
            // bunifuCustomLabel23
            // 
            this.bunifuCustomLabel23.AutoSize = true;
            this.bunifuCustomLabel23.BackColor = System.Drawing.Color.Aqua;
            this.bunifuCustomLabel23.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel23.Location = new System.Drawing.Point(24, 418);
            this.bunifuCustomLabel23.Name = "bunifuCustomLabel23";
            this.bunifuCustomLabel23.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuCustomLabel23.Size = new System.Drawing.Size(79, 17);
            this.bunifuCustomLabel23.TabIndex = 17;
            this.bunifuCustomLabel23.Text = "User Name";
            // 
            // bunifuCustomLabel24
            // 
            this.bunifuCustomLabel24.AutoSize = true;
            this.bunifuCustomLabel24.BackColor = System.Drawing.Color.Aqua;
            this.bunifuCustomLabel24.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel24.Location = new System.Drawing.Point(24, 338);
            this.bunifuCustomLabel24.Name = "bunifuCustomLabel24";
            this.bunifuCustomLabel24.Size = new System.Drawing.Size(74, 17);
            this.bunifuCustomLabel24.TabIndex = 9;
            this.bunifuCustomLabel24.Text = "User Type";
            // 
            // searchInUserSearchPanelButton
            // 
            this.searchInUserSearchPanelButton.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.searchInUserSearchPanelButton.BackColor = System.Drawing.Color.Silver;
            this.searchInUserSearchPanelButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.searchInUserSearchPanelButton.BorderRadius = 7;
            this.searchInUserSearchPanelButton.ButtonText = "Search";
            this.searchInUserSearchPanelButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.searchInUserSearchPanelButton.DisabledColor = System.Drawing.Color.DimGray;
            this.searchInUserSearchPanelButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.searchInUserSearchPanelButton.Iconcolor = System.Drawing.Color.Transparent;
            this.searchInUserSearchPanelButton.Iconimage = null;
            this.searchInUserSearchPanelButton.Iconimage_right = null;
            this.searchInUserSearchPanelButton.Iconimage_right_Selected = null;
            this.searchInUserSearchPanelButton.Iconimage_Selected = null;
            this.searchInUserSearchPanelButton.IconMarginLeft = 0;
            this.searchInUserSearchPanelButton.IconMarginRight = 0;
            this.searchInUserSearchPanelButton.IconRightVisible = false;
            this.searchInUserSearchPanelButton.IconRightZoom = 0D;
            this.searchInUserSearchPanelButton.IconVisible = true;
            this.searchInUserSearchPanelButton.IconZoom = 90D;
            this.searchInUserSearchPanelButton.IsTab = false;
            this.searchInUserSearchPanelButton.Location = new System.Drawing.Point(571, 19);
            this.searchInUserSearchPanelButton.Name = "searchInUserSearchPanelButton";
            this.searchInUserSearchPanelButton.Normalcolor = System.Drawing.Color.Silver;
            this.searchInUserSearchPanelButton.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.searchInUserSearchPanelButton.OnHoverTextColor = System.Drawing.Color.White;
            this.searchInUserSearchPanelButton.selected = false;
            this.searchInUserSearchPanelButton.Size = new System.Drawing.Size(128, 26);
            this.searchInUserSearchPanelButton.TabIndex = 5;
            this.searchInUserSearchPanelButton.Text = "Search";
            this.searchInUserSearchPanelButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.searchInUserSearchPanelButton.Textcolor = System.Drawing.Color.Black;
            this.searchInUserSearchPanelButton.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchInUserSearchPanelButton.Click += new System.EventHandler(this.searchInUserSearchPanelButton_Click);
            // 
            // userSearchDataGrid
            // 
            this.userSearchDataGrid.AllowUserToAddRows = false;
            this.userSearchDataGrid.AllowUserToDeleteRows = false;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.userSearchDataGrid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.userSearchDataGrid.BackgroundColor = System.Drawing.Color.Gainsboro;
            this.userSearchDataGrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.userSearchDataGrid.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.userSearchDataGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.userSearchDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.userSearchDataGrid.DoubleBuffered = true;
            this.userSearchDataGrid.EnableHeadersVisualStyles = false;
            this.userSearchDataGrid.HeaderBgColor = System.Drawing.Color.Blue;
            this.userSearchDataGrid.HeaderForeColor = System.Drawing.Color.White;
            this.userSearchDataGrid.Location = new System.Drawing.Point(3, 70);
            this.userSearchDataGrid.Name = "userSearchDataGrid";
            this.userSearchDataGrid.ReadOnly = true;
            this.userSearchDataGrid.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.userSearchDataGrid.Size = new System.Drawing.Size(775, 240);
            this.userSearchDataGrid.TabIndex = 4;
            this.userSearchDataGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.bunifuCustomDataGrid1_CellClick);
            // 
            // idTextBoxSearch
            // 
            this.idTextBoxSearch.Location = new System.Drawing.Point(425, 19);
            this.idTextBoxSearch.Name = "idTextBoxSearch";
            this.idTextBoxSearch.Size = new System.Drawing.Size(100, 20);
            this.idTextBoxSearch.TabIndex = 3;
            // 
            // nameTextBoxSearch
            // 
            this.nameTextBoxSearch.Location = new System.Drawing.Point(270, 16);
            this.nameTextBoxSearch.Name = "nameTextBoxSearch";
            this.nameTextBoxSearch.Size = new System.Drawing.Size(100, 20);
            this.nameTextBoxSearch.TabIndex = 3;
            // 
            // bunifuCustomLabel13
            // 
            this.bunifuCustomLabel13.AutoSize = true;
            this.bunifuCustomLabel13.BackColor = System.Drawing.Color.Aqua;
            this.bunifuCustomLabel13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel13.Location = new System.Drawing.Point(398, 20);
            this.bunifuCustomLabel13.Name = "bunifuCustomLabel13";
            this.bunifuCustomLabel13.Size = new System.Drawing.Size(21, 17);
            this.bunifuCustomLabel13.TabIndex = 2;
            this.bunifuCustomLabel13.Text = "ID";
            // 
            // bunifuCustomLabel12
            // 
            this.bunifuCustomLabel12.AutoSize = true;
            this.bunifuCustomLabel12.BackColor = System.Drawing.Color.Aqua;
            this.bunifuCustomLabel12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel12.Location = new System.Drawing.Point(219, 19);
            this.bunifuCustomLabel12.Name = "bunifuCustomLabel12";
            this.bunifuCustomLabel12.Size = new System.Drawing.Size(45, 17);
            this.bunifuCustomLabel12.TabIndex = 2;
            this.bunifuCustomLabel12.Text = "Name";
            // 
            // userTypeComboBoxSearch
            // 
            this.userTypeComboBoxSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.userTypeComboBoxSearch.FormattingEnabled = true;
            this.userTypeComboBoxSearch.Items.AddRange(new object[] {
            "All",
            "Admin",
            "Teacher",
            "Student"});
            this.userTypeComboBoxSearch.Location = new System.Drawing.Point(91, 16);
            this.userTypeComboBoxSearch.Name = "userTypeComboBoxSearch";
            this.userTypeComboBoxSearch.Size = new System.Drawing.Size(111, 21);
            this.userTypeComboBoxSearch.TabIndex = 1;
            // 
            // bunifuCustomLabel21
            // 
            this.bunifuCustomLabel21.AutoSize = true;
            this.bunifuCustomLabel21.BackColor = System.Drawing.Color.Aqua;
            this.bunifuCustomLabel21.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel21.Location = new System.Drawing.Point(11, 16);
            this.bunifuCustomLabel21.Name = "bunifuCustomLabel21";
            this.bunifuCustomLabel21.Size = new System.Drawing.Size(74, 17);
            this.bunifuCustomLabel21.TabIndex = 0;
            this.bunifuCustomLabel21.Text = "User Type";
            // 
            // sectionButton
            // 
            this.sectionButton.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.sectionButton.BackColor = System.Drawing.Color.Silver;
            this.sectionButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.sectionButton.BorderRadius = 7;
            this.sectionButton.ButtonText = "Sections";
            this.sectionButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.sectionButton.DisabledColor = System.Drawing.Color.DimGray;
            this.sectionButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.sectionButton.Iconcolor = System.Drawing.Color.Transparent;
            this.sectionButton.Iconimage = null;
            this.sectionButton.Iconimage_right = null;
            this.sectionButton.Iconimage_right_Selected = null;
            this.sectionButton.Iconimage_Selected = null;
            this.sectionButton.IconMarginLeft = 0;
            this.sectionButton.IconMarginRight = 0;
            this.sectionButton.IconRightVisible = false;
            this.sectionButton.IconRightZoom = 0D;
            this.sectionButton.IconVisible = true;
            this.sectionButton.IconZoom = 90D;
            this.sectionButton.IsTab = false;
            this.sectionButton.Location = new System.Drawing.Point(691, 3);
            this.sectionButton.Name = "sectionButton";
            this.sectionButton.Normalcolor = System.Drawing.Color.Silver;
            this.sectionButton.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.sectionButton.OnHoverTextColor = System.Drawing.Color.White;
            this.sectionButton.selected = false;
            this.sectionButton.Size = new System.Drawing.Size(128, 26);
            this.sectionButton.TabIndex = 0;
            this.sectionButton.Text = "Sections";
            this.sectionButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.sectionButton.Textcolor = System.Drawing.Color.Black;
            this.sectionButton.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sectionButton.Click += new System.EventHandler(this.sectionButton_click);
            // 
            // userButton
            // 
            this.userButton.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.userButton.BackColor = System.Drawing.Color.Silver;
            this.userButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.userButton.BorderRadius = 7;
            this.userButton.ButtonText = "Users";
            this.userButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.userButton.DisabledColor = System.Drawing.Color.DimGray;
            this.userButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.userButton.Iconcolor = System.Drawing.Color.Transparent;
            this.userButton.Iconimage = null;
            this.userButton.Iconimage_right = null;
            this.userButton.Iconimage_right_Selected = null;
            this.userButton.Iconimage_Selected = null;
            this.userButton.IconMarginLeft = 0;
            this.userButton.IconMarginRight = 0;
            this.userButton.IconRightVisible = false;
            this.userButton.IconRightZoom = 0D;
            this.userButton.IconVisible = true;
            this.userButton.IconZoom = 90D;
            this.userButton.IsTab = false;
            this.userButton.Location = new System.Drawing.Point(557, 3);
            this.userButton.Name = "userButton";
            this.userButton.Normalcolor = System.Drawing.Color.Silver;
            this.userButton.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.userButton.OnHoverTextColor = System.Drawing.Color.White;
            this.userButton.selected = false;
            this.userButton.Size = new System.Drawing.Size(128, 26);
            this.userButton.TabIndex = 0;
            this.userButton.Text = "Users";
            this.userButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.userButton.Textcolor = System.Drawing.Color.Black;
            this.userButton.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userButton.Click += new System.EventHandler(this.userButton_Click);
            // 
            // academicYearButton
            // 
            this.academicYearButton.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.academicYearButton.BackColor = System.Drawing.Color.Silver;
            this.academicYearButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.academicYearButton.BorderRadius = 7;
            this.academicYearButton.ButtonText = "Academic Year";
            this.academicYearButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.academicYearButton.DisabledColor = System.Drawing.Color.DimGray;
            this.academicYearButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.academicYearButton.Iconcolor = System.Drawing.Color.Transparent;
            this.academicYearButton.Iconimage = null;
            this.academicYearButton.Iconimage_right = null;
            this.academicYearButton.Iconimage_right_Selected = null;
            this.academicYearButton.Iconimage_Selected = null;
            this.academicYearButton.IconMarginLeft = 0;
            this.academicYearButton.IconMarginRight = 0;
            this.academicYearButton.IconRightVisible = false;
            this.academicYearButton.IconRightZoom = 0D;
            this.academicYearButton.IconVisible = true;
            this.academicYearButton.IconZoom = 90D;
            this.academicYearButton.IsTab = false;
            this.academicYearButton.Location = new System.Drawing.Point(423, 3);
            this.academicYearButton.Name = "academicYearButton";
            this.academicYearButton.Normalcolor = System.Drawing.Color.Silver;
            this.academicYearButton.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.academicYearButton.OnHoverTextColor = System.Drawing.Color.White;
            this.academicYearButton.selected = false;
            this.academicYearButton.Size = new System.Drawing.Size(128, 26);
            this.academicYearButton.TabIndex = 0;
            this.academicYearButton.Text = "Academic Year";
            this.academicYearButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.academicYearButton.Textcolor = System.Drawing.Color.Black;
            this.academicYearButton.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.academicYearButton.Click += new System.EventHandler(this.academicYearButton_Click);
            // 
            // academicYearPanel
            // 
            this.academicYearPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.academicYearPanel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("academicYearPanel.BackgroundImage")));
            this.academicYearPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.academicYearPanel.Controls.Add(this.academicYearTextBox);
            this.academicYearPanel.Controls.Add(this.bunifuCustomLabel1);
            this.academicYearPanel.Controls.Add(this.addAcademicYearButton);
            this.academicYearPanel.GradientBottomLeft = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.academicYearPanel.GradientBottomRight = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.academicYearPanel.GradientTopLeft = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.academicYearPanel.GradientTopRight = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.academicYearPanel.Location = new System.Drawing.Point(16, 6);
            this.academicYearPanel.Name = "academicYearPanel";
            this.academicYearPanel.Quality = 10;
            this.academicYearPanel.Size = new System.Drawing.Size(34, 29);
            this.academicYearPanel.TabIndex = 1;
            // 
            // academicYearTextBox
            // 
            this.academicYearTextBox.BorderColor = System.Drawing.Color.SeaGreen;
            this.academicYearTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.academicYearTextBox.Location = new System.Drawing.Point(171, 55);
            this.academicYearTextBox.Name = "academicYearTextBox";
            this.academicYearTextBox.Size = new System.Drawing.Size(155, 26);
            this.academicYearTextBox.TabIndex = 1;
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(36, 56);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(129, 20);
            this.bunifuCustomLabel1.TabIndex = 0;
            this.bunifuCustomLabel1.Text = "Academic Year : ";
            // 
            // addAcademicYearButton
            // 
            this.addAcademicYearButton.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.addAcademicYearButton.BackColor = System.Drawing.Color.Silver;
            this.addAcademicYearButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.addAcademicYearButton.BorderRadius = 7;
            this.addAcademicYearButton.ButtonText = "Add";
            this.addAcademicYearButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.addAcademicYearButton.DisabledColor = System.Drawing.Color.DimGray;
            this.addAcademicYearButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.addAcademicYearButton.Iconcolor = System.Drawing.Color.Transparent;
            this.addAcademicYearButton.Iconimage = null;
            this.addAcademicYearButton.Iconimage_right = null;
            this.addAcademicYearButton.Iconimage_right_Selected = null;
            this.addAcademicYearButton.Iconimage_Selected = null;
            this.addAcademicYearButton.IconMarginLeft = 0;
            this.addAcademicYearButton.IconMarginRight = 0;
            this.addAcademicYearButton.IconRightVisible = false;
            this.addAcademicYearButton.IconRightZoom = 0D;
            this.addAcademicYearButton.IconVisible = true;
            this.addAcademicYearButton.IconZoom = 90D;
            this.addAcademicYearButton.IsTab = false;
            this.addAcademicYearButton.Location = new System.Drawing.Point(198, 139);
            this.addAcademicYearButton.Name = "addAcademicYearButton";
            this.addAcademicYearButton.Normalcolor = System.Drawing.Color.Silver;
            this.addAcademicYearButton.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.addAcademicYearButton.OnHoverTextColor = System.Drawing.Color.White;
            this.addAcademicYearButton.selected = false;
            this.addAcademicYearButton.Size = new System.Drawing.Size(87, 26);
            this.addAcademicYearButton.TabIndex = 0;
            this.addAcademicYearButton.Text = "Add";
            this.addAcademicYearButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.addAcademicYearButton.Textcolor = System.Drawing.Color.Black;
            this.addAcademicYearButton.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addAcademicYearButton.Click += new System.EventHandler(this.academicYearButton_Click);
            // 
            // studentMenuButton
            // 
            this.studentMenuButton.Activecolor = System.Drawing.Color.Silver;
            this.studentMenuButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(48)))), ((int)(((byte)(146)))));
            this.studentMenuButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.studentMenuButton.BorderRadius = 0;
            this.studentMenuButton.ButtonText = "Students";
            this.studentMenuButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.studentMenuButton.DisabledColor = System.Drawing.Color.Gray;
            this.studentMenuButton.Iconcolor = System.Drawing.Color.Transparent;
            this.studentMenuButton.Iconimage = null;
            this.studentMenuButton.Iconimage_right = null;
            this.studentMenuButton.Iconimage_right_Selected = null;
            this.studentMenuButton.Iconimage_Selected = null;
            this.studentMenuButton.IconMarginLeft = 0;
            this.studentMenuButton.IconMarginRight = 0;
            this.studentMenuButton.IconRightVisible = true;
            this.studentMenuButton.IconRightZoom = 0D;
            this.studentMenuButton.IconVisible = true;
            this.studentMenuButton.IconZoom = 90D;
            this.studentMenuButton.IsTab = false;
            this.studentMenuButton.Location = new System.Drawing.Point(0, 112);
            this.studentMenuButton.Name = "studentMenuButton";
            this.studentMenuButton.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(48)))), ((int)(((byte)(146)))));
            this.studentMenuButton.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(48)))), ((int)(((byte)(146)))));
            this.studentMenuButton.OnHoverTextColor = System.Drawing.Color.White;
            this.studentMenuButton.selected = false;
            this.studentMenuButton.Size = new System.Drawing.Size(182, 33);
            this.studentMenuButton.TabIndex = 0;
            this.studentMenuButton.Text = "Students";
            this.studentMenuButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.studentMenuButton.Textcolor = System.Drawing.Color.White;
            this.studentMenuButton.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentMenuButton.Click += new System.EventHandler(this.studentMenuButton_Click);
            // 
            // administratorsMenuButton
            // 
            this.administratorsMenuButton.Activecolor = System.Drawing.Color.Silver;
            this.administratorsMenuButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(48)))), ((int)(((byte)(146)))));
            this.administratorsMenuButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.administratorsMenuButton.BorderRadius = 0;
            this.administratorsMenuButton.ButtonText = "Administrators";
            this.administratorsMenuButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.administratorsMenuButton.DisabledColor = System.Drawing.Color.Gray;
            this.administratorsMenuButton.Iconcolor = System.Drawing.Color.Transparent;
            this.administratorsMenuButton.Iconimage = null;
            this.administratorsMenuButton.Iconimage_right = null;
            this.administratorsMenuButton.Iconimage_right_Selected = null;
            this.administratorsMenuButton.Iconimage_Selected = null;
            this.administratorsMenuButton.IconMarginLeft = 0;
            this.administratorsMenuButton.IconMarginRight = 0;
            this.administratorsMenuButton.IconRightVisible = false;
            this.administratorsMenuButton.IconRightZoom = 0D;
            this.administratorsMenuButton.IconVisible = true;
            this.administratorsMenuButton.IconZoom = 90D;
            this.administratorsMenuButton.IsTab = false;
            this.administratorsMenuButton.Location = new System.Drawing.Point(3, 51);
            this.administratorsMenuButton.Name = "administratorsMenuButton";
            this.administratorsMenuButton.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(48)))), ((int)(((byte)(146)))));
            this.administratorsMenuButton.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(48)))), ((int)(((byte)(146)))));
            this.administratorsMenuButton.OnHoverTextColor = System.Drawing.Color.White;
            this.administratorsMenuButton.selected = false;
            this.administratorsMenuButton.Size = new System.Drawing.Size(179, 33);
            this.administratorsMenuButton.TabIndex = 0;
            this.administratorsMenuButton.Text = "Administrators";
            this.administratorsMenuButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.administratorsMenuButton.Textcolor = System.Drawing.Color.White;
            this.administratorsMenuButton.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.administratorsMenuButton.Click += new System.EventHandler(this.administratorsMenuButton_Click);
            // 
            // Id
            // 
            this.Id.HeaderText = "ID";
            this.Id.Name = "Id";
            this.Id.ReadOnly = true;
            // 
            // BloodGroup
            // 
            this.BloodGroup.HeaderText = "Blood Group";
            this.BloodGroup.Name = "BloodGroup";
            this.BloodGroup.ReadOnly = true;
            // 
            // Gender
            // 
            this.Gender.HeaderText = "Gender";
            this.Gender.Name = "Gender";
            this.Gender.ReadOnly = true;
            // 
            // DOB
            // 
            this.DOB.HeaderText = "Date of Birth";
            this.DOB.Name = "DOB";
            this.DOB.ReadOnly = true;
            // 
            // usersFullName
            // 
            this.usersFullName.HeaderText = "Name";
            this.usersFullName.Name = "usersFullName";
            this.usersFullName.ReadOnly = true;
            // 
            // UserName
            // 
            this.UserName.HeaderText = "User Name";
            this.UserName.Name = "UserName";
            this.UserName.ReadOnly = true;
            // 
            // Email
            // 
            this.Email.HeaderText = "Email";
            this.Email.Name = "Email";
            this.Email.ReadOnly = true;
            // 
            // Password
            // 
            this.Password.HeaderText = "Password";
            this.Password.Name = "Password";
            this.Password.ReadOnly = true;
            // 
            // Phone
            // 
            this.Phone.HeaderText = "Phone Number";
            this.Phone.Name = "Phone";
            this.Phone.ReadOnly = true;
            // 
            // attendancePanel
            // 
            this.attendancePanel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("attendancePanel.BackgroundImage")));
            this.attendancePanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.attendancePanel.Controls.Add(this.attendanceStudentPanel);
            this.attendancePanel.Controls.Add(this.attendanceStudentButton);
            this.attendancePanel.GradientBottomLeft = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.attendancePanel.GradientBottomRight = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.attendancePanel.GradientTopLeft = System.Drawing.Color.White;
            this.attendancePanel.GradientTopRight = System.Drawing.Color.White;
            this.attendancePanel.Location = new System.Drawing.Point(206, 180);
            this.attendancePanel.Name = "attendancePanel";
            this.attendancePanel.Quality = 10;
            this.attendancePanel.Size = new System.Drawing.Size(67, 35);
            this.attendancePanel.TabIndex = 3;
            this.attendancePanel.Visible = false;
            // 
            // attendanceStudentPanel
            // 
            this.attendanceStudentPanel.AutoScroll = true;
            this.attendanceStudentPanel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("attendanceStudentPanel.BackgroundImage")));
            this.attendanceStudentPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.attendanceStudentPanel.Controls.Add(this.attendanceStudentSectionComboBox);
            this.attendanceStudentPanel.Controls.Add(this.label35);
            this.attendanceStudentPanel.Controls.Add(this.attendanceStudentClassComboBox);
            this.attendanceStudentPanel.Controls.Add(this.attendanceStudentSearchButton);
            this.attendanceStudentPanel.Controls.Add(this.label72);
            this.attendanceStudentPanel.Controls.Add(this.attendanceStudentDataGrid);
            this.attendanceStudentPanel.GradientBottomLeft = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.attendanceStudentPanel.GradientBottomRight = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.attendanceStudentPanel.GradientTopLeft = System.Drawing.Color.White;
            this.attendanceStudentPanel.GradientTopRight = System.Drawing.Color.White;
            this.attendanceStudentPanel.Location = new System.Drawing.Point(15, 44);
            this.attendanceStudentPanel.Name = "attendanceStudentPanel";
            this.attendanceStudentPanel.Quality = 10;
            this.attendanceStudentPanel.Size = new System.Drawing.Size(751, 372);
            this.attendanceStudentPanel.TabIndex = 6;
            this.attendanceStudentPanel.Visible = false;
            // 
            // attendanceStudentSectionComboBox
            // 
            this.attendanceStudentSectionComboBox.FormattingEnabled = true;
            this.attendanceStudentSectionComboBox.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Others"});
            this.attendanceStudentSectionComboBox.Location = new System.Drawing.Point(383, 30);
            this.attendanceStudentSectionComboBox.Name = "attendanceStudentSectionComboBox";
            this.attendanceStudentSectionComboBox.Size = new System.Drawing.Size(151, 21);
            this.attendanceStudentSectionComboBox.TabIndex = 67;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(329, 33);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(48, 15);
            this.label35.TabIndex = 66;
            this.label35.Text = "Section";
            // 
            // attendanceStudentClassComboBox
            // 
            this.attendanceStudentClassComboBox.FormattingEnabled = true;
            this.attendanceStudentClassComboBox.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Others"});
            this.attendanceStudentClassComboBox.Location = new System.Drawing.Point(127, 30);
            this.attendanceStudentClassComboBox.Name = "attendanceStudentClassComboBox";
            this.attendanceStudentClassComboBox.Size = new System.Drawing.Size(151, 21);
            this.attendanceStudentClassComboBox.TabIndex = 63;
            // 
            // attendanceStudentSearchButton
            // 
            this.attendanceStudentSearchButton.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.attendanceStudentSearchButton.BackColor = System.Drawing.Color.Silver;
            this.attendanceStudentSearchButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.attendanceStudentSearchButton.BorderRadius = 7;
            this.attendanceStudentSearchButton.ButtonText = "Search";
            this.attendanceStudentSearchButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.attendanceStudentSearchButton.DisabledColor = System.Drawing.Color.DimGray;
            this.attendanceStudentSearchButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.attendanceStudentSearchButton.Iconcolor = System.Drawing.Color.Transparent;
            this.attendanceStudentSearchButton.Iconimage = null;
            this.attendanceStudentSearchButton.Iconimage_right = null;
            this.attendanceStudentSearchButton.Iconimage_right_Selected = null;
            this.attendanceStudentSearchButton.Iconimage_Selected = null;
            this.attendanceStudentSearchButton.IconMarginLeft = 0;
            this.attendanceStudentSearchButton.IconMarginRight = 0;
            this.attendanceStudentSearchButton.IconRightVisible = false;
            this.attendanceStudentSearchButton.IconRightZoom = 0D;
            this.attendanceStudentSearchButton.IconVisible = true;
            this.attendanceStudentSearchButton.IconZoom = 90D;
            this.attendanceStudentSearchButton.IsTab = false;
            this.attendanceStudentSearchButton.Location = new System.Drawing.Point(612, 25);
            this.attendanceStudentSearchButton.Name = "attendanceStudentSearchButton";
            this.attendanceStudentSearchButton.Normalcolor = System.Drawing.Color.Silver;
            this.attendanceStudentSearchButton.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.attendanceStudentSearchButton.OnHoverTextColor = System.Drawing.Color.White;
            this.attendanceStudentSearchButton.selected = false;
            this.attendanceStudentSearchButton.Size = new System.Drawing.Size(128, 26);
            this.attendanceStudentSearchButton.TabIndex = 62;
            this.attendanceStudentSearchButton.Text = "Search";
            this.attendanceStudentSearchButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.attendanceStudentSearchButton.Textcolor = System.Drawing.Color.Black;
            this.attendanceStudentSearchButton.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label72.Location = new System.Drawing.Point(47, 33);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(74, 15);
            this.label72.TabIndex = 60;
            this.label72.Text = "Class Name";
            // 
            // attendanceStudentDataGrid
            // 
            this.attendanceStudentDataGrid.AllowUserToAddRows = false;
            this.attendanceStudentDataGrid.AllowUserToDeleteRows = false;
            this.attendanceStudentDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.attendanceStudentDataGrid.Location = new System.Drawing.Point(4, 76);
            this.attendanceStudentDataGrid.Name = "attendanceStudentDataGrid";
            this.attendanceStudentDataGrid.ReadOnly = true;
            this.attendanceStudentDataGrid.Size = new System.Drawing.Size(747, 236);
            this.attendanceStudentDataGrid.TabIndex = 0;
            // 
            // attendanceStudentButton
            // 
            this.attendanceStudentButton.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.attendanceStudentButton.BackColor = System.Drawing.Color.Silver;
            this.attendanceStudentButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.attendanceStudentButton.BorderRadius = 7;
            this.attendanceStudentButton.ButtonText = "Student Attendance";
            this.attendanceStudentButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.attendanceStudentButton.DisabledColor = System.Drawing.Color.DimGray;
            this.attendanceStudentButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.attendanceStudentButton.Iconcolor = System.Drawing.Color.Transparent;
            this.attendanceStudentButton.Iconimage = null;
            this.attendanceStudentButton.Iconimage_right = null;
            this.attendanceStudentButton.Iconimage_right_Selected = null;
            this.attendanceStudentButton.Iconimage_Selected = null;
            this.attendanceStudentButton.IconMarginLeft = 0;
            this.attendanceStudentButton.IconMarginRight = 0;
            this.attendanceStudentButton.IconRightVisible = false;
            this.attendanceStudentButton.IconRightZoom = 0D;
            this.attendanceStudentButton.IconVisible = true;
            this.attendanceStudentButton.IconZoom = 90D;
            this.attendanceStudentButton.IsTab = false;
            this.attendanceStudentButton.Location = new System.Drawing.Point(638, 3);
            this.attendanceStudentButton.Name = "attendanceStudentButton";
            this.attendanceStudentButton.Normalcolor = System.Drawing.Color.Silver;
            this.attendanceStudentButton.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.attendanceStudentButton.OnHoverTextColor = System.Drawing.Color.White;
            this.attendanceStudentButton.selected = false;
            this.attendanceStudentButton.Size = new System.Drawing.Size(143, 26);
            this.attendanceStudentButton.TabIndex = 2;
            this.attendanceStudentButton.Text = "Student Attendance";
            this.attendanceStudentButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.attendanceStudentButton.Textcolor = System.Drawing.Color.Black;
            this.attendanceStudentButton.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.attendanceStudentButton.Click += new System.EventHandler(this.attendanceStudentButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1013, 489);
            this.Controls.Add(this.attendancePanel);
            this.Controls.Add(this.studentPanel);
            this.Controls.Add(this.tileBarPanel);
            this.Controls.Add(this.administratorPanel);
            this.Controls.Add(this.menu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.tileBarPanel.ResumeLayout(false);
            this.tileBarPanel.PerformLayout();
            this.menu.ResumeLayout(false);
            this.studentPanel.ResumeLayout(false);
            this.studentRegistrationPanel.ResumeLayout(false);
            this.studentRegistrationRegisterPanel.ResumeLayout(false);
            this.studentRegistrationRegisterPanel.PerformLayout();
            this.studentRegistrationSearchPanel.ResumeLayout(false);
            this.studentRegistrationSearchPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.studentRegistrationSearchDataGrid)).EndInit();
            this.studentPromotionPanel.ResumeLayout(false);
            this.studentPromotionPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.administratorPanel.ResumeLayout(false);
            this.sectionPanel.ResumeLayout(false);
            this.sectionSearchPanel.ResumeLayout(false);
            this.sectionSearchPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sectionSearchDataGrid)).EndInit();
            this.sectionAddPanel.ResumeLayout(false);
            this.sectionAddPanel.PerformLayout();
            this.userPanel.ResumeLayout(false);
            this.addUserPanel.ResumeLayout(false);
            this.addUserPanel.PerformLayout();
            this.userSearchPanel.ResumeLayout(false);
            this.userSearchPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.userSearchDataGrid)).EndInit();
            this.academicYearPanel.ResumeLayout(false);
            this.academicYearPanel.PerformLayout();
            this.attendancePanel.ResumeLayout(false);
            this.attendanceStudentPanel.ResumeLayout(false);
            this.attendanceStudentPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.attendanceStudentDataGrid)).EndInit();
            this.ResumeLayout(false);

        }

        

        

        

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
        private Bunifu.Framework.UI.BunifuGradientPanel menu;
        private Bunifu.Framework.UI.BunifuFlatButton administratorsMenuButton;
        private Bunifu.Framework.UI.BunifuFlatButton studentMenuButton;
        private Bunifu.Framework.UI.BunifuGradientPanel administratorPanel;
        private Bunifu.Framework.UI.BunifuGradientPanel studentPanel;
        private Bunifu.Framework.UI.BunifuFlatButton academicYearButton;
        private Bunifu.Framework.UI.BunifuGradientPanel tileBarPanel;
        private Bunifu.Framework.UI.BunifuFlatButton crossButton;
        private Bunifu.Framework.UI.BunifuFlatButton sectionButton;
        private Bunifu.Framework.UI.BunifuFlatButton userButton;
        private Bunifu.Framework.UI.BunifuGradientPanel academicYearPanel;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private WindowsFormsControlLibrary1.BunifuCustomTextbox academicYearTextBox;
        private Bunifu.Framework.UI.BunifuFlatButton addAcademicYearButton;
        private Bunifu.Framework.UI.BunifuGradientPanel userPanel;
        private Bunifu.Framework.UI.BunifuFlatButton searchUserButton;
        private Bunifu.Framework.UI.BunifuFlatButton addUserButton;
        private Bunifu.Framework.UI.BunifuGradientPanel addUserPanel;
        private System.Windows.Forms.TextBox userAddPhoneTextBox;
        private System.Windows.Forms.TextBox userAddPasswordTextBox;
        private System.Windows.Forms.TextBox userAddUsernameTextBox;
        private System.Windows.Forms.TextBox userAddConfirmPasswordTextBox;
        private System.Windows.Forms.TextBox userAddEmailTextBox;
        private System.Windows.Forms.TextBox userAddNameTextBox;
        private System.Windows.Forms.ComboBox userTypeComboBox;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel9;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel6;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel8;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel7;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel4;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel5;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel3;
        private System.Windows.Forms.ComboBox bgComboBox;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel11;
        private Bunifu.Framework.UI.BunifuCustomLabel bgLabel;
        private Bunifu.Framework.UI.BunifuFlatButton doneAddUserButton;
        private System.Windows.Forms.RadioButton othersRadioButton;
        private System.Windows.Forms.RadioButton femaleRadioButton;
        private System.Windows.Forms.RadioButton maleRadioButton;
        private Bunifu.Framework.UI.BunifuGradientPanel userSearchPanel;
        private System.Windows.Forms.TextBox nameTextBoxSearch;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel12;
        private System.Windows.Forms.ComboBox userTypeComboBoxSearch;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel21;
        private Bunifu.Framework.UI.BunifuCustomDataGrid userSearchDataGrid;
        private System.Windows.Forms.TextBox idTextBoxSearch;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel13;
        private Bunifu.Framework.UI.BunifuFlatButton deleteButton;
        private System.Windows.Forms.DateTimePicker datePickerUserUpdate;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel14;
        private Bunifu.Framework.UI.BunifuFlatButton updateButton;
        private System.Windows.Forms.RadioButton othersUpdate;
        private System.Windows.Forms.RadioButton femaleUpdate;
        private System.Windows.Forms.RadioButton maleUpdate;
        private System.Windows.Forms.TextBox phoneUpdateTextBox;
        private System.Windows.Forms.TextBox passwordUpdateTextBox;
        private System.Windows.Forms.TextBox userNameUpdateTextBox;
        private System.Windows.Forms.TextBox confirmPasswordUpdateTextBox;
        private System.Windows.Forms.TextBox emailUpdateTextBox;
        private System.Windows.Forms.TextBox nameUpdateTectBox;
        private System.Windows.Forms.ComboBox bgUpdateTextBox;
        private System.Windows.Forms.ComboBox userTypeUpdateComboBox;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel15;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel16;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel17;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel18;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel19;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel20;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel22;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel23;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel24;
        private Bunifu.Framework.UI.BunifuFlatButton searchInUserSearchPanelButton;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id;
        private System.Windows.Forms.DataGridViewTextBoxColumn BloodGroup;
        private System.Windows.Forms.DataGridViewTextBoxColumn Gender;
        private System.Windows.Forms.DataGridViewTextBoxColumn DOB;
        private System.Windows.Forms.DataGridViewTextBoxColumn usersFullName;
        private System.Windows.Forms.DataGridViewTextBoxColumn UserName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Email;
        private System.Windows.Forms.DataGridViewTextBoxColumn Password;
        private System.Windows.Forms.DataGridViewTextBoxColumn Phone;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel10;
        private Bunifu.Framework.UI.BunifuGradientPanel sectionPanel;
        private Bunifu.Framework.UI.BunifuFlatButton sectionSearchButton;
        private Bunifu.Framework.UI.BunifuFlatButton sectionAddButton;
        private Bunifu.Framework.UI.BunifuGradientPanel sectionAddPanel;
        private System.Windows.Forms.ComboBox classSectionAddComboBox;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel25;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel27;
        private System.Windows.Forms.TextBox sectionNameSectionAddTextBox;
        private Bunifu.Framework.UI.BunifuFlatButton sectionAddDoneButton;
        private System.Windows.Forms.ComboBox departmentSectionAddComboBox;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel26;
        private Bunifu.Framework.UI.BunifuGradientPanel sectionSearchPanel;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel28;
        private System.Windows.Forms.TextBox sectionSearchSectionNameTextBox;
        private System.Windows.Forms.ComboBox sectionSearchDepartmentComboBox;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel29;
        private System.Windows.Forms.ComboBox sectionSearchClassComboBox;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel30;
        private Bunifu.Framework.UI.BunifuFlatButton sectionSearchSearchButton;
        private Bunifu.Framework.UI.BunifuFlatButton sectionSearchUpdateButton;
        private Bunifu.Framework.UI.BunifuFlatButton sectionSearchDeleteButton;
        private Bunifu.Framework.UI.BunifuCustomDataGrid sectionSearchDataGrid;
        private System.Windows.Forms.DataGridViewTextBoxColumn className;
        private System.Windows.Forms.DataGridViewTextBoxColumn section;
        private System.Windows.Forms.DataGridViewTextBoxColumn department;
        private Bunifu.Framework.UI.BunifuCustomLabel path;
        private Bunifu.Framework.UI.BunifuFlatButton studentPromotion;
        private Bunifu.Framework.UI.BunifuFlatButton studentRegistrationButton;
        private Bunifu.Framework.UI.BunifuGradientPanel studentRegistrationPanel;
        private Bunifu.Framework.UI.BunifuFlatButton studentRegistrationSearchButton;
        private Bunifu.Framework.UI.BunifuFlatButton studentRegistrationRegisterButton;
        private Bunifu.Framework.UI.BunifuGradientPanel studentRegistrationRegisterPanel;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label8;
        private Bunifu.Framework.UI.BunifuGradientPanel studentRegistrationSearchPanel;
        private System.Windows.Forms.DataGridView studentRegistrationSearchDataGrid;
        private Bunifu.Framework.UI.BunifuFlatButton studentRegistrationRegisterSubmitButton;
        private System.Windows.Forms.DateTimePicker studentRegistrationRegisterDOB;
        private System.Windows.Forms.DateTimePicker studentRegistrationRegisterAdmissionDate;
        private System.Windows.Forms.ComboBox studentRegistrationRegisterDepartmentComboBox;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox studentRegistrationRegisterSectionComboBox;
        private System.Windows.Forms.ComboBox studentRegistrationRegisterClassComboBox;
        private System.Windows.Forms.ComboBox studentRegistrationRegisterGenderComboBox;
        private System.Windows.Forms.RichTextBox studentRegistrationRegisterAddressTextBox;
        private System.Windows.Forms.TextBox studentRegistrationRegisterEmailTextBox;
        private System.Windows.Forms.TextBox studentRegistrationRegisterPhoneTextBox;
        private System.Windows.Forms.TextBox studentRegistrationRegisterMotherOccupationTextBox;
        private System.Windows.Forms.TextBox studentRegistrationRegisterMotherNameTextBox;
        private System.Windows.Forms.TextBox studentRegistrationRegisterFatherOccupationTextBox;
        private System.Windows.Forms.TextBox studentRegistrationRegisterFatherNameTextBox;
        private System.Windows.Forms.TextBox studentRegistrationRegisterNameTextBox;
        private System.Windows.Forms.TextBox studentRegistrationRegisterAdmissionNumberTextBox;
        private System.Windows.Forms.Label label15;
        private Bunifu.Framework.UI.BunifuFlatButton studentRegistrationSearchUpdateButton;
        private Bunifu.Framework.UI.BunifuFlatButton studentRegistrationSearchDeleteButton;
        private System.Windows.Forms.DateTimePicker studentRegistrationSearchDOBUpdate;
        private System.Windows.Forms.DateTimePicker studentRegistrationSearchAdmissionDateUpdate;
        private System.Windows.Forms.ComboBox studentRegistrationSearchDepartmentUpdateComboBox;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox studentRegistrationSearchSectionUpdateComboBox;
        private System.Windows.Forms.ComboBox studentRegistrationSearchClassUpdateComboBox;
        private System.Windows.Forms.ComboBox studentRegistrationSearchGenderUpdateComboBox;
        private System.Windows.Forms.RichTextBox studentRegistrationSearchAddressUpdateTextBox;
        private System.Windows.Forms.TextBox studentRegistrationSearchEmailUpdateTextBox;
        private System.Windows.Forms.TextBox studentRegistrationSearchPhoneUpdateTextBox;
        private System.Windows.Forms.TextBox studentRegistrationSearchMotherOccupationUpdateTextBox;
        private System.Windows.Forms.TextBox studentRegistrationSearchMotherNameUpdateTextBox;
        private System.Windows.Forms.TextBox studentRegistrationSearchFatherOccupationUpdateTextBox;
        private System.Windows.Forms.TextBox studentRegistrationSearchFatherNameUpdateTextBox;
        private System.Windows.Forms.TextBox studentRegistrationSearchNameUpdateTextBox;
        private System.Windows.Forms.TextBox studentRegistrationSearchAdmissionNumberUpdateTextBox;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private Bunifu.Framework.UI.BunifuFlatButton studentRegistrationSearchSearchButton;
        private System.Windows.Forms.TextBox studentRegistrationSearchIDTextBox;
        private System.Windows.Forms.Label label33;
        private Bunifu.Framework.UI.BunifuGradientPanel studentPromotionPanel;
        private System.Windows.Forms.ComboBox studentPromotionClassUpdateComboBox;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.ComboBox studentPromotionClassComboBox;
        private Bunifu.Framework.UI.BunifuFlatButton studentPromotionSearchButton;
        private System.Windows.Forms.Label label50;
        private Bunifu.Framework.UI.BunifuFlatButton studentPromotionPromoteButton;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label34;
        private Bunifu.Framework.UI.BunifuGradientPanel attendancePanel;
        private Bunifu.Framework.UI.BunifuGradientPanel attendanceStudentPanel;
        private System.Windows.Forms.ComboBox attendanceStudentSectionComboBox;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.ComboBox attendanceStudentClassComboBox;
        private Bunifu.Framework.UI.BunifuFlatButton attendanceStudentSearchButton;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.DataGridView attendanceStudentDataGrid;
        private Bunifu.Framework.UI.BunifuFlatButton attendanceStudentButton;
        private Bunifu.Framework.UI.BunifuFlatButton attendanceMenuButton;
    }
}

