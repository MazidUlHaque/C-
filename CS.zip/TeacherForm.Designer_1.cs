﻿namespace Projectwork111
{
    partial class TeacherForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TeacherForm));
            this.menu = new System.Windows.Forms.Panel();
            this.profileMenuButton = new System.Windows.Forms.Button();
            this.LogoutBotton = new System.Windows.Forms.Button();
            this.termExamMenuButton = new System.Windows.Forms.Button();
            this.examMenuButton = new System.Windows.Forms.Button();
            this.attendanceMenuButton = new System.Windows.Forms.Button();
            this.attendancePanel = new System.Windows.Forms.Panel();
            this.attendanceUpdateAttendanceButton = new System.Windows.Forms.Button();
            this.attendanceUpdatePanel = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.attendanceUpdateData2 = new System.Windows.Forms.DataGridView();
            this.attendanceUpdateComboBox = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.attendanceUpdateUpdateButton = new System.Windows.Forms.Button();
            this.attendanceUpdateDate = new System.Windows.Forms.DateTimePicker();
            this.attendanceUpdateSearchButton = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.attendanceUpdateDataGrid = new System.Windows.Forms.DataGridView();
            this.dataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.attendanceStudentPanel = new System.Windows.Forms.Panel();
            this.attendanceDoneButton = new System.Windows.Forms.Button();
            this.attendanceStudentClassComboBox = new System.Windows.Forms.ComboBox();
            this.attendanceStudentSearchButton = new System.Windows.Forms.Button();
            this.label72 = new System.Windows.Forms.Label();
            this.attendanceStudentDataGrid = new System.Windows.Forms.DataGridView();
            this.checkBox = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.attendanceStudentButton = new System.Windows.Forms.Button();
            this.examUploadMarksPanel = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.examUploadMarksSubmitButton = new System.Windows.Forms.Button();
            this.examUploadMarksTextBox = new System.Windows.Forms.TextBox();
            this.examUploadMarksExamDataGrid = new System.Windows.Forms.DataGridView();
            this.examUploadMarksDataGrid = new System.Windows.Forms.DataGridView();
            this.tileBarPanel = new System.Windows.Forms.Panel();
            this.crossButton = new System.Windows.Forms.Button();
            this.examPanel = new System.Windows.Forms.Panel();
            this.examCreateExamPanel = new System.Windows.Forms.Panel();
            this.examCreateExamUpdateButton = new System.Windows.Forms.Button();
            this.examCreateExamDeleteButton = new System.Windows.Forms.Button();
            this.examCreateExamDataGridView = new System.Windows.Forms.DataGridView();
            this.label6 = new System.Windows.Forms.Label();
            this.examCreateExamSubmitBotton = new System.Windows.Forms.Button();
            this.examCreateExamDate = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.examCreateExamDepartmentComboBox = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.examCreateExamExamNameTextBox = new System.Windows.Forms.TextBox();
            this.examCreateExamClassNameComboBox = new System.Windows.Forms.ComboBox();
            this.examCreateExamButton = new System.Windows.Forms.Button();
            this.examUploadMarkButton = new System.Windows.Forms.Button();
            this.termExamPanel = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.termExamMarkSubmitButton = new System.Windows.Forms.Button();
            this.termExamMarkTextBox = new System.Windows.Forms.TextBox();
            this.termExamDataGrid = new System.Windows.Forms.DataGridView();
            this.termExamMarksData = new System.Windows.Forms.DataGridView();
            this.profilePanel = new System.Windows.Forms.Panel();
            this.profileDatas = new System.Windows.Forms.DataGridView();
            this.profileGenderTextBox = new System.Windows.Forms.TextBox();
            this.profileRegisterDateTextBox = new System.Windows.Forms.TextBox();
            this.profileSubjectTextBox = new System.Windows.Forms.TextBox();
            this.profileBGTextBox = new System.Windows.Forms.TextBox();
            this.profileDepartmentTextBox = new System.Windows.Forms.TextBox();
            this.profileDOBTextBox = new System.Windows.Forms.TextBox();
            this.label100 = new System.Windows.Forms.Label();
            this.profileStd6 = new System.Windows.Forms.CheckBox();
            this.profileStd10 = new System.Windows.Forms.CheckBox();
            this.profileStd2 = new System.Windows.Forms.CheckBox();
            this.profileStd5 = new System.Windows.Forms.CheckBox();
            this.profileStd8 = new System.Windows.Forms.CheckBox();
            this.profileStd7 = new System.Windows.Forms.CheckBox();
            this.profileStd1 = new System.Windows.Forms.CheckBox();
            this.profileStd3 = new System.Windows.Forms.CheckBox();
            this.profileStd9 = new System.Windows.Forms.CheckBox();
            this.profileNursary = new System.Windows.Forms.CheckBox();
            this.profileStd4 = new System.Windows.Forms.CheckBox();
            this.label76 = new System.Windows.Forms.Label();
            this.profileConfirmPasswordTextBox = new System.Windows.Forms.TextBox();
            this.label68 = new System.Windows.Forms.Label();
            this.profilePasswordTextBox = new System.Windows.Forms.TextBox();
            this.label69 = new System.Windows.Forms.Label();
            this.profileIDTextBox = new System.Windows.Forms.TextBox();
            this.label70 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.teacherAddPictureBox = new System.Windows.Forms.PictureBox();
            this.label73 = new System.Windows.Forms.Label();
            this.profileSubmitButton = new System.Windows.Forms.Button();
            this.label74 = new System.Windows.Forms.Label();
            this.profileAddressTextBox = new System.Windows.Forms.RichTextBox();
            this.profileEmailTextBox = new System.Windows.Forms.TextBox();
            this.profilePhoneTextBox = new System.Windows.Forms.TextBox();
            this.profileNameTextBox = new System.Windows.Forms.TextBox();
            this.label75 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.menu.SuspendLayout();
            this.attendancePanel.SuspendLayout();
            this.attendanceUpdatePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.attendanceUpdateData2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.attendanceUpdateDataGrid)).BeginInit();
            this.attendanceStudentPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.attendanceStudentDataGrid)).BeginInit();
            this.examUploadMarksPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.examUploadMarksExamDataGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.examUploadMarksDataGrid)).BeginInit();
            this.tileBarPanel.SuspendLayout();
            this.examPanel.SuspendLayout();
            this.examCreateExamPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.examCreateExamDataGridView)).BeginInit();
            this.termExamPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.termExamDataGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.termExamMarksData)).BeginInit();
            this.profilePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.profileDatas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacherAddPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // menu
            // 
            this.menu.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("menu.BackgroundImage")));
            this.menu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.menu.Controls.Add(this.profileMenuButton);
            this.menu.Controls.Add(this.LogoutBotton);
            this.menu.Controls.Add(this.termExamMenuButton);
            this.menu.Controls.Add(this.examMenuButton);
            this.menu.Controls.Add(this.attendanceMenuButton);
            this.menu.Dock = System.Windows.Forms.DockStyle.Left;
            this.menu.Location = new System.Drawing.Point(0, 0);
            this.menu.Name = "menu";
            this.menu.Size = new System.Drawing.Size(185, 670);
            this.menu.TabIndex = 1;
            // 
            // profileMenuButton
            // 
            this.profileMenuButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(48)))), ((int)(((byte)(146)))));
            this.profileMenuButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.profileMenuButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.profileMenuButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileMenuButton.ForeColor = System.Drawing.Color.White;
            this.profileMenuButton.Location = new System.Drawing.Point(-1, 327);
            this.profileMenuButton.Name = "profileMenuButton";
            this.profileMenuButton.Size = new System.Drawing.Size(185, 42);
            this.profileMenuButton.TabIndex = 8;
            this.profileMenuButton.Text = "Profile";
            this.profileMenuButton.UseVisualStyleBackColor = false;
            this.profileMenuButton.Click += new System.EventHandler(this.profileMenuButton_Click);
            // 
            // LogoutBotton
            // 
            this.LogoutBotton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(48)))), ((int)(((byte)(146)))));
            this.LogoutBotton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.LogoutBotton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.LogoutBotton.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)), true);
            this.LogoutBotton.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.LogoutBotton.Location = new System.Drawing.Point(3, 582);
            this.LogoutBotton.Name = "LogoutBotton";
            this.LogoutBotton.Size = new System.Drawing.Size(176, 76);
            this.LogoutBotton.TabIndex = 7;
            this.LogoutBotton.Text = "Log Out";
            this.LogoutBotton.UseVisualStyleBackColor = false;
            this.LogoutBotton.Click += new System.EventHandler(this.LogoutBotton_Click);
            // 
            // termExamMenuButton
            // 
            this.termExamMenuButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(48)))), ((int)(((byte)(146)))));
            this.termExamMenuButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.termExamMenuButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.termExamMenuButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.termExamMenuButton.ForeColor = System.Drawing.Color.White;
            this.termExamMenuButton.Location = new System.Drawing.Point(0, 263);
            this.termExamMenuButton.Name = "termExamMenuButton";
            this.termExamMenuButton.Size = new System.Drawing.Size(185, 42);
            this.termExamMenuButton.TabIndex = 6;
            this.termExamMenuButton.Text = "Term Exam";
            this.termExamMenuButton.UseVisualStyleBackColor = false;
            this.termExamMenuButton.Click += new System.EventHandler(this.termExamMenuButton_Click);
            // 
            // examMenuButton
            // 
            this.examMenuButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(48)))), ((int)(((byte)(146)))));
            this.examMenuButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.examMenuButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.examMenuButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.examMenuButton.ForeColor = System.Drawing.Color.White;
            this.examMenuButton.Location = new System.Drawing.Point(0, 205);
            this.examMenuButton.Name = "examMenuButton";
            this.examMenuButton.Size = new System.Drawing.Size(185, 42);
            this.examMenuButton.TabIndex = 5;
            this.examMenuButton.Text = "Class Test";
            this.examMenuButton.UseVisualStyleBackColor = false;
            this.examMenuButton.Click += new System.EventHandler(this.examMenuButton_Click);
            // 
            // attendanceMenuButton
            // 
            this.attendanceMenuButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(48)))), ((int)(((byte)(146)))));
            this.attendanceMenuButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.attendanceMenuButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.attendanceMenuButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.attendanceMenuButton.ForeColor = System.Drawing.Color.White;
            this.attendanceMenuButton.Location = new System.Drawing.Point(0, 148);
            this.attendanceMenuButton.Name = "attendanceMenuButton";
            this.attendanceMenuButton.Size = new System.Drawing.Size(184, 42);
            this.attendanceMenuButton.TabIndex = 3;
            this.attendanceMenuButton.Text = "Attendance";
            this.attendanceMenuButton.UseVisualStyleBackColor = false;
            this.attendanceMenuButton.Click += new System.EventHandler(this.attendanceMenuButton_Click);
            // 
            // attendancePanel
            // 
            this.attendancePanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.attendancePanel.Controls.Add(this.attendanceUpdateAttendanceButton);
            this.attendancePanel.Controls.Add(this.attendanceUpdatePanel);
            this.attendancePanel.Controls.Add(this.attendanceStudentPanel);
            this.attendancePanel.Controls.Add(this.attendanceStudentButton);
            this.attendancePanel.Location = new System.Drawing.Point(191, 29);
            this.attendancePanel.Name = "attendancePanel";
            this.attendancePanel.Size = new System.Drawing.Size(76, 49);
            this.attendancePanel.TabIndex = 4;
            this.attendancePanel.Visible = false;
            // 
            // attendanceUpdateAttendanceButton
            // 
            this.attendanceUpdateAttendanceButton.BackColor = System.Drawing.Color.MistyRose;
            this.attendanceUpdateAttendanceButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.attendanceUpdateAttendanceButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.attendanceUpdateAttendanceButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.attendanceUpdateAttendanceButton.Location = new System.Drawing.Point(898, 0);
            this.attendanceUpdateAttendanceButton.Name = "attendanceUpdateAttendanceButton";
            this.attendanceUpdateAttendanceButton.Size = new System.Drawing.Size(143, 26);
            this.attendanceUpdateAttendanceButton.TabIndex = 8;
            this.attendanceUpdateAttendanceButton.Text = "Update Attendance";
            this.attendanceUpdateAttendanceButton.UseVisualStyleBackColor = false;
            this.attendanceUpdateAttendanceButton.Click += new System.EventHandler(this.attendanceUpdateAttendanceButton_Click);
            // 
            // attendanceUpdatePanel
            // 
            this.attendanceUpdatePanel.AutoScroll = true;
            this.attendanceUpdatePanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.attendanceUpdatePanel.Controls.Add(this.button1);
            this.attendanceUpdatePanel.Controls.Add(this.attendanceUpdateData2);
            this.attendanceUpdatePanel.Controls.Add(this.attendanceUpdateComboBox);
            this.attendanceUpdatePanel.Controls.Add(this.label10);
            this.attendanceUpdatePanel.Controls.Add(this.label9);
            this.attendanceUpdatePanel.Controls.Add(this.attendanceUpdateUpdateButton);
            this.attendanceUpdatePanel.Controls.Add(this.attendanceUpdateDate);
            this.attendanceUpdatePanel.Controls.Add(this.attendanceUpdateSearchButton);
            this.attendanceUpdatePanel.Controls.Add(this.label8);
            this.attendanceUpdatePanel.Controls.Add(this.attendanceUpdateDataGrid);
            this.attendanceUpdatePanel.Location = new System.Drawing.Point(25, 68);
            this.attendanceUpdatePanel.Name = "attendanceUpdatePanel";
            this.attendanceUpdatePanel.Size = new System.Drawing.Size(978, 477);
            this.attendanceUpdatePanel.TabIndex = 7;
            this.attendanceUpdatePanel.Visible = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.MistyRose;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(761, 274);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 26);
            this.button1.TabIndex = 71;
            this.button1.Text = "Cancel Search";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // attendanceUpdateData2
            // 
            this.attendanceUpdateData2.AllowUserToAddRows = false;
            this.attendanceUpdateData2.AllowUserToDeleteRows = false;
            this.attendanceUpdateData2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(52)))), ((int)(((byte)(118)))));
            this.attendanceUpdateData2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.attendanceUpdateData2.Location = new System.Drawing.Point(761, 322);
            this.attendanceUpdateData2.Name = "attendanceUpdateData2";
            this.attendanceUpdateData2.ReadOnly = true;
            this.attendanceUpdateData2.Size = new System.Drawing.Size(176, 127);
            this.attendanceUpdateData2.TabIndex = 70;
            this.attendanceUpdateData2.Visible = false;
            // 
            // attendanceUpdateComboBox
            // 
            this.attendanceUpdateComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.attendanceUpdateComboBox.FormattingEnabled = true;
            this.attendanceUpdateComboBox.Location = new System.Drawing.Point(706, 113);
            this.attendanceUpdateComboBox.Name = "attendanceUpdateComboBox";
            this.attendanceUpdateComboBox.Size = new System.Drawing.Size(155, 24);
            this.attendanceUpdateComboBox.TabIndex = 69;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label10.Location = new System.Drawing.Point(611, 114);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(94, 20);
            this.label10.TabIndex = 68;
            this.label10.Text = "Class Name";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.White;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Maroon;
            this.label9.Location = new System.Drawing.Point(370, 18);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(198, 26);
            this.label9.TabIndex = 67;
            this.label9.Text = "Update Attendance";
            // 
            // attendanceUpdateUpdateButton
            // 
            this.attendanceUpdateUpdateButton.BackColor = System.Drawing.Color.MistyRose;
            this.attendanceUpdateUpdateButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.attendanceUpdateUpdateButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.attendanceUpdateUpdateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.attendanceUpdateUpdateButton.Location = new System.Drawing.Point(508, 461);
            this.attendanceUpdateUpdateButton.Name = "attendanceUpdateUpdateButton";
            this.attendanceUpdateUpdateButton.Size = new System.Drawing.Size(106, 26);
            this.attendanceUpdateUpdateButton.TabIndex = 66;
            this.attendanceUpdateUpdateButton.Text = "Update";
            this.attendanceUpdateUpdateButton.UseVisualStyleBackColor = false;
            this.attendanceUpdateUpdateButton.Click += new System.EventHandler(this.attendanceUpdateUpdateButton_Click);
            // 
            // attendanceUpdateDate
            // 
            this.attendanceUpdateDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.attendanceUpdateDate.Location = new System.Drawing.Point(706, 170);
            this.attendanceUpdateDate.Name = "attendanceUpdateDate";
            this.attendanceUpdateDate.Size = new System.Drawing.Size(155, 23);
            this.attendanceUpdateDate.TabIndex = 65;
            // 
            // attendanceUpdateSearchButton
            // 
            this.attendanceUpdateSearchButton.BackColor = System.Drawing.Color.MistyRose;
            this.attendanceUpdateSearchButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.attendanceUpdateSearchButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.attendanceUpdateSearchButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.attendanceUpdateSearchButton.Location = new System.Drawing.Point(761, 237);
            this.attendanceUpdateSearchButton.Name = "attendanceUpdateSearchButton";
            this.attendanceUpdateSearchButton.Size = new System.Drawing.Size(100, 26);
            this.attendanceUpdateSearchButton.TabIndex = 62;
            this.attendanceUpdateSearchButton.Text = "Search";
            this.attendanceUpdateSearchButton.UseVisualStyleBackColor = false;
            this.attendanceUpdateSearchButton.Click += new System.EventHandler(this.attendanceUpdateSearchButton_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label8.Location = new System.Drawing.Point(633, 169);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 20);
            this.label8.TabIndex = 60;
            this.label8.Text = "Date";
            // 
            // attendanceUpdateDataGrid
            // 
            this.attendanceUpdateDataGrid.AllowUserToAddRows = false;
            this.attendanceUpdateDataGrid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(52)))), ((int)(((byte)(118)))));
            this.attendanceUpdateDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.attendanceUpdateDataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewCheckBoxColumn1});
            this.attendanceUpdateDataGrid.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.attendanceUpdateDataGrid.Location = new System.Drawing.Point(41, 100);
            this.attendanceUpdateDataGrid.Name = "attendanceUpdateDataGrid";
            this.attendanceUpdateDataGrid.Size = new System.Drawing.Size(441, 385);
            this.attendanceUpdateDataGrid.TabIndex = 0;
            // 
            // dataGridViewCheckBoxColumn1
            // 
            this.dataGridViewCheckBoxColumn1.HeaderText = "Attendance";
            this.dataGridViewCheckBoxColumn1.Name = "dataGridViewCheckBoxColumn1";
            this.dataGridViewCheckBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // attendanceStudentPanel
            // 
            this.attendanceStudentPanel.AutoScroll = true;
            this.attendanceStudentPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.attendanceStudentPanel.Controls.Add(this.attendanceDoneButton);
            this.attendanceStudentPanel.Controls.Add(this.attendanceStudentClassComboBox);
            this.attendanceStudentPanel.Controls.Add(this.attendanceStudentSearchButton);
            this.attendanceStudentPanel.Controls.Add(this.label72);
            this.attendanceStudentPanel.Controls.Add(this.attendanceStudentDataGrid);
            this.attendanceStudentPanel.Location = new System.Drawing.Point(307, 9);
            this.attendanceStudentPanel.Name = "attendanceStudentPanel";
            this.attendanceStudentPanel.Size = new System.Drawing.Size(162, 48);
            this.attendanceStudentPanel.TabIndex = 6;
            this.attendanceStudentPanel.Visible = false;
            // 
            // attendanceDoneButton
            // 
            this.attendanceDoneButton.BackColor = System.Drawing.Color.MistyRose;
            this.attendanceDoneButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.attendanceDoneButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.attendanceDoneButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.attendanceDoneButton.Location = new System.Drawing.Point(518, 461);
            this.attendanceDoneButton.Name = "attendanceDoneButton";
            this.attendanceDoneButton.Size = new System.Drawing.Size(106, 26);
            this.attendanceDoneButton.TabIndex = 64;
            this.attendanceDoneButton.Text = "Done";
            this.attendanceDoneButton.UseVisualStyleBackColor = false;
            this.attendanceDoneButton.Click += new System.EventHandler(this.attendanceDoneButton_Click);
            // 
            // attendanceStudentClassComboBox
            // 
            this.attendanceStudentClassComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.attendanceStudentClassComboBox.FormattingEnabled = true;
            this.attendanceStudentClassComboBox.Location = new System.Drawing.Point(145, 30);
            this.attendanceStudentClassComboBox.Name = "attendanceStudentClassComboBox";
            this.attendanceStudentClassComboBox.Size = new System.Drawing.Size(151, 24);
            this.attendanceStudentClassComboBox.TabIndex = 63;
            // 
            // attendanceStudentSearchButton
            // 
            this.attendanceStudentSearchButton.BackColor = System.Drawing.Color.MistyRose;
            this.attendanceStudentSearchButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.attendanceStudentSearchButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.attendanceStudentSearchButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.attendanceStudentSearchButton.Location = new System.Drawing.Point(377, 30);
            this.attendanceStudentSearchButton.Name = "attendanceStudentSearchButton";
            this.attendanceStudentSearchButton.Size = new System.Drawing.Size(108, 26);
            this.attendanceStudentSearchButton.TabIndex = 62;
            this.attendanceStudentSearchButton.Text = "Search";
            this.attendanceStudentSearchButton.UseVisualStyleBackColor = false;
            this.attendanceStudentSearchButton.Click += new System.EventHandler(this.attendanceStudentSearchButton_Click);
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label72.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label72.Location = new System.Drawing.Point(47, 33);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(82, 16);
            this.label72.TabIndex = 60;
            this.label72.Text = "Class Name";
            // 
            // attendanceStudentDataGrid
            // 
            this.attendanceStudentDataGrid.AllowUserToAddRows = false;
            this.attendanceStudentDataGrid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(52)))), ((int)(((byte)(118)))));
            this.attendanceStudentDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.attendanceStudentDataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.checkBox});
            this.attendanceStudentDataGrid.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.attendanceStudentDataGrid.Location = new System.Drawing.Point(50, 74);
            this.attendanceStudentDataGrid.Name = "attendanceStudentDataGrid";
            this.attendanceStudentDataGrid.Size = new System.Drawing.Size(452, 413);
            this.attendanceStudentDataGrid.TabIndex = 0;
            // 
            // checkBox
            // 
            this.checkBox.HeaderText = "Attendance";
            this.checkBox.Name = "checkBox";
            this.checkBox.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // attendanceStudentButton
            // 
            this.attendanceStudentButton.BackColor = System.Drawing.Color.MistyRose;
            this.attendanceStudentButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.attendanceStudentButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.attendanceStudentButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.attendanceStudentButton.Location = new System.Drawing.Point(749, 0);
            this.attendanceStudentButton.Name = "attendanceStudentButton";
            this.attendanceStudentButton.Size = new System.Drawing.Size(143, 26);
            this.attendanceStudentButton.TabIndex = 2;
            this.attendanceStudentButton.Text = "Student Attendance";
            this.attendanceStudentButton.UseVisualStyleBackColor = false;
            this.attendanceStudentButton.Click += new System.EventHandler(this.attendanceStudentButton_Click);
            // 
            // examUploadMarksPanel
            // 
            this.examUploadMarksPanel.AutoScroll = true;
            this.examUploadMarksPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(52)))), ((int)(((byte)(118)))));
            this.examUploadMarksPanel.Controls.Add(this.label16);
            this.examUploadMarksPanel.Controls.Add(this.label15);
            this.examUploadMarksPanel.Controls.Add(this.label5);
            this.examUploadMarksPanel.Controls.Add(this.label7);
            this.examUploadMarksPanel.Controls.Add(this.examUploadMarksSubmitButton);
            this.examUploadMarksPanel.Controls.Add(this.examUploadMarksTextBox);
            this.examUploadMarksPanel.Controls.Add(this.examUploadMarksExamDataGrid);
            this.examUploadMarksPanel.Controls.Add(this.examUploadMarksDataGrid);
            this.examUploadMarksPanel.Location = new System.Drawing.Point(34, 71);
            this.examUploadMarksPanel.Name = "examUploadMarksPanel";
            this.examUploadMarksPanel.Size = new System.Drawing.Size(690, 330);
            this.examUploadMarksPanel.TabIndex = 77;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label16.Location = new System.Drawing.Point(508, 116);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(74, 20);
            this.label16.TabIndex = 87;
            this.label16.Text = "Students";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label15.Location = new System.Drawing.Point(40, 116);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(91, 20);
            this.label15.TabIndex = 86;
            this.label15.Text = "Class Tests";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.White;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Maroon;
            this.label5.Location = new System.Drawing.Point(346, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(221, 26);
            this.label5.TabIndex = 85;
            this.label5.Text = "Marks for Class Tests";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label7.Location = new System.Drawing.Point(595, 379);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 20);
            this.label7.TabIndex = 84;
            this.label7.Text = "Marks";
            // 
            // examUploadMarksSubmitButton
            // 
            this.examUploadMarksSubmitButton.BackColor = System.Drawing.Color.MistyRose;
            this.examUploadMarksSubmitButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.examUploadMarksSubmitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.examUploadMarksSubmitButton.Location = new System.Drawing.Point(822, 376);
            this.examUploadMarksSubmitButton.Name = "examUploadMarksSubmitButton";
            this.examUploadMarksSubmitButton.Size = new System.Drawing.Size(75, 23);
            this.examUploadMarksSubmitButton.TabIndex = 83;
            this.examUploadMarksSubmitButton.Text = "Submit";
            this.examUploadMarksSubmitButton.UseVisualStyleBackColor = false;
            this.examUploadMarksSubmitButton.Click += new System.EventHandler(this.examUploadMarksSubmitButton_Click);
            // 
            // examUploadMarksTextBox
            // 
            this.examUploadMarksTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.examUploadMarksTextBox.Location = new System.Drawing.Point(677, 376);
            this.examUploadMarksTextBox.Name = "examUploadMarksTextBox";
            this.examUploadMarksTextBox.Size = new System.Drawing.Size(100, 23);
            this.examUploadMarksTextBox.TabIndex = 82;
            // 
            // examUploadMarksExamDataGrid
            // 
            this.examUploadMarksExamDataGrid.AllowUserToAddRows = false;
            this.examUploadMarksExamDataGrid.AllowUserToDeleteRows = false;
            this.examUploadMarksExamDataGrid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(52)))), ((int)(((byte)(118)))));
            this.examUploadMarksExamDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.examUploadMarksExamDataGrid.Location = new System.Drawing.Point(38, 142);
            this.examUploadMarksExamDataGrid.Name = "examUploadMarksExamDataGrid";
            this.examUploadMarksExamDataGrid.ReadOnly = true;
            this.examUploadMarksExamDataGrid.Size = new System.Drawing.Size(326, 140);
            this.examUploadMarksExamDataGrid.TabIndex = 80;
            this.examUploadMarksExamDataGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.examUploadMarksExamDataGrid_CellClick);
            // 
            // examUploadMarksDataGrid
            // 
            this.examUploadMarksDataGrid.AllowUserToAddRows = false;
            this.examUploadMarksDataGrid.AllowUserToDeleteRows = false;
            this.examUploadMarksDataGrid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(52)))), ((int)(((byte)(118)))));
            this.examUploadMarksDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.examUploadMarksDataGrid.Location = new System.Drawing.Point(503, 142);
            this.examUploadMarksDataGrid.Name = "examUploadMarksDataGrid";
            this.examUploadMarksDataGrid.ReadOnly = true;
            this.examUploadMarksDataGrid.Size = new System.Drawing.Size(455, 207);
            this.examUploadMarksDataGrid.TabIndex = 81;
            this.examUploadMarksDataGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.examUploadMarksDataGrid_CellClick);
            // 
            // tileBarPanel
            // 
            this.tileBarPanel.BackColor = System.Drawing.Color.Silver;
            this.tileBarPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tileBarPanel.Controls.Add(this.crossButton);
            this.tileBarPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.tileBarPanel.Location = new System.Drawing.Point(185, 0);
            this.tileBarPanel.Name = "tileBarPanel";
            this.tileBarPanel.Size = new System.Drawing.Size(1075, 20);
            this.tileBarPanel.TabIndex = 6;
            // 
            // crossButton
            // 
            this.crossButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.crossButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("crossButton.BackgroundImage")));
            this.crossButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.crossButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.crossButton.Location = new System.Drawing.Point(1049, 0);
            this.crossButton.Name = "crossButton";
            this.crossButton.Size = new System.Drawing.Size(26, 20);
            this.crossButton.TabIndex = 0;
            this.crossButton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.crossButton.UseVisualStyleBackColor = false;
            this.crossButton.Click += new System.EventHandler(this.crossButton_Click);
            // 
            // examPanel
            // 
            this.examPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(52)))), ((int)(((byte)(118)))));
            this.examPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.examPanel.Controls.Add(this.examUploadMarksPanel);
            this.examPanel.Controls.Add(this.examCreateExamPanel);
            this.examPanel.Controls.Add(this.examCreateExamButton);
            this.examPanel.Controls.Add(this.examUploadMarkButton);
            this.examPanel.Location = new System.Drawing.Point(301, 35);
            this.examPanel.Name = "examPanel";
            this.examPanel.Size = new System.Drawing.Size(44, 30);
            this.examPanel.TabIndex = 7;
            this.examPanel.Visible = false;
            // 
            // examCreateExamPanel
            // 
            this.examCreateExamPanel.AutoScroll = true;
            this.examCreateExamPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(52)))), ((int)(((byte)(118)))));
            this.examCreateExamPanel.Controls.Add(this.examCreateExamUpdateButton);
            this.examCreateExamPanel.Controls.Add(this.examCreateExamDeleteButton);
            this.examCreateExamPanel.Controls.Add(this.examCreateExamDataGridView);
            this.examCreateExamPanel.Controls.Add(this.label6);
            this.examCreateExamPanel.Controls.Add(this.examCreateExamSubmitBotton);
            this.examCreateExamPanel.Controls.Add(this.examCreateExamDate);
            this.examCreateExamPanel.Controls.Add(this.label4);
            this.examCreateExamPanel.Controls.Add(this.label3);
            this.examCreateExamPanel.Controls.Add(this.label2);
            this.examCreateExamPanel.Controls.Add(this.examCreateExamDepartmentComboBox);
            this.examCreateExamPanel.Controls.Add(this.label1);
            this.examCreateExamPanel.Controls.Add(this.examCreateExamExamNameTextBox);
            this.examCreateExamPanel.Controls.Add(this.examCreateExamClassNameComboBox);
            this.examCreateExamPanel.Location = new System.Drawing.Point(19, 10);
            this.examCreateExamPanel.Name = "examCreateExamPanel";
            this.examCreateExamPanel.Size = new System.Drawing.Size(110, 35);
            this.examCreateExamPanel.TabIndex = 76;
            // 
            // examCreateExamUpdateButton
            // 
            this.examCreateExamUpdateButton.BackColor = System.Drawing.Color.MistyRose;
            this.examCreateExamUpdateButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.examCreateExamUpdateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.examCreateExamUpdateButton.Location = new System.Drawing.Point(747, 323);
            this.examCreateExamUpdateButton.Name = "examCreateExamUpdateButton";
            this.examCreateExamUpdateButton.Size = new System.Drawing.Size(92, 23);
            this.examCreateExamUpdateButton.TabIndex = 81;
            this.examCreateExamUpdateButton.Text = "Update";
            this.examCreateExamUpdateButton.UseVisualStyleBackColor = false;
            this.examCreateExamUpdateButton.Click += new System.EventHandler(this.examCreateExamUpdateButton_Click);
            // 
            // examCreateExamDeleteButton
            // 
            this.examCreateExamDeleteButton.BackColor = System.Drawing.Color.MistyRose;
            this.examCreateExamDeleteButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.examCreateExamDeleteButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.examCreateExamDeleteButton.Location = new System.Drawing.Point(845, 323);
            this.examCreateExamDeleteButton.Name = "examCreateExamDeleteButton";
            this.examCreateExamDeleteButton.Size = new System.Drawing.Size(92, 23);
            this.examCreateExamDeleteButton.TabIndex = 80;
            this.examCreateExamDeleteButton.Text = "Delete";
            this.examCreateExamDeleteButton.UseVisualStyleBackColor = false;
            this.examCreateExamDeleteButton.Click += new System.EventHandler(this.examCreateExamDeleteButton_Click);
            // 
            // examCreateExamDataGridView
            // 
            this.examCreateExamDataGridView.AllowUserToAddRows = false;
            this.examCreateExamDataGridView.AllowUserToDeleteRows = false;
            this.examCreateExamDataGridView.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(52)))), ((int)(((byte)(118)))));
            this.examCreateExamDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.examCreateExamDataGridView.GridColor = System.Drawing.Color.Silver;
            this.examCreateExamDataGridView.Location = new System.Drawing.Point(568, 138);
            this.examCreateExamDataGridView.Name = "examCreateExamDataGridView";
            this.examCreateExamDataGridView.ReadOnly = true;
            this.examCreateExamDataGridView.Size = new System.Drawing.Size(372, 168);
            this.examCreateExamDataGridView.TabIndex = 79;
            this.examCreateExamDataGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.examCreateExamDataGridView_CellClick);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label6.Location = new System.Drawing.Point(356, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(286, 24);
            this.label6.TabIndex = 78;
            this.label6.Text = "Create New Class Test Schedule";
            // 
            // examCreateExamSubmitBotton
            // 
            this.examCreateExamSubmitBotton.BackColor = System.Drawing.Color.MistyRose;
            this.examCreateExamSubmitBotton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.examCreateExamSubmitBotton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.examCreateExamSubmitBotton.Location = new System.Drawing.Point(248, 331);
            this.examCreateExamSubmitBotton.Name = "examCreateExamSubmitBotton";
            this.examCreateExamSubmitBotton.Size = new System.Drawing.Size(92, 23);
            this.examCreateExamSubmitBotton.TabIndex = 77;
            this.examCreateExamSubmitBotton.Text = "Submit";
            this.examCreateExamSubmitBotton.UseVisualStyleBackColor = false;
            this.examCreateExamSubmitBotton.Click += new System.EventHandler(this.examCreateExamSubmitBotton_Click);
            // 
            // examCreateExamDate
            // 
            this.examCreateExamDate.Location = new System.Drawing.Point(175, 229);
            this.examCreateExamDate.Name = "examCreateExamDate";
            this.examCreateExamDate.Size = new System.Drawing.Size(165, 20);
            this.examCreateExamDate.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.Control;
            this.label4.Location = new System.Drawing.Point(64, 133);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(94, 20);
            this.label4.TabIndex = 6;
            this.label4.Text = "Class Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.Control;
            this.label3.Location = new System.Drawing.Point(60, 266);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 20);
            this.label3.TabIndex = 5;
            this.label3.Text = "Department";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.Control;
            this.label2.Location = new System.Drawing.Point(64, 229);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 20);
            this.label2.TabIndex = 4;
            this.label2.Text = "Date";
            // 
            // examCreateExamDepartmentComboBox
            // 
            this.examCreateExamDepartmentComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.examCreateExamDepartmentComboBox.FormattingEnabled = true;
            this.examCreateExamDepartmentComboBox.Location = new System.Drawing.Point(175, 263);
            this.examCreateExamDepartmentComboBox.Name = "examCreateExamDepartmentComboBox";
            this.examCreateExamDepartmentComboBox.Size = new System.Drawing.Size(165, 24);
            this.examCreateExamDepartmentComboBox.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(64, 183);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Exam Name";
            // 
            // examCreateExamExamNameTextBox
            // 
            this.examCreateExamExamNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.examCreateExamExamNameTextBox.Location = new System.Drawing.Point(175, 180);
            this.examCreateExamExamNameTextBox.Name = "examCreateExamExamNameTextBox";
            this.examCreateExamExamNameTextBox.Size = new System.Drawing.Size(165, 23);
            this.examCreateExamExamNameTextBox.TabIndex = 1;
            // 
            // examCreateExamClassNameComboBox
            // 
            this.examCreateExamClassNameComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.examCreateExamClassNameComboBox.FormattingEnabled = true;
            this.examCreateExamClassNameComboBox.Location = new System.Drawing.Point(175, 133);
            this.examCreateExamClassNameComboBox.Name = "examCreateExamClassNameComboBox";
            this.examCreateExamClassNameComboBox.Size = new System.Drawing.Size(165, 24);
            this.examCreateExamClassNameComboBox.TabIndex = 0;
            // 
            // examCreateExamButton
            // 
            this.examCreateExamButton.BackColor = System.Drawing.Color.MistyRose;
            this.examCreateExamButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.examCreateExamButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.examCreateExamButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.examCreateExamButton.Location = new System.Drawing.Point(774, 1);
            this.examCreateExamButton.Name = "examCreateExamButton";
            this.examCreateExamButton.Size = new System.Drawing.Size(128, 29);
            this.examCreateExamButton.TabIndex = 75;
            this.examCreateExamButton.Text = "Create Exam";
            this.examCreateExamButton.UseVisualStyleBackColor = false;
            this.examCreateExamButton.Click += new System.EventHandler(this.examCreateExamButton_Click);
            // 
            // examUploadMarkButton
            // 
            this.examUploadMarkButton.BackColor = System.Drawing.Color.MistyRose;
            this.examUploadMarkButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.examUploadMarkButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.examUploadMarkButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.examUploadMarkButton.Location = new System.Drawing.Point(908, 1);
            this.examUploadMarkButton.Name = "examUploadMarkButton";
            this.examUploadMarkButton.Size = new System.Drawing.Size(128, 29);
            this.examUploadMarkButton.TabIndex = 74;
            this.examUploadMarkButton.Text = "Upload Marks";
            this.examUploadMarkButton.UseVisualStyleBackColor = false;
            this.examUploadMarkButton.Click += new System.EventHandler(this.examUploadMarkButton_Click);
            // 
            // termExamPanel
            // 
            this.termExamPanel.AutoScroll = true;
            this.termExamPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(52)))), ((int)(((byte)(118)))));
            this.termExamPanel.Controls.Add(this.label14);
            this.termExamPanel.Controls.Add(this.label13);
            this.termExamPanel.Controls.Add(this.label11);
            this.termExamPanel.Controls.Add(this.label12);
            this.termExamPanel.Controls.Add(this.termExamMarkSubmitButton);
            this.termExamPanel.Controls.Add(this.termExamMarkTextBox);
            this.termExamPanel.Controls.Add(this.termExamDataGrid);
            this.termExamPanel.Controls.Add(this.termExamMarksData);
            this.termExamPanel.Location = new System.Drawing.Point(415, 35);
            this.termExamPanel.Name = "termExamPanel";
            this.termExamPanel.Size = new System.Drawing.Size(118, 54);
            this.termExamPanel.TabIndex = 78;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.Control;
            this.label14.Location = new System.Drawing.Point(53, 65);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(118, 20);
            this.label14.TabIndex = 87;
            this.label14.Text = "Term Exam List";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.Control;
            this.label13.Location = new System.Drawing.Point(58, 318);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(74, 20);
            this.label13.TabIndex = 86;
            this.label13.Text = "Students";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Maroon;
            this.label11.Location = new System.Drawing.Point(346, 9);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(221, 26);
            this.label11.TabIndex = 85;
            this.label11.Text = "Marks for Class Tests";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.Control;
            this.label12.Location = new System.Drawing.Point(700, 433);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(52, 20);
            this.label12.TabIndex = 84;
            this.label12.Text = "Marks";
            // 
            // termExamMarkSubmitButton
            // 
            this.termExamMarkSubmitButton.BackColor = System.Drawing.Color.MistyRose;
            this.termExamMarkSubmitButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.termExamMarkSubmitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.termExamMarkSubmitButton.Location = new System.Drawing.Point(787, 476);
            this.termExamMarkSubmitButton.Name = "termExamMarkSubmitButton";
            this.termExamMarkSubmitButton.Size = new System.Drawing.Size(75, 23);
            this.termExamMarkSubmitButton.TabIndex = 83;
            this.termExamMarkSubmitButton.Text = "Submit";
            this.termExamMarkSubmitButton.UseVisualStyleBackColor = false;
            this.termExamMarkSubmitButton.Click += new System.EventHandler(this.termExamMarkSubmitButton_Click);
            // 
            // termExamMarkTextBox
            // 
            this.termExamMarkTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.termExamMarkTextBox.Location = new System.Drawing.Point(762, 433);
            this.termExamMarkTextBox.Name = "termExamMarkTextBox";
            this.termExamMarkTextBox.Size = new System.Drawing.Size(100, 23);
            this.termExamMarkTextBox.TabIndex = 82;
            // 
            // termExamDataGrid
            // 
            this.termExamDataGrid.AllowUserToAddRows = false;
            this.termExamDataGrid.AllowUserToDeleteRows = false;
            this.termExamDataGrid.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(52)))), ((int)(((byte)(118)))));
            this.termExamDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.termExamDataGrid.Location = new System.Drawing.Point(53, 94);
            this.termExamDataGrid.Name = "termExamDataGrid";
            this.termExamDataGrid.ReadOnly = true;
            this.termExamDataGrid.Size = new System.Drawing.Size(527, 172);
            this.termExamDataGrid.TabIndex = 80;
            this.termExamDataGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.termExamDataGrid_CellClick);
            // 
            // termExamMarksData
            // 
            this.termExamMarksData.AllowUserToAddRows = false;
            this.termExamMarksData.AllowUserToDeleteRows = false;
            this.termExamMarksData.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(52)))), ((int)(((byte)(118)))));
            this.termExamMarksData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.termExamMarksData.Location = new System.Drawing.Point(49, 345);
            this.termExamMarksData.Name = "termExamMarksData";
            this.termExamMarksData.ReadOnly = true;
            this.termExamMarksData.Size = new System.Drawing.Size(645, 207);
            this.termExamMarksData.TabIndex = 81;
            this.termExamMarksData.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.termExamMarksData_CellClick);
            // 
            // profilePanel
            // 
            this.profilePanel.AutoScroll = true;
            this.profilePanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(52)))), ((int)(((byte)(118)))));
            this.profilePanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.profilePanel.Controls.Add(this.profileDatas);
            this.profilePanel.Controls.Add(this.profileGenderTextBox);
            this.profilePanel.Controls.Add(this.profileRegisterDateTextBox);
            this.profilePanel.Controls.Add(this.profileSubjectTextBox);
            this.profilePanel.Controls.Add(this.profileBGTextBox);
            this.profilePanel.Controls.Add(this.profileDepartmentTextBox);
            this.profilePanel.Controls.Add(this.profileDOBTextBox);
            this.profilePanel.Controls.Add(this.label100);
            this.profilePanel.Controls.Add(this.profileStd6);
            this.profilePanel.Controls.Add(this.profileStd10);
            this.profilePanel.Controls.Add(this.profileStd2);
            this.profilePanel.Controls.Add(this.profileStd5);
            this.profilePanel.Controls.Add(this.profileStd8);
            this.profilePanel.Controls.Add(this.profileStd7);
            this.profilePanel.Controls.Add(this.profileStd1);
            this.profilePanel.Controls.Add(this.profileStd3);
            this.profilePanel.Controls.Add(this.profileStd9);
            this.profilePanel.Controls.Add(this.profileNursary);
            this.profilePanel.Controls.Add(this.profileStd4);
            this.profilePanel.Controls.Add(this.label76);
            this.profilePanel.Controls.Add(this.profileConfirmPasswordTextBox);
            this.profilePanel.Controls.Add(this.label68);
            this.profilePanel.Controls.Add(this.profilePasswordTextBox);
            this.profilePanel.Controls.Add(this.label69);
            this.profilePanel.Controls.Add(this.profileIDTextBox);
            this.profilePanel.Controls.Add(this.label70);
            this.profilePanel.Controls.Add(this.label17);
            this.profilePanel.Controls.Add(this.teacherAddPictureBox);
            this.profilePanel.Controls.Add(this.label73);
            this.profilePanel.Controls.Add(this.profileSubmitButton);
            this.profilePanel.Controls.Add(this.label74);
            this.profilePanel.Controls.Add(this.profileAddressTextBox);
            this.profilePanel.Controls.Add(this.profileEmailTextBox);
            this.profilePanel.Controls.Add(this.profilePhoneTextBox);
            this.profilePanel.Controls.Add(this.profileNameTextBox);
            this.profilePanel.Controls.Add(this.label75);
            this.profilePanel.Controls.Add(this.label79);
            this.profilePanel.Controls.Add(this.label80);
            this.profilePanel.Controls.Add(this.label84);
            this.profilePanel.Controls.Add(this.label85);
            this.profilePanel.Controls.Add(this.label86);
            this.profilePanel.Controls.Add(this.label87);
            this.profilePanel.Location = new System.Drawing.Point(568, 32);
            this.profilePanel.Name = "profilePanel";
            this.profilePanel.Size = new System.Drawing.Size(85, 48);
            this.profilePanel.TabIndex = 79;
            this.profilePanel.Visible = false;
            // 
            // profileDatas
            // 
            this.profileDatas.AllowUserToAddRows = false;
            this.profileDatas.AllowUserToDeleteRows = false;
            this.profileDatas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.profileDatas.Location = new System.Drawing.Point(13, 12);
            this.profileDatas.Name = "profileDatas";
            this.profileDatas.ReadOnly = true;
            this.profileDatas.Size = new System.Drawing.Size(88, 50);
            this.profileDatas.TabIndex = 62;
            this.profileDatas.Visible = false;
            // 
            // profileGenderTextBox
            // 
            this.profileGenderTextBox.Enabled = false;
            this.profileGenderTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileGenderTextBox.Location = new System.Drawing.Point(189, 162);
            this.profileGenderTextBox.Name = "profileGenderTextBox";
            this.profileGenderTextBox.Size = new System.Drawing.Size(226, 26);
            this.profileGenderTextBox.TabIndex = 61;
            // 
            // profileRegisterDateTextBox
            // 
            this.profileRegisterDateTextBox.Enabled = false;
            this.profileRegisterDateTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileRegisterDateTextBox.Location = new System.Drawing.Point(586, 91);
            this.profileRegisterDateTextBox.Name = "profileRegisterDateTextBox";
            this.profileRegisterDateTextBox.Size = new System.Drawing.Size(195, 26);
            this.profileRegisterDateTextBox.TabIndex = 60;
            // 
            // profileSubjectTextBox
            // 
            this.profileSubjectTextBox.Enabled = false;
            this.profileSubjectTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileSubjectTextBox.Location = new System.Drawing.Point(586, 129);
            this.profileSubjectTextBox.Name = "profileSubjectTextBox";
            this.profileSubjectTextBox.Size = new System.Drawing.Size(195, 26);
            this.profileSubjectTextBox.TabIndex = 59;
            // 
            // profileBGTextBox
            // 
            this.profileBGTextBox.Enabled = false;
            this.profileBGTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileBGTextBox.Location = new System.Drawing.Point(586, 164);
            this.profileBGTextBox.Name = "profileBGTextBox";
            this.profileBGTextBox.Size = new System.Drawing.Size(195, 26);
            this.profileBGTextBox.TabIndex = 58;
            // 
            // profileDepartmentTextBox
            // 
            this.profileDepartmentTextBox.Enabled = false;
            this.profileDepartmentTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileDepartmentTextBox.Location = new System.Drawing.Point(586, 199);
            this.profileDepartmentTextBox.Name = "profileDepartmentTextBox";
            this.profileDepartmentTextBox.Size = new System.Drawing.Size(195, 26);
            this.profileDepartmentTextBox.TabIndex = 57;
            // 
            // profileDOBTextBox
            // 
            this.profileDOBTextBox.Enabled = false;
            this.profileDOBTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileDOBTextBox.Location = new System.Drawing.Point(187, 345);
            this.profileDOBTextBox.Name = "profileDOBTextBox";
            this.profileDOBTextBox.Size = new System.Drawing.Size(228, 26);
            this.profileDOBTextBox.TabIndex = 55;
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Enabled = false;
            this.label100.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label100.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label100.Location = new System.Drawing.Point(472, 95);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(108, 20);
            this.label100.TabIndex = 54;
            this.label100.Text = "Register Date";
            // 
            // profileStd6
            // 
            this.profileStd6.AutoSize = true;
            this.profileStd6.Enabled = false;
            this.profileStd6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileStd6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.profileStd6.Location = new System.Drawing.Point(524, 313);
            this.profileStd6.Name = "profileStd6";
            this.profileStd6.Size = new System.Drawing.Size(61, 19);
            this.profileStd6.TabIndex = 53;
            this.profileStd6.Text = "STD-6";
            this.profileStd6.UseVisualStyleBackColor = true;
            // 
            // profileStd10
            // 
            this.profileStd10.AutoSize = true;
            this.profileStd10.Enabled = false;
            this.profileStd10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileStd10.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.profileStd10.Location = new System.Drawing.Point(615, 336);
            this.profileStd10.Name = "profileStd10";
            this.profileStd10.Size = new System.Drawing.Size(68, 19);
            this.profileStd10.TabIndex = 52;
            this.profileStd10.Text = "STD-10";
            this.profileStd10.UseVisualStyleBackColor = true;
            // 
            // profileStd2
            // 
            this.profileStd2.AutoSize = true;
            this.profileStd2.Enabled = false;
            this.profileStd2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileStd2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.profileStd2.Location = new System.Drawing.Point(711, 270);
            this.profileStd2.Name = "profileStd2";
            this.profileStd2.Size = new System.Drawing.Size(61, 19);
            this.profileStd2.TabIndex = 51;
            this.profileStd2.Text = "STD-2";
            this.profileStd2.UseVisualStyleBackColor = true;
            // 
            // profileStd5
            // 
            this.profileStd5.AutoSize = true;
            this.profileStd5.Enabled = false;
            this.profileStd5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileStd5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.profileStd5.Location = new System.Drawing.Point(711, 292);
            this.profileStd5.Name = "profileStd5";
            this.profileStd5.Size = new System.Drawing.Size(61, 19);
            this.profileStd5.TabIndex = 50;
            this.profileStd5.Text = "STD-5";
            this.profileStd5.UseVisualStyleBackColor = true;
            // 
            // profileStd8
            // 
            this.profileStd8.AutoSize = true;
            this.profileStd8.Enabled = false;
            this.profileStd8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileStd8.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.profileStd8.Location = new System.Drawing.Point(711, 317);
            this.profileStd8.Name = "profileStd8";
            this.profileStd8.Size = new System.Drawing.Size(61, 19);
            this.profileStd8.TabIndex = 49;
            this.profileStd8.Text = "STD-8";
            this.profileStd8.UseVisualStyleBackColor = true;
            // 
            // profileStd7
            // 
            this.profileStd7.AutoSize = true;
            this.profileStd7.Enabled = false;
            this.profileStd7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileStd7.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.profileStd7.Location = new System.Drawing.Point(615, 316);
            this.profileStd7.Name = "profileStd7";
            this.profileStd7.Size = new System.Drawing.Size(61, 19);
            this.profileStd7.TabIndex = 48;
            this.profileStd7.Text = "STD-7";
            this.profileStd7.UseVisualStyleBackColor = true;
            // 
            // profileStd1
            // 
            this.profileStd1.AutoSize = true;
            this.profileStd1.Enabled = false;
            this.profileStd1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileStd1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.profileStd1.Location = new System.Drawing.Point(615, 271);
            this.profileStd1.Name = "profileStd1";
            this.profileStd1.Size = new System.Drawing.Size(61, 19);
            this.profileStd1.TabIndex = 47;
            this.profileStd1.Text = "STD-1";
            this.profileStd1.UseVisualStyleBackColor = true;
            // 
            // profileStd3
            // 
            this.profileStd3.AutoSize = true;
            this.profileStd3.Enabled = false;
            this.profileStd3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileStd3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.profileStd3.Location = new System.Drawing.Point(523, 293);
            this.profileStd3.Name = "profileStd3";
            this.profileStd3.Size = new System.Drawing.Size(61, 19);
            this.profileStd3.TabIndex = 46;
            this.profileStd3.Text = "STD-3";
            this.profileStd3.UseVisualStyleBackColor = true;
            // 
            // profileStd9
            // 
            this.profileStd9.AutoSize = true;
            this.profileStd9.Enabled = false;
            this.profileStd9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileStd9.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.profileStd9.Location = new System.Drawing.Point(524, 338);
            this.profileStd9.Name = "profileStd9";
            this.profileStd9.Size = new System.Drawing.Size(61, 19);
            this.profileStd9.TabIndex = 45;
            this.profileStd9.Text = "STD-9";
            this.profileStd9.UseVisualStyleBackColor = true;
            // 
            // profileNursary
            // 
            this.profileNursary.AutoSize = true;
            this.profileNursary.Enabled = false;
            this.profileNursary.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileNursary.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.profileNursary.Location = new System.Drawing.Point(523, 272);
            this.profileNursary.Name = "profileNursary";
            this.profileNursary.Size = new System.Drawing.Size(68, 19);
            this.profileNursary.TabIndex = 44;
            this.profileNursary.Text = "Nursary";
            this.profileNursary.UseVisualStyleBackColor = true;
            // 
            // profileStd4
            // 
            this.profileStd4.AutoSize = true;
            this.profileStd4.Enabled = false;
            this.profileStd4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileStd4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.profileStd4.Location = new System.Drawing.Point(615, 295);
            this.profileStd4.Name = "profileStd4";
            this.profileStd4.Size = new System.Drawing.Size(61, 19);
            this.profileStd4.TabIndex = 43;
            this.profileStd4.Text = "STD-4";
            this.profileStd4.UseVisualStyleBackColor = true;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label76.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label76.Location = new System.Drawing.Point(474, 233);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(221, 20);
            this.label76.TabIndex = 42;
            this.label76.Text = "Classes.......................................";
            // 
            // profileConfirmPasswordTextBox
            // 
            this.profileConfirmPasswordTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileConfirmPasswordTextBox.Location = new System.Drawing.Point(189, 230);
            this.profileConfirmPasswordTextBox.Name = "profileConfirmPasswordTextBox";
            this.profileConfirmPasswordTextBox.Size = new System.Drawing.Size(226, 26);
            this.profileConfirmPasswordTextBox.TabIndex = 41;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label68.Location = new System.Drawing.Point(47, 234);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(121, 17);
            this.label68.TabIndex = 40;
            this.label68.Text = "Confirm Password";
            // 
            // profilePasswordTextBox
            // 
            this.profilePasswordTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profilePasswordTextBox.Location = new System.Drawing.Point(189, 196);
            this.profilePasswordTextBox.Name = "profilePasswordTextBox";
            this.profilePasswordTextBox.Size = new System.Drawing.Size(226, 26);
            this.profilePasswordTextBox.TabIndex = 39;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label69.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label69.Location = new System.Drawing.Point(84, 199);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(78, 20);
            this.label69.TabIndex = 38;
            this.label69.Text = "Password";
            // 
            // profileIDTextBox
            // 
            this.profileIDTextBox.Enabled = false;
            this.profileIDTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileIDTextBox.Location = new System.Drawing.Point(188, 84);
            this.profileIDTextBox.Name = "profileIDTextBox";
            this.profileIDTextBox.Size = new System.Drawing.Size(227, 26);
            this.profileIDTextBox.TabIndex = 33;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label70.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label70.Location = new System.Drawing.Point(97, 87);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(78, 17);
            this.label70.TabIndex = 32;
            this.label70.Text = "Teacher ID";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.White;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label17.Location = new System.Drawing.Point(370, 10);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(66, 25);
            this.label17.TabIndex = 31;
            this.label17.Text = "Profile";
            // 
            // teacherAddPictureBox
            // 
            this.teacherAddPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.teacherAddPictureBox.Location = new System.Drawing.Point(795, 39);
            this.teacherAddPictureBox.Name = "teacherAddPictureBox";
            this.teacherAddPictureBox.Size = new System.Drawing.Size(153, 143);
            this.teacherAddPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.teacherAddPictureBox.TabIndex = 29;
            this.teacherAddPictureBox.TabStop = false;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label73.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label73.Location = new System.Drawing.Point(481, 165);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(99, 20);
            this.label73.TabIndex = 27;
            this.label73.Text = "Blood Group";
            // 
            // profileSubmitButton
            // 
            this.profileSubmitButton.BackColor = System.Drawing.Color.MistyRose;
            this.profileSubmitButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.profileSubmitButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.profileSubmitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileSubmitButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.profileSubmitButton.Location = new System.Drawing.Point(729, 460);
            this.profileSubmitButton.Name = "profileSubmitButton";
            this.profileSubmitButton.Size = new System.Drawing.Size(128, 26);
            this.profileSubmitButton.TabIndex = 26;
            this.profileSubmitButton.Text = "Submit";
            this.profileSubmitButton.UseVisualStyleBackColor = false;
            this.profileSubmitButton.Click += new System.EventHandler(this.profileSubmitButton_Click);
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label74.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label74.Location = new System.Drawing.Point(488, 202);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(94, 20);
            this.label74.TabIndex = 22;
            this.label74.Text = "Department";
            // 
            // profileAddressTextBox
            // 
            this.profileAddressTextBox.Enabled = false;
            this.profileAddressTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileAddressTextBox.Location = new System.Drawing.Point(133, 395);
            this.profileAddressTextBox.Name = "profileAddressTextBox";
            this.profileAddressTextBox.Size = new System.Drawing.Size(545, 63);
            this.profileAddressTextBox.TabIndex = 17;
            this.profileAddressTextBox.Text = "";
            // 
            // profileEmailTextBox
            // 
            this.profileEmailTextBox.Enabled = false;
            this.profileEmailTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileEmailTextBox.Location = new System.Drawing.Point(188, 268);
            this.profileEmailTextBox.Name = "profileEmailTextBox";
            this.profileEmailTextBox.Size = new System.Drawing.Size(227, 26);
            this.profileEmailTextBox.TabIndex = 16;
            // 
            // profilePhoneTextBox
            // 
            this.profilePhoneTextBox.Enabled = false;
            this.profilePhoneTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profilePhoneTextBox.Location = new System.Drawing.Point(188, 307);
            this.profilePhoneTextBox.Name = "profilePhoneTextBox";
            this.profilePhoneTextBox.Size = new System.Drawing.Size(228, 26);
            this.profilePhoneTextBox.TabIndex = 16;
            // 
            // profileNameTextBox
            // 
            this.profileNameTextBox.Enabled = false;
            this.profileNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profileNameTextBox.Location = new System.Drawing.Point(189, 126);
            this.profileNameTextBox.Name = "profileNameTextBox";
            this.profileNameTextBox.Size = new System.Drawing.Size(227, 26);
            this.profileNameTextBox.TabIndex = 16;
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label75.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label75.Location = new System.Drawing.Point(55, 412);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(62, 18);
            this.label75.TabIndex = 14;
            this.label75.Text = "Address";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label79.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label79.Location = new System.Drawing.Point(54, 310);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(115, 20);
            this.label79.TabIndex = 10;
            this.label79.Text = "Phone Number";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label80.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label80.Location = new System.Drawing.Point(94, 268);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(48, 20);
            this.label80.TabIndex = 9;
            this.label80.Text = "Email";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label84.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label84.Location = new System.Drawing.Point(111, 132);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(51, 20);
            this.label84.TabIndex = 5;
            this.label84.Text = "Name";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label85.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label85.Location = new System.Drawing.Point(64, 344);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(102, 20);
            this.label85.TabIndex = 4;
            this.label85.Text = "Date Of Birth";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label86.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label86.Location = new System.Drawing.Point(103, 165);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(63, 20);
            this.label86.TabIndex = 3;
            this.label86.Text = "Gender";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label87.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label87.Location = new System.Drawing.Point(515, 132);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(63, 20);
            this.label87.TabIndex = 2;
            this.label87.Text = "Subject";
            // 
            // TeacherForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(52)))), ((int)(((byte)(118)))));
            this.ClientSize = new System.Drawing.Size(1260, 670);
            this.Controls.Add(this.profilePanel);
            this.Controls.Add(this.termExamPanel);
            this.Controls.Add(this.examPanel);
            this.Controls.Add(this.attendancePanel);
            this.Controls.Add(this.tileBarPanel);
            this.Controls.Add(this.menu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "TeacherForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form2";
            this.menu.ResumeLayout(false);
            this.attendancePanel.ResumeLayout(false);
            this.attendanceUpdatePanel.ResumeLayout(false);
            this.attendanceUpdatePanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.attendanceUpdateData2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.attendanceUpdateDataGrid)).EndInit();
            this.attendanceStudentPanel.ResumeLayout(false);
            this.attendanceStudentPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.attendanceStudentDataGrid)).EndInit();
            this.examUploadMarksPanel.ResumeLayout(false);
            this.examUploadMarksPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.examUploadMarksExamDataGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.examUploadMarksDataGrid)).EndInit();
            this.tileBarPanel.ResumeLayout(false);
            this.examPanel.ResumeLayout(false);
            this.examCreateExamPanel.ResumeLayout(false);
            this.examCreateExamPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.examCreateExamDataGridView)).EndInit();
            this.termExamPanel.ResumeLayout(false);
            this.termExamPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.termExamDataGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.termExamMarksData)).EndInit();
            this.profilePanel.ResumeLayout(false);
            this.profilePanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.profileDatas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.teacherAddPictureBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel menu;
        private System.Windows.Forms.Button attendanceMenuButton;
        private System.Windows.Forms.Panel attendancePanel;
        private System.Windows.Forms.Panel attendanceStudentPanel;
        private System.Windows.Forms.ComboBox attendanceStudentClassComboBox;
        private System.Windows.Forms.Button attendanceStudentSearchButton;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.DataGridView attendanceStudentDataGrid;
        private System.Windows.Forms.Button attendanceStudentButton;
        private System.Windows.Forms.Panel tileBarPanel;
        private System.Windows.Forms.Button crossButton;
        private System.Windows.Forms.Button examMenuButton;
        private System.Windows.Forms.Panel examPanel;
        private System.Windows.Forms.Panel examCreateExamPanel;
        private System.Windows.Forms.Button examCreateExamButton;
        private System.Windows.Forms.Button examUploadMarkButton;
        private System.Windows.Forms.Panel examUploadMarksPanel;
        private System.Windows.Forms.ComboBox examCreateExamClassNameComboBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox examCreateExamDepartmentComboBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox examCreateExamExamNameTextBox;
        private System.Windows.Forms.DateTimePicker examCreateExamDate;
        private System.Windows.Forms.DataGridView examCreateExamDataGridView;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button examCreateExamSubmitBotton;
        private System.Windows.Forms.Button examCreateExamUpdateButton;
        private System.Windows.Forms.Button examCreateExamDeleteButton;
        private System.Windows.Forms.DataGridView examUploadMarksExamDataGrid;
        private System.Windows.Forms.DataGridView examUploadMarksDataGrid;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button examUploadMarksSubmitButton;
        private System.Windows.Forms.TextBox examUploadMarksTextBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridViewCheckBoxColumn checkBox;
        private System.Windows.Forms.Button attendanceDoneButton;
        private System.Windows.Forms.Panel attendanceUpdatePanel;
        private System.Windows.Forms.Button attendanceUpdateUpdateButton;
        private System.Windows.Forms.DateTimePicker attendanceUpdateDate;
        private System.Windows.Forms.Button attendanceUpdateSearchButton;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DataGridView attendanceUpdateDataGrid;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button attendanceUpdateAttendanceButton;
        private System.Windows.Forms.ComboBox attendanceUpdateComboBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DataGridView attendanceUpdateData2;
        private System.Windows.Forms.Button termExamMenuButton;
        private System.Windows.Forms.Panel termExamPanel;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button termExamMarkSubmitButton;
        private System.Windows.Forms.TextBox termExamMarkTextBox;
        private System.Windows.Forms.DataGridView termExamDataGrid;
        private System.Windows.Forms.DataGridView termExamMarksData;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button LogoutBotton;
        private System.Windows.Forms.Button profileMenuButton;
        private System.Windows.Forms.Panel profilePanel;
        private System.Windows.Forms.TextBox profileGenderTextBox;
        private System.Windows.Forms.TextBox profileRegisterDateTextBox;
        private System.Windows.Forms.TextBox profileSubjectTextBox;
        private System.Windows.Forms.TextBox profileBGTextBox;
        private System.Windows.Forms.TextBox profileDepartmentTextBox;
        private System.Windows.Forms.TextBox profileDOBTextBox;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.CheckBox profileStd6;
        private System.Windows.Forms.CheckBox profileStd10;
        private System.Windows.Forms.CheckBox profileStd2;
        private System.Windows.Forms.CheckBox profileStd5;
        private System.Windows.Forms.CheckBox profileStd8;
        private System.Windows.Forms.CheckBox profileStd7;
        private System.Windows.Forms.CheckBox profileStd1;
        private System.Windows.Forms.CheckBox profileStd3;
        private System.Windows.Forms.CheckBox profileStd9;
        private System.Windows.Forms.CheckBox profileNursary;
        private System.Windows.Forms.CheckBox profileStd4;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.TextBox profileConfirmPasswordTextBox;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.TextBox profilePasswordTextBox;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.TextBox profileIDTextBox;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label17;
        public System.Windows.Forms.PictureBox teacherAddPictureBox;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Button profileSubmitButton;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.RichTextBox profileAddressTextBox;
        private System.Windows.Forms.TextBox profileEmailTextBox;
        private System.Windows.Forms.TextBox profilePhoneTextBox;
        private System.Windows.Forms.TextBox profileNameTextBox;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.DataGridView profileDatas;
        private System.Windows.Forms.Button button1;

    }
}