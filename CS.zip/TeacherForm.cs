﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bussiness_Logic_Layer;
using System.IO;

namespace Projectwork111
{
    public partial class TeacherForm : Form
    {
        string userId, password;
        Login l;
        public TeacherForm(string s1, string s2,Login lo)
        {
            this.l = lo;
            userId = s1; password = s2;
            InitializeComponent();

            //Attendance Panel
            this.attendancePanel.SetBounds(185, 20, 1075, 644);
            this.attendancePanel.Visible = false;
            this.attendanceStudentPanel.SetBounds(0, 30, 1075, 605);
            this.attendanceStudentPanel.Visible = false;
            this.attendanceUpdatePanel.SetBounds(0, 30, 1075, 605);
            this.attendanceUpdatePanel.Visible = false;

            

            //exam Panel
            this.examPanel.SetBounds(185, 20, 1075, 644);
            this.examPanel.Visible = false;
            this.examCreateExamPanel.SetBounds(0, 30, 1075, 605);
            this.examCreateExamPanel.Visible = false;
            this.examUploadMarksPanel.SetBounds(0, 30, 1075, 605);
            this.examUploadMarksPanel.Visible = false;
            //termExam Panel
            this.termExamPanel.SetBounds(185, 20, 1075, 644);
            this.termExamPanel.Visible = false;
            //profile panel
            this.profilePanel.SetBounds(185, 20, 1075, 644);
            this.profilePanel.Visible = false;

        }

        private void crossButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //attendance Panel
        private void attendanceMenuButton_Click(object sender, EventArgs e)
        {
            this.profilePanel.Visible = false;
            termExamPanel.Visible = false;
            this.attendancePanel.Visible = true;
            this.examPanel.Visible = false;
        }
        int count2 = 0;
        private void attendanceStudentButton_Click(object sender, EventArgs e)
        {
            Teacher t = new Teacher();
            if (count2 == 0)
            {
                string[] classes = t.GetClasses(userId, password);
                for (int i = 0; i < 11; i++)
                {
                    if (classes[i] != null) { attendanceStudentClassComboBox.Items.Add(classes[i]); }
                }
                count2++;
            }
            
            this.attendanceStudentPanel.Visible = true;
            this.attendanceUpdatePanel.Visible = false;
        }

        //Student Panel
        private void studentMenuButton_Click(object sender, EventArgs e)
        {
            this.attendancePanel.Visible = false;
            this.examPanel.Visible = false;
        }



        

        //exam Panel
        private void examMenuButton_Click(object sender, EventArgs e)
        {
            this.profilePanel.Visible = false;
            this.termExamPanel.Visible = false;
            this.attendancePanel.Visible = false;
            this.examPanel.Visible = true;
        }
        int count=0;
        private void examCreateExamButton_Click(object sender, EventArgs e)
        {
            
            this.examUploadMarksPanel.Visible = false;
            this.examCreateExamPanel.Visible = true;
            if(count==0)
            {
            Teacher t = new Teacher();
            string[] classes = t.GetClasses(userId,password);
            for (int i = 0; i < 11; i++)
            {
                if (classes[i] != null) { examCreateExamClassNameComboBox.Items.Add(classes[i]); }
            }
            if (t.GetDepartment(userId, password) != "x")
            { examCreateExamDepartmentComboBox.Items.Add(t.GetDepartment(userId, password)); }
            else { examCreateExamDepartmentComboBox.Enabled = false; }
            count++;
            }
            Exam ex = new Exam();
            examCreateExamDataGridView.DataSource = ex.GetList(userId);
        }

        private void examUploadMarkButton_Click(object sender, EventArgs e)
        {
            this.examCreateExamPanel.Visible = false;
            this.examUploadMarksPanel.Visible = true;
            Exam ex = new Exam();
            examUploadMarksExamDataGrid.DataSource = ex.GetList(userId);
        }

        private void examCreateExamSubmitBotton_Click(object sender, EventArgs e)
        {
            Exam ex = new Exam();
            Teacher t = new Teacher();
            Marks m = new Marks();
            try { ex.Name = examCreateExamExamNameTextBox.Text; }
            catch (Exception ec) { ex.Name = ""; }
            try { ex.Class = examCreateExamClassNameComboBox.Text; }
            catch (Exception ec) { ex.Class = ""; }
            try { ex.Date = examCreateExamDate.Value.ToShortDateString(); }
            catch (Exception ec) { ex.Date = ""; }
            try { ex.TeacherId = userId; }
            catch (Exception ec) { }

            m.AddInMarksTable(ex.GetLastId() + 1, examCreateExamClassNameComboBox.Text, examCreateExamDepartmentComboBox.Text);

            ex.AddExam();
            MessageBox.Show("New Exam Schedule Added.");
            examCreateExamDataGridView.DataSource = ex.GetList(userId);
            examCreateExamExamNameTextBox.Text = examCreateExamDate.Text = examCreateExamDepartmentComboBox.Text
                = examCreateExamClassNameComboBox.Text = "";
     
        }

        private void examCreateExamUpdateButton_Click(object sender, EventArgs e)
        {
            Exam ex = new Exam(userId);
            try { ex.Name = examCreateExamExamNameTextBox.Text; }
            catch (Exception ec) { ex.Name = ""; }
            try { ex.Class = examCreateExamClassNameComboBox.Text; }
            catch (Exception ec) { ex.Class = ""; }
            try { ex.Date = examCreateExamDate.Value.ToShortDateString(); }
            catch (Exception ec) { ex.Date = ""; }
            try { ex.TeacherId = userId; }
            catch (Exception ec) { }

            try { ex.UpdateExam(examId); }
            catch (Exception ec) { MessageBox.Show("Select First."); }
            MessageBox.Show("New Exam Schedule Added.");
            examCreateExamDataGridView.DataSource = ex.GetList(userId);
            examCreateExamExamNameTextBox.Text = examCreateExamDate.Text = examCreateExamDepartmentComboBox.Text
                = examCreateExamClassNameComboBox.Text = "";
        }
        int examId;
        private void examCreateExamDataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try { examId = Convert.ToInt32(examCreateExamDataGridView.CurrentRow.Cells[0].Value); }
            catch (Exception ec) { }
            try { examCreateExamExamNameTextBox.Text = examCreateExamDataGridView.CurrentRow.Cells[1].Value.ToString(); }
            catch (Exception ec) { examCreateExamExamNameTextBox.Text = ""; }
            try { examCreateExamClassNameComboBox.Text = examCreateExamDataGridView.CurrentRow.Cells[2].Value.ToString(); }
            catch (Exception ec) { examCreateExamClassNameComboBox.Text = ""; }
            try { examCreateExamDate.Text = examCreateExamDataGridView.CurrentRow.Cells[4].Value.ToString(); }
            catch (Exception ec) { examCreateExamDate.Text = ""; }
            try { examCreateExamDepartmentComboBox.Text = examCreateExamDataGridView.CurrentRow.Cells[6].Value.ToString(); }
            catch (Exception ec) { examCreateExamDepartmentComboBox.Text = ""; }
        }

        private void examCreateExamDeleteButton_Click(object sender, EventArgs e)
        {
            Exam ex = new Exam();
            ex.DeleteExam(userId,examId);
            MessageBox.Show("Exam Schedule Deleted.");
            examCreateExamDataGridView.DataSource = ex.GetList(userId);
            examCreateExamExamNameTextBox.Text = examCreateExamDate.Text = examCreateExamDepartmentComboBox.Text
                = examCreateExamClassNameComboBox.Text = "";
        }
        int examIdinUploadPanel;
        private void examUploadMarksExamDataGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            examIdinUploadPanel = Convert.ToInt32(examUploadMarksExamDataGrid.CurrentRow.Cells[0].Value);
            Marks m = new Marks();
            examUploadMarksDataGrid.DataSource = m.GetList(examIdinUploadPanel);
        }
        int examUploadMarksDataGridID;
        string examUploadMarksDataGridSID;
        private void examUploadMarksDataGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            examUploadMarksDataGridID = Convert.ToInt32(examUploadMarksDataGrid.CurrentRow.Cells[0].Value);
            examUploadMarksDataGridSID = examUploadMarksDataGrid.CurrentRow.Cells[1].Value.ToString();
        }

        private void examUploadMarksSubmitButton_Click(object sender, EventArgs e)
        {
            try
            {
                Marks m = new Marks();
                m.SetMark(examUploadMarksDataGridID, examUploadMarksDataGridSID, float.Parse(examUploadMarksTextBox.Text));
                examUploadMarksTextBox.Text = "";
                examUploadMarksDataGrid.DataSource = m.GetList(examUploadMarksDataGridID);
            }
            catch (Exception ec) { MessageBox.Show("Select a Student."); }
        }

        private void attendanceStudentSearchButton_Click(object sender, EventArgs e)
        {
            string clsName;
            StudentAttendance sa = new StudentAttendance();
            try {  clsName = attendanceStudentClassComboBox.Text; }
            catch (Exception ec) { clsName = ""; }
            attendanceStudentDataGrid.DataSource = sa.GetStudentList(clsName, userId);
        }

        

        private void attendanceDoneButton_Click(object sender, EventArgs e)
        {
            StudentAttendance sa = new StudentAttendance();
            string name, sid;
            int p;
            for (int i = 0; i < attendanceStudentDataGrid.Rows.Count; i++)
            {
                if (Convert.ToBoolean(attendanceStudentDataGrid.Rows[i].Cells[0].Value) == true)
                {
                    p = 1;
                    name = attendanceStudentDataGrid.CurrentRow.Cells[1].Value.ToString();
                    sid = attendanceStudentDataGrid.CurrentRow.Cells[2].Value.ToString();
                    sa.AddStu(name, sid, p, attendanceStudentClassComboBox.Text, userId);
                }
                else
                {
                    p = 0;
                    name = attendanceStudentDataGrid.CurrentRow.Cells[1].Value.ToString();
                    sid = attendanceStudentDataGrid.CurrentRow.Cells[2].Value.ToString();
                    sa.AddStu(name, sid, p, attendanceStudentClassComboBox.Text, userId);
                }
            }
            MessageBox.Show("Attendance Done.");
            attendanceStudentDataGrid.DataSource = null;
        }

        int attendanceUpdateComboCount = 0;
        private void attendanceUpdateAttendanceButton_Click(object sender, EventArgs e)
        {
            Teacher t = new Teacher();
            if (attendanceUpdateComboCount == 0)
            {
                string[] classes = t.GetClasses(userId, password);
                for (int i = 0; i < 11; i++)
                {
                    if (classes[i] != null) { attendanceUpdateComboBox.Items.Add(classes[i]); }
                }
                attendanceUpdateComboCount++;
            }

            this.attendanceStudentPanel.Visible = false;
            this.attendanceUpdatePanel.Visible = true;
        }

        private void attendanceUpdateSearchButton_Click(object sender, EventArgs e)
        {
                StudentAttendance sa = new StudentAttendance();
                attendanceUpdateDataGrid.DataSource = sa.GetListByDate(attendanceUpdateDate.Text, attendanceUpdateComboBox.Text, userId);
                attendanceUpdateData2.DataSource = sa.GetAttendanceListByDate(attendanceUpdateDate.Text, attendanceUpdateComboBox.Text, userId);

                for (int i = 0; i < attendanceUpdateDataGrid.Rows.Count; i++)
                {
                    if (Convert.ToInt32(attendanceUpdateData2.Rows[i].Cells[0].Value) == 1)
                    {
                        attendanceUpdateDataGrid.Rows[i].Cells[0].Value = true;

                    }
                    else
                    {
                        attendanceUpdateDataGrid.Rows[i].Cells[0].Value = false;

                    }
                }
        }

        private void attendanceUpdateUpdateButton_Click(object sender, EventArgs e)
        {
            int p;
            StudentAttendance s = new StudentAttendance();
            for (int i = 0; i < attendanceUpdateDataGrid.Rows.Count; i++)
            {
                if (Convert.ToBoolean(attendanceUpdateDataGrid.Rows[i].Cells[0].Value) == true)
                {
                    p = 1;
                    s.Update(attendanceUpdateDate.Value.ToShortDateString(), attendanceUpdateComboBox.Text, userId, p);
                }
                else
                {
                    p = 0;
                    s.Update(attendanceUpdateDate.Value.ToShortDateString(), attendanceUpdateComboBox.Text, userId, p);
                }
            }
            MessageBox.Show("Attendance Done.");
            attendanceUpdateDataGrid.DataSource = null;
        }

        int count3=0;
        private void termExamMenuButton_Click(object sender, EventArgs e)
        {
            
            Exam ex = new Exam();
            termExamDataGrid.DataSource = ex.GetTermExamListForTeacher(userId);
            this.profilePanel.Visible = false;
            this.termExamPanel.Visible = true;
            this.attendancePanel.Visible = false;
            this.examPanel.Visible = false;
        }

        int eid;
        private void termExamDataGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            eid = Convert.ToInt32(termExamDataGrid.CurrentRow.Cells[0].Value);
            Exam ex = new Exam();
            termExamMarksData.DataSource = ex.GetMarksList(eid);
        }

        string si;
        private void termExamMarksData_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            si = termExamMarksData.CurrentRow.Cells[1].Value.ToString();
            try { termExamMarkTextBox.Text = termExamMarksData.CurrentRow.Cells[4].Value.ToString(); }
            catch (Exception ec) { termExamMarkTextBox.Text = ""; }
        }

        private void termExamMarkSubmitButton_Click(object sender, EventArgs e)
        {
            try
            {
                Exam ex = new Exam();
                ex.AddMark(si, float.Parse(termExamMarkTextBox.Text));
                termExamMarksData.DataSource = ex.GetMarksList(eid);
            }
            catch (Exception ec) { MessageBox.Show("Select a Student."); }
        }

        private void LogoutBotton_Click(object sender, EventArgs e)
        {
            this.l.Show();
            this.Hide();
        }

        //profile Panel
        private void profileMenuButton_Click(object sender, EventArgs e)
        {
            this.profilePanel.Visible = true;
            this.termExamPanel.Visible = false;
            this.attendancePanel.Visible = false;
            this.examPanel.Visible = false;

            ProfileData();

        }

        void ProfileData()
        {
            Teacher t = new Teacher();
            profileDatas.DataSource = t.GetListForProfile(userId);

            profileIDTextBox.Text = profileDatas.Rows[0].Cells[0].Value.ToString();
            profileNameTextBox.Text = profileDatas.Rows[0].Cells[1].Value.ToString();
            profileGenderTextBox.Text = profileDatas.Rows[0].Cells[2].Value.ToString();
            profilePasswordTextBox.Text = profileDatas.Rows[0].Cells[3].Value.ToString();
            profileConfirmPasswordTextBox.Text = profileDatas.Rows[0].Cells[3].Value.ToString();
            profileEmailTextBox.Text = profileDatas.Rows[0].Cells[4].Value.ToString();
            profilePhoneTextBox.Text= profileDatas.Rows[0].Cells[5].Value.ToString();
            profileDOBTextBox.Text = profileDatas.Rows[0].Cells[6].Value.ToString();
            profileSubjectTextBox.Text = profileDatas.Rows[0].Cells[7].Value.ToString();
            profileDepartmentTextBox.Text = profileDatas.Rows[0].Cells[8].Value.ToString();
            profileBGTextBox.Text = profileDatas.Rows[0].Cells[9].Value.ToString();
            profileAddressTextBox.Text = profileDatas.Rows[0].Cells[10].Value.ToString();
            profileRegisterDateTextBox.Text = profileDatas.Rows[0].Cells[11].Value.ToString();
            if (Convert.ToInt32(profileDatas.Rows[0].Cells[12].Value) == 1) { profileNursary.Checked = true; }
            if (Convert.ToInt32(profileDatas.Rows[0].Cells[13].Value) == 1) { profileStd1.Checked = true; }
            if (Convert.ToInt32(profileDatas.Rows[0].Cells[14].Value) == 1) { profileStd2.Checked = true; }
            if (Convert.ToInt32(profileDatas.Rows[0].Cells[15].Value) == 1) { profileStd3.Checked = true; }
            if (Convert.ToInt32(profileDatas.Rows[0].Cells[16].Value) == 1) { profileStd4.Checked = true; }
            if (Convert.ToInt32(profileDatas.Rows[0].Cells[17].Value) == 1) { profileStd5.Checked = true; }
            if (Convert.ToInt32(profileDatas.Rows[0].Cells[18].Value) == 1) { profileStd6.Checked = true; }
            if (Convert.ToInt32(profileDatas.Rows[0].Cells[19].Value) == 1) { profileStd7.Checked = true; }
            if (Convert.ToInt32(profileDatas.Rows[0].Cells[20].Value) == 1) { profileStd8.Checked = true; }
            if (Convert.ToInt32(profileDatas.Rows[0].Cells[21].Value) == 1) { profileStd9.Checked = true; }
            if (Convert.ToInt32(profileDatas.Rows[0].Cells[22].Value) == 1) { profileStd10.Checked = true; }
            teacherAddPictureBox.Image=byteArrayToImage(t.GetPhotoOfTeacher(userId));
        }

        public Image byteArrayToImage(byte[] byteArrayIn)
        {
            MemoryStream ms = new MemoryStream(byteArrayIn);
            Image returnImage = Image.FromStream(ms);
            return returnImage;
        }
       

        private void profileSubmitButton_Click(object sender, EventArgs e)
        {
            if (profilePasswordTextBox.Text == profileConfirmPasswordTextBox.Text)
            {
                Teacher t = new Teacher();
                t.UpdatePassword(userId, profilePasswordTextBox.Text);
                MessageBox.Show("Password Updated");
            }
            else
            {
                MessageBox.Show("Password Did not Matched.");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            attendanceUpdateDataGrid.DataSource = null;
        }

        

        
    }
}
