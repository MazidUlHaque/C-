﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projectwork111
{
    public partial class Teacher : Form
    {
        public Teacher()
        {
            InitializeComponent();

            //Attendance Panel
            this.attendancePanel.SetBounds(185, 20, 1075, 644);
            this.attendancePanel.Visible = false;
            this.attendanceStudentPanel.SetBounds(0, 28, 1075, 605);
            this.attendanceStudentPanel.Visible = false;

            //Student Panel
            this.studentPanel.SetBounds(185, 20, 1075, 644);
            this.studentPanel.Visible = false;
            this.studentPromotionPanel.SetBounds(0, 28, 1075, 605);
            this.studentPromotionPanel.Visible = false;

            //exam Panel
            this.examPanel.SetBounds(185, 20, 1075, 644);
            this.examPanel.Visible = false;
            this.examCreateExamPanel.SetBounds(0, 28, 1075, 605);
            this.examCreateExamPanel.Visible = false;
            this.examUploadMarksPanel.SetBounds(0, 28, 1075, 605);
            this.examUploadMarksPanel.Visible = false;

        }

        private void crossButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //attendance Panel
        private void attendanceMenuButton_Click(object sender, EventArgs e)
        {
            this.attendancePanel.Visible = true;
            this.studentPanel.Visible = false;
            this.examPanel.Visible = false;
        }

        private void attendanceStudentButton_Click(object sender, EventArgs e)
        {
            this.attendanceStudentPanel.Visible = true;
        }

        //Student Panel
        private void studentMenuButton_Click(object sender, EventArgs e)
        {
            this.attendancePanel.Visible = false;
            this.studentPanel.Visible = true;
            this.examPanel.Visible = false;
        }

        private void studentPromotion_Click(object sender, EventArgs e)
        {
            this.studentPromotionPanel.Visible = true;
        }

        

        //exam Panel
        private void examMenuButton_Click(object sender, EventArgs e)
        {
            this.attendancePanel.Visible = false;
            this.studentPanel.Visible = false;
            this.examPanel.Visible = true;
        }

        private void examCreateExamButton_Click(object sender, EventArgs e)
        {
            this.examUploadMarksPanel.Visible = false;
            this.examCreateExamPanel.Visible = true;
        }

        private void examUploadMarkButton_Click(object sender, EventArgs e)
        {
            this.examCreateExamPanel.Visible = false;
            this.examUploadMarksPanel.Visible = true;
        }

        
    }
}
