﻿namespace Projectwork111
{
    partial class Teacher
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Teacher));
            this.menu = new System.Windows.Forms.Panel();
            this.examMenuButton = new System.Windows.Forms.Button();
            this.studentMenuButton = new System.Windows.Forms.Button();
            this.attendanceMenuButton = new System.Windows.Forms.Button();
            this.attendancePanel = new System.Windows.Forms.Panel();
            this.attendanceStudentPanel = new System.Windows.Forms.Panel();
            this.attendanceStudentSectionComboBox = new System.Windows.Forms.ComboBox();
            this.label35 = new System.Windows.Forms.Label();
            this.attendanceStudentClassComboBox = new System.Windows.Forms.ComboBox();
            this.attendanceStudentSearchButton = new System.Windows.Forms.Button();
            this.label72 = new System.Windows.Forms.Label();
            this.attendanceStudentDataGrid = new System.Windows.Forms.DataGridView();
            this.attendanceStudentButton = new System.Windows.Forms.Button();
            this.studentPanel = new System.Windows.Forms.Panel();
            this.studentPromotionPanel = new System.Windows.Forms.Panel();
            this.studentPromotionClassUpdateComboBox = new System.Windows.Forms.ComboBox();
            this.label64 = new System.Windows.Forms.Label();
            this.studentPromotionClassComboBox = new System.Windows.Forms.ComboBox();
            this.studentPromotionSearchButton = new System.Windows.Forms.Button();
            this.label50 = new System.Windows.Forms.Label();
            this.studentPromotionPromoteButton = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.studentPromotion = new System.Windows.Forms.Button();
            this.examUploadMarksPanel = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.examUploadMarksSubmitButton = new System.Windows.Forms.Button();
            this.examUploadMarksTextBox = new System.Windows.Forms.TextBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.tileBarPanel = new System.Windows.Forms.Panel();
            this.crossButton = new System.Windows.Forms.Button();
            this.examPanel = new System.Windows.Forms.Panel();
            this.examCreateExamPanel = new System.Windows.Forms.Panel();
            this.examCreateExamUpdateButton = new System.Windows.Forms.Button();
            this.examCreateExamDeleteButton = new System.Windows.Forms.Button();
            this.examCreateExamDataGridView = new System.Windows.Forms.DataGridView();
            this.label6 = new System.Windows.Forms.Label();
            this.examCreateExamSubmitBotton = new System.Windows.Forms.Button();
            this.examCreateExamDate = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.examCreateExamSectionComboBox = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.examCreateExamDepartmentComboBox = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.examCreateExamExamNameTextBox = new System.Windows.Forms.TextBox();
            this.examCreateExamClassNameComboBox = new System.Windows.Forms.ComboBox();
            this.examCreateExamButton = new System.Windows.Forms.Button();
            this.examUploadMarkButton = new System.Windows.Forms.Button();
            this.menu.SuspendLayout();
            this.attendancePanel.SuspendLayout();
            this.attendanceStudentPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.attendanceStudentDataGrid)).BeginInit();
            this.studentPanel.SuspendLayout();
            this.studentPromotionPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.examUploadMarksPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.tileBarPanel.SuspendLayout();
            this.examPanel.SuspendLayout();
            this.examCreateExamPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.examCreateExamDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // menu
            // 
            this.menu.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("menu.BackgroundImage")));
            this.menu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.menu.Controls.Add(this.examMenuButton);
            this.menu.Controls.Add(this.studentMenuButton);
            this.menu.Controls.Add(this.attendanceMenuButton);
            this.menu.Dock = System.Windows.Forms.DockStyle.Left;
            this.menu.Location = new System.Drawing.Point(0, 0);
            this.menu.Name = "menu";
            this.menu.Size = new System.Drawing.Size(185, 670);
            this.menu.TabIndex = 1;
            // 
            // examMenuButton
            // 
            this.examMenuButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(48)))), ((int)(((byte)(146)))));
            this.examMenuButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.examMenuButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.examMenuButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.examMenuButton.ForeColor = System.Drawing.Color.White;
            this.examMenuButton.Location = new System.Drawing.Point(3, 191);
            this.examMenuButton.Name = "examMenuButton";
            this.examMenuButton.Size = new System.Drawing.Size(182, 33);
            this.examMenuButton.TabIndex = 5;
            this.examMenuButton.Text = "Exam";
            this.examMenuButton.UseVisualStyleBackColor = false;
            this.examMenuButton.Click += new System.EventHandler(this.examMenuButton_Click);
            // 
            // studentMenuButton
            // 
            this.studentMenuButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(48)))), ((int)(((byte)(146)))));
            this.studentMenuButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.studentMenuButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.studentMenuButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentMenuButton.ForeColor = System.Drawing.Color.White;
            this.studentMenuButton.Location = new System.Drawing.Point(3, 133);
            this.studentMenuButton.Name = "studentMenuButton";
            this.studentMenuButton.Size = new System.Drawing.Size(182, 33);
            this.studentMenuButton.TabIndex = 4;
            this.studentMenuButton.Text = "Students";
            this.studentMenuButton.UseVisualStyleBackColor = false;
            this.studentMenuButton.Click += new System.EventHandler(this.studentMenuButton_Click);
            // 
            // attendanceMenuButton
            // 
            this.attendanceMenuButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(48)))), ((int)(((byte)(146)))));
            this.attendanceMenuButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.attendanceMenuButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.attendanceMenuButton.ForeColor = System.Drawing.Color.White;
            this.attendanceMenuButton.Location = new System.Drawing.Point(2, 74);
            this.attendanceMenuButton.Name = "attendanceMenuButton";
            this.attendanceMenuButton.Size = new System.Drawing.Size(182, 33);
            this.attendanceMenuButton.TabIndex = 3;
            this.attendanceMenuButton.Text = "Attendance";
            this.attendanceMenuButton.UseVisualStyleBackColor = false;
            this.attendanceMenuButton.Click += new System.EventHandler(this.attendanceMenuButton_Click);
            // 
            // attendancePanel
            // 
            this.attendancePanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.attendancePanel.Controls.Add(this.attendanceStudentPanel);
            this.attendancePanel.Controls.Add(this.attendanceStudentButton);
            this.attendancePanel.Location = new System.Drawing.Point(210, 38);
            this.attendancePanel.Name = "attendancePanel";
            this.attendancePanel.Size = new System.Drawing.Size(66, 69);
            this.attendancePanel.TabIndex = 4;
            this.attendancePanel.Visible = false;
            // 
            // attendanceStudentPanel
            // 
            this.attendanceStudentPanel.AutoScroll = true;
            this.attendanceStudentPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.attendanceStudentPanel.Controls.Add(this.attendanceStudentSectionComboBox);
            this.attendanceStudentPanel.Controls.Add(this.label35);
            this.attendanceStudentPanel.Controls.Add(this.attendanceStudentClassComboBox);
            this.attendanceStudentPanel.Controls.Add(this.attendanceStudentSearchButton);
            this.attendanceStudentPanel.Controls.Add(this.label72);
            this.attendanceStudentPanel.Controls.Add(this.attendanceStudentDataGrid);
            this.attendanceStudentPanel.Location = new System.Drawing.Point(15, 44);
            this.attendanceStudentPanel.Name = "attendanceStudentPanel";
            this.attendanceStudentPanel.Size = new System.Drawing.Size(751, 372);
            this.attendanceStudentPanel.TabIndex = 6;
            this.attendanceStudentPanel.Visible = false;
            // 
            // attendanceStudentSectionComboBox
            // 
            this.attendanceStudentSectionComboBox.FormattingEnabled = true;
            this.attendanceStudentSectionComboBox.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Others"});
            this.attendanceStudentSectionComboBox.Location = new System.Drawing.Point(383, 30);
            this.attendanceStudentSectionComboBox.Name = "attendanceStudentSectionComboBox";
            this.attendanceStudentSectionComboBox.Size = new System.Drawing.Size(151, 21);
            this.attendanceStudentSectionComboBox.TabIndex = 67;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(329, 33);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(48, 15);
            this.label35.TabIndex = 66;
            this.label35.Text = "Section";
            // 
            // attendanceStudentClassComboBox
            // 
            this.attendanceStudentClassComboBox.FormattingEnabled = true;
            this.attendanceStudentClassComboBox.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Others"});
            this.attendanceStudentClassComboBox.Location = new System.Drawing.Point(127, 30);
            this.attendanceStudentClassComboBox.Name = "attendanceStudentClassComboBox";
            this.attendanceStudentClassComboBox.Size = new System.Drawing.Size(151, 21);
            this.attendanceStudentClassComboBox.TabIndex = 63;
            // 
            // attendanceStudentSearchButton
            // 
            this.attendanceStudentSearchButton.BackColor = System.Drawing.Color.Silver;
            this.attendanceStudentSearchButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.attendanceStudentSearchButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.attendanceStudentSearchButton.Location = new System.Drawing.Point(612, 25);
            this.attendanceStudentSearchButton.Name = "attendanceStudentSearchButton";
            this.attendanceStudentSearchButton.Size = new System.Drawing.Size(128, 26);
            this.attendanceStudentSearchButton.TabIndex = 62;
            this.attendanceStudentSearchButton.Text = "Search";
            this.attendanceStudentSearchButton.UseVisualStyleBackColor = false;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label72.Location = new System.Drawing.Point(47, 33);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(74, 15);
            this.label72.TabIndex = 60;
            this.label72.Text = "Class Name";
            // 
            // attendanceStudentDataGrid
            // 
            this.attendanceStudentDataGrid.AllowUserToAddRows = false;
            this.attendanceStudentDataGrid.AllowUserToDeleteRows = false;
            this.attendanceStudentDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.attendanceStudentDataGrid.Location = new System.Drawing.Point(4, 76);
            this.attendanceStudentDataGrid.Name = "attendanceStudentDataGrid";
            this.attendanceStudentDataGrid.ReadOnly = true;
            this.attendanceStudentDataGrid.Size = new System.Drawing.Size(747, 236);
            this.attendanceStudentDataGrid.TabIndex = 0;
            // 
            // attendanceStudentButton
            // 
            this.attendanceStudentButton.BackColor = System.Drawing.Color.Silver;
            this.attendanceStudentButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.attendanceStudentButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.attendanceStudentButton.Location = new System.Drawing.Point(638, 3);
            this.attendanceStudentButton.Name = "attendanceStudentButton";
            this.attendanceStudentButton.Size = new System.Drawing.Size(143, 26);
            this.attendanceStudentButton.TabIndex = 2;
            this.attendanceStudentButton.Text = "Student Attendance";
            this.attendanceStudentButton.UseVisualStyleBackColor = false;
            this.attendanceStudentButton.Click += new System.EventHandler(this.attendanceStudentButton_Click);
            // 
            // studentPanel
            // 
            this.studentPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.studentPanel.Controls.Add(this.studentPromotionPanel);
            this.studentPanel.Controls.Add(this.studentPromotion);
            this.studentPanel.Location = new System.Drawing.Point(210, 158);
            this.studentPanel.Name = "studentPanel";
            this.studentPanel.Size = new System.Drawing.Size(66, 39);
            this.studentPanel.TabIndex = 5;
            this.studentPanel.Visible = false;
            // 
            // studentPromotionPanel
            // 
            this.studentPromotionPanel.AutoScroll = true;
            this.studentPromotionPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.studentPromotionPanel.Controls.Add(this.studentPromotionClassUpdateComboBox);
            this.studentPromotionPanel.Controls.Add(this.label64);
            this.studentPromotionPanel.Controls.Add(this.studentPromotionClassComboBox);
            this.studentPromotionPanel.Controls.Add(this.studentPromotionSearchButton);
            this.studentPromotionPanel.Controls.Add(this.label50);
            this.studentPromotionPanel.Controls.Add(this.studentPromotionPromoteButton);
            this.studentPromotionPanel.Controls.Add(this.dataGridView1);
            this.studentPromotionPanel.Location = new System.Drawing.Point(27, 18);
            this.studentPromotionPanel.Name = "studentPromotionPanel";
            this.studentPromotionPanel.Size = new System.Drawing.Size(534, 153);
            this.studentPromotionPanel.TabIndex = 6;
            this.studentPromotionPanel.Visible = false;
            // 
            // studentPromotionClassUpdateComboBox
            // 
            this.studentPromotionClassUpdateComboBox.FormattingEnabled = true;
            this.studentPromotionClassUpdateComboBox.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Others"});
            this.studentPromotionClassUpdateComboBox.Location = new System.Drawing.Point(337, 379);
            this.studentPromotionClassUpdateComboBox.Name = "studentPromotionClassUpdateComboBox";
            this.studentPromotionClassUpdateComboBox.Size = new System.Drawing.Size(151, 21);
            this.studentPromotionClassUpdateComboBox.TabIndex = 65;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.Location = new System.Drawing.Point(272, 385);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(37, 15);
            this.label64.TabIndex = 64;
            this.label64.Text = "Class";
            // 
            // studentPromotionClassComboBox
            // 
            this.studentPromotionClassComboBox.FormattingEnabled = true;
            this.studentPromotionClassComboBox.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Others"});
            this.studentPromotionClassComboBox.Location = new System.Drawing.Point(409, 30);
            this.studentPromotionClassComboBox.Name = "studentPromotionClassComboBox";
            this.studentPromotionClassComboBox.Size = new System.Drawing.Size(151, 21);
            this.studentPromotionClassComboBox.TabIndex = 63;
            // 
            // studentPromotionSearchButton
            // 
            this.studentPromotionSearchButton.BackColor = System.Drawing.Color.Silver;
            this.studentPromotionSearchButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.studentPromotionSearchButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.studentPromotionSearchButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.studentPromotionSearchButton.Location = new System.Drawing.Point(612, 25);
            this.studentPromotionSearchButton.Name = "studentPromotionSearchButton";
            this.studentPromotionSearchButton.Size = new System.Drawing.Size(128, 26);
            this.studentPromotionSearchButton.TabIndex = 62;
            this.studentPromotionSearchButton.Text = "Search";
            this.studentPromotionSearchButton.UseVisualStyleBackColor = false;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(329, 33);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(74, 15);
            this.label50.TabIndex = 60;
            this.label50.Text = "Class Name";
            // 
            // studentPromotionPromoteButton
            // 
            this.studentPromotionPromoteButton.BackColor = System.Drawing.Color.Silver;
            this.studentPromotionPromoteButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.studentPromotionPromoteButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.studentPromotionPromoteButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.studentPromotionPromoteButton.Location = new System.Drawing.Point(549, 378);
            this.studentPromotionPromoteButton.Name = "studentPromotionPromoteButton";
            this.studentPromotionPromoteButton.Size = new System.Drawing.Size(128, 26);
            this.studentPromotionPromoteButton.TabIndex = 58;
            this.studentPromotionPromoteButton.Text = "Promote";
            this.studentPromotionPromoteButton.UseVisualStyleBackColor = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(14, 76);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(747, 236);
            this.dataGridView1.TabIndex = 0;
            // 
            // studentPromotion
            // 
            this.studentPromotion.BackColor = System.Drawing.Color.Silver;
            this.studentPromotion.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.studentPromotion.Cursor = System.Windows.Forms.Cursors.Default;
            this.studentPromotion.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.studentPromotion.Location = new System.Drawing.Point(693, 2);
            this.studentPromotion.Name = "studentPromotion";
            this.studentPromotion.Size = new System.Drawing.Size(128, 26);
            this.studentPromotion.TabIndex = 2;
            this.studentPromotion.Text = "Promotion";
            this.studentPromotion.UseVisualStyleBackColor = false;
            this.studentPromotion.Click += new System.EventHandler(this.studentPromotion_Click);
            // 
            // examUploadMarksPanel
            // 
            this.examUploadMarksPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.examUploadMarksPanel.Controls.Add(this.label7);
            this.examUploadMarksPanel.Controls.Add(this.examUploadMarksSubmitButton);
            this.examUploadMarksPanel.Controls.Add(this.examUploadMarksTextBox);
            this.examUploadMarksPanel.Controls.Add(this.dataGridView2);
            this.examUploadMarksPanel.Controls.Add(this.dataGridView3);
            this.examUploadMarksPanel.Location = new System.Drawing.Point(142, 28);
            this.examUploadMarksPanel.Name = "examUploadMarksPanel";
            this.examUploadMarksPanel.Size = new System.Drawing.Size(63, 59);
            this.examUploadMarksPanel.TabIndex = 77;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(393, 221);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(46, 17);
            this.label7.TabIndex = 84;
            this.label7.Text = "Marks";
            // 
            // examUploadMarksSubmitButton
            // 
            this.examUploadMarksSubmitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.examUploadMarksSubmitButton.Location = new System.Drawing.Point(620, 218);
            this.examUploadMarksSubmitButton.Name = "examUploadMarksSubmitButton";
            this.examUploadMarksSubmitButton.Size = new System.Drawing.Size(75, 23);
            this.examUploadMarksSubmitButton.TabIndex = 83;
            this.examUploadMarksSubmitButton.Text = "Submit";
            this.examUploadMarksSubmitButton.UseVisualStyleBackColor = true;
            // 
            // examUploadMarksTextBox
            // 
            this.examUploadMarksTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.examUploadMarksTextBox.Location = new System.Drawing.Point(475, 218);
            this.examUploadMarksTextBox.Name = "examUploadMarksTextBox";
            this.examUploadMarksTextBox.Size = new System.Drawing.Size(100, 23);
            this.examUploadMarksTextBox.TabIndex = 82;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(3, 3);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.Size = new System.Drawing.Size(326, 140);
            this.dataGridView2.TabIndex = 80;
            // 
            // dataGridView3
            // 
            this.dataGridView3.AllowUserToAddRows = false;
            this.dataGridView3.AllowUserToDeleteRows = false;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(351, 3);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.ReadOnly = true;
            this.dataGridView3.Size = new System.Drawing.Size(455, 140);
            this.dataGridView3.TabIndex = 81;
            // 
            // tileBarPanel
            // 
            this.tileBarPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.tileBarPanel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tileBarPanel.BackgroundImage")));
            this.tileBarPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tileBarPanel.Controls.Add(this.crossButton);
            this.tileBarPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.tileBarPanel.Location = new System.Drawing.Point(185, 0);
            this.tileBarPanel.Name = "tileBarPanel";
            this.tileBarPanel.Size = new System.Drawing.Size(1075, 20);
            this.tileBarPanel.TabIndex = 6;
            // 
            // crossButton
            // 
            this.crossButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.crossButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("crossButton.BackgroundImage")));
            this.crossButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.crossButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.crossButton.Location = new System.Drawing.Point(817, 0);
            this.crossButton.Name = "crossButton";
            this.crossButton.Size = new System.Drawing.Size(26, 20);
            this.crossButton.TabIndex = 0;
            this.crossButton.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.crossButton.UseVisualStyleBackColor = false;
            this.crossButton.Click += new System.EventHandler(this.crossButton_Click);
            // 
            // examPanel
            // 
            this.examPanel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.examPanel.Controls.Add(this.examUploadMarksPanel);
            this.examPanel.Controls.Add(this.examCreateExamPanel);
            this.examPanel.Controls.Add(this.examCreateExamButton);
            this.examPanel.Controls.Add(this.examUploadMarkButton);
            this.examPanel.Location = new System.Drawing.Point(210, 241);
            this.examPanel.Name = "examPanel";
            this.examPanel.Size = new System.Drawing.Size(88, 48);
            this.examPanel.TabIndex = 7;
            this.examPanel.Visible = false;
            // 
            // examCreateExamPanel
            // 
            this.examCreateExamPanel.AutoScroll = true;
            this.examCreateExamPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.examCreateExamPanel.Controls.Add(this.examCreateExamUpdateButton);
            this.examCreateExamPanel.Controls.Add(this.examCreateExamDeleteButton);
            this.examCreateExamPanel.Controls.Add(this.examCreateExamDataGridView);
            this.examCreateExamPanel.Controls.Add(this.label6);
            this.examCreateExamPanel.Controls.Add(this.examCreateExamSubmitBotton);
            this.examCreateExamPanel.Controls.Add(this.examCreateExamDate);
            this.examCreateExamPanel.Controls.Add(this.label5);
            this.examCreateExamPanel.Controls.Add(this.examCreateExamSectionComboBox);
            this.examCreateExamPanel.Controls.Add(this.label4);
            this.examCreateExamPanel.Controls.Add(this.label3);
            this.examCreateExamPanel.Controls.Add(this.label2);
            this.examCreateExamPanel.Controls.Add(this.examCreateExamDepartmentComboBox);
            this.examCreateExamPanel.Controls.Add(this.label1);
            this.examCreateExamPanel.Controls.Add(this.examCreateExamExamNameTextBox);
            this.examCreateExamPanel.Controls.Add(this.examCreateExamClassNameComboBox);
            this.examCreateExamPanel.Location = new System.Drawing.Point(8, 15);
            this.examCreateExamPanel.Name = "examCreateExamPanel";
            this.examCreateExamPanel.Size = new System.Drawing.Size(108, 89);
            this.examCreateExamPanel.TabIndex = 76;
            // 
            // examCreateExamUpdateButton
            // 
            this.examCreateExamUpdateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.examCreateExamUpdateButton.Location = new System.Drawing.Point(406, 382);
            this.examCreateExamUpdateButton.Name = "examCreateExamUpdateButton";
            this.examCreateExamUpdateButton.Size = new System.Drawing.Size(92, 23);
            this.examCreateExamUpdateButton.TabIndex = 81;
            this.examCreateExamUpdateButton.Text = "Update";
            this.examCreateExamUpdateButton.UseVisualStyleBackColor = true;
            // 
            // examCreateExamDeleteButton
            // 
            this.examCreateExamDeleteButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.examCreateExamDeleteButton.Location = new System.Drawing.Point(504, 382);
            this.examCreateExamDeleteButton.Name = "examCreateExamDeleteButton";
            this.examCreateExamDeleteButton.Size = new System.Drawing.Size(92, 23);
            this.examCreateExamDeleteButton.TabIndex = 80;
            this.examCreateExamDeleteButton.Text = "Delete";
            this.examCreateExamDeleteButton.UseVisualStyleBackColor = true;
            // 
            // examCreateExamDataGridView
            // 
            this.examCreateExamDataGridView.AllowUserToAddRows = false;
            this.examCreateExamDataGridView.AllowUserToDeleteRows = false;
            this.examCreateExamDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.examCreateExamDataGridView.Location = new System.Drawing.Point(20, 260);
            this.examCreateExamDataGridView.Name = "examCreateExamDataGridView";
            this.examCreateExamDataGridView.ReadOnly = true;
            this.examCreateExamDataGridView.Size = new System.Drawing.Size(372, 168);
            this.examCreateExamDataGridView.TabIndex = 79;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label6.Location = new System.Drawing.Point(237, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(286, 24);
            this.label6.TabIndex = 78;
            this.label6.Text = "Create New Class Test Schedule";
            // 
            // examCreateExamSubmitBotton
            // 
            this.examCreateExamSubmitBotton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.examCreateExamSubmitBotton.Location = new System.Drawing.Point(521, 192);
            this.examCreateExamSubmitBotton.Name = "examCreateExamSubmitBotton";
            this.examCreateExamSubmitBotton.Size = new System.Drawing.Size(92, 23);
            this.examCreateExamSubmitBotton.TabIndex = 77;
            this.examCreateExamSubmitBotton.Text = "Submit";
            this.examCreateExamSubmitBotton.UseVisualStyleBackColor = true;
            // 
            // examCreateExamDate
            // 
            this.examCreateExamDate.Location = new System.Drawing.Point(179, 171);
            this.examCreateExamDate.Name = "examCreateExamDate";
            this.examCreateExamDate.Size = new System.Drawing.Size(143, 20);
            this.examCreateExamDate.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(403, 128);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 17);
            this.label5.TabIndex = 8;
            this.label5.Text = "Section";
            // 
            // examCreateExamSectionComboBox
            // 
            this.examCreateExamSectionComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.examCreateExamSectionComboBox.FormattingEnabled = true;
            this.examCreateExamSectionComboBox.Items.AddRange(new object[] {
            "Science",
            "Arts",
            "Commerce"});
            this.examCreateExamSectionComboBox.Location = new System.Drawing.Point(521, 125);
            this.examCreateExamSectionComboBox.Name = "examCreateExamSectionComboBox";
            this.examCreateExamSectionComboBox.Size = new System.Drawing.Size(121, 24);
            this.examCreateExamSectionComboBox.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(68, 75);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 17);
            this.label4.TabIndex = 6;
            this.label4.Text = "Class Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(403, 75);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 17);
            this.label3.TabIndex = 5;
            this.label3.Text = "Department";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(68, 171);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "Date";
            // 
            // examCreateExamDepartmentComboBox
            // 
            this.examCreateExamDepartmentComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.examCreateExamDepartmentComboBox.FormattingEnabled = true;
            this.examCreateExamDepartmentComboBox.Items.AddRange(new object[] {
            "Science",
            "Arts",
            "Commerce"});
            this.examCreateExamDepartmentComboBox.Location = new System.Drawing.Point(521, 72);
            this.examCreateExamDepartmentComboBox.Name = "examCreateExamDepartmentComboBox";
            this.examCreateExamDepartmentComboBox.Size = new System.Drawing.Size(121, 24);
            this.examCreateExamDepartmentComboBox.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(68, 125);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Exam Name";
            // 
            // examCreateExamExamNameTextBox
            // 
            this.examCreateExamExamNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.examCreateExamExamNameTextBox.Location = new System.Drawing.Point(179, 122);
            this.examCreateExamExamNameTextBox.Name = "examCreateExamExamNameTextBox";
            this.examCreateExamExamNameTextBox.Size = new System.Drawing.Size(100, 23);
            this.examCreateExamExamNameTextBox.TabIndex = 1;
            // 
            // examCreateExamClassNameComboBox
            // 
            this.examCreateExamClassNameComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.examCreateExamClassNameComboBox.FormattingEnabled = true;
            this.examCreateExamClassNameComboBox.Items.AddRange(new object[] {
            "Nursary",
            "STD-1",
            "STD-2",
            "STD-3",
            "STD-4",
            "STD-5",
            "STD-6",
            "STD-7",
            "STD-8",
            "STD-9",
            "STD-10"});
            this.examCreateExamClassNameComboBox.Location = new System.Drawing.Point(179, 75);
            this.examCreateExamClassNameComboBox.Name = "examCreateExamClassNameComboBox";
            this.examCreateExamClassNameComboBox.Size = new System.Drawing.Size(121, 24);
            this.examCreateExamClassNameComboBox.TabIndex = 0;
            // 
            // examCreateExamButton
            // 
            this.examCreateExamButton.BackColor = System.Drawing.Color.Silver;
            this.examCreateExamButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.examCreateExamButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.examCreateExamButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.examCreateExamButton.Location = new System.Drawing.Point(572, 3);
            this.examCreateExamButton.Name = "examCreateExamButton";
            this.examCreateExamButton.Size = new System.Drawing.Size(128, 31);
            this.examCreateExamButton.TabIndex = 75;
            this.examCreateExamButton.Text = "Create Exam";
            this.examCreateExamButton.UseVisualStyleBackColor = false;
            this.examCreateExamButton.Click += new System.EventHandler(this.examCreateExamButton_Click);
            // 
            // examUploadMarkButton
            // 
            this.examUploadMarkButton.BackColor = System.Drawing.Color.Silver;
            this.examUploadMarkButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.examUploadMarkButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.examUploadMarkButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.examUploadMarkButton.Location = new System.Drawing.Point(706, 3);
            this.examUploadMarkButton.Name = "examUploadMarkButton";
            this.examUploadMarkButton.Size = new System.Drawing.Size(128, 31);
            this.examUploadMarkButton.TabIndex = 74;
            this.examUploadMarkButton.Text = "Upload Marks";
            this.examUploadMarkButton.UseVisualStyleBackColor = false;
            this.examUploadMarkButton.Click += new System.EventHandler(this.examUploadMarkButton_Click);
            // 
            // Teacher
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1260, 670);
            this.Controls.Add(this.examPanel);
            this.Controls.Add(this.studentPanel);
            this.Controls.Add(this.attendancePanel);
            this.Controls.Add(this.tileBarPanel);
            this.Controls.Add(this.menu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Teacher";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form2";
            this.menu.ResumeLayout(false);
            this.attendancePanel.ResumeLayout(false);
            this.attendanceStudentPanel.ResumeLayout(false);
            this.attendanceStudentPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.attendanceStudentDataGrid)).EndInit();
            this.studentPanel.ResumeLayout(false);
            this.studentPromotionPanel.ResumeLayout(false);
            this.studentPromotionPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.examUploadMarksPanel.ResumeLayout(false);
            this.examUploadMarksPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.tileBarPanel.ResumeLayout(false);
            this.examPanel.ResumeLayout(false);
            this.examCreateExamPanel.ResumeLayout(false);
            this.examCreateExamPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.examCreateExamDataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel menu;
        private System.Windows.Forms.Button attendanceMenuButton;
        private System.Windows.Forms.Panel attendancePanel;
        private System.Windows.Forms.Panel attendanceStudentPanel;
        private System.Windows.Forms.ComboBox attendanceStudentSectionComboBox;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.ComboBox attendanceStudentClassComboBox;
        private System.Windows.Forms.Button attendanceStudentSearchButton;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.DataGridView attendanceStudentDataGrid;
        private System.Windows.Forms.Button attendanceStudentButton;
        private System.Windows.Forms.Button studentMenuButton;
        private System.Windows.Forms.Panel studentPanel;
        private System.Windows.Forms.Panel studentPromotionPanel;
        private System.Windows.Forms.ComboBox studentPromotionClassUpdateComboBox;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.ComboBox studentPromotionClassComboBox;
        private System.Windows.Forms.Button studentPromotionSearchButton;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Button studentPromotionPromoteButton;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button studentPromotion;
        private System.Windows.Forms.Panel tileBarPanel;
        private System.Windows.Forms.Button crossButton;
        private System.Windows.Forms.Button examMenuButton;
        private System.Windows.Forms.Panel examPanel;
        private System.Windows.Forms.Panel examCreateExamPanel;
        private System.Windows.Forms.Button examCreateExamButton;
        private System.Windows.Forms.Button examUploadMarkButton;
        private System.Windows.Forms.Panel examUploadMarksPanel;
        private System.Windows.Forms.ComboBox examCreateExamClassNameComboBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox examCreateExamDepartmentComboBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox examCreateExamExamNameTextBox;
        private System.Windows.Forms.DateTimePicker examCreateExamDate;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox examCreateExamSectionComboBox;
        private System.Windows.Forms.DataGridView examCreateExamDataGridView;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button examCreateExamSubmitBotton;
        private System.Windows.Forms.Button examCreateExamUpdateButton;
        private System.Windows.Forms.Button examCreateExamDeleteButton;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button examUploadMarksSubmitButton;
        private System.Windows.Forms.TextBox examUploadMarksTextBox;

    }
}